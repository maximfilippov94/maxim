/* Раскрытие меню на узких экранах: морф гамбургера и выезжающая панель.
   Общий файл для публичных страниц — иначе на каждой новой странице
   меню на телефоне просто исчезает, как это и случилось. */
(function(){
  var b=document.getElementById('burger'),sheet=document.getElementById('sheetnav');
  if(!b||!sheet)return;
  function set(open){
    document.body.classList.toggle('nav-open',open);
    b.setAttribute('aria-expanded',open?'true':'false');
    document.body.style.overflow=open?'hidden':'';
  }
  b.addEventListener('click',function(){set(!document.body.classList.contains('nav-open'))});
  sheet.addEventListener('click',function(e){if(e.target.closest('a'))set(false)});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')set(false)});
})();
