/* EQUA service worker.
   Правило: данные API никогда не кэшируются, оболочка — сеть в приоритете,
   кэш только как офлайн-запас. Cache-first здесь ломал обновление данных. */
const CACHE = 'nutrimenu-v108';
/* Иконки держим в кэше: на «Домой» приложение запускается и без сети,
   и знак должен быть на месте. Экраны запуска не кэшируем — их читает
   сама iOS до старта страницы, service worker туда не достаёт. */
const ASSETS = ['/app/', '/app/style.css', '/app/ui.css', '/app/theme-dark.css',
                '/app/call.css', '/app/app-parity.css', '/app/fonts.css', '/app/app.js', '/manifest.json',
                /* Заголовочный шрифт: без него офлайн-запуск подставит
                   системный, и знакомый экран встретит чужой типографикой. */
                '/app/fonts/onest-700-cyrillic.woff2', '/app/fonts/onest-600-cyrillic.woff2',
                '/icon.svg', '/icon-192.png', '/icon-512.png', '/icon-180.png', '/icon-badge.png',
                /* Кадр с экрана входа: без него первый заход по плохой связи
                   показывает пустую тёмную полосу вместо шапки. */
                '/auth-leaves.jpg'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  // Ответы API — только из сети, иначе приложение показывает вчерашние данные.
  if (url.origin === location.origin && url.pathname.startsWith('/api/')) return;
  if (url.origin !== location.origin) return;

  e.respondWith(
    fetch(e.request)
      .then(r => {
        if (r.ok) { const cp = r.clone(); caches.open(CACHE).then(c => c.put(e.request, cp)); }
        return r;
      })
      /* Стили и скрипт приходят с отпечатком в адресе (?v=…): без ignoreSearch
         офлайн-запас по ним не находился бы до первого удачного захода. */
      .catch(() => caches.match(e.request, { ignoreSearch: true })
        .then(x => x || caches.match('/app/')))
  );
});

/* --- Push-уведомления ---
   Без этих двух обработчиков сервер отправляет уведомление, браузер его
   получает, а показать некому — оно молча пропадает. */
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) { d = { body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || 'EQUA', {
    body: d.body || '',
    /* Chrome на Android не рисует SVG в уведомлении — только растр.
       badge — монохромный силуэт: систему интересует форма, цвет она
       накладывает сама. */
    icon: '/icon-192.png',
    badge: '/icon-badge.png',
    tag: d.tag || 'nutrimenu',
    renotify: true,
    data: { url: d.url || '/app/' }
  }));
});

/* Нажатие на уведомление: если вкладка уже открыта — переводим её на нужный
   экран, а не плодим вторую копию приложения. */
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || '/app/';
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      for (const c of list) {
        if (c.url.includes('/app') && 'focus' in c) {
          if ('navigate' in c) c.navigate(url).catch(() => {});
          return c.focus();
        }
      }
      return self.clients.openWindow(url);
    })
  );
});
