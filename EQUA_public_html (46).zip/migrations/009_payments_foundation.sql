-- Фундамент под платежи: откуда пришёл клиент и почём работает специалист.
-- Денег здесь ещё нет — только данные, которые обязаны собираться заранее.

-- Атрибуция: пара «клиент + специалист». Пара, а не клиент, потому что
-- клиент может сменить специалиста, и источник у новой связи будет другой.
-- От source зависит ставка комиссии, и задним числом его не восстановить.
CREATE TABLE IF NOT EXISTS client_attribution(
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id     INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  source        TEXT NOT NULL,     -- catalog | invite | self | unknown
  lead_id       INTEGER REFERENCES catalog_leads(id),
  linked_at     TEXT NOT NULL,
  UNIQUE(client_id, specialist_id)
);
CREATE INDEX IF NOT EXISTS idx_attr_spec ON client_attribution(specialist_id, source);

-- Прайс специалиста. public_profiles.price остаётся витринной ценой «от»
-- для карточки в каталоге; платят по этой таблице.
CREATE TABLE IF NOT EXISTS specialist_services(
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  description   TEXT,
  kind          TEXT NOT NULL DEFAULT 'one_time',   -- one_time | subscription
  price_kop     INTEGER NOT NULL,
  period_days   INTEGER,
  is_active     INTEGER NOT NULL DEFAULT 1,
  sort_order    INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_services_spec ON specialist_services(specialist_id, is_active, sort_order);

-- Ставки комиссии. Одна строка: CHECK не даст завести вторую.
CREATE TABLE IF NOT EXISTS commission_settings(
  id                  INTEGER PRIMARY KEY CHECK(id = 1),
  rate_own            REAL NOT NULL DEFAULT 0.10,
  rate_catalog        REAL NOT NULL DEFAULT 0.25,
  catalog_period_days INTEGER NOT NULL DEFAULT 90,
  updated_at          TEXT
);
INSERT OR IGNORE INTO commission_settings(id,updated_at) VALUES(1,datetime('now'));

-- Уже существующие связи: источник неизвестен и восстановлению не подлежит.
-- Помечаем unknown — он считается «своим» клиентом и идёт по базовой ставке.
-- Брать повышенную комиссию за клиента, про которого мы не можем доказать,
-- что привели его сами, нечестно.
INSERT OR IGNORE INTO client_attribution(client_id,specialist_id,source,linked_at)
SELECT id, specialist_id, 'unknown', created_at
FROM clients WHERE specialist_id IS NOT NULL;
