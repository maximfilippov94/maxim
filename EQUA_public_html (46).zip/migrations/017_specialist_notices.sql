-- Уведомления, адресованные самому специалисту.
--
-- Таблица notifications привязана к client_id: она про события у клиентов
-- и специалисту показывается через JOIN. Решение по верификации, новый
-- отзыв или заявка из каталога ни к какому клиенту не относятся, и места
-- для них не было — специалист просто не узнавал о них.
--
-- Заодно чинится давняя мелочь: у специалиста колокольчик не гас никогда.
-- Отметка «прочитано» жила только у клиентских уведомлений, а гасить
-- чужие записи специалист не вправе. Теперь у него есть своя отметка
-- времени: всё, что старше её, считается просмотренным.

CREATE TABLE IF NOT EXISTS specialist_notices(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  type TEXT NOT NULL,          -- verification | review | lead
  title TEXT NOT NULL,
  body TEXT,
  read_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notices_specialist ON specialist_notices(specialist_id);
