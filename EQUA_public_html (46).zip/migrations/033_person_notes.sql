-- Заметки о человеке в панели.
--
-- Позвонили, договорились, пообещали вернуть деньги, пожаловались на
-- специалиста — всё это прежде оставалось в голове у владельца. Без
-- заметок панель остаётся списком пользователей: видно, кто есть, но не
-- видно, о чём с ним уже говорили. С появлением помощников это
-- становится обязательным — иначе двое пишут одному человеку одно и то
-- же по второму разу.
--
-- Имя автора храним снимком: сотрудник уйдёт, а заметка должна остаться
-- читаемой, как и запись в журнале.
CREATE TABLE IF NOT EXISTS person_notes(
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  target_type TEXT    NOT NULL,      -- specialist | client
  target_id   INTEGER NOT NULL,
  author_id   INTEGER,
  author_name TEXT,
  body        TEXT    NOT NULL,
  created_at  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notes_target ON person_notes(target_type, target_id, id DESC);
