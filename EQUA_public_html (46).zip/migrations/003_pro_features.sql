CREATE TABLE IF NOT EXISTS client_preferences (
  client_id INTEGER PRIMARY KEY REFERENCES clients(id) ON DELETE CASCADE,
  likes TEXT,
  dislikes TEXT,
  excluded TEXT,
  allowed_replacements INTEGER DEFAULT 1,
  notes TEXT,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS menu_item_replacements (
  menu_item_id INTEGER NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
  dish_id INTEGER NOT NULL REFERENCES dishes(id) ON DELETE CASCADE,
  sort_order INTEGER DEFAULT 0,
  PRIMARY KEY(menu_item_id,dish_id)
);
CREATE TABLE IF NOT EXISTS meal_log_feedback (
  menu_item_id INTEGER PRIMARY KEY REFERENCES menu_items(id) ON DELETE CASCADE,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  reason TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS progress_measurements (
  id INTEGER PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  measured_on TEXT NOT NULL,
  waist_cm REAL,
  hips_cm REAL,
  chest_cm REAL,
  note TEXT,
  UNIQUE(client_id,measured_on)
);
CREATE TABLE IF NOT EXISTS progress_photos (
  id INTEGER PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  photo_url TEXT NOT NULL,
  measured_on TEXT NOT NULL,
  note TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INTEGER PRIMARY KEY,
  user_type TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  device TEXT,
  created_at TEXT NOT NULL,
  last_used_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_push_user ON push_subscriptions(user_type,user_id);
CREATE TABLE IF NOT EXISTS notification_preferences (
  user_type TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  breakfast INTEGER DEFAULT 1,
  lunch INTEGER DEFAULT 1,
  dinner INTEGER DEFAULT 1,
  weight INTEGER DEFAULT 1,
  messages INTEGER DEFAULT 1,
  menu_updates INTEGER DEFAULT 1,
  meal_logs INTEGER DEFAULT 0,
  client_inactive INTEGER DEFAULT 1,
  quiet_start TEXT DEFAULT '22:00',
  quiet_end TEXT DEFAULT '08:00',
  PRIMARY KEY(user_type,user_id)
);
CREATE TABLE IF NOT EXISTS shopping_items (
  id INTEGER PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  menu_id INTEGER NOT NULL REFERENCES menus(id) ON DELETE CASCADE,
  ingredient_name TEXT NOT NULL,
  grams REAL NOT NULL,
  category TEXT,
  checked INTEGER DEFAULT 0,
  UNIQUE(client_id,menu_id,ingredient_name)
);
CREATE TABLE IF NOT EXISTS push_events (
  event_key TEXT PRIMARY KEY,
  created_at TEXT NOT NULL
);
