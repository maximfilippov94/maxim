-- Услуга, которую клиент выбрал у своего специалиста.
--
-- Оплаты пока нет: услуга активируется сразу, а paid остаётся нулём.
-- Когда появится приём платежей, активной будет считаться строка с
-- paid = 1, и менять придётся одно условие, а не всю схему.
--
-- Название, цена и период копируются в строку: специалист может
-- переименовать услугу или поменять прайс, а у клиента должно остаться
-- то, на что он согласился.
CREATE TABLE IF NOT EXISTS client_subscriptions(
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id     INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  service_id    INTEGER REFERENCES specialist_services(id),
  title         TEXT    NOT NULL,
  kind          TEXT    NOT NULL DEFAULT 'one_time',   -- one_time | subscription
  price_kop     INTEGER NOT NULL DEFAULT 0,
  period_days   INTEGER,
  status        TEXT    NOT NULL DEFAULT 'active',     -- active | expired | cancelled
  paid          INTEGER NOT NULL DEFAULT 0,
  started_at    TEXT    NOT NULL,
  expires_at    TEXT,                                   -- у разовой услуги пусто
  created_at    TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_csub_client ON client_subscriptions(client_id, status);
CREATE INDEX IF NOT EXISTS idx_csub_spec   ON client_subscriptions(specialist_id, status);
