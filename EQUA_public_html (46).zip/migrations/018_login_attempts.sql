-- Ограничение перебора пароля.
--
-- Восстановление пароля было защищено с самого начала, а вход — нет:
-- пароль можно было перебирать без ограничений. В базе особая категория
-- персональных данных, поэтому дыра маленькая по объёму кода и большая
-- по последствиям.
--
-- Считаем неудачные попытки отдельно по адресу и по IP. По адресу —
-- чтобы не подобрали пароль к конкретному человеку; по IP — чтобы не
-- перебирали адреса пачкой. Успешный вход стирает счётчик по адресу.

CREATE TABLE IF NOT EXISTS login_attempts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL,
  ip TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_attempts_email ON login_attempts(email, created_at);
CREATE INDEX IF NOT EXISTS idx_attempts_ip ON login_attempts(ip, created_at);
