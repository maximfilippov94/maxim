-- Журнал действий в панели владельца.
--
-- Панель распоряжается деньгами и доступом: блокировка закрывает
-- человеку вход, выплата отправляет деньги, замена каталога стирает
-- меню. До сих пор ни одно из этих действий не оставляло следа — через
-- месяц ответить «кто и когда заблокировал этого специалиста» было
-- нечем. С появлением помощников, у которых свой доступ, такой ответ
-- нужен постоянно.
--
-- Имя исполнителя храним снимком, а не ссылкой: сотрудник может уйти, а
-- запись о том, что сделал именно он, должна остаться читаемой.
CREATE TABLE IF NOT EXISTS admin_log(
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  actor_type  TEXT    NOT NULL,          -- admin | specialist
  actor_id    INTEGER,
  actor_name  TEXT,
  action      TEXT    NOT NULL,          -- block | unblock | verify | payout | delete | broadcast | ...
  target_type TEXT,                      -- specialist | client | dish | ingredient | post | payout | catalog
  target_id   INTEGER,
  target_name TEXT,
  note        TEXT,
  created_at  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_admin_log_time ON admin_log(id DESC);
CREATE INDEX IF NOT EXISTS idx_admin_log_target ON admin_log(target_type, target_id);
