-- Питьевой режим.
--
-- Одна строка на день: показатель дневной, а не журнал глотков — так
-- «Сегодня» читается одним значением, а история не разрастается.
-- Норма живёт в карточке клиента: она меняется вместе с весом и целью,
-- и специалист должен её видеть рядом с остальными назначениями.
CREATE TABLE IF NOT EXISTS water_logs(
  id INTEGER PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  logged_on TEXT NOT NULL,
  ml INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT,
  UNIQUE(client_id, logged_on)
);
CREATE INDEX IF NOT EXISTS idx_water_client ON water_logs(client_id, logged_on);
