-- Вход через Apple, Google и VK.
-- Учётка остаётся одна: внешний аккаунт привязывается к клиенту или
-- специалисту, а не заводит параллельного пользователя.
CREATE TABLE IF NOT EXISTS oauth_identities(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  provider TEXT NOT NULL,          -- apple | google | vk
  provider_uid TEXT NOT NULL,      -- идентификатор пользователя у провайдера
  user_type TEXT NOT NULL,         -- client | specialist
  user_id INTEGER NOT NULL,
  email TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(provider,provider_uid)
);
CREATE INDEX IF NOT EXISTS idx_oauth_user ON oauth_identities(user_type,user_id);

-- Незавершённые входы: state защищает от подделки ответа, verifier нужен
-- PKCE, target говорит, куда возвращать — в приложение или в браузер.
CREATE TABLE IF NOT EXISTS oauth_states(
  state TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  verifier TEXT NOT NULL,
  target TEXT NOT NULL,
  created_at TEXT NOT NULL
);
