/* Дневник продуктов.

   Раньше отметить можно было только блюдо из назначенного меню:
   в meal_logs стоит уникальный ключ по menu_item_id, и свёклы с
   греческим йогуртом в этой схеме не существовало. Человек ел не по
   меню, а в итоге дня этого не было — специалист видел «съедено 30%»
   и не понимал, почему вес стоит.

   Запись независима от меню: она привязана к дате и приёму пищи, а не
   к блюду. Съел вместо обеда — отмечает обед «не ел» и добавляет свой
   набор; съел сверх — просто добавляет. Меню при этом не трогается:
   соблюдение меню и съеденные калории — разные вопросы, и смешивать
   их нельзя, иначе съеденный торт поднимет соблюдение. */

CREATE TABLE IF NOT EXISTS food_entries(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  eaten_on TEXT NOT NULL,                 -- YYYY-MM-DD, день по часам клиента
  meal TEXT NOT NULL DEFAULT 'snack',     -- breakfast | lunch | dinner | snack
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT);
CREATE INDEX IF NOT EXISTS idx_food_entries_day ON food_entries(client_id, eaten_on);

/* КБЖУ храним в строке записи, а не берём из справочника при показе.
   Продукт могут поправить или убрать, а съеденное позавчера от этого
   измениться не должно: дневник — это история, а не ссылка на текущее
   состояние справочника. ingredient_id остаётся для «добавить ещё
   раз» и статистики, но ничего не решает. */
CREATE TABLE IF NOT EXISTS food_entry_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entry_id INTEGER NOT NULL REFERENCES food_entries(id) ON DELETE CASCADE,
  ingredient_id INTEGER REFERENCES ingredients(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  grams REAL NOT NULL,
  kcal REAL NOT NULL DEFAULT 0,
  protein REAL NOT NULL DEFAULT 0,
  fat REAL NOT NULL DEFAULT 0,
  carbs REAL NOT NULL DEFAULT 0,
  fiber REAL NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_food_items_entry ON food_entry_items(entry_id);

/* Часто едят одно и то же. Список «недавние» строится из истории, но
   отдельный индекс по паре «клиент + продукт» бережёт время на
   больших дневниках. */
CREATE INDEX IF NOT EXISTS idx_food_items_ing ON food_entry_items(ingredient_id);
