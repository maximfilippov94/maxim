CREATE TABLE IF NOT EXISTS catalog_leads(
  id INTEGER PRIMARY KEY,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  contact TEXT NOT NULL,
  message TEXT,
  read_at TEXT,
  created_at TEXT NOT NULL
);
