CREATE TABLE IF NOT EXISTS specialist_notes (
  id INTEGER PRIMARY KEY,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_notes_client ON specialist_notes(client_id, created_at DESC);

CREATE TABLE IF NOT EXISTS client_checkins (
  id INTEGER PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  week_start TEXT NOT NULL,
  ease_score INTEGER NOT NULL,
  wellbeing_score INTEGER,
  difficulties TEXT,
  comment TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(client_id, week_start)
);
CREATE INDEX IF NOT EXISTS idx_checkins_client ON client_checkins(client_id, week_start DESC);

CREATE TABLE IF NOT EXISTS home_products (
  id INTEGER PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  quantity TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(client_id, name)
);

CREATE TABLE IF NOT EXISTS dish_meta (
  dish_id INTEGER PRIMARY KEY REFERENCES dishes(id) ON DELETE CASCADE,
  cost_rub REAL,
  difficulty TEXT,
  office_friendly INTEGER DEFAULT 0,
  freezer_friendly INTEGER DEFAULT 0,
  restaurant_friendly INTEGER DEFAULT 0,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS nutrition_programs (
  id INTEGER PRIMARY KEY,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  goal TEXT,
  start_date TEXT NOT NULL,
  weeks_count INTEGER DEFAULT 12,
  status TEXT DEFAULT 'active',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_program_client ON nutrition_programs(client_id, start_date DESC);
