-- Журналы платежей и входящих уведомлений.
--
-- Ни то, ни другое пока не заполняется: эквайер не подключён. Заводим
-- заранее, потому что обе таблицы нужны не для удобства, а чтобы
-- интеграция вообще была возможна.

-- Что происходило с деньгами по покупке на стороне эквайера.
--
-- Это не дубль client_subscriptions: там наша покупка, здесь его платёж.
-- Одной покупке может соответствовать несколько платежей — неудавшаяся
-- попытка, повторная, возврат, — и без отдельной записи разобраться,
-- почему деньги не пришли, будет не по чему.
CREATE TABLE IF NOT EXISTS payments(
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  sub_id              INTEGER NOT NULL REFERENCES client_subscriptions(id) ON DELETE CASCADE,
  provider            TEXT    NOT NULL,          -- stub | yookassa | tbank
  provider_payment_id TEXT,
  amount_kop          INTEGER NOT NULL,
  -- pending — ждём оплаты, held — деньги удержаны у эквайера,
  -- succeeded — сделка закрыта и выплачена, canceled, refunded
  status              TEXT    NOT NULL DEFAULT 'pending',
  paid_at             TEXT,
  raw                 TEXT,                      -- ответ провайдера как есть
  created_at          TEXT    NOT NULL,
  updated_at          TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_payments_sub ON payments(sub_id, id DESC);
-- Один платёж эквайера — одна наша запись: повторный ответ не заведёт вторую.
CREATE UNIQUE INDEX IF NOT EXISTS idx_payments_provider
  ON payments(provider, provider_payment_id) WHERE provider_payment_id IS NOT NULL;

-- Входящие уведомления эквайера.
--
-- Вебхуки приходят повторно — это норма, а не сбой. Уникальный ключ по
-- идентификатору события и есть защита: второй раз то же уведомление
-- просто не вставится, и заморозка не задвоится.
CREATE TABLE IF NOT EXISTS webhooks(
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  provider     TEXT    NOT NULL,
  event_id     TEXT,
  event_type   TEXT,
  body         TEXT    NOT NULL,
  status       TEXT    NOT NULL DEFAULT 'received',  -- received | processed | ignored | failed
  error        TEXT,
  received_at  TEXT    NOT NULL,
  processed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_webhooks_new ON webhooks(status, id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_webhooks_event
  ON webhooks(provider, event_id) WHERE event_id IS NOT NULL;
