-- Отзывы о специалисте.
--
-- До этого рейтинг и число отзывов лежали в public_profiles как числа,
-- которые никто никогда не пересчитывал: они попадали туда при установке
-- и оставались навсегда. Рядом с отметкой «Проверен» такая витрина
-- обесценивает и саму проверку, поэтому теперь рейтинг выводится из
-- настоящих отзывов, а пустой рейтинг честно показывается пустым.
--
-- Отзыв может оставить только клиент, которого ведёт этот специалист,
-- и только один: иначе это не отзыв, а голосование.

CREATE TABLE IF NOT EXISTS specialist_reviews(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL,                  -- 1..5
  body TEXT,
  -- Скрыть отзыв может только владелец сервиса и только за брань или
  -- личные данные. Специалист своим отзывам не хозяин — в этом смысл.
  status TEXT NOT NULL DEFAULT 'published', -- published | hidden
  hidden_reason TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT,
  UNIQUE(specialist_id, client_id)
);
CREATE INDEX IF NOT EXISTS idx_reviews_specialist ON specialist_reviews(specialist_id, status);

-- Разовая уборка для баз, которые уже работают: рейтинг без единого
-- отзыва — выдумка, снимаем. Условие идемпотентно и не мешает
-- refreshRating(): оба приводят рейтинг к одному и тому же значению.
UPDATE public_profiles SET rating=NULL, reviews_count=0
 WHERE NOT EXISTS(
   SELECT 1 FROM specialist_reviews r
    WHERE r.specialist_id=public_profiles.specialist_id AND r.status='published');
