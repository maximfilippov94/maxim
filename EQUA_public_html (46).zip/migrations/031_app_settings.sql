-- Общие настройки приложения парами «ключ — значение».
-- Понадобились для ключей VAPID: на части хостингов каталог storage
-- закрыт на запись, и ключи было негде хранить, а без них браузер не
-- подписывается на уведомления.
CREATE TABLE IF NOT EXISTS app_settings(
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT
);
