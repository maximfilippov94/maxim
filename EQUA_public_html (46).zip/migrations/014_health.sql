-- Здоровье клиента: аллергии, препараты и БАДы, анализы, рекомендации.
--
-- Это специальная категория персональных данных: доступ есть только
-- у самого клиента и у его специалиста, и записи уходят вместе с
-- аккаунтом (ON DELETE CASCADE).

-- Аллергии и непереносимости. Отдельно от excluded_ingredients:
-- то — вкусовые исключения, здесь — то, что нельзя по здоровью.
CREATE TABLE IF NOT EXISTS client_allergies(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'allergy',   -- allergy | intolerance | avoid
  note TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_allergies_client ON client_allergies(client_id);

-- Препараты, БАДы и витамины одной таблицей: различает поле kind,
-- а поля у них одинаковые — что, сколько, когда и до каких пор.
CREATE TABLE IF NOT EXISTS client_meds(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'supplement', -- medicine | supplement | vitamin
  title TEXT NOT NULL,
  dosage TEXT,                             -- «1000 МЕ», «2 капсулы»
  schedule TEXT,                           -- «утром натощак»
  started_on TEXT,
  ended_on TEXT,                           -- пусто — принимает сейчас
  note TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_meds_client ON client_meds(client_id);

-- Анализы храним файлом с датой сдачи. Показатели по строкам не
-- разбираем намеренно: ошибка в распознанной цифре опаснее, чем её
-- отсутствие, а решение по анализам принимает человек.
CREATE TABLE IF NOT EXISTS client_labs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  taken_on TEXT,
  file_url TEXT,
  note TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_labs_client ON client_labs(client_id);

-- История рекомендаций: то, что специалист сказал и когда. В отличие
-- от specialist_notes это видит и клиент.
CREATE TABLE IF NOT EXISTS client_recommendations(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  specialist_id INTEGER,
  body TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_recs_client ON client_recommendations(client_id);
