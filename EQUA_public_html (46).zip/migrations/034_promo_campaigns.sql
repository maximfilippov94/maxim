-- Промокоды и отложенные рассылки.
--
-- Промокод в комиссионной модели — это скидка клиенту на услугу
-- специалиста, и главный вопрос в ней: за чей счёт. Поэтому источник
-- скидки хранится явно: «service» — платит сервис из своей комиссии,
-- «specialist» — платит специалист из своей доли. Молча размазать
-- скидку между обоими нельзя: это чужие деньги.
CREATE TABLE IF NOT EXISTS promo_codes(
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  code          TEXT NOT NULL UNIQUE,
  percent       INTEGER NOT NULL,          -- размер скидки, %
  payer         TEXT NOT NULL DEFAULT 'service',  -- service | specialist
  specialist_id INTEGER,                   -- пусто = действует у всех
  max_uses      INTEGER,                   -- пусто = без ограничения
  uses          INTEGER NOT NULL DEFAULT 0,
  expires_at    TEXT,
  status        TEXT NOT NULL DEFAULT 'active',   -- active | off
  note          TEXT,
  created_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_promo_code ON promo_codes(code);

-- Кто и когда воспользовался: без этого нельзя ни посчитать расход на
-- скидки, ни разобрать спор «я вводил, а не сработало».
CREATE TABLE IF NOT EXISTS promo_uses(
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  promo_id   INTEGER NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
  client_id  INTEGER,
  sub_id     INTEGER,
  amount_kop INTEGER NOT NULL DEFAULT 0,
  used_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_promo_uses ON promo_uses(promo_id, id DESC);
