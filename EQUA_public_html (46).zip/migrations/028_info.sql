-- EQUA info: рассказ о сервисе и его обновлениях.
--
-- Это не лента и не рассылка. Лента — про клиентов и их успехи,
-- рассылка уходит разово и исчезает. Здесь то, что должно лежать на
-- месте и читаться когда угодно: что за сервис, как он устроен, что в
-- нём появилось за последние месяцы.
CREATE TABLE IF NOT EXISTS info_posts(
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  kind         TEXT    NOT NULL DEFAULT 'update',   -- about | update
  title        TEXT    NOT NULL,
  body         TEXT    NOT NULL,
  -- Кому показывать: всем или только одной стороне. У специалистов свои
  -- новости (комиссия, выплаты), у клиентов — свои.
  audience     TEXT    NOT NULL DEFAULT 'all',      -- all | client | specialist
  is_published INTEGER NOT NULL DEFAULT 1,
  sort_order   INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT    NOT NULL,
  updated_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_info_pub ON info_posts(is_published, kind, sort_order, id DESC);
