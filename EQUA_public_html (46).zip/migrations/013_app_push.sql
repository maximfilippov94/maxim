-- Push в мобильном приложении.
-- Подписки браузера и приложения лежат в одной таблице: у браузера это
-- адрес с ключами VAPID, у приложения — токен службы Expo. Различает их
-- столбец platform; для старых баз он добавляется отдельной проверкой
-- в config.php, потому что ALTER TABLE выполнить повторно нельзя.
-- Там же заводится индекс по platform: до появления столбца его нет.
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INTEGER PRIMARY KEY,
  user_type TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  device TEXT,
  platform TEXT DEFAULT 'web',   -- web | expo
  created_at TEXT NOT NULL,
  last_used_at TEXT
);
