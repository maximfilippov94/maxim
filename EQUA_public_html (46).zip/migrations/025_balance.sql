-- Баланс специалиста: заморожено и доступно.
--
-- Денег на нашем счету нет и не будет: они лежат у эквайера, а здесь —
-- только учёт, кому и сколько причитается. Поэтому баланс не колонка,
-- которую можно молча испортить, а сумма движений: каждая строка ниже
-- объясняет сама себя, и выписка специалисту — это она же.
--
-- У движения два столбца со знаком, а не один с пометкой «куда»:
-- разморозка — это одно событие, которое убавляет замороженное и
-- прибавляет доступное. Двумя строками пришлось бы следить, чтобы они
-- не разъехались.
CREATE TABLE IF NOT EXISTS balance_entries(
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  sub_id        INTEGER REFERENCES client_subscriptions(id) ON DELETE SET NULL,
  payout_id     INTEGER,
  kind          TEXT    NOT NULL,          -- hold | release | refund | payout | payout_back
  held_kop      INTEGER NOT NULL DEFAULT 0,
  avail_kop     INTEGER NOT NULL DEFAULT 0,
  -- Номер разморозенного дня подписки. Он же защита от двойного
  -- начисления: см. уникальный индекс ниже.
  day_no        INTEGER,
  note          TEXT,
  occurred_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bal_spec ON balance_entries(specialist_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_bal_sub  ON balance_entries(sub_id, kind);
-- Начисление за один и тот же день подписки не пройдёт дважды, даже если
-- два запроса взялись за него одновременно.
CREATE UNIQUE INDEX IF NOT EXISTS idx_bal_day
  ON balance_entries(sub_id, day_no) WHERE day_no IS NOT NULL;

-- Реквизиты для вывода. Одна строка на специалиста: счёт у человека один,
-- а история переводов хранится снимками в заявках.
CREATE TABLE IF NOT EXISTS payout_details(
  specialist_id INTEGER PRIMARY KEY REFERENCES specialists(id) ON DELETE CASCADE,
  legal_type    TEXT NOT NULL DEFAULT 'self_employed',  -- self_employed | ip | individual
  full_name     TEXT NOT NULL,
  inn           TEXT,
  account       TEXT NOT NULL,
  bank          TEXT,
  agreement_accepted_at TEXT,
  updated_at    TEXT NOT NULL
);

-- Заявка на вывод. Реквизиты копируются снимком: специалист может сменить
-- карту на следующий день, а перевести нужно туда, куда он просил.
CREATE TABLE IF NOT EXISTS payout_requests(
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  amount_kop    INTEGER NOT NULL,
  status        TEXT    NOT NULL DEFAULT 'pending',   -- pending | paid | rejected
  details_json  TEXT    NOT NULL,
  note          TEXT,
  created_at    TEXT    NOT NULL,
  decided_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_payout_spec ON payout_requests(specialist_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_payout_open ON payout_requests(status, id);

-- Какие покупки вошли в заявку на вывод.
--
-- Эквайер закрывает не «сумму», а конкретные сделки: чтобы перевести
-- специалисту 5 400 ₽, нужно знать, из каких покупок они сложились.
-- Составной первичный ключ — защита от двойной выплаты по одной сделке:
-- второй раз строка просто не вставится.
CREATE TABLE IF NOT EXISTS payout_orders(
  payout_id  INTEGER NOT NULL REFERENCES payout_requests(id) ON DELETE CASCADE,
  sub_id     INTEGER NOT NULL REFERENCES client_subscriptions(id) ON DELETE CASCADE,
  amount_kop INTEGER NOT NULL,
  PRIMARY KEY(payout_id, sub_id)
);
CREATE INDEX IF NOT EXISTS idx_payout_orders_sub ON payout_orders(sub_id);
