CREATE TABLE IF NOT EXISTS posts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author_type TEXT NOT NULL,
  author_id INTEGER NOT NULL,
  text TEXT,
  photo_url TEXT,
  status TEXT NOT NULL DEFAULT 'visible',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_posts_created ON posts(status, id DESC);
CREATE TABLE IF NOT EXISTS post_likes(
  post_id INTEGER NOT NULL,
  user_type TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(post_id, user_type, user_id)
);
