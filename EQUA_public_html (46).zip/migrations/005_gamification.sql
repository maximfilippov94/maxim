CREATE TABLE IF NOT EXISTS point_redemptions(
  id INTEGER PRIMARY KEY,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  reward_key TEXT NOT NULL,
  points_cost INTEGER NOT NULL,
  discount_pct INTEGER NOT NULL,
  code TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  created_at TEXT NOT NULL
);
