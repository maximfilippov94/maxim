-- Восстановление пароля по почте.
-- Храним не сам код из письма, а его хеш: если база утечёт, по ней
-- нельзя будет зайти в чужой аккаунт. Ссылка живёт час и работает раз.
CREATE TABLE IF NOT EXISTS password_resets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token_hash TEXT NOT NULL UNIQUE,
  user_type TEXT NOT NULL,          -- client | specialist | admin
  user_id INTEGER NOT NULL,
  email TEXT NOT NULL,
  requested_ip TEXT,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_reset_user ON password_resets(user_type,user_id);
CREATE INDEX IF NOT EXISTS idx_reset_created ON password_resets(created_at);
