-- Верификация специалиста: подтверждение образования и курсов.
--
-- Диплом — такой же личный документ, как анализы клиента: имя файла
-- случайное, отдача идёт через маршрут с проверкой прав, кэш запрещён.
-- Видеть документ может только сам специалист и владелец сервиса;
-- клиенту в каталог уходит один флаг «проверен» и список названий,
-- но не файлы.

CREATE TABLE IF NOT EXISTS specialist_documents(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  kind TEXT NOT NULL DEFAULT 'diploma',   -- diploma | course | certificate | license
  title TEXT NOT NULL,                    -- «Нутрициология, РНИМУ им. Пирогова»
  issuer TEXT,                            -- кто выдал
  issued_on TEXT,                         -- год или дата выдачи
  file_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  review_note TEXT,                       -- причина отказа, её видит специалист
  reviewed_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_docs_specialist ON specialist_documents(specialist_id);
CREATE INDEX IF NOT EXISTS idx_docs_status ON specialist_documents(status);
