CREATE TABLE IF NOT EXISTS client_onboarding (
  client_id INTEGER PRIMARY KEY REFERENCES clients(id) ON DELETE CASCADE,
  answers_json TEXT NOT NULL,
  completed_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_client_onboarding_completed ON client_onboarding(completed_at);
