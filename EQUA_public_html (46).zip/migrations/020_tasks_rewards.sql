-- Задания от специалиста и привилегии за баллы.
--
-- До этого «задания» были зашиты в код: отметить приёмы пищи и записать
-- вес. Это не задания специалиста, а правила сервиса — личное задание
-- («сдать анализы», «пройти 8000 шагов», «приготовить по рецепту и
-- прислать фото») поставить было нечем.
--
-- Награды были такой же выдумкой: «−10% на подписку» при том, что
-- никакой подписки в сервисе нет. Теперь привилегии задаёт тот, кто
-- их и будет выдавать — сам специалист.

CREATE TABLE IF NOT EXISTS client_tasks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  specialist_id INTEGER REFERENCES specialists(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  note TEXT,
  -- photo — задание с фотоотчётом: без снимка его не закрыть
  kind TEXT NOT NULL DEFAULT 'simple',   -- simple | photo
  points INTEGER NOT NULL DEFAULT 20,
  due_on TEXT,
  status TEXT NOT NULL DEFAULT 'open',   -- open | done | cancelled
  photo_url TEXT,
  comment TEXT,                          -- что клиент написал, закрывая
  done_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_client ON client_tasks(client_id, status);

-- Привилегии специалиста: за что он готов принимать баллы.
-- Никаких скидок на несуществующую подписку — что написал, то и даёт.
CREATE TABLE IF NOT EXISTS specialist_rewards(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  note TEXT,
  cost INTEGER NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rewards_specialist ON specialist_rewards(specialist_id, is_active);
