-- Рассылки владельца и обращения в техподдержку.

-- Что и кому уже отправлено. Нужно не для отчётности, а чтобы не
-- отправить одно и то же дважды: рассылка расходится по почте, и
-- отменить её нельзя — только не повторить.
CREATE TABLE IF NOT EXISTS broadcasts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  audience TEXT NOT NULL,        -- specialists | clients | all
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  by_email INTEGER NOT NULL DEFAULT 1,
  recipients INTEGER NOT NULL DEFAULT 0,
  emails_sent INTEGER NOT NULL DEFAULT 0,
  emails_failed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

-- Обращение в поддержку. Пишут и клиенты, и специалисты, поэтому автор
-- задан парой тип+id, как в ленте и лайках, а не двумя пустующими
-- столбцами.
--
-- last_reply_at ведём отдельно от created_at: очередь у владельца
-- сортируется по последнему сообщению, иначе давнее обращение с новым
-- ответом клиента утонет под свежими.
CREATE TABLE IF NOT EXISTS support_tickets(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  author_type TEXT NOT NULL,     -- client | specialist
  author_id INTEGER NOT NULL,
  topic TEXT NOT NULL,           -- account | menu | payment | bug | other
  subject TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'new',   -- new | in_progress | closed
  created_at TEXT NOT NULL,
  last_reply_at TEXT NOT NULL,
  closed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tickets_queue ON support_tickets(status,last_reply_at);
CREATE INDEX IF NOT EXISTS idx_tickets_author ON support_tickets(author_type,author_id);

-- Сообщения обращения. Владелец отвечает здесь же, отдельной таблицы
-- для ответов нет: переписка одна, и читается она подряд.
CREATE TABLE IF NOT EXISTS support_messages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  from_admin INTEGER NOT NULL DEFAULT 0,
  body TEXT NOT NULL,
  read_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ticket_msgs ON support_messages(ticket_id,id);
