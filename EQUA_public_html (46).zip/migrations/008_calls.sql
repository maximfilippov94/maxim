-- Видеозвонки в чате: сессии звонков и WebRTC-сигналинг.
-- Медиа идут напрямую между браузерами; сервер хранит только SDP/ICE на время дозвона.
CREATE TABLE IF NOT EXISTS calls(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  specialist_id INTEGER REFERENCES specialists(id) ON DELETE CASCADE,
  caller_type TEXT NOT NULL,                 -- client | specialist
  status TEXT NOT NULL DEFAULT 'ringing',    -- ringing | active | ended | declined | missed
  end_reason TEXT,                           -- hangup | declined | timeout | failed
  started_at TEXT,                           -- момент, когда вызов приняли
  ended_at TEXT,
  duration_sec INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_calls_client ON calls(client_id,status);
CREATE INDEX IF NOT EXISTS idx_calls_spec ON calls(specialist_id,status);

CREATE TABLE IF NOT EXISTS call_signals(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  call_id INTEGER NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  from_type TEXT NOT NULL,                   -- client | specialist
  kind TEXT NOT NULL,                        -- offer | answer | ice
  payload TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_signals_call ON call_signals(call_id,id);
