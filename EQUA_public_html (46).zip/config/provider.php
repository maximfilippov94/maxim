<?php
/**
 * Платёжный провайдер: четыре операции, которые нужны платформе.
 *
 * Смысл этого файла — чтобы подключение банка было одним новым классом,
 * а не переделкой учёта. Учёт (кто кому сколько должен) живёт у нас и от
 * банка не зависит: банк умеет только удержать деньги, отдать их
 * получателю и вернуть плательщику.
 *
 * Конкретной интеграции здесь нет намеренно. Её нельзя написать вслепую:
 * у «Безопасной сделки» ЮKassa и «Мультирасчётов» Т-Банка половина
 * условий выясняется в переписке с менеджером, а проверить код без
 * тестового магазина всё равно невозможно. Поэтому пока работает
 * заглушка, а настоящий класс добавится рядом.
 *
 * Ключи провайдера кладутся в config/payments.php — он, как и
 * config/mail.php, содержит секреты и в поставку не входит:
 *
 *   <?php
 *   return ['provider'=>'yookassa','shop_id'=>'…','secret_key'=>'…'];
 */
declare(strict_types=1);

interface PaymentProvider {
  /** Короткое имя, оно же пишется в журналы. */
  public function name():string;

  /**
   * Открыть сделку: клиент платит, деньги удерживаются у эквайера.
   *
   * @param array $sub   строка client_subscriptions
   * @param array $payer ['email'=>…, 'name'=>…] — для чека и уведомлений
   * @return array ['payment_id'=>string, 'confirmation_url'=>?string, 'raw'=>array]
   */
  public function openDeal(array $sub,array $payer):array;

  /**
   * Разобрать входящее уведомление.
   *
   * Возвращает null, если это не наше событие или подпись не сошлась —
   * тогда уведомление помечается в журнале как проигнорированное, но не
   * теряется: разбирать потом будет по чему.
   *
   * @return array|null ['event_id'=>?string,'type'=>string,'payment_id'=>?string,
   *                     'status'=>'held'|'succeeded'|'canceled'|'refunded']
   */
  public function parseWebhook(string $body,array $headers):?array;

  /**
   * Закрыть сделки и перевести деньги получателю.
   *
   * Эквайер закрывает не «сумму», а конкретные сделки, поэтому вторым
   * параметром идёт их список: [['sub_id'=>…,'provider_deal_id'=>…,'amount_kop'=>…], …]
   *
   * @param array $payout строка payout_requests
   * @param array $details реквизиты получателя
   * @return array ['payout_id'=>string,'raw'=>array]
   */
  public function settle(array $payout,array $items,array $details):array;

  /** Вернуть деньги плательщику — целиком или часть. */
  public function refund(array $payment,int $amountKop):array;
}

/**
 * Заглушка. Ничего никуда не отправляет и честно об этом говорит.
 *
 * Нужна не для вида: с ней весь учёт — заморозка, приёмка, споры,
 * заявки — работает и проверяется целиком, и к моменту, когда появятся
 * ключи, останется написать только обмен по сети.
 */
final class StubProvider implements PaymentProvider {
  public function name():string{ return 'stub'; }

  public function openDeal(array $sub,array $payer):array{
    return ['payment_id'=>'stub-'.bin2hex(random_bytes(8)),
            'confirmation_url'=>null,
            'raw'=>['note'=>'Приём платежей не подключён: сделка не создавалась']];
  }

  public function parseWebhook(string $body,array $headers):?array{ return null; }

  public function settle(array $payout,array $items,array $details):array{
    return ['payout_id'=>'stub-payout-'.bin2hex(random_bytes(6)),
            'raw'=>['note'=>'Перевод не выполнялся: приём платежей не подключён',
                    'deals'=>count($items)]];
  }

  public function refund(array $payment,int $amountKop):array{
    return ['raw'=>['note'=>'Возврат не выполнялся: приём платежей не подключён']];
  }
}

/** Настройки провайдера. Файла нет — значит работает заглушка. */
function paymentConfig():array{
  static $cfg;
  if($cfg===null){
    $f=__DIR__.'/payments.php';
    $cfg=is_file($f) ? (array)require $f : [];
  }
  return $cfg;
}

/**
 * Текущий провайдер.
 *
 * Имя берётся из config/payments.php. Неизвестное имя — это заглушка, а
 * не исключение: лучше молчащий приём платежей, чем упавший сайт.
 */
function paymentProvider():PaymentProvider{
  static $p;
  if($p)return $p;
  $name=(string)(paymentConfig()['provider']??'stub');
  $class=['stub'=>StubProvider::class][$name]??null;
  if($class===null){
    error_log('Неизвестный платёжный провайдер: '.$name.' — работает заглушка');
    $class=StubProvider::class;
  }
  return $p=new $class();
}
