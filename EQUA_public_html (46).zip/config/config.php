<?php
declare(strict_types=1);
const DB_PATH = __DIR__.'/../storage/nutrimenu.sqlite';
const SESSION_DAYS = 30;
const APP_NAME = 'EQUA';
const APP_URL = '';
/* --- Владелец сервиса: ИЗМЕНИТЕ ДО ЗАГРУЗКИ НА ХОСТИНГ --- */
const OWNER_EMAIL = 'owner@nutrimenu.local';
const OWNER_PASSWORD = 'change-me-8';

/* --- Видеозвонки (WebRTC) ---
   STUN нужен всегда, он бесплатный и публичный.
   TURN нужен для тех ~10-20% звонков, где прямое соединение не поднимается
   (мобильный интернет за CGNAT, корпоративный Wi-Fi). Без TURN такие звонки
   просто не соединятся. Подробности и варианты — в INSTALL.md.
   Оставьте TURN_URL пустым, если TURN пока нет. */
const STUN_SERVERS = ['stun:stun.l.google.com:19302','stun:stun1.l.google.com:19302'];
const TURN_URL  = '';   // напр. 'turn:turn.example.com:3478' или 'turns:turn.example.com:5349'
const TURN_USER = '';
const TURN_PASS = '';
/* Сколько секунд звонит вызов, прежде чем стать пропущенным */
const CALL_RING_SECONDS = 45;
function db(): PDO { static $pdo; if(!$pdo){$dir=dirname(DB_PATH);if(!is_dir($dir))mkdir($dir,0775,true);$pdo=new PDO('sqlite:'.DB_PATH,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);$pdo->exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  /* LOWER() в SQLite понижает только латиницу: «Мария» так и остаётся
     «Мария», и поиск по «мария» ничего не находит. Своя функция свёртки
     решает это для всей базы сразу — и заодно приравнивает «ё» к «е»,
     иначе «Алёна» не ищется по «алена». */
  $pdo->sqliteCreateFunction('fold', 'foodFold', 1);
  } return $pdo; }
function now():string{return gmdate('Y-m-d H:i:s');}
function input():array{$j=json_decode(file_get_contents('php://input')?:'[]',true);return is_array($j)?$j:$_POST;}
function json_response($data,int $status=200):never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function token(int $bytes=32):string{return bin2hex(random_bytes($bytes));}
function saveAvatar():string{ if(empty($_FILES['photo'])||$_FILES['photo']['error']!==UPLOAD_ERR_OK)json_response(['error'=>'Фото не загружено'],422);$f=$_FILES['photo'];if($f['size']>6*1024*1024)json_response(['error'=>'Фото больше 6 МБ'],422);$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];if(!isset($allowed[$mime]))json_response(['error'=>'Разрешены JPG, PNG, WEBP'],422);$dir=__DIR__.'/../storage/uploads';if(!is_dir($dir))mkdir($dir,0775,true);
  /* Снимок с телефона — 3–5 МБ, а показывается он в лучшем случае на
     1100 точек. Ужимаем при загрузке: один раз здесь вместо каждого
     показа у каждого зрителя. Не вышло (нет GD, битый файл) — кладём
     как есть: отказать в загрузке из-за размера хуже, чем принять
     тяжёлое. */
  $name='av_'.bin2hex(random_bytes(10)).'.jpg';
  if(shrinkImage($f['tmp_name'],$dir.'/'.$name,1100,82)) { @unlink($f['tmp_name']); return '/api/v1/avatar/'.$name; }
  $name='av_'.bin2hex(random_bytes(10)).'.'.$allowed[$mime];
  move_uploaded_file($f['tmp_name'],$dir.'/'.$name);return '/api/v1/avatar/'.$name; }
/* Вложение в переписке: кроме снимков сюда приходят видео с телефона и
   голосовые. Тип проверяем по содержимому файла, а не по имени: имя
   присылает клиент, и доверять ему нельзя. */
function saveAttachment():string{ if(empty($_FILES['file'])||$_FILES['file']['error']!==UPLOAD_ERR_OK)json_response(['error'=>'Файл не загружен'],422);$f=$_FILES['file'];if($f['size']>25*1024*1024)json_response(['error'=>'Файл больше 25 МБ'],422);$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','video/mp4'=>'mp4','video/quicktime'=>'mov','audio/mp4'=>'m4a','audio/x-m4a'=>'m4a','audio/mpeg'=>'mp3','audio/aac'=>'aac','audio/webm'=>'webm','video/webm'=>'webm','audio/ogg'=>'ogg'];if(!isset($allowed[$mime]))json_response(['error'=>'Разрешены фото, видео MP4/MOV и голосовые'],422);/* Контейнер без звука весит сотни байт: такое голосовое показывает 0:00 и молчит. Лучше отказать, чем повесить в переписке пустой кружок. */if(str_starts_with($mime,'audio/')&&$f['size']<1024)json_response(['error'=>'Запись слишком короткая'],422);$dir=__DIR__.'/../storage/uploads';if(!is_dir($dir))mkdir($dir,0775,true);
  $ext=$allowed[$mime];
  /* Запись без видеодорожки лежит в том же контейнере, что и ролик с
     камеры: mp4 остаётся mp4, а webm определяется как video/webm. По
     расширению переписка потом не отличит голосовое от видео и покажет
     чёрный прямоугольник плеера. Отправитель помечает запись полем
     voice — тогда контейнер получает звуковое расширение. */
  if(!empty($_POST['voice'])){ if($ext==='mp4')$ext='m4a'; }
  $name='at_'.bin2hex(random_bytes(10)).'.'.$ext;move_uploaded_file($f['tmp_name'],$dir.'/'.$name);return '/api/v1/avatar/'.$name; }
/* Файл анализа: кроме снимка сюда приходит PDF из лаборатории. Тип
   проверяем по содержимому, а не по имени. Имя на диске случайное:
   по ссылке из чужой переписки файл не подберёшь. */
function saveLabFile():?string{
  if(empty($_FILES['file'])||$_FILES['file']['error']===UPLOAD_ERR_NO_FILE)return null;
  if($_FILES['file']['error']!==UPLOAD_ERR_OK)json_response(['error'=>'Файл не загружен'],422);
  $f=$_FILES['file'];
  if($f['size']>15*1024*1024)json_response(['error'=>'Файл больше 15 МБ'],422);
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  $allowed=['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
  if(!isset($allowed[$mime]))json_response(['error'=>'Разрешены PDF, JPG, PNG'],422);
  $dir=__DIR__.'/../storage/uploads';if(!is_dir($dir))mkdir($dir,0775,true);
  $name='lab_'.bin2hex(random_bytes(16)).'.'.$allowed[$mime];
  move_uploaded_file($f['tmp_name'],$dir.'/'.$name);
  return '/api/v1/labs/file/'.$name;
}

/* ======================================================================
   Перебор пароля.
   Порог по адресу ниже, чем по IP: за одним внешним адресом может сидеть
   целый офис, и блокировать его из-за одного забывчивого человека нельзя.
   Считаем только неудачные попытки; удачный вход счётчик по адресу
   стирает.
   ====================================================================== */
const LOGIN_MAX_EMAIL = 8;      // неудач по одному адресу
const LOGIN_MAX_IP    = 40;     // неудач с одного IP
const LOGIN_WINDOW    = 900;    // за 15 минут

function loginBlocked(string $email,string $ip):int{
  $pdo=db();
  $since=gmdate('Y-m-d H:i:s',time()-LOGIN_WINDOW);
  $pdo->prepare('DELETE FROM login_attempts WHERE created_at<?')
      ->execute([gmdate('Y-m-d H:i:s',time()-LOGIN_WINDOW*4)]);

  $q=$pdo->prepare('SELECT COUNT(*), MAX(created_at) FROM login_attempts WHERE email=? AND created_at>?');
  $q->execute([$email,$since]); [$ne,$le]=$q->fetch(PDO::FETCH_NUM);
  $q=$pdo->prepare('SELECT COUNT(*), MAX(created_at) FROM login_attempts WHERE ip=? AND created_at>?');
  $q->execute([$ip,$since]); [$ni,$li]=$q->fetch(PDO::FETCH_NUM);

  $hit=null;
  if((int)$ne>=LOGIN_MAX_EMAIL)$hit=$le;
  if((int)$ni>=LOGIN_MAX_IP && (!$hit || $li>$hit))$hit=$li;
  if(!$hit)return 0;
  /* Ждать нужно от последней попытки, иначе перебор просто продолжат
     через секунду после истечения окна. */
  return max(1,LOGIN_WINDOW-(time()-strtotime((string)$hit.' UTC')));
}
function loginFailed(string $email,string $ip):void{
  db()->prepare('INSERT INTO login_attempts(email,ip,created_at) VALUES(?,?,?)')
      ->execute([$email,$ip,now()]);
}
function loginOk(string $email):void{
  db()->prepare('DELETE FROM login_attempts WHERE email=?')->execute([$email]);
}
/** «через 4 минуты» — человеку нужен срок, а не число секунд. */
function waitWord(int $sec):string{
  $m=(int)ceil($sec/60);
  if($m<=1)return 'через минуту';
  $a=$m%100;$b=$a%10;
  $w=($a>4&&$a<21)?'минут':($b===1?'минуту':(($b>1&&$b<5)?'минуты':'минут'));
  return "через $m $w";
}

/* ======================================================================
   Уведомления самому специалисту.
   Отдельно от notifications: та таблица про события у клиентов, а здесь
   то, что касается его самого — решение по верификации, новый отзыв,
   заявка из каталога.
   ====================================================================== */
function notifySpecialist(int $sid,string $type,string $title,string $body=''):void{
  db()->prepare('INSERT INTO specialist_notices(specialist_id,type,title,body,created_at) VALUES(?,?,?,?,?)')
      ->execute([$sid,$type,$title,$body?:null,now()]);
}
/* Письмо специалисту. Ошибку не поднимаем наверх: не отправленное
   письмо не должно отменять уже принятое решение по верификации. */
function mailSpecialist(int $sid,string $subject,string $html,string $text):void{
  $q=db()->prepare('SELECT email,name FROM specialists WHERE id=?');
  $q->execute([$sid]); $r=$q->fetch();
  if(!$r||!$r['email'])return;
  try{ sendMail((string)$r['email'],$subject,$html,$text); }
  catch(Throwable $e){ error_log('mailSpecialist: '.$e->getMessage()); }
}
/* Письмо владельцу сервиса: очередь верификации он иначе не увидит,
   пока сам не откроет панель. */
function mailOwner(string $subject,string $html,string $text):void{
  $to=OWNER_EMAIL;
  $q=db()->query('SELECT email FROM admins ORDER BY id LIMIT 1');
  $a=$q->fetchColumn();
  if($a)$to=(string)$a;
  try{ sendMail($to,$subject,$html,$text); }
  catch(Throwable $e){ error_log('mailOwner: '.$e->getMessage()); }
}
/** Простое письмо в той же вёрстке, что и письмо о смене пароля. */
function plainLetter(string $lead,string $body,string $tail=''):array{
  $html='<div style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;font-size:16px;line-height:1.55;color:#121820">'
    .'<p>'.htmlspecialchars($lead).'</p>'
    .'<p>'.nl2br(htmlspecialchars($body)).'</p>'
    .($tail?'<p style="color:#5B6572;font-size:14px">'.htmlspecialchars($tail).'</p>':'')
    .'</div>';
  $text=$lead."\n\n".$body.($tail?"\n\n".$tail:'');
  return [$html,$text];
}

/* ======================================================================
   Управление приложением из панели.

   Магазины проверяют новую версию неделю, а иногда и дольше. Всё, что
   нельзя переждать эту неделю, должно управляться с сервера: объявление
   людям («в субботу техработы»), требование обновиться, если в старой
   версии нашлась настоящая поломка, и выключатель незрелой возможности.

   Флаги держим в одном списке с понятными названиями: иначе через
   полгода никто не вспомнит, что выключает feature_x.
   ================================================================== */
const APP_FEATURES=[
  'calls'   =>['Видеозвонки','Кнопка звонка у клиента и специалиста'],
  'scan'    =>['Сканер штрихкодов','Поиск продукта по коду с упаковки'],
  'feed'    =>['Лента','Записи специалистов и лайки'],
  'catalog' =>['Каталог специалистов','Поиск специалиста внутри приложения'],
  'payments'=>['Оплата услуг','Покупка услуг специалиста в приложении'],
];

/** Всё, что приложение спрашивает при запуске. */
function appConfig():array{
  $flags=[];
  foreach(APP_FEATURES as $k=>$v)
    $flags[$k]=settingGet('feature_'.$k)!=='0';   // по умолчанию включено
  $text=trim((string)(settingGet('announce_text')??''));
  return [
    'min_version'=>trim((string)(settingGet('min_version')??'')),
    'store_url'=>trim((string)(settingGet('store_url')??'')),
    'announce'=>($text!==''&&settingGet('announce_on')==='1')
      ? ['text'=>$text,'kind'=>settingGet('announce_kind')?:'info',
         'id'=>substr(md5($text),0,8)]   // сменился текст — снова показываем
      : null,
    'features'=>$flags,
  ];
}

/** Версия старее требуемой? Сравниваем по числам, а не строкой:
 *  «1.10.0» строкой меньше «1.9.0», хотя на деле новее. */
function versionOlder(string $have,string $need):bool{
  if($have===''||$need==='')return false;
  $a=array_map('intval',explode('.',$have));
  $b=array_map('intval',explode('.',$need));
  for($i=0;$i<max(count($a),count($b));$i++){
    $x=$a[$i]??0; $y=$b[$i]??0;
    if($x<$y)return true;
    if($x>$y)return false;
  }
  return false;
}

/* ======================================================================
   Сессии.

   Раньше сессия заводилась шестью разными строками с безымянным
   VALUES(?,?,?,?,?): добавить в таблицу столбец было нельзя, не сломав
   все шесть. Теперь точка одна, и она же записывает, откуда вошли —
   без этого список активных входов показать не из чего.
   ================================================================== */
function sessionStart(string $type,int $uid,?string $note=null):string{
  $t=token();
  $ua=mb_substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,300);
  $ip=(string)($_SERVER['REMOTE_ADDR']??'');
  db()->prepare('INSERT INTO sessions(token,user_type,user_id,expires_at,created_at,ip,user_agent,last_seen_at)
                 VALUES(?,?,?,?,?,?,?,?)')
      ->execute([$t,$type,$uid,date('Y-m-d H:i:s',time()+SESSION_DAYS*86400),now(),
                 $ip?:null,$ua?:$note,now()]);
  return $t;
}

/** Человеческое название устройства из строки браузера. */
function deviceName(?string $ua):string{
  $ua=(string)$ua;
  if($ua==='')return 'Неизвестное устройство';
  $os = str_contains($ua,'iPhone')?'iPhone'
      :(str_contains($ua,'iPad')?'iPad'
      :(str_contains($ua,'Android')?'Android'
      :(str_contains($ua,'Mac OS')?'Mac'
      :(str_contains($ua,'Windows')?'Windows'
      :(str_contains($ua,'Linux')?'Linux':'')))));
  $br = str_contains($ua,'Edg/')?'Edge'
      :(str_contains($ua,'OPR/')?'Opera'
      :(str_contains($ua,'Firefox')?'Firefox'
      :(str_contains($ua,'Chrome')?'Chrome'
      :(str_contains($ua,'Safari')?'Safari':''))));
  $out=trim($os.($os&&$br?' · ':'').$br);
  /* Не распознали — показываем начало самой строки: «curl/8.5.0» всё же
     говорит больше, чем «неизвестное устройство». */
  return $out!==''?$out:mb_substr($ua,0,32);
}

/* ======================================================================
   Второй фактор владельца.

   Пароль от панели — единственное, что отделяет чужого человека от
   всех клиентских данных и денег. Код на почту не защищает от всего, но
   закрывает главный случай: пароль подсмотрели или он утёк вместе с
   архивом.

   Включить второй фактор можно только при рабочей почте — иначе код
   отправлять некуда и владелец запрёт сам себя. Если почта сломалась
   после включения, аварийный выход один: выключить twofa в базе
   (UPDATE admins SET twofa=0), и об этом сказано прямо на экране.
   ================================================================== */
const TWOFA_MINUTES = 10;   // столько живёт код
const TWOFA_TRIES   = 5;    // столько раз можно ошибиться

/** Завести код и отправить письмом. Вернёт текст ошибки или null. */
function twofaSend(array $admin):?string{
  $code=str_pad((string)random_int(0,999999),6,'0',STR_PAD_LEFT);
  db()->prepare('UPDATE admins SET twofa_code=?,twofa_until=?,twofa_tries=0 WHERE id=?')
      ->execute([password_hash($code,PASSWORD_DEFAULT),
                 date('Y-m-d H:i:s',time()+TWOFA_MINUTES*60),(int)$admin['id']]);
  [$html,$text]=plainLetter(
    'Код для входа в панель '.APP_NAME.': '.$code,
    'Код действует '.TWOFA_MINUTES.' минут и нужен один раз.',
    'Если вы не входили — кто-то знает ваш пароль. Смените его.');
  try{ sendMail((string)$admin['email'],'Код входа — '.APP_NAME,$html,$text); }
  catch(Throwable $e){ error_log('twofa mail: '.$e->getMessage());
    return 'Не удалось отправить код на почту. Попробуйте ещё раз.'; }
  return null;
}

/** Проверить код. Вернёт текст ошибки или null, если код верный. */
function twofaCheck(array $admin,string $code):?string{
  $pdo=db();
  $q=$pdo->prepare('SELECT twofa_code,twofa_until,twofa_tries FROM admins WHERE id=?');
  $q->execute([(int)$admin['id']]); $r=$q->fetch();
  if(!$r||!$r['twofa_code'])          return 'Код не запрашивали. Войдите заново.';
  if(strtotime((string)$r['twofa_until'])<time()) return 'Код истёк. Войдите заново.';
  if((int)$r['twofa_tries']>=TWOFA_TRIES){
    $pdo->prepare('UPDATE admins SET twofa_code=NULL WHERE id=?')->execute([(int)$admin['id']]);
    return 'Слишком много попыток. Войдите заново.';
  }
  if(!password_verify($code,(string)$r['twofa_code'])){
    $pdo->prepare('UPDATE admins SET twofa_tries=twofa_tries+1 WHERE id=?')->execute([(int)$admin['id']]);
    return 'Неверный код';
  }
  $pdo->prepare('UPDATE admins SET twofa_code=NULL,twofa_until=NULL,twofa_tries=0 WHERE id=?')
      ->execute([(int)$admin['id']]);
  return null;
}

/* ======================================================================
   Дела владельца: очередь, письма и отчёты.

   Очередь дел (заявка на верификацию, обращение, заявка на вывод) до
   сих пор жила только на экране сводки: не открыл панель — не узнал.
   Заявка на вывод при этом лежит живыми деньгами и ждёт решения.
   Поэтому очередь считается одной функцией и её же читает планировщик,
   чтобы письмо и экран никогда не расходились.
   ================================================================== */

/** Дела, требующие решения владельца. Ключ → [сколько, как называется]. */
function ownerQueue():array{
  $pdo=db();
  $n=fn(string $sql)=>(int)$pdo->query($sql)->fetchColumn();
  return [
    'verifications'=>['n'=>$n("SELECT COUNT(*) FROM specialists WHERE verify_status='pending'"),
                      'label'=>'заявок на проверку документов'],
    'support'      =>['n'=>$n("SELECT COUNT(*) FROM support_tickets WHERE status<>'closed'"),
                      'label'=>'обращений без ответа'],
    'payouts'      =>['n'=>$n("SELECT COUNT(*) FROM payout_requests WHERE status='pending'"),
                      'label'=>'заявок на вывод денег'],
    'posts'        =>['n'=>$n("SELECT COUNT(*) FROM posts WHERE status='hidden'"),
                      'label'=>'скрытых записей в ленте'],
  ];
}

/* Письмо владельцу не чаще раза в N часов на каждый повод.
   Десять обращений подряд — это десять писем, после которых письма от
   сервиса начинают уходить мимо глаз; одно письмо в час доносит то же
   самое. Метку держим в настройках: отдельная таблица ради одной даты
   не нужна. */
function mailOwnerThrottled(string $key,int $hours,string $subject,string $html,string $text):bool{
  $k='owner_mail_'.$key;
  $last=settingGet($k);
  if($last!==null && (time()-strtotime($last)) < $hours*3600) return false;
  settingSet($k,now());
  mailOwner($subject,$html,$text);
  return true;
}

/** Утренняя сводка дел. Пусто — молчим: письмо «дел нет» никто не ждёт. */
function ownerDigest():bool{
  $q=ownerQueue();
  $lines=[];
  foreach($q as $x) if($x['n']>0) $lines[]=$x['n'].' '.$x['label'];
  if(!$lines)return false;
  [$html,$text]=plainLetter(
    'Дела в панели '.APP_NAME.' ждут решения:',
    "• ".implode("\n• ",$lines),
    'Открыть панель: '.siteUrl().'/app/');
  return mailOwnerThrottled('digest',20,'Дела в панели — '.APP_NAME,$html,$text);
}

/* ----------------------------------------------------------------------
   Аналитика: удержание и воронка.

   «Сколько всего клиентов» не отвечает на вопрос, работает ли сервис:
   люди регистрируются и уходят молча. Удержание считаем по отметкам еды
   — это единственное действие, которое человек делает по своей воле
   каждый день. Воронка показывает, где он останавливается: без
   специалиста, без меню или получив меню, но ни разу не отметившись.
   -------------------------------------------------------------------- */

/** Доля вернувшихся: из зарегистрированных в окне — кто отметился на N-й день и позже. */
function retentionStats():array{
  $pdo=db();
  $out=[];
  foreach([7,30] as $day){
    /* Берём только тех, кто успел прожить N дней: иначе вчерашние
       регистрации тянут долю вниз, ничего о ней не говоря. */
    $cohort=(int)$pdo->query("SELECT COUNT(*) FROM clients
      WHERE created_at<=datetime('now','-{$day} day')
        AND created_at>=datetime('now','-".($day*3)." day')")->fetchColumn();
    $kept=(int)$pdo->query("SELECT COUNT(DISTINCT c.id) FROM clients c
      JOIN meal_logs m ON m.client_id=c.id
      WHERE c.created_at<=datetime('now','-{$day} day')
        AND c.created_at>=datetime('now','-".($day*3)." day')
        AND m.logged_at>=datetime(c.created_at,'+{$day} day')")->fetchColumn();
    $out['d'.$day]=['cohort'=>$cohort,'kept'=>$kept,
      'percent'=>$cohort?round($kept*100/$cohort):0];
  }
  return $out;
}

/** Воронка: зарегистрировался → взял специалиста → получил меню → отметился.
 *
 *  Шаги строго вложены: каждый следующий считается из тех, кто прошёл
 *  предыдущий. Считать их по отдельности нельзя — отметиться можно по
 *  черновому меню, и «отметили еду» тогда выходит больше, чем «получили
 *  меню». Воронка, которая расширяется, не воронка, а четыре не
 *  связанных числа рядом. */
function funnelStats(int $days=30):array{
  $pdo=db();
  $w="c.created_at>=datetime('now','-{$days} day')";
  $n=fn(string $sql)=>(int)$pdo->query($sql)->fetchColumn();
  $linkedSql="$w AND c.specialist_id IS NOT NULL";
  $menuSql  ="$linkedSql AND EXISTS(SELECT 1 FROM menus m
                WHERE m.client_id=c.id AND m.status='published')";
  $logSql   ="$menuSql AND EXISTS(SELECT 1 FROM meal_logs l WHERE l.client_id=c.id)";
  $signed=$n("SELECT COUNT(*) FROM clients c WHERE $w");
  $linked=$n("SELECT COUNT(*) FROM clients c WHERE $linkedSql");
  $menued=$n("SELECT COUNT(*) FROM clients c WHERE $menuSql");
  $logged=$n("SELECT COUNT(*) FROM clients c WHERE $logSql");
  $step=fn(string $t,int $v)=>['title'=>$t,'n'=>$v,'percent'=>$signed?round($v*100/$signed):0];
  return ['days'=>$days,'steps'=>[
    $step('Зарегистрировались',$signed),
    $step('Взяли специалиста',$linked),
    $step('Получили меню',$menued),
    $step('Отметили первую еду',$logged),
  ]];
}

/** Недельный отчёт владельцу: цифры за семь дней против предыдущих семи. */
function weeklyReport():array{
  $pdo=db();
  $n=fn(string $sql)=>(int)$pdo->query($sql)->fetchColumn();
  $pair=function(string $table,string $col='created_at')use($n){
    $now =$n("SELECT COUNT(*) FROM $table WHERE $col>=datetime('now','-7 day')");
    $prev=$n("SELECT COUNT(*) FROM $table WHERE $col>=datetime('now','-14 day') AND $col<datetime('now','-7 day')");
    return ['now'=>$now,'prev'=>$prev];
  };
  /* Комиссия считается там же, где раздел «Деньги»: по оплаченным
     покупкам, а не по записям учёта — в учёте её отдельной строкой нет,
     и две разные цифры в панели и в письме хуже, чем никакой. */
  $money=(int)$pdo->query("SELECT COALESCE(SUM(commission_kop),0) FROM client_subscriptions
    WHERE paid=1 AND paid_at>=datetime('now','-7 day')")->fetchColumn();
  return [
    'clients'    =>$pair('clients'),
    'specialists'=>$pair('specialists'),
    'menus'      =>$pair('menus'),
    'logs'       =>$pair('meal_logs','logged_at'),
    'commission_kop'=>$money,
    'retention'  =>retentionStats(),
    'queue'      =>ownerQueue(),
  ];
}

/* Отправка недельного отчёта. Запускает планировщик; день недели и час
   владелец выбирает в панели. Нечего слать (сервис пустой) — молчим. */
function sendWeeklyReport():bool{
  $r=weeklyReport();
  $d=fn(array $p)=>$p['now'].' (было '.$p['prev'].')';
  $lines=[
    'Новых клиентов: '.$d($r['clients']),
    'Новых специалистов: '.$d($r['specialists']),
    'Опубликовано меню: '.$d($r['menus']),
    'Отметок еды: '.$d($r['logs']),
    'Комиссия за неделю: '.number_format($r['commission_kop']/100,0,',',' ').' ₽',
    'Вернулись через неделю: '.$r['retention']['d7']['percent'].' %'
      .' ('.$r['retention']['d7']['kept'].' из '.$r['retention']['d7']['cohort'].')',
  ];
  $wait=[];
  foreach($r['queue'] as $x) if($x['n']>0)$wait[]=$x['n'].' '.$x['label'];
  if($wait)$lines[]='Ждут решения: '.implode(', ',$wait);
  [$html,$text]=plainLetter('Неделя в '.APP_NAME.':',implode("\n",$lines),
    'Панель: '.siteUrl().'/app/');
  return mailOwnerThrottled('weekly',100,'Итоги недели — '.APP_NAME,$html,$text);
}

/* ======================================================================
   Отзывы и рейтинг.
   Рейтинг — не поле, которое кто-то заполняет, а следствие отзывов.
   Поэтому храним его в public_profiles только как посчитанное значение
   и пересчитываем при каждом изменении отзывов. Нет отзывов — нет и
   рейтинга: ноль честнее, чем «5.0» из воздуха.
   ====================================================================== */
function refreshRating(int $sid):void{
  $pdo=db();
  $q=$pdo->prepare("SELECT COUNT(*) n, AVG(rating) r FROM specialist_reviews
                    WHERE specialist_id=? AND status='published'");
  $q->execute([$sid]);
  $a=$q->fetch()?:['n'=>0,'r'=>null];
  $n=(int)$a['n'];
  $pdo->prepare('UPDATE public_profiles SET rating=?, reviews_count=? WHERE specialist_id=?')
      ->execute([$n? round((float)$a['r'],1) : null, $n, $sid]);
}
/* Имя под отзывом: «Анна П.». Полную фамилию в открытый доступ не
   выносим — клиент писал отзыв, а не публиковал себя. */
function reviewAuthor(?string $name):string{
  $name=trim((string)$name);
  if($name==='')return 'Клиент';
  $parts=preg_split('/\s+/u',$name);
  $first=$parts[0];
  if(count($parts)>1){
    $ini=mb_substr($parts[1],0,1);
    if($ini!=='')return $first.' '.mb_strtoupper($ini).'.';
  }
  return $first;
}
/** Опубликованные отзывы специалиста — то, что видит любой посетитель. */
function reviewsOf(int $sid,int $limit=50):array{
  $q=db()->prepare("SELECT r.id,r.rating,r.body,r.created_at,c.name
                    FROM specialist_reviews r JOIN clients c ON c.id=r.client_id
                    WHERE r.specialist_id=? AND r.status='published'
                    ORDER BY r.id DESC LIMIT $limit");
  $q->execute([$sid]);
  $out=[];
  foreach($q->fetchAll() as $r){
    $out[]=['id'=>(int)$r['id'],'rating'=>(int)$r['rating'],
            'body'=>$r['body'],'created_at'=>$r['created_at'],
            'author'=>reviewAuthor($r['name'])];
  }
  return $out;
}

/* ======================================================================
   Верификация специалиста.
   Клиент не может проверить диплом сам, поэтому проверку берёт на себя
   сервис: специалист прикладывает документы, владелец сверяет их глазами
   и ставит отметку. Автоматического подтверждения нет и быть не должно —
   галочка «проверен» стоит ровно столько, сколько стоит проверка за ней.
   ====================================================================== */
/* Паспорт подтверждает личность, остальное — квалификацию. Скан
   паспорта видит только владелец при проверке: в каталог уходят лишь
   названия принятых документов, и паспорт среди них не показывается —
   см. фильтр в /public/specialists. */
const VERIFY_KINDS = ['passport','diploma','course','certificate','license'];

/* Диплом хранится по тем же правилам, что и анализы клиента: имя на
   диске случайное, отдача — только через маршрут с проверкой прав. */
function saveDocFile():?string{
  if(empty($_FILES['file'])||$_FILES['file']['error']===UPLOAD_ERR_NO_FILE)return null;
  if($_FILES['file']['error']!==UPLOAD_ERR_OK)json_response(['error'=>'Файл не загружен'],422);
  $f=$_FILES['file'];
  if($f['size']>15*1024*1024)json_response(['error'=>'Файл больше 15 МБ'],422);
  $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
  $allowed=['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
  if(!isset($allowed[$mime]))json_response(['error'=>'Разрешены PDF, JPG, PNG'],422);
  $dir=__DIR__.'/../storage/uploads';if(!is_dir($dir))mkdir($dir,0775,true);
  $name='doc_'.bin2hex(random_bytes(16)).'.'.$allowed[$mime];
  move_uploaded_file($f['tmp_name'],$dir.'/'.$name);
  return '/api/v1/docs/file/'.$name;
}
function docFileOwner(string $name):?int{
  $q=db()->prepare('SELECT specialist_id FROM specialist_documents WHERE file_url LIKE ?');
  $q->execute(['%/'.$name]);
  $r=$q->fetch();
  return $r?(int)$r['specialist_id']:null;
}
/* ==========================================================================
   ДНЕВНИК ПРОДУКТОВ

   Меню отвечает на вопрос «что назначено», дневник — «что съедено».
   Это разные вопросы, и складывать их в одну таблицу нельзя: съеденный
   не по меню творог не делает меню соблюдённым, а соблюдённое меню не
   отменяет съеденного сверх него.
   ========================================================================== */

/** Имя для поиска: строчными и без «ё». */
function foodFold(string $s):string{
  return str_replace(['ё','Ё'],'е',mb_strtolower(trim($s)));
}

/* Те же пять слотов, что у меню: день один, и назначенное со съеденным
   должны попадать в один и тот же приём пищи, а не в два разных списка. */
const FOOD_MEALS = ['breakfast','snack1','lunch','snack2','dinner'];
const FOOD_MEAL_TITLES = ['breakfast'=>'Завтрак','snack1'=>'Перекус','lunch'=>'Обед',
  'snack2'=>'Перекус','dinner'=>'Ужин'];

/** Записи дневника за день с их КБЖУ. */
function foodEntries(int $cid,string $date):array{
  $q=db()->prepare('SELECT * FROM food_entries WHERE client_id=? AND eaten_on=? ORDER BY id');
  $q->execute([$cid,$date]);
  $rows=$q->fetchAll();
  if(!$rows)return [];
  $ids=array_map(fn($r)=>(int)$r['id'],$rows);
  $in=implode(',',array_fill(0,count($ids),'?'));
  $qi=db()->prepare("SELECT * FROM food_entry_items WHERE entry_id IN ($in) ORDER BY entry_id,sort_order,id");
  $qi->execute($ids);
  $by=[];
  foreach($qi->fetchAll() as $i)$by[(int)$i['entry_id']][]=[
    'id'=>(int)$i['id'],'ingredient_id'=>$i['ingredient_id']===null?null:(int)$i['ingredient_id'],
    'name'=>$i['name'],'grams'=>(float)$i['grams'],
    'kcal'=>(float)$i['kcal'],'protein'=>(float)$i['protein'],
    'fat'=>(float)$i['fat'],'carbs'=>(float)$i['carbs'],'fiber'=>(float)$i['fiber']];
  $out=[];
  foreach($rows as $r){
    $items=$by[(int)$r['id']]??[];
    $t=['kcal'=>0,'protein'=>0,'fat'=>0,'carbs'=>0,'fiber'=>0];
    foreach($items as $i)foreach($t as $k=>$v)$t[$k]+=$i[$k];
    foreach($t as $k=>$v)$t[$k]=round($v,1);
    $out[]=['id'=>(int)$r['id'],'eaten_on'=>$r['eaten_on'],'meal'=>$r['meal'],
      'meal_title'=>FOOD_MEAL_TITLES[$r['meal']]??'Перекус','note'=>$r['note'],
      'created_at'=>$r['created_at'],'items'=>$items,'totals'=>$t];
  }
  return $out;
}

/** Сумма съеденного не по меню за день. */
function foodTotals(array $entries):array{
  $t=['kcal'=>0,'protein'=>0,'fat'=>0,'carbs'=>0,'fiber'=>0];
  foreach($entries as $e)foreach($t as $k=>$v)$t[$k]+=$e['totals'][$k]??0;
  foreach($t as $k=>$v)$t[$k]=round($v,1);
  return $t;
}

/** Складываем итог меню и итог дневника в один итог дня. */
function sumTotals(array $a,array $b):array{
  $out=[];
  foreach(['kcal','protein','fat','carbs'] as $k)$out[$k]=round(($a[$k]??0)+($b[$k]??0),1);
  return $out;
}

/** Строка дневника из продукта справочника и граммовки. */
/* Блюдо под один продукт.

   Специалист назначает клиенту не только блюда, но и просто продукты:
   «150 г индейки», «банан». Позиция меню умеет ссылаться только на
   блюдо, поэтому под такой продукт заводится блюдо из одного
   ингредиента — и всё остальное (подсчёт КБЖУ, отметка «съел»,
   замены, список покупок) продолжает работать без единой правки.

   Блюдо создаётся один раз на продукт и дальше переиспользуется:
   граммовку задаёт сама позиция меню, а не блюдо. В базе блюд такие
   записи не показываются — там им делать нечего. */
function dishForIngredient(int $ingId,int $specialistId):int{
  $pdo=db();
  $q=$pdo->prepare('SELECT id FROM dishes WHERE from_ingredient_id=? AND created_by=? LIMIT 1');
  $q->execute([$ingId,$specialistId]);
  if($id=(int)($q->fetchColumn()?:0))return $id;

  $q=$pdo->prepare('SELECT * FROM ingredients WHERE id=?');
  $q->execute([$ingId]);
  $ing=$q->fetch();
  if(!$ing)throw new RuntimeException('Продукт не найден');

  $pdo->prepare('INSERT INTO dishes(name,meal_types,cook_minutes,instructions,photo_url,steps,
                                    is_public,created_by,from_ingredient_id,created_at)
                 VALUES(?,?,?,?,?,?,?,?,?,?)')
      ->execute([$ing['name'],json_encode(['breakfast','lunch','dinner','snack1','snack2']),
                 0,null,null,null,0,$specialistId,$ingId,now()]);
  $did=(int)$pdo->lastInsertId();
  /* Сто граммов в составе: порция задаётся позицией меню и умножает
     состав, поэтому база должна быть ровной сотней. */
  $pdo->prepare('INSERT INTO dish_ingredients(dish_id,ingredient_id,grams,sort_order) VALUES(?,?,?,0)')
      ->execute([$did,$ingId,100]);
  recalc_dish($did);
  return $did;
}

function foodItemFrom(array $ing,float $grams):array{
  $k=$grams/100;
  return ['ingredient_id'=>(int)$ing['id'],'name'=>$ing['name'],'grams'=>round($grams,1),
    'kcal'=>round(((float)$ing['kcal'])*$k,1),'protein'=>round(((float)$ing['protein'])*$k,1),
    'fat'=>round(((float)$ing['fat'])*$k,1),'carbs'=>round(((float)$ing['carbs'])*$k,1),
    'fiber'=>round(((float)($ing['fiber']??0))*$k,1)];
}

/* Сходится ли калорийность с белками, жирами и углеводами.
   Вилка, а не одно число: в разных таблицах клетчатка то входит в
   углеводы, то нет, и жёсткая формула 4-9-4 отвергала бы половину
   честных данных.
     верх = 4Б + 9Ж + 4У
     низ  = 4Б + 9Ж + 4(У − клетчатка)
   Нужна и загрузчику своего файла, и импортёру Open Food Facts:
   чужие данные заносит кто угодно, и опечатка в них — обычное дело. */
function foodKcalPlausible(float $kcal,float $p,float $f,float $c,float $fib=0.0):bool{
  $up=4*$p+9*$f+4*$c;
  $low=4*$p+9*$f+4*max(0.0,$c-$fib);
  $tol=max(15.0,$up*0.10);
  return $kcal<=$up+$tol && $kcal>=$low-$tol;
}
function verificationOf(int $sid):array{
  $pdo=db();
  $q=$pdo->prepare('SELECT verify_status,verify_note,verify_submitted_at,verified_at FROM specialists WHERE id=?');
  $q->execute([$sid]); $s=$q->fetch()?:[];
  $d=$pdo->prepare('SELECT id,kind,title,issuer,issued_on,file_url,status,review_note,reviewed_at,created_at,is_public
                    FROM specialist_documents WHERE specialist_id=? ORDER BY id DESC');
  $d->execute([$sid]);
  return [
    'status'=>$s['verify_status']??'none',
    'note'=>$s['verify_note']??null,
    'submitted_at'=>$s['verify_submitted_at']??null,
    'verified_at'=>$s['verified_at']??null,
    'documents'=>$d->fetchAll(),
  ];
}
/* Отметку снимаем автоматически, если не осталось ни одного принятого
   документа: иначе специалист удалит диплом, а галочка останется. */
function refreshVerification(int $sid):void{
  $pdo=db();
  $q=$pdo->prepare('SELECT verify_status FROM specialists WHERE id=?');
  $q->execute([$sid]); $st=(string)($q->fetchColumn()?:'none');
  if($st!=='verified')return;
  $n=$pdo->prepare("SELECT COUNT(*) FROM specialist_documents WHERE specialist_id=? AND status='approved'");
  $n->execute([$sid]);
  if((int)$n->fetchColumn()===0)
    $pdo->prepare("UPDATE specialists SET verify_status='none',verified_at=NULL WHERE id=?")->execute([$sid]);
}

/* ======================================================================
   Здоровье клиента.
   Данные особой категории, поэтому все выборки идут по client_id, а
   право на этот client_id проверяет вызывающий маршрут.
   ====================================================================== */
function healthOf(int $cid):array{
  $pdo=db();
  $all=function(string $sql)use($pdo,$cid){ $q=$pdo->prepare($sql);$q->execute([$cid]);return $q->fetchAll(); };
  return [
    'allergies'=>$all('SELECT * FROM client_allergies WHERE client_id=? ORDER BY id DESC'),
    /* Сначала то, что принимают сейчас: закончившиеся курсы нужны
       для истории, но каждый день на них смотреть незачем. */
    'meds'=>$all("SELECT * FROM client_meds WHERE client_id=?
                  ORDER BY (ended_on IS NOT NULL AND ended_on<>'') ASC, id DESC"),
    'labs'=>$all('SELECT * FROM client_labs WHERE client_id=? ORDER BY COALESCE(taken_on,created_at) DESC, id DESC'),
    'recommendations'=>$all('SELECT * FROM client_recommendations WHERE client_id=? ORDER BY id DESC LIMIT 100'),
  ];
}
/* Ссылка на файл анализа ведёт сюда: имя случайное, но этого мало —
   проверяем, что файл действительно принадлежит тому, кто просит. */
function labFileOwner(string $name):?array{
  $q=db()->prepare('SELECT client_id FROM client_labs WHERE file_url LIKE ?');
  $q->execute(['%/'.$name]);
  $r=$q->fetch();
  return $r?:null;
}

/* Отдача файла с поддержкой Range.
   Плеер iOS начинает с запроса первых байтов и ждёт ответ 206. Если
   вместо него приходит 200 со всем файлом — AVFoundation бросает поток:
   голосовое показывает 0:00 и не играет. Заголовок Accept-Ranges без
   настоящей обработки Range хуже, чем его отсутствие. */
function serveFile(string $file, string $mime, string $cache='public, max-age=86400'):never{
  $size=filesize($file);
  $start=0; $end=$size-1; $partial=false;
  $range=$_SERVER['HTTP_RANGE'] ?? '';
  if($range!=='' && preg_match('/bytes=(\d*)-(\d*)/', $range, $m)){
    if($m[1]!==''){ $start=(int)$m[1]; if($m[2]!=='')$end=(int)$m[2]; }
    elseif($m[2]!==''){ $start=max(0,$size-(int)$m[2]); }   // «последние N байт»
    if($start>$end||$start>=$size){
      http_response_code(416);header('Content-Range: bytes */'.$size);exit;
    }
    $end=min($end,$size-1);
    $partial=true;
  }
  $len=$end-$start+1;
  http_response_code($partial?206:200);
  header('Content-Type: '.$mime);
  header('Accept-Ranges: bytes');
  header('Content-Length: '.$len);
  if($partial)header("Content-Range: bytes $start-$end/$size");
  header('Cache-Control: '.$cache);
  $fh=fopen($file,'rb');
  if($fh===false){http_response_code(500);exit;}
  fseek($fh,$start);
  $left=$len;
  while($left>0 && !feof($fh)){
    $chunk=fread($fh,(int)min(262144,$left));
    if($chunk===false)break;
    echo $chunk;
    $left-=strlen($chunk);
    flush();
  }
  fclose($fh);
  exit;
}

function bearer():?string{$h=$_SERVER['HTTP_AUTHORIZATION']??$_SERVER['REDIRECT_HTTP_AUTHORIZATION']??'';if(!$h&&function_exists('getallheaders')){foreach(getallheaders() as $k=>$v){if(strcasecmp($k,'Authorization')===0){$h=$v;break;}}}if(!$h&&function_exists('apache_request_headers')){foreach(apache_request_headers() as $k=>$v){if(strcasecmp($k,'Authorization')===0){$h=$v;break;}}}return preg_match('/Bearer\s+(\S+)/i',(string)$h,$m)?$m[1]:null;}
function ensurePrefs(string $type,int $uid):void{ $p=db();$q=$p->prepare('SELECT 1 FROM notification_preferences WHERE user_type=? AND user_id=?');$q->execute([$type,$uid]);if(!$q->fetch())$p->prepare('INSERT INTO notification_preferences(user_type,user_id) VALUES(?,?)')->execute([$type,$uid]);}
function auth():array{$t=bearer();if(!$t)json_response(['error'=>'Unauthorized'],401);$q=db()->prepare('SELECT * FROM sessions WHERE token=? AND expires_at>datetime("now")');$q->execute([$t]);$s=$q->fetch();if(!$s)json_response(['error'=>'Unauthorized'],401);touchSeen($s);return $s;}
/* «Была в сети сегодня в 11:05» в каталоге: отметка последнего запроса
   специалиста. Пишем не чаще раза в пять минут — иначе каждый опрос
   чата будет стоить записи в базу. */
function touchSeen(array $s):void{
  /* Сама сессия: без этой отметки список активных входов показывает
     только дату входа, и отличить брошенную вкладку от живого сеанса
     нельзя. Пишем не чаще раза в пять минут — иначе каждый запрос
     страницы превращается в запись в базу. */
  db()->prepare("UPDATE sessions SET last_seen_at=? WHERE token=?
                 AND (last_seen_at IS NULL OR last_seen_at<datetime('now','-5 minutes'))")
      ->execute([now(),(string)$s['token']]);
  if(($s['user_type']??'')!=='specialist')return;
  $q=db()->prepare("UPDATE specialists SET last_seen_at=? WHERE id=? AND (last_seen_at IS NULL OR last_seen_at<datetime('now','-5 minutes'))");
  $q->execute([now(),(int)$s['user_id']]);
}
function require_role(string $role):array{$a=auth();if($a['user_type']!==$role)json_response(['error'=>'Forbidden'],403);$GLOBALS['__auth']=$a;return $a;}
function password_ok(string $p):bool{return strlen($p)>=8 && preg_match('/[A-Za-zА-Яа-я]/',$p) && preg_match('/\d/',$p);}
function recalc_dish(int $id):void{$pdo=db();$q=$pdo->prepare('SELECT di.grams,i.kcal,i.protein,i.fat,i.carbs,i.fiber,i.cooked_ratio FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=?');$q->execute([$id]);$rows=$q->fetchAll();$totalRaw=0;$weight=0;$k=$p=$f=$c=0;foreach($rows as $r){$g=(float)$r['grams'];$ratio=max(0.0001,(float)$r['cooked_ratio']);$totalRaw+=$g;$weight+=$g*$ratio;$k+=(float)$r['kcal']*$g/100;$p+=(float)$r['protein']*$g/100;$f+=(float)$r['fat']*$g/100;$c+=(float)$r['carbs']*$g/100;} $pdo->prepare('UPDATE dishes SET base_portion_g=?,kcal_100=?,protein_100=?,fat_100=?,carbs_100=? WHERE id=?')->execute([$weight,$weight?$k/$weight*100:0,$weight?$p/$weight*100:0,$weight?$f/$weight*100:0,$weight?$c/$weight*100:0,$id]);}
function nutrition(int $dishId,float $portion,?string $overrides=null):array{$pdo=db();$q=$pdo->prepare('SELECT kcal_100,protein_100,fat_100,carbs_100,base_portion_g FROM dishes WHERE id=?');$q->execute([$dishId]);$d=$q->fetch();if(!$d)return ['kcal'=>0,'protein'=>0,'fat'=>0,'carbs'=>0];if($overrides){$o=json_decode($overrides,true);if(is_array($o)&&count($o)){ $q=$pdo->prepare('SELECT di.grams,i.kcal,i.protein,i.fat,i.carbs,i.cooked_ratio,i.id ingredient_id FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=?');$q->execute([$dishId]);$k=$p=$f=$c=0;$base=0;foreach($q->fetchAll() as $r){$g=array_key_exists((string)$r['ingredient_id'],$o)?(float)$o[(string)$r['ingredient_id']]:((float)$r['grams']*(float)$r['cooked_ratio']);$base+=$g;$k+=(float)$r['kcal']*($g/(float)$r['cooked_ratio'])/100;$p+=(float)$r['protein']*($g/(float)$r['cooked_ratio'])/100;$f+=(float)$r['fat']*($g/(float)$r['cooked_ratio'])/100;$c+=(float)$r['carbs']*($g/(float)$r['cooked_ratio'])/100;} $scale=$base?($portion/$base):0;return ['kcal'=>round($k*$scale,1),'protein'=>round($p*$scale,1),'fat'=>round($f*$scale,1),'carbs'=>round($c*$scale,1)];}}
$scale=(float)$d['base_portion_g']?(float)$portion/(float)$d['base_portion_g']:0;return ['kcal'=>round((float)$d['kcal_100']*(float)$portion/100,1),'protein'=>round((float)$d['protein_100']*(float)$portion/100,1),'fat'=>round((float)$d['fat_100']*(float)$portion/100,1),'carbs'=>round((float)$d['carbs_100']*(float)$portion/100,1)];}
const REWARDS=[['d10','−10% на подписку',500,10],['d25','−25% на подписку',1200,25],['d50','−50% на подписку',2500,50]];
/**
 * Снимок прогресса — строкой data: прямо в ответе.
 *
 * Ссылкой отдать нельзя: тег <img> в вебе и expo-image не отправляют
 * заголовок авторизации, а токен в адресе осел бы в истории браузера.
 * Поэтому вкладываем содержимое.
 *
 * Раньше всё тяжелее 512 КБ отбрасывалось и превращалось в пустую
 * строку — снимок с телефона просто исчезал, и никто не понимал почему.
 * Теперь большие снимки уменьшаются: результат кладём рядом с
 * оригиналом, чтобы не пережимать одно и то же при каждом открытии.
 */
/* ======================================================================
   Сжатие снимков.

   Фотография с телефона — это 3–5 МБ, а на экране она занимает от силы
   400 точек по ширине. Каталог из полусотни таких снимков грузится
   минуту на мобильной сети и съедает трафик, показывая ровно то же
   самое. Поэтому всё, что попадает в сервис как фотография, ужимается
   один раз при появлении, а не при каждом показе.

   JPEG, а не WebP: WebP легче, но снимки лежат в папке и отдаются
   веб-сервером напрямую, а старый Safari и часть почтовых клиентов
   WebP не покажут. Разница в весе тут не стоит риска чёрного квадрата.
   ====================================================================== */

/**
 * Ужать снимок в JPEG по длинной стороне.
 *
 * Возвращает false, если исходник не читается или GD на хостинге нет, —
 * тогда вызывающий оставляет оригинал: показать тяжёлое фото лучше, чем
 * не показать никакого.
 */
function shrinkImage(string $src,string $dst,int $maxSide,int $quality):bool{
  if(!function_exists('imagecreatefromstring')||!is_file($src))return false;
  $img=@imagecreatefromstring((string)file_get_contents($src));
  if(!$img)return false;
  $w=imagesx($img); $h=imagesy($img);
  /* Увеличивать нечего: маленький снимок от растяжения только потяжелеет. */
  $k=min(1,$maxSide/max($w,$h));
  $nw=max(1,(int)round($w*$k)); $nh=max(1,(int)round($h*$k));
  $out=imagecreatetruecolor($nw,$nh);
  /* PNG с прозрачностью кладём на белый: в JPEG прозрачности нет, и без
     подложки фон станет чёрным. */
  imagefilledrectangle($out,0,0,$nw,$nh,imagecolorallocate($out,255,255,255));
  imagecopyresampled($out,$img,0,0,0,0,$nw,$nh,$w,$h);
  $dir=dirname($dst); if(!is_dir($dir))@mkdir($dir,0775,true);
  $ok=imagejpeg($out,$dst,$quality);
  imagedestroy($img); imagedestroy($out);
  return (bool)$ok;
}

/** Размеры, в которых фото блюда реально показывается. */
const DISH_PHOTO_BIG   = 1100;   // карточка блюда во весь экран
const DISH_PHOTO_THUMB = 420;    // сетка каталога и строки списков

/**
 * Подготовить фото блюда: большая версия и миниатюра.
 *
 * Оригинал остаётся нетронутым — его положил владелец, и переписывать
 * чужой файл на месте нельзя: если сжатие однажды выйдет неудачным,
 * вернуться будет некуда. Результат кладём рядом, в dishes/opt.
 *
 * Возвращает [большая, миниатюра] — пути от корня сайта, или null,
 * если сжать не вышло.
 */
function dishPhotoVariants(string $file):?array{
  $dir=__DIR__.'/../dishes';
  $src=$dir.'/'.$file;
  if(!is_file($src))return null;
  $base=preg_replace('/[^a-zA-Z0-9_-]+/','_',pathinfo($file,PATHINFO_FILENAME));
  $big=$dir.'/opt/'.$base.'.jpg';
  $sm =$dir.'/opt/'.$base.'_sm.jpg';
  /* Перегенерируем, только если оригинал новее готового: владелец мог
     заменить снимок, не меняя имени файла. */
  $fresh=fn(string $f)=>is_file($f)&&filemtime($f)>=filemtime($src);
  if(!$fresh($big)&&!shrinkImage($src,$big,DISH_PHOTO_BIG,82))return null;
  if(!$fresh($sm)) shrinkImage($src,$sm,DISH_PHOTO_THUMB,76);
  return ['/dishes/opt/'.$base.'.jpg',
          is_file($sm)?'/dishes/opt/'.$base.'_sm.jpg':'/dishes/opt/'.$base.'.jpg'];
}

function photoData(string $url):string{
  $name=basename($url);
  $dir=__DIR__.'/../storage/uploads';
  $file=$dir.'/'.$name;
  if(!is_file($file))return '';
  $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
  $mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'][$ext]??'';
  if($mime==='')return '';

  /* Небольшой снимок отдаём как есть. */
  if(filesize($file)<=524288)
    return 'data:'.$mime.';base64,'.base64_encode((string)file_get_contents($file));

  $small=$dir.'/sm_'.pathinfo($name,PATHINFO_FILENAME).'.jpg';
  if(!is_file($small)||filemtime($small)<filemtime($file)){
    if(!function_exists('imagecreatefromstring'))return '';   // хостинг без GD
    $src=@imagecreatefromstring((string)file_get_contents($file));
    if(!$src)return '';
    $w=imagesx($src); $h=imagesy($src);
    /* 900 по длинной стороне: снимки прогресса показываются сеткой
       миниатюр, и больше на экране телефона всё равно не видно. При
       1400 один снимок весил под 600 КБ в base64, а их в ленте десятки. */
    $k=min(1,900/max($w,$h));
    $nw=max(1,(int)round($w*$k)); $nh=max(1,(int)round($h*$k));
    $dst=imagecreatetruecolor($nw,$nh);
    /* PNG с прозрачностью кладём на белый фон: снимок прогресса —
       фотография, чёрные разводы вместо фона выглядели бы как брак. */
    imagefilledrectangle($dst,0,0,$nw,$nh,imagecolorallocate($dst,255,255,255));
    imagecopyresampled($dst,$src,0,0,0,0,$nw,$nh,$w,$h);
    imagejpeg($dst,$small,78);
    imagedestroy($src); imagedestroy($dst);
  }
  return is_file($small)
    ? 'data:image/jpeg;base64,'.base64_encode((string)file_get_contents($small))
    : '';
}
/* Поля-списки хранятся строкой JSON — разбираем в одном месте. */
function jsonField(?string $v):array{if(!$v)return []; $x=json_decode($v,true);return is_array($x)?$x:[];}

/* ======================================================================
   Сборка меню под цели клиента.

   Это черновик, а не решение за специалиста. Программа умеет ровно
   одно: набрать блюда так, чтобы день сходился по калориям, и не
   поставить то, что клиенту нельзя. Всё остальное — состав тарелки,
   сочетаемость, повторы по вкусу — решает человек, поэтому меню
   создаётся черновиком и открывается на правку.

   Чего здесь намеренно нет: подгонки под белки, жиры и углеводы
   одновременно. Точно свести все четыре числа перестановкой готовых
   блюд нельзя, а вид «всё сошлось» при расхождении в полтора раза
   опаснее честного «по белку недобор». Поэтому БЖУ считается и
   показывается как есть, а решение принимает специалист.
   ====================================================================== */

/** Доли калорий по приёмам. Сумма приводится к единице по факту. */
const MEAL_SHARE = [
  'breakfast'=>0.25, 'snack1'=>0.10, 'lunch'=>0.35, 'snack2'=>0.10, 'dinner'=>0.20,
];

/**
 * Что клиенту нельзя.
 *
 * Три источника: аллергии из карточки здоровья, исключения из анкеты и
 * то, что он не любит. Первые два — запрет, третье — пожелание, но в
 * подборе мы одинаково их избегаем: невкусное меню не соблюдают.
 */
function menuLimits(int $cid):array{
  /* Ограничения клиента бывают двух разных весов, и путать их нельзя.
     Аллергия и непереносимость — запрет: такое блюдо нельзя предлагать
     вообще. «Не люблю гречку» — пожелание: блюдо стоит обходить, но
     если выбора нет, лучше дать его, чем оставить приём пустым.
     Раньше оба списка складывались в один, и пара нелюбимых продуктов
     вырезала из каталога половину блюд наравне с аллергенами. */
  $pdo=db(); $hard=[]; $soft=[];
  $split=function($v){
    $out=[];
    foreach(preg_split('/[,;\n]+/u',(string)$v) as $x){
      $x=mb_strtolower(trim($x));
      if($x!=='')$out[]=$x;
    }
    return $out;
  };
  /* Жёсткие: аллергии и то, что специалист явно исключил. */
  $q=$pdo->prepare('SELECT title FROM client_allergies WHERE client_id=?');
  $q->execute([$cid]);
  foreach($q->fetchAll() as $r) foreach($split($r['title']) as $w) $hard[$w]=true;

  $q=$pdo->prepare('SELECT excluded_ingredients FROM clients WHERE id=?');
  $q->execute([$cid]);
  $raw=(string)($q->fetchColumn()?:'');
  $j=json_decode($raw,true);
  foreach(is_array($j)?$j:[$raw] as $x) foreach($split($x) as $w) $hard[$w]=true;

  $q=$pdo->prepare('SELECT likes,dislikes,excluded FROM client_preferences WHERE client_id=?');
  $q->execute([$cid]);
  $likes=[];
  if($pr=$q->fetch()){
    $j=json_decode((string)$pr['excluded'],true);
    foreach(is_array($j)?$j:[(string)$pr['excluded']] as $x) foreach($split($x) as $w) $hard[$w]=true;
    /* Мягкие: то, что клиент просто не любит. */
    $j=json_decode((string)$pr['dislikes'],true);
    foreach(is_array($j)?$j:[(string)$pr['dislikes']] as $x) foreach($split($x) as $w) $soft[$w]=true;
    $j=json_decode((string)$pr['likes'],true);
    foreach(is_array($j)?$j:[(string)$pr['likes']] as $x) foreach($split($x) as $w) $likes[$w]=true;
  }
  return ['hard'=>array_keys($hard),'soft'=>array_keys($soft),'likes'=>array_keys($likes)];
}

/** Прежнее имя оставлено: им пользуются инструменты и старые вызовы. */
function menuForbidden(int $cid):array{ return menuLimits($cid)['hard']; }

/** Сколько слов из списка встретилось в названии и составе блюда. */
function dishMatches(array $dish,array $ingredients,array $words):int{
  if(!$words)return 0;
  $hay=mb_strtolower($dish['name'].' '.implode(' ',$ingredients));
  $n=0; foreach($words as $w) if($w!==''&&mb_strpos($hay,$w)!==false)$n++;
  return $n;
}

/**
 * Чем можно заменить блюдо в меню.
 *
 * Специалист может задать список замен руками, но делает это редко, и
 * тогда у клиента кнопка «Заменить» упиралась в пустоту. Подбираем сами:
 * тот же приём пищи, близкие калории и состав, без запретов клиента.
 * Порцию считаем так, чтобы замена дала столько же калорий, сколько
 * стояло в плане, — иначе «равноценная» замена сдвигает весь день.
 *
 * $only — список блюд, заданный специалистом руками. Тогда отбирать не
 * из чего: считаем для них порции и расхождения и отдаём в том же
 * порядке, а фильтры приёма пищи и ограничений не применяем — их уже
 * учёл человек.
 */
function autoReplacements(int $itemId,int $cid,int $limit=6,?array $only=null):array{
  $pdo=db();
  $q=$pdo->prepare('SELECT mi.*,d.name,d.kcal_100,d.protein_100,d.fat_100,d.carbs_100,
                           d.base_portion_g,mn.specialist_id
                    FROM menu_items mi
                    JOIN dishes d ON d.id=mi.dish_id
                    JOIN menus mn ON mn.id=mi.menu_id
                    WHERE mi.id=? AND mn.client_id=?');
  $q->execute([$itemId,$cid]);
  $it=$q->fetch(); if(!$it)return [];

  $k=(float)$it['portion_g']/100;
  $want=['kcal'=>(float)$it['kcal_100']*$k,'p'=>(float)$it['protein_100']*$k,
         'f'=>(float)$it['fat_100']*$k,'c'=>(float)$it['carbs_100']*$k];
  if($want['kcal']<=0)return [];

  $limits=menuLimits($cid);
  $cols='id,name,meal_types,base_portion_g,kcal_100,protein_100,fat_100,carbs_100,photo_url,photo_thumb_url';
  if($only!==null){
    $ids=array_values(array_unique(array_map('intval',$only)));
    if(!$ids)return [];
    $in=implode(',',array_fill(0,count($ids),'?'));
    $q=$pdo->prepare("SELECT $cols FROM dishes WHERE id IN ($in) AND kcal_100>0");
    $q->execute($ids);
    $order=array_flip($ids);
  }else{
    $q=$pdo->prepare("SELECT $cols FROM dishes WHERE (is_public=1 OR created_by=?) AND id<>? AND kcal_100>0");
    $q->execute([(int)$it['specialist_id'],(int)$it['dish_id']]);
    $order=null;
  }
  $ing=$pdo->prepare('SELECT i.name FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=?');

  $out=[];
  foreach($q->fetchAll() as $d){
    $ing->execute([(int)$d['id']]);
    $names=array_column($ing->fetchAll(),'name');
    if($order===null){
      /* Приём пищи важнее всего: ужин вместо завтрака — не замена. */
      $meals=jsonField($d['meal_types']);
      if($meals && !in_array($it['meal_type'],$meals,true))continue;
      if(!dishAllowed($d,$names,$limits['hard']))continue;
    }

    $base=(float)($d['base_portion_g']?:250);
    $g=$want['kcal']/((float)$d['kcal_100']/100);
    $g=max($base*0.6,min($base*1.5,$g));
    $g=max(30,round($g/10)*10);
    $kk=$g/100;
    $got=['kcal'=>(float)$d['kcal_100']*$kk,'p'=>(float)$d['protein_100']*$kk,
          'f'=>(float)$d['fat_100']*$kk,'c'=>(float)$d['carbs_100']*$kk];

    /* Насколько замена отличается: калории весят больше, чем отдельная
       строчка БЖУ, но состав тоже учитываем — иначе «те же калории»
       приведут к сладкому вместо мяса. */
    $rel=fn($a,$b)=>$b>0?abs($a-$b)/$b:($a>0?1:0);
    $score=1.6*$rel($got['kcal'],$want['kcal'])
          +0.7*$rel($got['p'],$want['p'])
          +0.5*$rel($got['f'],$want['f'])
          +0.5*$rel($got['c'],$want['c'])
          +0.30*dishMatches($d,$names,$limits['soft'])
          -0.15*min(2,dishMatches($d,$names,$limits['likes']));
    $out[]=[
      'id'=>(int)$d['id'],'name'=>$d['name'],
      'photo_url'=>$d['photo_url'],'photo_thumb_url'=>$d['photo_thumb_url'],
      'portion_g'=>$g,
      'kcal'=>round($got['kcal']),'protein'=>round($got['p']),
      'fat'=>round($got['f']),'carbs'=>round($got['c']),
      'kcal_diff'=>round($got['kcal']-$want['kcal']),
      'protein_diff'=>round($got['p']-$want['p']),
      'fat_diff'=>round($got['f']-$want['f']),
      'carbs_diff'=>round($got['c']-$want['c']),
      '_score'=>$order===null?$score:($order[(int)$d['id']]??999),
    ];
  }
  usort($out,fn($a,$b)=>$a['_score']<=>$b['_score']);
  $out=array_slice($out,0,$limit);
  foreach($out as &$x)unset($x['_score']);
  return $out;
}

/** Подходит ли блюдо: ни один запрет не встречается в его составе. */
function dishAllowed(array $dish,array $ingredients,array $forbidden):bool{
  if(!$forbidden)return true;
  $hay=mb_strtolower($dish['name'].' '.implode(' ',$ingredients));
  foreach($forbidden as $bad) if(mb_strpos($hay,$bad)!==false) return false;
  return true;
}

/**
 * Доли белков, жиров и углеводов в калориях.
 *
 * Сравнивать граммы напрямую нельзя: грамм жира даёт вдвое больше
 * калорий, чем грамм белка, и «поровну в граммах» — это совсем не
 * поровну в тарелке.
 */
function macroShares(float $p,float $f,float $c):array{
  $kp=$p*4; $kf=$f*9; $kc=$c*4;
  $sum=$kp+$kf+$kc;
  /* Цели не заданы — берём общепринятое 25/30/45. */
  if($sum<=0)return ['p'=>0.25,'f'=>0.30,'c'=>0.45];
  return ['p'=>$kp/$sum,'f'=>$kf/$sum,'c'=>$kc/$sum];
}
/** Насколько состав блюда далёк от целевого. 0 — точное попадание. */
function macroDistance(array $dish,array $target):float{
  $s=macroShares((float)$dish['protein_100'],(float)$dish['fat_100'],(float)$dish['carbs_100']);
  return abs($s['p']-$target['p'])+abs($s['f']-$target['f'])+abs($s['c']-$target['c']);
}

/**
 * Собрать черновик меню.
 *
 * Возвращает не только меню, но и отчёт: сколько получилось калорий и
 * БЖУ по дням и насколько это разошлось с целью. Без отчёта специалист
 * не знает, что именно ему править.
 */
function generateMenu(int $cid,int $sid,array $opt):array{
  $pdo=db();
  $q=$pdo->prepare('SELECT * FROM clients WHERE id=?'); $q->execute([$cid]);
  $c=$q->fetch(); if(!$c)throw new RuntimeException('Клиент не найден');

  $days=max(1,min(31,(int)($opt['days_count']??7)));
  $meals=array_values(array_intersect(
    array_keys(MEAL_SHARE),
    (array)($opt['meals']??array_keys(MEAL_SHARE))
  ));
  if(!$meals)$meals=array_keys(MEAL_SHARE);

  $targetKcal=max(800,(int)($c['target_kcal']?:1800));
  /* Доли берём только у выбранных приёмов и приводим их сумму к единице:
     если снять перекусы, их калории должны разойтись по остальным, а не
     пропасть. */
  $sum=0; foreach($meals as $m)$sum+=MEAL_SHARE[$m];
  $share=[]; foreach($meals as $m)$share[$m]=MEAL_SHARE[$m]/$sum;

  $macroTarget=macroShares(
    (float)$c['target_protein'],(float)$c['target_fat'],(float)$c['target_carbs']);

  /* Цели по БЖУ в граммах. Раньше подбор смотрел только на доли внутри
     блюда: каждое по отдельности выглядело подходящим, а день собирался
     из белковых блюд и давал 150 г белка при цели 110. Теперь смотрим на
     то, сколько уже набрано за день и сколько осталось до цели.

     Каталог намеренно высокобелковый, поэтому к цели по белку подбор
     стремится, но не всегда её достаёт — и это не считается сбоем: о
     расхождении по белку специалисту не сообщаем. */
  $tG=['p'=>(float)$c['target_protein'],'f'=>(float)$c['target_fat'],'c'=>(float)$c['target_carbs']];
  $hasMacroGoal=$tG['p']>0&&$tG['f']>0&&$tG['c']>0;

  $limits=menuLimits($cid);
  $forbidden=$limits['hard'];

  /* Пул блюд: общие плюс собственные блюда этого специалиста. */
  $q=$pdo->prepare('SELECT id,name,meal_types,base_portion_g,kcal_100,protein_100,fat_100,carbs_100
                    FROM dishes WHERE is_public=1 OR created_by=?');
  $q->execute([$sid]); $all=$q->fetchAll();

  $ing=$pdo->prepare('SELECT i.name FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=?');
  $pool=[]; $skipped=0;
  foreach($all as $d){
    if((float)$d['kcal_100']<=0)continue;          // без калорийности порцию не посчитать
    $ing->execute([(int)$d['id']]);
    $names=array_column($ing->fetchAll(),'name');
    if(!dishAllowed($d,$names,$forbidden)){ $skipped++; continue; }
    /* Пожелания считаем один раз на блюдо, а не на каждом шаге подбора. */
    $d['_soft']=dishMatches($d,$names,$limits['soft']);
    $d['_like']=dishMatches($d,$names,$limits['likes']);
    foreach(jsonField($d['meal_types']) as $mt)
      if(isset($share[$mt]))$pool[$mt][]=$d;
  }

  $warnings=[];
  /* Пустой приём бывает по двум разным причинам, и путать их нельзя:
     либо ограничения клиента вырезали всё, либо таких блюд в каталоге
     не было изначально. Чинится это по-разному. */
  $inCatalog=[];
  foreach($all as $d) foreach(jsonField($d['meal_types']) as $mt) $inCatalog[$mt]=true;
  $mealName=['breakfast'=>'завтрак','snack1'=>'перекус','lunch'=>'обед',
             'snack2'=>'полдник','dinner'=>'ужин'];
  foreach($meals as $m){
    if(!empty($pool[$m]))continue;
    $warnings[]=empty($inCatalog[$m])
      ? 'В каталоге нет блюд для приёма «'.($mealName[$m]??$m).'» — добавьте их в базу блюд.'
      : 'Все блюда для приёма «'.($mealName[$m]??$m).'» исключены ограничениями клиента.';
  }
  if($skipped)$warnings[]='Исключено блюд по ограничениям клиента: '.$skipped.'.';

  /* Указатель по каждому приёму: идём по перемешанному списку по кругу,
     чтобы блюда не повторялись через день. */
  $cursor=[];
  foreach($pool as $m=>&$list){ shuffle($list); $cursor[$m]=0; }
  unset($list);

  $items=[]; $report=[]; $lastUsed=[];
  for($day=1;$day<=$days;$day++){
    $sort=0; $tot=['kcal'=>0,'protein'=>0,'fat'=>0,'carbs'=>0];
    $dayRows=[];
    $got=['p'=>0.0,'f'=>0.0,'c'=>0.0]; $doneShare=0.0;
    foreach($meals as $m){
      if(empty($pool[$m]))continue;
      $list=$pool[$m]; $n=count($list);
      $want=$targetKcal*$share[$m];

      /* Блюдо выбираем под приём, а не растягиваем порцию под блюдо.
         Смотрим окно из следующих по кругу и оцениваем каждое по двум
         вещам: насколько обычная порция попадает в нужные калории и
         насколько состав похож на целевой БЖУ.

         Состав весит больше калорий: калории чинятся порцией, а доля
         жира в блюде — нет. Без этого дни сходились по калориям и при
         этом давали вдвое больше жира, чем нужно клиенту. */
      $best=null; $bestI=0; $bestScore=INF;
      for($w=0;$w<min(28,$n);$w++){
        $cand=$list[($cursor[$m]+$w)%$n];
        $atBase=(float)$cand['kcal_100']*((float)($cand['base_portion_g']?:250)/100);
        $kcalErr=abs($atBase-$want)/max(1,$want);
        if($hasMacroGoal){
          /* Прикидываем порцию, которой блюдо закроет калории приёма, и
             смотрим, куда после него уедет день. Сравниваем не с целью
             на день целиком, а с тем, сколько к этому приёму должно быть
             набрано: иначе первый же приём выглядит недобором по всему. */
          $g=$want/max(0.01,(float)$cand['kcal_100']/100);
          $cb=(float)($cand['base_portion_g']?:250);
          $g=max($cb*0.7,min($cb*1.4,$g));
          $kk=$g/100;
          $upto=$doneShare+$share[$m];
          $macroErr=
             abs($got['p']+(float)$cand['protein_100']*$kk-$tG['p']*$upto)/$tG['p']
            +abs($got['f']+(float)$cand['fat_100']*$kk    -$tG['f']*$upto)/$tG['f']
            +abs($got['c']+(float)$cand['carbs_100']*$kk  -$tG['c']*$upto)/$tG['c'];
        } else {
          $macroErr=macroDistance($cand,$macroTarget);
        }
        /* Нелюбимое блюдо не запрещено, но уступает равному по составу:
           штраф меньше веса КБЖУ, поэтому пустых приёмов он не создаёт. */
        $score=0.6*$kcalErr + 1.4*$macroErr
             + 0.45*(int)($cand['_soft']??0)
             - 0.20*min(2,(int)($cand['_like']??0));
        /* Штраф за недавнее повторение, затухающий за неделю. Без него
           лучшее по составу блюдо побеждало каждый раз, и неделя выходила
           из трёх-четырёх повторяющихся дней — формально идеальных и
           несъедобных. Ступенчатый штраф давал ровно такой же цикл, только
           длиннее, поэтому он линейный. */
        $last=$lastUsed[(int)$cand['id']]??-99;
        $ago=$day-$last;
        if($ago<7) $score+=(7-$ago)*0.5;
        if($score<$bestScore){ $bestScore=$score; $best=$cand; $bestI=$w; }
      }
      $d=$best; $cursor[$m]+=$bestI+1;
      $lastUsed[(int)$d['id']]=$day;

      $base=(float)($d['base_portion_g']?:250);
      $grams=$want/((float)$d['kcal_100']/100);
      /* Границы порции держим узкими: 400 г овсянки формально дают те
         же калории, но есть это никто не станет. */
      $grams=max($base*0.7,min($base*1.4,$grams));
      $kk=$grams/100;
      $got['p']+=(float)$d['protein_100']*$kk;
      $got['f']+=(float)$d['fat_100']*$kk;
      $got['c']+=(float)$d['carbs_100']*$kk;
      $doneShare+=$share[$m];
      $dayRows[]=['dish'=>$d,'meal'=>$m,'grams'=>$grams,'base'=>$base];
    }

    /* Доводка по дню: если после подбора день всё равно ушёл от цели,
       подтягиваем все порции одним коэффициентом. Так расхождение
       размазывается по приёмам, а не сидит в одном блюде. */
    $sumK=0; foreach($dayRows as $r)$sumK+=(float)$r['dish']['kcal_100']*$r['grams']/100;
    if($sumK>0){
      $fix=max(0.75,min(1.3,$targetKcal/$sumK));
      foreach($dayRows as &$r)
        $r['grams']=max($r['base']*0.6,min($r['base']*1.5,$r['grams']*$fix));
      unset($r);
    }

    /* Общий коэффициент двигает калории, но не пропорции: он растит белок
       ровно вместе с углеводами. Поэтому вторым проходом двигаем порции
       по отдельности — каждый шаг туда, где суммарная невязка дня падает
       сильнее всего. Калории входят в ту же невязку, поэтому доводка по
       БЖУ не может увести день от целевой калорийности. */
    if($hasMacroGoal&&$dayRows){
      $miss=function(array $rows) use($targetKcal,$tG){
        $k=0;$p=0;$f=0;$c=0;
        foreach($rows as $r){ $x=$r['grams']/100; $d=$r['dish'];
          $k+=(float)$d['kcal_100']*$x; $p+=(float)$d['protein_100']*$x;
          $f+=(float)$d['fat_100']*$x;  $c+=(float)$d['carbs_100']*$x; }
        return 4.0*abs($k-$targetKcal)/max(1,$targetKcal)
             + abs($p-$tG['p'])/$tG['p']
             + abs($f-$tG['f'])/$tG['f']
             + abs($c-$tG['c'])/$tG['c'];
      };
      $cur=$miss($dayRows);
      for($it=0;$it<80;$it++){
        $bestGain=0.0; $bi=-1; $bg=0.0;
        foreach($dayRows as $i=>$r){
          foreach([-10,10] as $step){
            $g=$r['grams']+$step;
            if($g<$r['base']*0.6||$g>$r['base']*1.5)continue;
            $try=$dayRows; $try[$i]['grams']=$g;
            $gain=$cur-$miss($try);
            if($gain>$bestGain){ $bestGain=$gain; $bi=$i; $bg=$g; }
          }
        }
        if($bi<0||$bestGain<1e-4)break;      // дальше не улучшается
        $dayRows[$bi]['grams']=$bg; $cur-=$bestGain;
      }
    }

    /* Порции ходят в границах 0,6–1,5 базовой — если день собрался из
       слишком белковых блюд, подстройкой это уже не вытащить. Поэтому
       пробуем поменять само блюдо: перебираем замены для каждого приёма
       и берём ту, что сильнее всего уводит день к цели. */
    if($hasMacroGoal&&$dayRows){
      $fit=function(array $rows) use($targetKcal,$tG){
        $k=0;$p=0;$f=0;$c=0;
        foreach($rows as $r){ $x=$r['grams']/100; $d=$r['dish'];
          $k+=(float)$d['kcal_100']*$x; $p+=(float)$d['protein_100']*$x;
          $f+=(float)$d['fat_100']*$x;  $c+=(float)$d['carbs_100']*$x; }
        return 4.0*abs($k-$targetKcal)/max(1,$targetKcal)
             + abs($p-$tG['p'])/$tG['p'] + abs($f-$tG['f'])/$tG['f'] + abs($c-$tG['c'])/$tG['c'];
      };
      for($pass=0;$pass<3;$pass++){
        $cur=$fit($dayRows);
        if($cur<0.10)break;                       // день уже сходится
        $bestGain=0.0; $bi=-1; $bd=null; $bgr=0.0;
        foreach($dayRows as $i=>$r){
          $m=$r['meal']; if(empty($pool[$m]))continue;
          $want=$targetKcal*$share[$m];
          foreach($pool[$m] as $cand){
            if((int)$cand['id']===(int)$r['dish']['id'])continue;
            if((float)$cand['kcal_100']<=0)continue;
            /* Не тянем обратно то, что стоит в соседних днях: замена не
               должна чинить БЖУ ценой недели из одинаковых обедов. */
            $last=$lastUsed[(int)$cand['id']]??-99;
            if($day-$last<3)continue;
            $cb=(float)($cand['base_portion_g']?:250);
            $g=max($cb*0.7,min($cb*1.4,$want/((float)$cand['kcal_100']/100)));
            $try=$dayRows; $try[$i]=['dish'=>$cand,'meal'=>$m,'grams'=>$g,'base'=>$cb];
            $gain=$cur-$fit($try)
                - 0.10*(int)($cand['_soft']??0)
                + 0.05*min(2,(int)($cand['_like']??0));
            if($gain>$bestGain){ $bestGain=$gain; $bi=$i; $bd=$cand; $bgr=$g; }
          }
        }
        if($bi<0||$bestGain<0.02)break;
        $old=(int)$dayRows[$bi]['dish']['id'];
        if(isset($lastUsed[$old])&&$lastUsed[$old]===$day)unset($lastUsed[$old]);
        $dayRows[$bi]=['dish'=>$bd,'meal'=>$dayRows[$bi]['meal'],'grams'=>$bgr,
                       'base'=>(float)($bd['base_portion_g']?:250)];
        $lastUsed[(int)$bd['id']]=$day;

        /* После замены порции опять расходятся — подгоняем их заново. */
        $cur2=$fit($dayRows);
        for($it=0;$it<80;$it++){
          $bg2=0.0;$i2=-1;$g2=0.0;
          foreach($dayRows as $i=>$r){
            foreach([-10,10] as $step){
              $g=$r['grams']+$step;
              if($g<$r['base']*0.6||$g>$r['base']*1.5)continue;
              $try=$dayRows; $try[$i]['grams']=$g;
              $gain=$cur2-$fit($try);
              if($gain>$bg2){ $bg2=$gain; $i2=$i; $g2=$g; }
            }
          }
          if($i2<0||$bg2<1e-4)break;
          $dayRows[$i2]['grams']=$g2; $cur2-=$bg2;
        }
      }
    }

    foreach($dayRows as $r){
      $d=$r['dish'];
      $grams=max(30,round($r['grams']/10)*10);
      $k=$grams/100;
      $tot['kcal']+=(float)$d['kcal_100']*$k;
      $tot['protein']+=(float)$d['protein_100']*$k;
      $tot['fat']+=(float)$d['fat_100']*$k;
      $tot['carbs']+=(float)$d['carbs_100']*$k;
      $items[]=[$day,$r['meal'],(int)$d['id'],$grams,$sort++];
    }
    /* Расхождение показываем по каждому числу, а не только по калориям:
       день может сойтись по калориям и при этом дать вдвое больше жира,
       и специалисту нужно видеть именно это. */
    $report[]=[
      'day'=>$day,
      'kcal'=>round($tot['kcal']),
      'protein'=>round($tot['protein']),
      'fat'=>round($tot['fat']),
      'carbs'=>round($tot['carbs']),
      'kcal_diff'=>round($tot['kcal']-$targetKcal),
      'protein_diff'=>$c['target_protein']?round($tot['protein']-(float)$c['target_protein']):null,
      'fat_diff'=>$c['target_fat']?round($tot['fat']-(float)$c['target_fat']):null,
      'carbs_diff'=>$c['target_carbs']?round($tot['carbs']-(float)$c['target_carbs']):null,
    ];
  }
  if(!$items)throw new RuntimeException('Не нашлось блюд, подходящих этому клиенту');

  $pdo->beginTransaction();
  try{
    $pdo->prepare('INSERT INTO menus(client_id,specialist_id,title,start_date,days_count,status,created_at)
                   VALUES(?,?,?,?,?,?,?)')
        ->execute([$cid,$sid,mb_substr(trim((string)($opt['title']??''))?:'Меню на '.$days.' дн.',0,120),
                   (string)($opt['start_date']??date('Y-m-d')),$days,'draft',now()]);
    $mid=(int)$pdo->lastInsertId();
    $ins=$pdo->prepare('INSERT INTO menu_items(menu_id,day_number,meal_type,dish_id,portion_g,sort_order) VALUES(?,?,?,?,?,?)');
    foreach($items as $it)$ins->execute([$mid,$it[0],$it[1],$it[2],$it[3],$it[4]]);
    $pdo->commit();
  }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); throw $e; }

  $avg=count($report)?array_sum(array_column($report,'kcal'))/count($report):0;
  /* Про белок не предупреждаем: каталог собран высокобелковым намеренно,
     и превышение цели здесь — свойство меню, а не сбой подбора. Жиры и
     углеводы остаются: там расхождение говорит о настоящей нехватке
     подходящих блюд. Числа по каждому дню и так возвращаются в отчёте. */
  $n=max(1,count($report));
  foreach([['fat','жирам','target_fat'],['carbs','углеводам','target_carbs']] as [$k,$word,$tk]){
    if(!$c[$tk])continue;
    $avgV=array_sum(array_column($report,$k))/$n;
    $goal=(float)$c[$tk];
    $off=$goal? ($avgV-$goal)/$goal : 0;
    if(abs($off)>0.2)
      $warnings[]='По '.$word.' в среднем '.round($avgV).' г при цели '.round($goal)
        .' г. Подбор упёрся в каталог: блюд с нужным составом не хватило — '
        .'добавьте свои или измените цель клиента.';
  }
  /* Короткий вывод по всему меню: четыре строки вместо семи столбцов
     чисел. Специалисту в первую очередь нужен ответ «попали или нет», а
     разбираться по дням он идёт уже потом. Калориям даём 5 % допуска,
     БЖУ — 10 %: держать граммы точнее подбор не может, да и незачем. */
  $quality=[];
  foreach([['kcal','Калории','ккал',$targetKcal,0.05],
           ['protein','Белки','г',(float)$c['target_protein'],0.10],
           ['fat','Жиры','г',(float)$c['target_fat'],0.10],
           ['carbs','Углеводы','г',(float)$c['target_carbs'],0.10]] as [$k,$label,$unit,$goal,$tol]){
    if($goal<=0)continue;
    $avgV=array_sum(array_column($report,$k))/$n;
    $off=($avgV-$goal)/$goal;
    $verdict=abs($off)<=$tol?'ok':($off>0?'high':'low');
    $quality[]=[
      'key'=>$k,'label'=>$label,'unit'=>$unit,
      'avg'=>round($avgV),'goal'=>round($goal),
      'diff'=>round($avgV-$goal),'pct'=>round($off*100),
      'verdict'=>$verdict,
      'text'=>['ok'=>'в норме','high'=>'выше цели','low'=>'ниже цели'][$verdict],
    ];
  }
  return [
    'menu_id'=>$mid,
    'target_kcal'=>$targetKcal,
    'avg_kcal'=>round($avg),
    'targets'=>['protein'=>(float)$c['target_protein'],'fat'=>(float)$c['target_fat'],'carbs'=>(float)$c['target_carbs']],
    'quality'=>$quality,
    'days'=>$report,
    'excluded_count'=>$skipped,
    'warnings'=>$warnings,
  ];
}

function gamification(int $cid):array{$pdo=db();
  $eaten=(int)$pdo->query("SELECT COUNT(*) FROM meal_logs WHERE client_id=$cid AND status='eaten'")->fetchColumn();
  // даты с приёмами (для стрика и «идеальных дней»)
  $q=$pdo->prepare("SELECT date(logged_at) d, SUM(status='eaten') e, SUM(status='skipped') s FROM meal_logs WHERE client_id=? GROUP BY date(logged_at) ORDER BY d DESC");$q->execute([$cid]);$days=$q->fetchAll();
  $eatenDates=[];$perfect=0;$dmap=[];foreach($days as $r){if((int)$r['e']>0)$eatenDates[$r['d']]=true;if((int)$r['e']>=3&&(int)$r['s']===0)$perfect++;$dmap[$r['d']]=$r;}
  // приверженность по дням за последние 7 дней (для бар-чарта)
  $wdN=['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];$week=[];for($i=6;$i>=0;$i--){$ts=strtotime("-$i day");$d=date('Y-m-d',$ts);$e=(int)($dmap[$d]['e']??0);$s=(int)($dmap[$d]['s']??0);$t=$e+$s;$week[]=['label'=>$wdN[(int)date('w',$ts)],'date'=>$d,'pct'=>$t>0?(int)round($e/$t*100):null,'logged'=>$t];}
  // стрик: подряд идущие дни с приёмами до сегодня/вчера
  $streak=0;$cur=strtotime(date('Y-m-d'));if(empty($eatenDates[date('Y-m-d',$cur)]))$cur-=86400;while(!empty($eatenDates[date('Y-m-d',$cur)])){$streak++;$cur-=86400;}
  // вес: отдельные даты
  $weighDates=(int)$pdo->query("SELECT COUNT(*) FROM weight_logs WHERE client_id=$cid")->fetchColumn();
  /* Задания специалиста дают баллы наравне с отметками: он для того их
     и ставит. Считаем только закрытые. */
  $q=$pdo->prepare("SELECT COALESCE(SUM(points),0) FROM client_tasks WHERE client_id=? AND status='done'");
  $q->execute([$cid]); $taskPoints=(int)$q->fetchColumn();
  $earned=$eaten*10 + $perfect*25 + $weighDates*15 + $taskPoints;
  $spent=(int)$pdo->query("SELECT COALESCE(SUM(points_cost),0) FROM point_redemptions WHERE client_id=$cid")->fetchColumn();
  $balance=max(0,$earned-$spent);
  $level=intdiv($earned,500)+1;$levelBase=($level-1)*500;$next=$level*500;
  $titles=['Новичок','Стараюсь','В ритме','Дисциплина','Мастер','Легенда'];
  // задания на сегодня
  $today=date('Y-m-d');
  $q=$pdo->prepare("SELECT * FROM menus WHERE client_id=? AND status='published' ORDER BY id DESC LIMIT 1");$q->execute([$cid]);$mn=$q->fetch();
  $todayEaten=0;$todayTotal=0;
  if($mn){$dayNum=max(1,min((int)$mn['days_count'],(int)floor((strtotime($today)-strtotime($mn['start_date']))/86400)+1));
    $q=$pdo->prepare('SELECT mi.id FROM menu_items mi WHERE mi.menu_id=? AND mi.day_number=?');$q->execute([$mn['id'],$dayNum]);$ids=$q->fetchAll(PDO::FETCH_COLUMN);$todayTotal=count($ids);
    if($todayTotal){$in=implode(',',array_map('intval',$ids));$todayEaten=(int)$pdo->query("SELECT COUNT(*) FROM meal_logs WHERE client_id=$cid AND status='eaten' AND menu_item_id IN ($in)")->fetchColumn();}}
  $weighToday=(int)$pdo->query("SELECT COUNT(*) FROM weight_logs WHERE client_id=$cid AND measured_on='$today'")->fetchColumn()>0;
  $tasks=[
    ['key'=>'meals','label'=>'Отметить все приёмы пищи','reward'=>30,'done'=>$todayTotal>0&&$todayEaten>=$todayTotal,'progress'=>$todayTotal?"$todayEaten/$todayTotal":'—'],
    ['key'=>'weight','label'=>'Записать вес сегодня','reward'=>15,'done'=>$weighToday,'progress'=>$weighToday?'✓':''],
  ];
  /* Личные задания специалиста — отдельным списком: у них своя судьба
     (фотоотчёт, срок, отмена), и в ежедневные они не сворачиваются. */
  $q=$pdo->prepare("SELECT id,title,note,kind,points,due_on,status,photo_url,comment,done_at,created_at
                    FROM client_tasks WHERE client_id=? AND status<>'cancelled'
                    ORDER BY (status='done') ASC, COALESCE(due_on,'9999') ASC, id DESC LIMIT 50");
  $q->execute([$cid]); $personal=$q->fetchAll();
  foreach($personal as &$pt) if($pt['photo_url']) $pt['photo_url']=photoData($pt['photo_url']);
  unset($pt);
  $ach=[
    ['key'=>'first','icon'=>'star','label'=>'Первый шаг','hint'=>'Первый отмеченный приём','unlocked'=>$eaten>=1],
    ['key'=>'week','icon'=>'flame','label'=>'Неделя силы','hint'=>'Стрик 7 дней','unlocked'=>$streak>=7],
    ['key'=>'fifty','icon'=>'check','label'=>'50 приёмов','hint'=>'50 съеденных блюд','unlocked'=>$eaten>=50],
    ['key'=>'perfect','icon'=>'trophy','label'=>'Идеальные дни','hint'=>'3 дня без пропусков','unlocked'=>$perfect>=3],
    ['key'=>'weigh','icon'=>'trend','label'=>'На контроле','hint'=>'5 замеров веса','unlocked'=>$weighDates>=5],
  ];
  $q=$pdo->prepare('SELECT reward_key,title,discount_pct,points_cost,code,status,created_at FROM point_redemptions WHERE client_id=? ORDER BY id DESC LIMIT 20');$q->execute([$cid]);$reds=$q->fetchAll();
  /* Привилегии задаёт специалист: выдавать их будет он, значит он и
     решает, что предложить. Прежний зашитый список обещал скидку на
     подписку, которой в сервисе нет. */
  $q=$pdo->prepare("SELECT r.id,r.title,r.note,r.cost FROM specialist_rewards r
                    JOIN clients c ON c.specialist_id=r.specialist_id
                    WHERE c.id=? AND r.is_active=1 ORDER BY r.cost");
  $q->execute([$cid]);
  $rewards=array_map(fn($r)=>[
    'id'=>(int)$r['id'],'label'=>$r['title'],'note'=>$r['note'],'cost'=>(int)$r['cost'],
  ],$q->fetchAll());
  return ['balance'=>$balance,'earned'=>$earned,'spent'=>$spent,'streak'=>$streak,'eaten'=>$eaten,'perfect_days'=>$perfect,
    'level'=>$level,'level_title'=>$titles[min($level-1,count($titles)-1)],'level_base'=>$levelBase,'level_next'=>$next,
    'tasks'=>$tasks,'personal_tasks'=>$personal,'achievements'=>$ach,
    'rewards'=>$rewards,'redemptions'=>$reds,'week'=>$week,'adh'=>adherence7($cid)];
}

/**
 * Что клиент сделал с планом за последние семь дней.
 *
 * Приверженность считалась как «съедено из отмеченного», и тот, кто
 * отметил один приём из двадцати пяти и его съел, выходил стопроцентным.
 * Молчание — не отказ: одно значит, что человек перестал открывать
 * программу, другое — что меню ему не подошло, и делать с этим нужно
 * разное. Поэтому считаем три числа отдельно.
 */
/* ======================================================================
   ПОДПИСКА КЛИЕНТА НА УСЛУГУ СПЕЦИАЛИСТА.

   Оплаты пока нет: услуга включается сразу. Когда появится приём
   платежей, активной станет считаться только оплаченная — менять
   придётся условие в subActive(), а не схему и не экраны.
   ====================================================================== */

/** Текущая подписка клиента: активная и не истёкшая. Иначе null. */
function subActive(int $cid): ?array {
  $pdo=db();
  /* Истёкшие гасим на месте: без этого «активной» числилась бы
     подписка, кончившаяся полгода назад, и клиент видел бы
     отрицательный остаток дней. */
  $pdo->prepare("UPDATE client_subscriptions SET status='expired'
                  WHERE status='active' AND expires_at IS NOT NULL AND expires_at < ?")
      ->execute([now()]);
  $q=$pdo->prepare("SELECT s.*, sp.name specialist_name
                      FROM client_subscriptions s
                      JOIN specialists sp ON sp.id=s.specialist_id
                     WHERE s.client_id=? AND s.status='active'
                     ORDER BY s.id DESC LIMIT 1");
  $q->execute([$cid]);
  $r=$q->fetch();
  if(!$r)return null;
  return subDecorate($r);
}

/** Добавить к строке подписки то, что считается, а не хранится. */
function subDecorate(array $r): array {
  $r['price']=round(((int)$r['price_kop'])/100);
  $r['days_left']=null; $r['expired']=false;
  /* Приёмка разовой услуги: экран должен отличать «идёт работа» от
     «специалист отметил выполнение, ждём вас». */
  $r['paid']=(int)$r['paid'];
  $r['awaiting_accept']=($r['kind']==='one_time'&&(int)$r['paid']===1
      &&!empty($r['done_at'])&&empty($r['accepted_at'])&&empty($r['disputed_at']));
  $r['accept_days_left']=null;
  if($r['awaiting_accept']&&!empty($r['accept_due_at']))
    $r['accept_days_left']=max(0,(int)ceil((strtotime((string)$r['accept_due_at'])-time())/86400));
  if(!empty($r['expires_at'])){
    $left=(strtotime($r['expires_at']) - time())/86400;
    /* Остаток округляем вверх: в последний день подписка ещё
       действует, и писать «0 дней» у работающей услуги неверно. */
    $r['days_left']=max(0,(int)ceil($left));
    $r['expired']=$left<=0;
  }
  return $r;
}

/**
 * Включить услугу клиенту.
 *
 * Прежняя активная закрывается: одновременно действующих подписок у
 * клиента не бывает — иначе непонятно, по какой из них работает
 * специалист и какая кончается.
 */
function subActivate(int $cid,int $sid,array $svc): array {
  $pdo=db();
  /* Дата закрытия нужна балансу: до неё дни подписки заработаны,
     после — незаработанный остаток вернётся клиенту. */
  $pdo->prepare("UPDATE client_subscriptions SET status='cancelled',ended_at=?
                  WHERE client_id=? AND status='active'")->execute([now(),$cid]);
  $days=(int)($svc['period_days']??0);
  $kind=(string)($svc['kind']??'one_time');
  $exp=($kind==='subscription'&&$days>0)?date('Y-m-d H:i:s',time()+$days*86400):null;
  $pdo->prepare('INSERT INTO client_subscriptions
      (client_id,specialist_id,service_id,title,kind,price_kop,period_days,
       status,paid,started_at,expires_at,created_at)
      VALUES(?,?,?,?,?,?,?,\'active\',0,?,?,?)')
     ->execute([$cid,$sid,(int)$svc['id'],$svc['title'],$kind,
                (int)$svc['price_kop'],$days?:null,now(),$exp,now()]);
  return subActive($cid) ?? [];
}

/* ======================================================================
   БАЛАНС СПЕЦИАЛИСТА: ЗАМОРОЖЕНО И ДОСТУПНО.

   Денег на счету платформы нет: они остаются у эквайера, а здесь —
   учёт, кому и сколько причитается. Отсюда три правила, на которых
   держится всё ниже.

   1. Баланс не хранится. Он считается суммой движений в
      balance_entries — испортить его одним неудачным UPDATE нельзя, а
      выписка специалисту получается из тех же строк.
   2. Начисление ленивое. Разморозка подписки идёт посуточно, но не по
      крону: пропущенный крон — это молчаливая недоплата, которую никто
      не заметит. Вместо этого при каждом обращении к балансу
      дописываем движения за дни, которые уже прошли.
   3. Цифры фиксируются снимком. Ставка комиссии, наша доля и доля
      специалиста записываются в строку покупки в момент оплаты:
      владелец поменяет ставку завтра, а по вчерашнему заказу
      причитается то, о чём договаривались вчера.
   ====================================================================== */

/** Настройки комиссии, сроков и порога вывода. Строка всегда одна. */
function balanceSettings():array{
  $r=db()->query('SELECT * FROM commission_settings WHERE id=1')->fetch()?:[];
  return [
    'rate_own'=>(float)($r['rate_own']??0.10),
    'rate_catalog'=>(float)($r['rate_catalog']??0.25),
    'catalog_period_days'=>(int)($r['catalog_period_days']??90),
    'accept_days'=>(int)($r['accept_days']??7),
    'abandon_days'=>(int)($r['abandon_days']??45),
    'payout_min_kop'=>(int)($r['payout_min_kop']??100000),
    'payments_mode'=>in_array($r['payments_mode']??'off',['off','demo','live'],true)
        ? (string)$r['payments_mode'] : 'off',
  ];
}

/**
 * Ставка комиссии по этой паре «клиент — специалист».
 *
 * Повышенная берётся только с тех, кого привели мы сами, и только
 * ограниченное время: дальше клиент работает со специалистом сам по
 * себе, и брать за него как за нового нечестно.
 */
function commissionRate(int $cid,int $sid):float{
  $s=balanceSettings();
  /* Личная ставка специалиста важнее общей: с сильным специалистом
     договариваются отдельно, и менять из-за одного правила для всех
     нельзя. Пустое поле — значит действует общая. */
  $own=db()->prepare('SELECT rate_own,rate_catalog FROM specialists WHERE id=?');
  $own->execute([$sid]); $p=$own->fetch()?:[];
  $rateOwn = ($p['rate_own']!==null && $p['rate_own']!=='') ? (float)$p['rate_own'] : $s['rate_own'];
  $rateCat = ($p['rate_catalog']!==null && $p['rate_catalog']!=='') ? (float)$p['rate_catalog'] : $s['rate_catalog'];
  $q=db()->prepare('SELECT source,linked_at FROM client_attribution WHERE client_id=? AND specialist_id=?');
  $q->execute([$cid,$sid]); $a=$q->fetch();
  if(!$a||$a['source']!=='catalog')return $rateOwn;
  $until=strtotime((string)$a['linked_at'])+$s['catalog_period_days']*86400;
  return time()<=$until ? $rateCat : $rateOwn;
}

/**
 * Записать движение.
 *
 * Суммы со знаком: разморозка убавляет замороженное и прибавляет
 * доступное одной строкой. Возвращает false, если движение за этот день
 * подписки уже есть — на этом стоит защита от двойного начисления, и
 * ловить её исключением правильнее, чем проверять заранее: между
 * проверкой и вставкой успевает вклиниться второй запрос.
 */
function balanceAdd(int $sid,?int $subId,string $kind,int $held,int $avail,string $note,
                    ?int $dayNo=null,?int $payoutId=null,?string $at=null):bool{
  try{
    db()->prepare('INSERT INTO balance_entries
        (specialist_id,sub_id,payout_id,kind,held_kop,avail_kop,day_no,note,occurred_at)
        VALUES(?,?,?,?,?,?,?,?,?)')
       ->execute([$sid,$subId,$payoutId,$kind,$held,$avail,$dayNo,$note,$at?:now()]);
    return true;
  }catch(PDOException $e){ return false; }
}

/** Сколько по этой покупке ещё заморожено. */
function subHeld(int $subId):int{
  $q=db()->prepare('SELECT COALESCE(SUM(held_kop),0) FROM balance_entries WHERE sub_id=?');
  $q->execute([$subId]); return (int)$q->fetchColumn();
}

/**
 * Оплата прошла: замораживаем долю специалиста.
 *
 * Точка входа одна, и позвать её дважды по одному заказу безопасно —
 * вебхуки эквайера приходят повторно, это норма, а не сбой.
 */
/**
 * Проверить промокод и посчитать скидку.
 *
 * Возвращает промокод и сумму скидки в копейках либо ошибку словами —
 * человеку важно понимать, код просрочен, исчерпан или не подходит
 * этому специалисту, а не просто «не сработало».
 */
function promoCheck(string $code,int $specialistId,int $priceKop):array{
  $code=strtoupper(trim($code));
  if($code==='')return ['error'=>'Пустой код'];
  $q=db()->prepare('SELECT * FROM promo_codes WHERE code=?');
  $q->execute([$code]); $p=$q->fetch();
  if(!$p)                                   return ['error'=>'Такого кода нет'];
  if(($p['status']??'active')!=='active')   return ['error'=>'Код выключен'];
  if(!empty($p['expires_at'])&&strtotime((string)$p['expires_at'])<time())
                                            return ['error'=>'Срок действия кода истёк'];
  if($p['max_uses']!==null&&(int)$p['uses']>=(int)$p['max_uses'])
                                            return ['error'=>'Код уже использован полностью'];
  if($p['specialist_id']!==null&&(int)$p['specialist_id']!==$specialistId)
                                            return ['error'=>'Код действует у другого специалиста'];
  $discount=(int)round($priceKop*((int)$p['percent'])/100);
  if($discount>=$priceKop)$discount=$priceKop-1;  /* ноль к оплате эквайер не примет */
  return ['promo'=>$p,'discount_kop'=>max(0,$discount)];
}

function subPay(int $subId,?string $promoCode=null):void{
  $pdo=db();
  $q=$pdo->prepare('SELECT * FROM client_subscriptions WHERE id=?');$q->execute([$subId]);
  $sub=$q->fetch(); if(!$sub||(int)$sub['paid']===1)return;
  $sid=(int)$sub['specialist_id'];
  $rate=commissionRate((int)$sub['client_id'],$sid);
  $price=(int)$sub['price_kop'];
  $comm=(int)round($price*$rate);
  $payout=$price-$comm;
  /* Скидка по промокоду. За чей счёт — записано в самом коде: сервис
     отдаёт из комиссии, специалист — из своей доли. Если скидка больше
     комиссии, остаток всё равно вычитается из неё: уходить в минус по
     чужим деньгам нельзя, поэтому дальше нуля не опускаемся. */
  $promo=null; $discount=0;
  if($promoCode){
    $chk=promoCheck($promoCode,$sid,$price);
    if(empty($chk['error'])){
      $promo=$chk['promo']; $discount=(int)$chk['discount_kop'];
      if(($promo['payer']??'service')==='specialist'){
        $payout=max(0,$payout-$discount);
      }else{
        $comm=max(0,$comm-$discount);
        $payout=$price-$discount-$comm;
        if($payout<0){ $payout=0; }
      }
    }
  }
  $st=$pdo->prepare('UPDATE client_subscriptions
        SET paid=1,paid_at=?,commission_rate=?,commission_kop=?,payout_kop=?
        WHERE id=? AND paid=0');
  $st->execute([now(),$rate,$comm,$payout,$subId]);
  /* Кто-то опередил — заморозку уже записал он. */
  if(!$st->rowCount())return;
  if($promo){
    $pdo->prepare('UPDATE promo_codes SET uses=uses+1 WHERE id=?')->execute([(int)$promo['id']]);
    $pdo->prepare('INSERT INTO promo_uses(promo_id,client_id,sub_id,amount_kop,used_at)
      VALUES(?,?,?,?,?)')->execute([(int)$promo['id'],(int)$sub['client_id'],$subId,$discount,now()]);
  }
  balanceAdd($sid,$subId,'hold',$payout,0,'Оплата'.($promo?' со скидкой по коду '.$promo['code']:''));
}

/** Доля дня в сумме, которая делится на дни без потери копеек. */
function dayShare(int $total,int $days,int $d):int{
  return (int)floor($total*$d/$days)-(int)floor($total*($d-1)/$days);
}

/**
 * Дописать начисления, срок которых уже наступил.
 *
 * Делает четыре вещи: размораживает подписки по суткам, засчитывает
 * молчание клиента как согласие, возвращает деньги за разовую услугу,
 * к которой специалист так и не приступил, и возвращает клиенту
 * незаработанный остаток закрытой подписки.
 */
function balanceAccrue(int $sid=0):void{
  $pdo=db(); $s=balanceSettings(); $now=time();
  $where=$sid>0?' AND specialist_id='.(int)$sid:'';

  /* --- Подписки: сутки за сутками --------------------------------- */
  $rows=$pdo->query("SELECT * FROM client_subscriptions
                      WHERE paid=1 AND kind='subscription'
                        AND COALESCE(payout_kop,0)>0".$where)->fetchAll();
  foreach($rows as $sub){
    $days=(int)$sub['period_days']; if($days<1)continue;
    $subId=(int)$sub['id']; $spec=(int)$sub['specialist_id'];
    $payout=(int)$sub['payout_kop'];
    $from=strtotime((string)$sub['paid_at']);
    /* Конец отсчёта: сейчас, конец периода или день досрочного
       закрытия — что наступило раньше. */
    $to=$now;
    if(!empty($sub['expires_at'])) $to=min($to,strtotime((string)$sub['expires_at']));
    if(!empty($sub['ended_at']))   $to=min($to,strtotime((string)$sub['ended_at']));
    $due=max(0,min($days,(int)floor(($to-$from)/86400)));
    $q=$pdo->prepare('SELECT COALESCE(MAX(day_no),0) FROM balance_entries WHERE sub_id=?');
    $q->execute([$subId]); $done=(int)$q->fetchColumn();
    for($d=$done+1;$d<=$due;$d++){
      $part=dayShare($payout,$days,$d);
      /* Датируем днём, за который начислено: иначе догнавший крон
         поставит всем пропущенным дням одно и то же «только что». */
      balanceAdd($spec,$subId,'release',-$part,$part,'День '.$d.' из '.$days,$d,null,
                 date('Y-m-d H:i:s',$from+$d*86400));
    }
    /* Подписка закрыта, а часть денег так и осталась замороженной —
       эти дни специалист не отработал, они возвращаются клиенту. */
    $closed=in_array($sub['status'],['expired','cancelled'],true)
            || (!empty($sub['expires_at'])&&strtotime((string)$sub['expires_at'])<=$now);
    if($closed){
      $left=subHeld($subId);
      if($left>0) balanceAdd($spec,$subId,'refund',-$left,0,
        'Возврат клиенту: неотработанная часть',null,null,
        (string)($sub['ended_at']?:$sub['expires_at']?:now()));
    }
  }

  /* --- Разовые услуги --------------------------------------------- */
  $rows=$pdo->query("SELECT * FROM client_subscriptions
                      WHERE paid=1 AND kind='one_time'
                        AND COALESCE(payout_kop,0)>0
                        AND accepted_at IS NULL AND disputed_at IS NULL".$where)->fetchAll();
  foreach($rows as $sub){
    $subId=(int)$sub['id']; $spec=(int)$sub['specialist_id'];
    $left=subHeld($subId); if($left<=0)continue;

    /* Клиент промолчал до конца окна — это согласие. */
    if(!empty($sub['accept_due_at'])&&strtotime((string)$sub['accept_due_at'])<=$now){
      /* Датируем концом окна: приёмка случилась тогда, а не в тот
         момент, когда мы это заметили. */
      if(balanceAdd($spec,$subId,'release',-$left,$left,'Принято без возражений',null,null,
                    (string)$sub['accept_due_at']))
        $pdo->prepare("UPDATE client_subscriptions SET accepted_at=?,accepted_by='auto' WHERE id=?")
            ->execute([now(),$subId]);
      continue;
    }
    /* Специалист так и не отметил выполнение. Держать чужие деньги
       бессрочно нельзя — возвращаем. */
    if(empty($sub['done_at'])
       && strtotime((string)$sub['paid_at'])+$s['abandon_days']*86400<=$now){
      if(balanceAdd($spec,$subId,'refund',-$left,0,'Возврат клиенту: услуга не выполнена',null,null,
                    date('Y-m-d H:i:s',strtotime((string)$sub['paid_at'])+$s['abandon_days']*86400)))
        $pdo->prepare("UPDATE client_subscriptions SET status='refunded',accepted_at=?,accepted_by='refund' WHERE id=?")
            ->execute([now(),$subId]);
    }
  }
}

/** Два числа для экрана баланса и то, что уже ушло в заявку. */
function balanceOf(int $sid):array{
  balanceAccrue($sid);
  $q=db()->prepare('SELECT COALESCE(SUM(held_kop),0) held,COALESCE(SUM(avail_kop),0) avail
                      FROM balance_entries WHERE specialist_id=?');
  $q->execute([$sid]); $r=$q->fetch();
  $q=db()->prepare("SELECT COALESCE(SUM(amount_kop),0) FROM payout_requests
                     WHERE specialist_id=? AND status='pending'");
  $q->execute([$sid]); $pending=(int)$q->fetchColumn();
  $s=balanceSettings();
  return [
    'held_kop'=>(int)$r['held'],
    'available_kop'=>(int)$r['avail'],
    'pending_kop'=>$pending,
    'payout_min_kop'=>$s['payout_min_kop'],
    'payments_mode'=>$s['payments_mode'],
    'can_payout'=>$s['payments_mode']==='live',
    'accept_days'=>$s['accept_days'],
  ];
}

/** Склонение при числе: 1 день, 2 дня, 5 дней. */
function plural_ru(int $n,string $one,string $few,string $many):string{
  $n=abs($n)%100; $d=$n%10;
  if($n>10&&$n<20)return $many;
  if($d>1&&$d<5)return $few;
  return $d===1?$one:$many;
}

/** Реквизиты специалиста или null, если ещё не заполнены. */
function payoutDetailsOf(int $sid):?array{
  $q=db()->prepare('SELECT * FROM payout_details WHERE specialist_id=?');
  $q->execute([$sid]); $r=$q->fetch(); if(!$r)return null;
  /* Полный номер счёта со страницы не нужен: сверить перевод хватает
     последних четырёх цифр, а утечь может весь экран целиком. */
  $r['account_tail']=mb_substr((string)$r['account'],-4);
  unset($r['account']);
  return $r;
}

/** Заявки на вывод этого специалиста. */
function payoutList(int $sid,int $limit=20):array{
  $q=db()->prepare('SELECT id,amount_kop,status,note,created_at,decided_at
                      FROM payout_requests WHERE specialist_id=? ORDER BY id DESC LIMIT ?');
  $q->execute([$sid,$limit]); return $q->fetchAll();
}


/* ======================================================================
   СВЯЗЬ С ЭКВАЙЕРОМ.

   Учёт выше от банка не зависит: он знает, кто кому сколько должен.
   Здесь — тонкая прослойка, которая переводит это в язык эквайера:
   открыть сделку, принять уведомление, закрыть сделки и выплатить.
   Пока провайдер — заглушка, всё это ведёт журналы и ничего не шлёт.
   ====================================================================== */

/**
 * Открыть сделку по покупке: клиент платит, деньги удерживаются.
 *
 * Запись в payments появляется до обращения к эквайеру, а не после:
 * если ответ потеряется в сети, платёж всё равно будет нашим, и найти
 * его у эквайера будет по чему.
 */
function paymentOpen(int $subId):array{
  $pdo=db();
  $q=$pdo->prepare('SELECT * FROM client_subscriptions WHERE id=?');$q->execute([$subId]);
  $sub=$q->fetch(); if(!$sub)return ['error'=>'Покупка не найдена'];
  $q=$pdo->prepare('SELECT name,email FROM clients WHERE id=?');$q->execute([(int)$sub['client_id']]);
  $payer=$q->fetch()?:[];
  $pv=paymentProvider();
  $pdo->prepare('INSERT INTO payments(sub_id,provider,amount_kop,status,created_at,updated_at)
                 VALUES(?,?,?,\'pending\',?,?)')
     ->execute([$subId,$pv->name(),(int)$sub['price_kop'],now(),now()]);
  $pid=(int)$pdo->lastInsertId();
  try{
    $r=$pv->openDeal($sub,$payer);
  }catch(Throwable $e){
    $pdo->prepare('UPDATE payments SET status=\'canceled\',raw=?,updated_at=? WHERE id=?')
        ->execute([json_encode(['error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE),now(),$pid]);
    return ['error'=>'Платёжный сервис недоступен'];
  }
  $pdo->prepare('UPDATE payments SET provider_payment_id=?,raw=?,updated_at=? WHERE id=?')
     ->execute([$r['payment_id']??null,json_encode($r['raw']??[],JSON_UNESCAPED_UNICODE),now(),$pid]);
  /* Идентификатор сделки нужен потом выплате: она закрывает не сумму,
     а конкретные сделки. */
  if(!empty($r['payment_id']))
    $pdo->prepare('UPDATE client_subscriptions SET provider_deal_id=? WHERE id=? AND provider_deal_id IS NULL')
        ->execute([$r['payment_id'],$subId]);
  return ['payment_id'=>$r['payment_id']??null,'confirmation_url'=>$r['confirmation_url']??null];
}

/**
 * Принять уведомление эквайера.
 *
 * Сначала журнал, потом разбор: уведомление, которое мы не поняли, — это
 * повод разобраться, а не повод его потерять. Повторные уведомления
 * приходят всегда, и защита от них — уникальный ключ по идентификатору
 * события, а не проверка перед вставкой: между проверкой и вставкой
 * успевает вклиниться второй запрос.
 */
function webhookReceive(string $providerName,string $body,array $headers):array{
  $pdo=db();
  $pv=paymentProvider();
  $ev=null;
  try{ $ev=$pv->parseWebhook($body,$headers); }catch(Throwable $e){ $ev=null; }
  $eventId=$ev['event_id']??null;
  try{
    $pdo->prepare('INSERT INTO webhooks(provider,event_id,event_type,body,status,received_at)
                   VALUES(?,?,?,?,?,?)')
       ->execute([$providerName,$eventId,$ev['type']??null,mb_substr($body,0,65536),
                  $ev?'received':'ignored',now()]);
  }catch(PDOException $e){
    /* Уже принимали это уведомление — отвечаем «ок», иначе эквайер
       будет слать его снова и снова. */
    return ['ok'=>true,'duplicate'=>true];
  }
  $wid=(int)$pdo->lastInsertId();
  if(!$ev)return ['ok'=>true,'ignored'=>true];

  try{
    $paymentId=(string)($ev['payment_id']??'');
    $q=$pdo->prepare('SELECT * FROM payments WHERE provider=? AND provider_payment_id=?');
    $q->execute([$providerName,$paymentId]);
    $pay=$q->fetch();
    if(!$pay)throw new RuntimeException('Платёж '.$paymentId.' не найден');
    $status=(string)$ev['status'];
    $pdo->prepare('UPDATE payments SET status=?,paid_at=COALESCE(paid_at,?),updated_at=? WHERE id=?')
       ->execute([$status,$status==='held'?now():null,now(),(int)$pay['id']]);
    /* Деньги удержаны — значит покупка оплачена, и доля специалиста
       замораживается. subPay зовётся повторно безопасно. */
    if($status==='held')subPay((int)$pay['sub_id']);
    $pdo->prepare('UPDATE webhooks SET status=\'processed\',processed_at=? WHERE id=?')->execute([now(),$wid]);
    return ['ok'=>true];
  }catch(Throwable $e){
    $pdo->prepare('UPDATE webhooks SET status=\'failed\',error=?,processed_at=? WHERE id=?')
       ->execute([mb_substr($e->getMessage(),0,500),now(),$wid]);
    return ['ok'=>false,'error'=>$e->getMessage()];
  }
}

/**
 * Из каких покупок складывается вывод.
 *
 * Эквайер закрывает не сумму, а сделки, поэтому заявку надо разложить на
 * покупки. Берём по порядку разморозки — первыми уходят те деньги,
 * которые дольше всего ждут: так специалист не удивится, почему свежая
 * оплата ушла раньше старой.
 *
 * @return array [['sub_id'=>int,'amount_kop'=>int], …] или [] если не набралось
 */
function payoutPick(int $sid,int $amountKop):array{
  $pdo=db();
  /* Уже обещанное другим заявкам. Отклонённая заявка свои строки
     удаляет, поэтому здесь только живые. */
  $taken=[];
  $q=$pdo->prepare('SELECT o.sub_id,SUM(o.amount_kop) n FROM payout_orders o
                      JOIN payout_requests r ON r.id=o.payout_id
                     WHERE r.specialist_id=? GROUP BY o.sub_id');
  $q->execute([$sid]);
  foreach($q->fetchAll() as $r)$taken[(int)$r['sub_id']]=(int)$r['n'];

  $q=$pdo->prepare('SELECT sub_id,SUM(avail_kop) released,MAX(occurred_at) at
                      FROM balance_entries
                     WHERE specialist_id=? AND sub_id IS NOT NULL AND avail_kop>0
                     GROUP BY sub_id ORDER BY at, sub_id');
  $q->execute([$sid]);
  $out=[]; $left=$amountKop;
  foreach($q->fetchAll() as $r){
    if($left<=0)break;
    $sub=(int)$r['sub_id'];
    $free=(int)$r['released']-($taken[$sub]??0);
    if($free<=0)continue;
    $take=min($free,$left);
    $out[]=['sub_id'=>$sub,'amount_kop'=>$take];
    $left-=$take;
  }
  return $left>0 ? [] : $out;
}

/** Покупка клиента — его собственная, а не по чужому номеру. */
function clientSub(int $cid,int $subId):array{
  $q=db()->prepare('SELECT * FROM client_subscriptions WHERE id=? AND client_id=?');
  $q->execute([$subId,$cid]); $r=$q->fetch();
  if(!$r)json_response(['error'=>'Покупка не найдена'],404);
  return $r;
}

/**
 * Выписка: последние движения, свежие сверху.
 *
 * Посуточные начисления по одной подписке собираются в одну строку.
 * В реестре они лежат по дням — иначе не сойдутся копейки и не
 * защититься от повторного начисления, — но читать выписку, где
 * тридцать строк «День N из 30» вытесняют всё остальное, невозможно.
 */
function balanceEntries(int $sid,int $limit=60):array{
  $q=db()->prepare('SELECT b.id,b.sub_id,b.kind,b.held_kop,b.avail_kop,b.day_no,b.note,b.occurred_at,
                           s.title sub_title,s.period_days,c.name client_name
                      FROM balance_entries b
                      LEFT JOIN client_subscriptions s ON s.id=b.sub_id
                      LEFT JOIN clients c ON c.id=s.client_id
                     WHERE b.specialist_id=? ORDER BY b.id DESC LIMIT ?');
  $q->execute([$sid,max($limit*6,300)]);
  $out=[]; $daily=[];
  foreach($q->fetchAll() as $r){
    $r['held_kop']=(int)$r['held_kop']; $r['avail_kop']=(int)$r['avail_kop'];
    if($r['day_no']===null){ $out[]=['k'=>'e','r'=>$r]; continue; }
    $k=(int)$r['sub_id'];
    if(!isset($daily[$k])){ $daily[$k]=$r; $daily[$k]['days']=0; $out[]=['k'=>'d','sub'=>$k]; }
    /* Свежая запись идёт первой — её дата и есть дата всей группы. */
    $daily[$k]['held_kop']+=$r['held_kop'];
    $daily[$k]['avail_kop']+=$r['avail_kop'];
    $daily[$k]['days']++;
  }
  $res=[];
  foreach($out as $x){
    if($x['k']==='e'){ $res[]=$x['r']; continue; }
    $g=$daily[$x['sub']];
    $total=(int)($g['period_days']??0);
    $g['note']='Разморожено за '.$g['days'].' '.plural_ru($g['days'],'день','дня','дней')
              .($total?' из '.$total:'');
    unset($g['days']);
    $res[]=$g;
  }
  return array_slice($res,0,$limit);
}

function adherence7(int $cid):array{
  $pdo=db();
  $q=$pdo->prepare("SELECT COUNT(*) FROM menu_items mi JOIN menus mn ON mn.id=mi.menu_id
                    WHERE mn.id=(SELECT x.id FROM menus x WHERE x.client_id=? AND x.status='published'
                                 ORDER BY x.id DESC LIMIT 1)
                      AND date(mn.start_date,'+'||(mi.day_number-1)||' day')
                          BETWEEN date('now','-6 day') AND date('now')");
  $q->execute([$cid]); $planned=(int)$q->fetchColumn();
  $q=$pdo->prepare("SELECT SUM(status='eaten') e,COUNT(*) n FROM meal_logs
                    WHERE client_id=? AND logged_at>=datetime('now','-7 day')");
  $q->execute([$cid]); $r=$q->fetch();
  $eaten=(int)($r['e']??0); $logged=(int)($r['n']??0);
  return [
    'planned'=>$planned,'logged'=>$logged,'eaten'=>$eaten,
    'skipped'=>max(0,$logged-$eaten),
    'unlogged'=>max(0,$planned-$logged),
    'marked_pct'=>$planned>0?(int)round($logged/$planned*100):null,
    'eaten_pct'=>$planned>0?(int)round($eaten/$planned*100):null,
  ];
}
/* --- Отправка push ---------------------------------------------------
   Общая точка для API и для cron. Молча ничего не делает, если библиотека
   не установлена или ключи не созданы: push — не критичный путь, ошибка
   здесь не должна ронять основной запрос. */
/* Push в приложение идёт не тем путём, что в браузер: там протокол
   Web Push с ключами VAPID, здесь — служба Expo, которой отдают её
   собственный токен устройства. Обе подписки лежат в одной таблице и
   различаются столбцом platform. */
function expoPushSend(array $tokens,string $title,string $body,array $data=[]):void{
  $tokens=array_values(array_unique(array_filter($tokens)));
  if(!$tokens)return;
  /* Служба принимает не больше сотни сообщений за раз. */
  foreach(array_chunk($tokens,100) as $chunk){
    $msgs=array_map(fn($t)=>[
      'to'=>$t,'title'=>$title,'body'=>$body,'sound'=>'default',
      'data'=>$data,'channelId'=>'default','priority'=>'high',
    ],$chunk);
    $ch=curl_init('https://exp.host/--/api/v2/push/send');
    curl_setopt_array($ch,[
      CURLOPT_POST=>true,
      CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_TIMEOUT=>15,
      CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],
      CURLOPT_POSTFIELDS=>json_encode($msgs,JSON_UNESCAPED_UNICODE),
    ]);
    $res=curl_exec($ch);$err=curl_error($ch);curl_close($ch);
    if($res===false){error_log('expo push: '.$err);continue;}
    $j=json_decode((string)$res,true);
    $list=$j['data']??[];
    if(!is_array($list))continue;
    /* Приложение удалили или переустановили — токен мёртв навсегда,
       чистим, чтобы не стучаться в него до конца времён. */
    foreach($list as $i=>$r){
      if(($r['status']??'')==='error'&&($r['details']['error']??'')==='DeviceNotRegistered'&&isset($chunk[$i]))
        db()->prepare('DELETE FROM push_subscriptions WHERE endpoint=?')->execute([$chunk[$i]]);
      elseif(($r['status']??'')==='error')
        error_log('expo push: '.json_encode($r,JSON_UNESCAPED_UNICODE));
    }
  }
}
/* Токены приложения у одного пользователя. */
function expoTokensOf(string $type,int $uid):array{
  $q=db()->prepare("SELECT endpoint FROM push_subscriptions WHERE user_type=? AND user_id=? AND platform='expo'");
  $q->execute([$type,$uid]);
  return array_column($q->fetchAll(),'endpoint');
}
/* $screen — куда открыть приложение по нажатию на уведомление. Адрес
   $url остаётся для браузера: там свои страницы. */
/* Проверка доставки уведомлений.

   «Всё включено, ключи прописаны, а ничего не приходит» — самая
   дорогая жалоба: обрыв может быть в пяти местах, и снаружи они
   выглядят одинаково. Функция отвечает, что именно отсутствует, и
   пробует отправить одно сообщение, возвращая ответ службы. */
function pushDiag(string $type,int $uid,bool $send=false):array{
  /* Шифрование и подпись делает сам PHP через openssl — каталог vendor
     для уведомлений больше не нужен. Проверяем то, без чего не обойтись:
     расширение openssl с нужной кривой. */
  $r=['openssl'=>vapidBlocker()===''?true:vapidBlocker(),
      'keys'=>false,'web'=>0,'expo'=>0,'sent'=>null,'errors'=>[]];
  $v=vapidKeys();
  $r['keys']=!empty($v['publicKey'])&&!empty($v['privateKey']);
  if($r['openssl']!==true)$r['errors'][]='На сервере '.$r['openssl'].' — уведомления отправлять нечем.';
  $q=db()->prepare("SELECT COALESCE(platform,'web') pf,COUNT(*) n FROM push_subscriptions
                    WHERE user_type=? AND user_id=? GROUP BY pf");
  $q->execute([$type,$uid]);
  foreach($q->fetchAll() as $row){
    if($row['pf']==='expo')$r['expo']=(int)$row['n']; else $r['web']+=(int)$row['n'];
  }
  if(!$send)return $r;
  if(!$r['web']&&!$r['expo']){$r['errors'][]='Нет ни одной подписки: уведомления не включены на этом устройстве.';return $r;}
  if($r['expo'])expoPushSend(expoTokensOf($type,$uid),'Проверка EQUA','Если вы видите это — уведомления работают.',['url'=>'/app/']);
  if($r['web']){
    if(!$r['keys']){$r['errors'][]='Не удалось создать ключи VAPID.';return $r;}
    try{
      $q=db()->prepare("SELECT * FROM push_subscriptions WHERE user_type=? AND user_id=? AND COALESCE(platform,'web')='web'");
      $q->execute([$type,$uid]);
      $payload=json_encode(['title'=>'Проверка EQUA','body'=>'Если вы видите это — уведомления работают.',
                            'url'=>'/app/','tag'=>'diag'],JSON_UNESCAPED_UNICODE);
      $ok=0;
      foreach($q->fetchAll() as $sub){
        $code=webPushSendRaw($sub['endpoint'],$sub['p256dh'],$sub['auth'],$payload,$v,pushSubject());
        if($code>=200&&$code<300){$ok++;continue;}
        if($code===400||$code===404||$code===410){
          $r['errors'][]='Одна подписка устарела и убрана — это старое устройство или прежняя установка.';
          db()->prepare('DELETE FROM push_subscriptions WHERE endpoint=?')->execute([$sub['endpoint']]);
        }elseif($code===403){
          $r['errors'][]='Служба отклонила подпись (403). Подписка на этом устройстве '
                        .'сделана под другой ключ — нажмите «Включить уведомления» ещё раз.';
          db()->prepare('DELETE FROM push_subscriptions WHERE endpoint=?')->execute([$sub['endpoint']]);
        }else $r['errors'][]='Служба доставки ответила кодом '.$code.'.';
      }
      $r['sent']=$ok;
    }catch(Throwable $e){$r['errors'][]=$e->getMessage();}
  }
  return $r;
}

function pushSend(string $type,int $uid,string $title,string $body,string $url='/app/',string $tag='nutrimenu',string $screen=''):void{
  /* Приложению ни ключи, ни шифрование не нужны — его уведомления
     уходят через Expo, поэтому шлём их первыми. */
  expoPushSend(expoTokensOf($type,$uid),$title,$body,
    ['url'=>$url,'tag'=>$tag,'screen'=>$screen?:($type==='specialist'?'/sp':'/client')]);
  try{
    $v=vapidKeys();
    if(empty($v['publicKey'])||empty($v['privateKey']))return;
    $q=db()->prepare("SELECT * FROM push_subscriptions WHERE user_type=? AND user_id=? AND COALESCE(platform,'web')='web'");
    $q->execute([$type,$uid]);$rows=$q->fetchAll();
    if(!$rows)return;
    $payload=json_encode(['title'=>$title,'body'=>$body,'url'=>$url,'tag'=>$tag],JSON_UNESCAPED_UNICODE);
    $subject=pushSubject();
    foreach($rows as $sub){
      $code=webPushSendRaw($sub['endpoint'],$sub['p256dh'],$sub['auth'],$payload,$v,$subject);
      /* Отписку браузер сообщает кодом 404 или 410 — чистим, чтобы не
         долбиться в мёртвый адрес до конца времён. */
      /* 400, 404 и 410 службы отдают на подписку, которой больше нет:
         устройство стёрло её или переустановило приложение. Держать
         такой адрес незачем — он даёт ошибку на каждой отправке. */
      if($code===400||$code===404||$code===410)
        db()->prepare('DELETE FROM push_subscriptions WHERE endpoint=?')->execute([$sub['endpoint']]);
    }
  }catch(Throwable $e){error_log('push: '.$e->getMessage());}
}

/* ======================================================================
   ВХОД ЧЕРЕЗ APPLE, GOOGLE И VK
   Обмен кодом идёт на сервере, а не в приложении: секрет провайдера не
   должен уезжать на устройство, и один и тот же путь работает и для
   браузера, и для приложения. Ключи лежат в config/oauth.php — если его
   нет или поля пустые, провайдер просто не показывается.
   ====================================================================== */

function oauthConfig():array{
  static $c=null;
  if($c===null){$f=__DIR__.'/oauth.php';$c=is_file($f)?(require $f):[];if(!is_array($c))$c=[];}
  return $c;
}

/** Провайдер настроен, если заполнено всё, без чего обмен кодом невозможен. */
function oauthReady(string $p):bool{
  $c=oauthConfig()[$p]??[];
  $need=['google'=>['client_id','client_secret'],
         'vk'=>['client_id'],
         'apple'=>['client_id','team_id','key_id','private_key']];
  foreach($need[$p]??['client_id'] as $k) if(empty($c[$k])) return false;
  return true;
}

/** Список готовых провайдеров — его и показывают приложение и сайт. */
function oauthProviders():array{
  return array_values(array_filter(['apple','google','vk'],'oauthReady'));
}

function oauthRedirectUri(string $provider):string{
  return selfOrigin().'/api/v1/auth/oauth/'.$provider.'/callback';
}

/** Куда вернуть пользователя. Список закрытый: свободный адрес в параметре
    позволил бы увести чужой токен на посторонний сайт. */
function oauthTarget(string $key):?string{
  if($key===''||$key==='web')return selfOrigin().'/app/';
  $t=oauthConfig()['targets']??[];
  if(isset($t[$key]))return (string)$t[$key];
  /* Приложение присылает свой адрес целиком: у Expo Go он свой на каждой
     машине. Принимаем только то, что уже перечислено в настройках. */
  return in_array($key,array_map('strval',array_values($t)),true)?$key:null;
}

function base64url(string $b):string{return rtrim(strtr(base64_encode($b),'+/','-_'),'=');}

/** Полезная нагрузка id_token. Подпись не проверяем: токен получен прямо
    от провайдера по TLS в ответ на обмен кодом, посредника здесь нет. */
function jwtPayload(string $jwt):array{
  $p=explode('.',$jwt);
  if(count($p)<2)return [];
  $j=json_decode(base64_decode(strtr($p[1],'-_','+/')) ?: '[]',true);
  return is_array($j)?$j:[];
}

/** Секрет Apple — это подписанный ES256 токен, а не строка из кабинета. */
function appleClientSecret():string{
  $c=oauthConfig()['apple']??[];
  $head=base64url(json_encode(['alg'=>'ES256','kid'=>$c['key_id'],'typ'=>'JWT']));
  $now=time();
  $body=base64url(json_encode([
    'iss'=>$c['team_id'],'iat'=>$now,'exp'=>$now+3600,
    'aud'=>'https://appleid.apple.com','sub'=>$c['client_id'],
  ]));
  $key=openssl_pkey_get_private((string)$c['private_key']);
  if(!$key)throw new RuntimeException('Apple: не читается приватный ключ');
  $der='';
  if(!openssl_sign($head.'.'.$body,$der,$key,OPENSSL_ALGO_SHA256))
    throw new RuntimeException('Apple: не удалось подписать секрет');
  /* openssl отдаёт подпись в DER, а JOSE ждёт 64 байта R||S подряд */
  $sig=derToRawSignature($der,32);
  return $head.'.'.$body.'.'.base64url($sig);
}

function derToRawSignature(string $der,int $part):string{
  $o=0;
  if(ord($der[$o++])!==0x30)throw new RuntimeException('Подпись: не DER');
  if(ord($der[$o])>0x80)$o+=ord($der[$o])-0x80;
  $o++;
  $read=function() use ($der,&$o,$part){
    if(ord($der[$o++])!==0x02)throw new RuntimeException('Подпись: нет INTEGER');
    $len=ord($der[$o++]);
    $v=substr($der,$o,$len);$o+=$len;
    $v=ltrim($v,"\x00");
    return str_pad($v,$part,"\x00",STR_PAD_LEFT);
  };
  return $read().$read();
}

function httpPostForm(string $url,array $fields,array $headers=[]):array{
  $ch=curl_init($url);
  curl_setopt_array($ch,[
    CURLOPT_POST=>true,
    CURLOPT_POSTFIELDS=>http_build_query($fields),
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_TIMEOUT=>15,
    CURLOPT_HTTPHEADER=>array_merge(['Content-Type: application/x-www-form-urlencoded'],$headers),
  ]);
  $body=curl_exec($ch);
  if($body===false){$e=curl_error($ch);curl_close($ch);throw new RuntimeException('Сеть: '.$e);}
  curl_close($ch);
  $j=json_decode((string)$body,true);
  return is_array($j)?$j:[];
}

/** Адрес, куда отправляем пользователя за согласием. */
function oauthAuthorizeUrl(string $provider,string $state,string $verifier):string{
  $c=oauthConfig()[$provider];
  $redirect=oauthRedirectUri($provider);
  if($provider==='google')
    return 'https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query([
      'client_id'=>$c['client_id'],'redirect_uri'=>$redirect,'response_type'=>'code',
      'scope'=>'openid email profile','state'=>$state,'prompt'=>'select_account']);
  if($provider==='vk')
    return 'https://id.vk.ru/authorize?'.http_build_query([
      'client_id'=>$c['client_id'],'redirect_uri'=>$redirect,'response_type'=>'code',
      'scope'=>'email','state'=>$state,
      'code_challenge'=>base64url(hash('sha256',$verifier,true)),
      'code_challenge_method'=>'S256']);
  /* Apple отвечает POST-ом формы: иначе почта и имя до нас не доедут */
  return 'https://appleid.apple.com/auth/authorize?'.http_build_query([
    'client_id'=>$c['client_id'],'redirect_uri'=>$redirect,'response_type'=>'code',
    'scope'=>'name email','response_mode'=>'form_post','state'=>$state]);
}

/** Обмен кода на профиль: [uid, email, name]. */
function oauthFetchProfile(string $provider,string $code,array $st,array $req):array{
  $c=oauthConfig()[$provider];
  $redirect=oauthRedirectUri($provider);

  if($provider==='google'){
    $r=httpPostForm('https://oauth2.googleapis.com/token',[
      'code'=>$code,'client_id'=>$c['client_id'],'client_secret'=>$c['client_secret'],
      'redirect_uri'=>$redirect,'grant_type'=>'authorization_code']);
    if(empty($r['id_token']))throw new RuntimeException('Google не выдал токен');
    $p=jwtPayload($r['id_token']);
    return [(string)($p['sub']??''),(string)($p['email']??''),trim((string)($p['name']??''))];
  }

  if($provider==='vk'){
    $r=httpPostForm('https://id.vk.ru/oauth2/auth',array_filter([
      'grant_type'=>'authorization_code','code'=>$code,'code_verifier'=>$st['verifier'],
      'client_id'=>$c['client_id'],'client_secret'=>$c['client_secret']??null,
      'device_id'=>(string)($req['device_id']??''),'redirect_uri'=>$redirect,
      'state'=>$st['state']]));
    if(empty($r['access_token']))throw new RuntimeException('VK не выдал токен');
    $u=httpPostForm('https://id.vk.ru/oauth2/user_info',[
      'client_id'=>$c['client_id'],'access_token'=>$r['access_token']]);
    $x=$u['user']??[];
    $name=trim(((string)($x['first_name']??'')).' '.((string)($x['last_name']??'')));
    return [(string)($x['user_id']??''),(string)($x['email']??''),$name];
  }

  $r=httpPostForm('https://appleid.apple.com/auth/token',[
    'client_id'=>$c['client_id'],'client_secret'=>appleClientSecret(),
    'code'=>$code,'grant_type'=>'authorization_code','redirect_uri'=>$redirect]);
  if(empty($r['id_token']))throw new RuntimeException('Apple не выдал токен');
  $p=jwtPayload($r['id_token']);
  /* Имя Apple присылает один раз, вместе с формой возврата */
  $name='';
  if(!empty($req['user'])){$u=json_decode((string)$req['user'],true);
    if(is_array($u))$name=trim(((string)($u['name']['firstName']??'')).' '.((string)($u['name']['lastName']??'')));}
  return [(string)($p['sub']??''),(string)($p['email']??''),$name];
}

/* Откуда пришёл клиент к специалисту: из каталога, по приглашению или
   сам. Нужна и маршрутам, и входу из Telegram, поэтому живёт здесь, а
   не в api/index.php, где её не видно ни планировщику, ни проверкам. */
function attributeClient(int $clientId,int $specialistId,string $source,?int $leadId=null):void{
  if($clientId<=0||$specialistId<=0)return;
  if(!in_array($source,['catalog','invite','self','unknown'],true))$source='unknown';
  db()->prepare('INSERT OR IGNORE INTO client_attribution(client_id,specialist_id,source,lead_id,linked_at) VALUES(?,?,?,?,?)')
     ->execute([$clientId,$specialistId,$source,$leadId,now()]);
}

/* ======================================================================
   Вход из Telegram Mini App.

   Telegram отдаёт странице подписанную строку initData. Подпись —
   HMAC-SHA256 по отсортированным полям, ключ считается из токена бота.
   Проверять её обязательно: initData приходит из браузера, и человек
   волен прислать туда что угодно, включая чужой telegram_id.

   Дальше вход идёт через тот же oauthSignIn, что у Google и VK: там уже
   разобрано, как найти существующего человека и как завести нового.
   Telegram отличается одним — он не даёт почты, и это нормально:
   oauthSignIn заводит клиента и с пустым адресом.
   ================================================================== */
function telegramConfig():array{
  static $c;
  if($c===null){
    $f=__DIR__.'/telegram.php';
    $c=is_file($f)?(array)require $f:[];
    $c+=['bot_token'=>'','bot_name'=>''];
    /* Откуда взялся токен — видно в панели: иначе владелец правит поле,
       а работает всё равно файл, и понять это неоткуда. */
    $c['source']=$c['bot_token']!==''?'file':'';
    /* Токен можно держать и в настройках: на хостинге без SSH класть
       файл рядом с config неудобно. Файл важнее — он не уедет с базой. */
    if($c['bot_token']===''){
      $c['bot_token']=(string)(settingGet('tg_bot_token')??'');
      if($c['bot_token']!=='')$c['source']='settings';
    }
    if($c['bot_name']==='') $c['bot_name'] =(string)(settingGet('tg_bot_name')??'');
  }
  return $c;
}
function telegramReady():bool{ return telegramConfig()['bot_token']!==''; }

/**
 * Разобрать и проверить initData.
 *
 * Вернёт поля (user, start_param, auth_date) или null, если подпись не
 * сходится. Возраст подписи ограничиваем сутками: украденная строка не
 * должна работать вечно.
 */
function telegramVerify(string $initData,?string $botToken=null,int $maxAge=86400):?array{
  $token=$botToken??telegramConfig()['bot_token'];
  if($token===''||$initData==='')return null;

  parse_str($initData,$fields);
  if(!is_array($fields)||empty($fields['hash']))return null;
  $hash=(string)$fields['hash'];
  unset($fields['hash']);

  /* Подписывается не исходная строка, а поля, склеенные по алфавиту:
     порядок в запросе Telegram не гарантирует. */
  ksort($fields);
  $pairs=[];
  foreach($fields as $k=>$v)$pairs[]=$k.'='.(is_array($v)?json_encode($v):(string)$v);
  $check=implode("\n",$pairs);

  $secret=hash_hmac('sha256',$token,'WebAppData',true);
  $calc=hash_hmac('sha256',$check,$secret);
  if(!hash_equals($calc,$hash))return null;

  $age=time()-(int)($fields['auth_date']??0);
  if($maxAge>0&&($age<-300||$age>$maxAge))return null;   // и из будущего тоже не берём

  $user=[];
  if(!empty($fields['user'])){
    $u=json_decode((string)$fields['user'],true);
    if(is_array($u))$user=$u;
  }
  if(empty($user['id']))return null;
  return [
    'user'=>$user,
    'start_param'=>(string)($fields['start_param']??''),
    'auth_date'=>(int)($fields['auth_date']??0),
  ];
}

/** Имя человека из полей Telegram: фамилия есть не у всех, username — тоже. */
function telegramName(array $u):string{
  $n=trim(((string)($u['first_name']??'')).' '.((string)($u['last_name']??'')));
  if($n==='')$n=(string)($u['username']??'');
  return $n!==''?$n:'Новый клиент';
}

/**
 * Привязка к специалисту по ссылке вида t.me/bot?startapp=spec_12.
 *
 * Это главное, ради чего Mini App вообще имеет смысл: человек приходит
 * по ссылке от специалиста и оказывается у него сразу, без регистрации
 * и без пароля. Уже привязанного не трогаем — чужая ссылка не должна
 * уводить клиента у его специалиста.
 */
function telegramStartLink(string $param,int $clientId):?array{
  if($param==='')return null;
  $pdo=db();
  $cur=(int)fetchOne($pdo,'SELECT COALESCE(specialist_id,0) FROM clients WHERE id=?',[$clientId]);
  if($cur)return null;

  $sp=null;
  if(preg_match('/^spec[_-](\d+)$/i',$param,$m)){
    $q=$pdo->prepare('SELECT id,name FROM specialists WHERE id=?');
    $q->execute([(int)$m[1]]); $sp=$q->fetch()?:null;
  }elseif(preg_match('/^code[_-]([A-Za-z0-9]{3,32})$/',$param,$m)){
    $q=$pdo->prepare('SELECT id,name FROM specialists WHERE UPPER(join_code)=?');
    $q->execute([strtoupper($m[1])]); $sp=$q->fetch()?:null;
  }
  if(!$sp)return null;

  $pdo->prepare('UPDATE clients SET specialist_id=? WHERE id=?')->execute([(int)$sp['id'],$clientId]);
  attributeClient($clientId,(int)$sp['id'],'invite');
  return $sp;
}

/** Находим или заводим пользователя и выдаём сессию. */
function oauthSignIn(string $provider,string $uid,string $email,string $name):array{
  $pdo=db();
  if($uid==='')throw new RuntimeException('Провайдер не вернул идентификатор');

  $q=$pdo->prepare('SELECT * FROM oauth_identities WHERE provider=? AND provider_uid=?');
  $q->execute([$provider,$uid]);
  $link=$q->fetch();

  if($link){$type=(string)$link['user_type'];$id=(int)$link['user_id'];}
  else{
    $type=null;$id=0;
    /* Тот же email — тот же человек: привязываем к существующей учётке,
       иначе у него окажется два аккаунта с разными меню. */
    if($email!==''){
      foreach(['specialist'=>'specialists','client'=>'clients'] as $t=>$table){
        $f=$pdo->prepare("SELECT id FROM $table WHERE email=?");$f->execute([$email]);
        if($row=$f->fetch()){$type=$t;$id=(int)$row['id'];break;}
      }
    }
    if(!$type){
      $type='client';
      $pdo->prepare('INSERT INTO clients(specialist_id,name,email,sex,height_cm,weight_kg,goal,target_kcal,target_protein,target_fat,target_carbs,status,created_at) VALUES(NULL,?,?,NULL,NULL,NULL,?,?,?,?,?,?,?)')
          ->execute([$name!==''?$name:'Новый клиент',$email!==''?$email:null,'Поддержание',1800,110,60,190,'active',now()]);
      $id=(int)$pdo->lastInsertId();
    }
    $pdo->prepare('INSERT INTO oauth_identities(provider,provider_uid,user_type,user_id,email,created_at) VALUES(?,?,?,?,?,?)')
        ->execute([$provider,$uid,$type,$id,$email!==''?$email:null,now()]);
  }

  $row=$pdo->prepare($type==='specialist'?'SELECT * FROM specialists WHERE id=?':'SELECT * FROM clients WHERE id=?');
  $row->execute([$id]);$u=$row->fetch();
  if(!$u)throw new RuntimeException('Учётная запись не найдена');
  if(($u['status']??'active')==='blocked')throw new RuntimeException('Доступ приостановлен');

  $t=sessionStart($type,$id);
  return ['token'=>$t,'user_type'=>$type,'user_id'=>$id,'name'=>(string)$u['name']];
}


/* --- Удаление учётной записи ------------------------------------------
   Требование App Store: удалить аккаунт можно из самого приложения, и
   удаление должно быть настоящим. Связанные записи уходят каскадом, а
   вот файлы на диске и таблицы, где связь хранится парой «тип + id»,
   каскад не видит — их убираем руками. */

/** Файлы вложений и фотографий с диска. Путь всегда наш, но проверяем. */
function dropUploads(array $urls):void{
  $dir=realpath(__DIR__.'/../storage/uploads');
  if(!$dir)return;
  foreach($urls as $u){
    $u=(string)$u; if($u==='')continue;
    $f=realpath($dir.'/'.basename($u));
    if($f && str_starts_with($f,$dir) && is_file($f)) @unlink($f);
  }
}

function deleteClientAccount(int $cid):void{
  $p=db();
  $files=[];
  foreach(['SELECT photo_url u FROM progress_photos WHERE client_id=?',
           'SELECT attachment_url u FROM messages WHERE client_id=? AND attachment_url IS NOT NULL',
           /* Анализы — данные о здоровье: файлы должны уйти с диска
              вместе с аккаунтом, а не остаться лежать без владельца. */
           'SELECT file_url u FROM client_labs WHERE client_id=? AND file_url IS NOT NULL',
           'SELECT avatar_url u FROM clients WHERE id=?'] as $sql){
    $q=$p->prepare($sql);$q->execute([$cid]);
    foreach($q->fetchAll() as $r) if(!empty($r['u'])) $files[]=$r['u'];
  }
  $p->beginTransaction();
  try{
    foreach(['sessions','push_subscriptions','notification_preferences','oauth_identities'] as $t)
      $p->prepare("DELETE FROM $t WHERE user_type='client' AND user_id=?")->execute([$cid]);
    /* Всё остальное подвязано к clients каскадом */
    $p->prepare('DELETE FROM clients WHERE id=?')->execute([$cid]);
    $p->commit();
  }catch(Throwable $e){ if($p->inTransaction())$p->rollBack(); throw $e; }
  dropUploads($files);
}

function deleteSpecialistAccount(int $sid):void{
  $p=db();
  $files=[];
  $q=$p->prepare('SELECT avatar_url u FROM specialists WHERE id=?');$q->execute([$sid]);
  foreach($q->fetchAll() as $r) if(!empty($r['u'])) $files[]=$r['u'];
  $p->beginTransaction();
  try{
    /* Клиентов не трогаем: это их данные и их аккаунты. Они просто
       остаются без специалиста и могут выбрать другого. */
    $p->prepare('UPDATE clients SET specialist_id=NULL WHERE specialist_id=?')->execute([$sid]);
    foreach(['sessions','push_subscriptions','notification_preferences','oauth_identities'] as $t)
      $p->prepare("DELETE FROM $t WHERE user_type='specialist' AND user_id=?")->execute([$sid]);
    /* Блюда каталога переживают автора: они уже стоят в чужих меню */
    $p->prepare('UPDATE dishes SET created_by=NULL WHERE created_by=?')->execute([$sid]);
    $p->prepare('DELETE FROM specialists WHERE id=?')->execute([$sid]);
    $p->commit();
  }catch(Throwable $e){ if($p->inTransaction())$p->rollBack(); throw $e; }
  dropUploads($files);
}

/* ---------------------------------------------------------------
   Почта. Нужна ровно для одного письма — ссылки на смену пароля.
   Настройки лежат в config/mail.php (рядом есть mail.sample.php).
   Пустой host означает «отдать письмо функции mail() хостинга»:
   так работает из коробки, но письма чаще уходят в спам.
   --------------------------------------------------------------- */
function mailConfig():array{
  static $c;
  if($c===null){
    $f=__DIR__.'/mail.php';
    $c=is_file($f)?(array)require $f:[];
    $c+=['from'=>'','from_name'=>APP_NAME,'host'=>'','port'=>465,'security'=>'ssl','username'=>'','password'=>'','site_url'=>''];
    if($c['from']==='')$c['from']=$c['username']?:('no-reply@'.($_SERVER['HTTP_HOST']??'localhost'));
  }
  return $c;
}
/**
 * Настроена ли отправка почты по-настоящему.
 *
 * Пустой host — это «отдать письмо функции mail() хостинга»: иногда так
 * работает, но на shared-хостинге чаще молча не уходит никуда. Считаем
 * почту настроенной, только когда указан SMTP-сервер: обещать человеку
 * письмо, которого не будет, хуже, чем честно сказать, что его нет.
 */
function mailReady():bool{
  $c=mailConfig();
  return $c['host']!=='' && $c['username']!=='';
}

/* ======================================================================
   Ключи VAPID для push-уведомлений.

   Лежат в storage/vapid.php, а не в .json. Разница не косметическая:
   .json отдаётся веб-сервером как обычный файл, и если .htaccess
   почему-то не сработает — сменили хостинг, перешли на nginx, — то
   приватный ключ прочитает кто угодно, а с ним можно слать
   уведомления от имени сервиса. PHP-файл в том же случае отдаёт
   пустоту: он исполняется, а не показывается.

   Прежние установки с vapid.json продолжают работать: файл читается,
   но при первой же возможности переписывается в .php.
   ====================================================================== */
/* Ключи создаются сами при первом обращении.

   Раньше их надо было завести руками в панели владельца, и пока этого
   никто не сделал, приложение молча не подписывалось на уведомления:
   `/public/config` отдавал пустой ключ, кнопка «Включить» отвечала
   «push пока не настроен», а владелец видел исправно включённые
   переключатели и не понимал, почему тихо. Пара ключей — обычный ключ
   на кривой P-256, для неё не нужно ни библиотеки, ни настроек. */
function vapidKeys(bool $create=true):?array{
  $k=vapidRead();
  if($k||!$create)return $k;
  $new=vapidCreate();
  return vapidSave($new)?$new:null;
}
function vapidRead():?array{
  $dir=__DIR__.'/../storage';
  $php=$dir.'/vapid.php';
  if(is_file($php)){ $k=(array)require $php; return isset($k['publicKey'])?$k:null; }
  /* Запасное место — база. На части хостингов storage закрыт на запись,
     и ключи там завести негде. */
  $k=settingGet('vapid');
  if($k){ $k=json_decode($k,true); if(is_array($k)&&isset($k['publicKey']))return $k; }
  $json=$dir.'/vapid.json';
  if(is_file($json)){
    $k=json_decode((string)file_get_contents($json),true);
    if(is_array($k)&&isset($k['publicKey'])){
      /* Переносим в защищённый вид молча: владельцу об этом думать не надо. */
      if(vapidSave($k)) @unlink($json);
      return $k;
    }
  }
  return null;
}

/* --- Создание ключей ---------------------------------------------------
   Пара VAPID — это обычный ключ на кривой P-256. Раньше её делала
   библиотека web-push, и когда на хостинге чего-то не хватало, вызов
   падал молча, а владелец видел «Ошибка сервера». Делаем сами, на голом
   openssl: меньше движущихся частей и внятная причина отказа.

   Публичный ключ — несжатая точка 0x04‖X‖Y, приватный — число D.
   Оба в base64url без выравнивания: ровно в таком виде их ждут браузеры. */
function b64u(string $bin):string{ return rtrim(strtr(base64_encode($bin),'+/','-_'),'='); }

/* ======================================================================
   ОТПРАВКА БРАУЗЕРНЫХ УВЕДОМЛЕНИЙ БЕЗ БИБЛИОТЕКИ

   Библиотека web-push — это 900 файлов в каталоге vendor, и на
   боевом сервере его раз за разом не оказывалось: уведомления при этом
   молча не уходили. Всё, что нужно для доставки, умеет сам PHP с
   openssl, поэтому отправка живёт здесь и работает без vendor.

   Устройство ровно такое, как описано в RFC 8291 и RFC 8188:
   общий секрет по Диффи — Хеллману на кривой P-256, из него HKDF
   выводит ключ и одноразовое число, тело шифруется AES-128-GCM,
   а запрос подписывается ключом VAPID (JWT с алгоритмом ES256).
   ====================================================================== */
function b64ud(string $s):string{
  return (string)base64_decode(strtr($s,'-_','+/').str_repeat('=',(4-strlen($s)%4)%4));
}
/* Ключи P-256 из «сырых» чисел в формат, понятный openssl. Длины в
   заголовках постоянные, поэтому шаблон собирается без разбора ASN.1. */
function ecPublicPem(string $point65):string{
  $der="\x30\x59\x30\x13\x06\x07\x2a\x86\x48\xce\x3d\x02\x01"
      ."\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07\x03\x42\x00".$point65;
  return "-----BEGIN PUBLIC KEY-----\n".chunk_split(base64_encode($der),64,"\n")."-----END PUBLIC KEY-----\n";
}
function ecPrivatePem(string $d32,string $point65):string{
  $inner="\x30\x6b\x02\x01\x01\x04\x20".$d32."\xa1\x44\x03\x42\x00".$point65;
  $der="\x30\x81\x87\x02\x01\x00\x30\x13\x06\x07\x2a\x86\x48\xce\x3d\x02\x01"
      ."\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07\x04\x6d".$inner;
  return "-----BEGIN PRIVATE KEY-----\n".chunk_split(base64_encode($der),64,"\n")."-----END PRIVATE KEY-----\n";
}
/* Подпись ES256: openssl отдаёт её в ASN.1, а JWT ждёт две части по
   32 байта подряд. */
function derToRawSig(string $der):string{
  $o=0;
  if(($der[$o++]??'')!=="\x30")return '';
  $len=ord($der[$o++]??"\0"); if($len&0x80){$n=$len&0x7f;$o+=$n;}
  $take=function() use ($der,&$o){
    if(($der[$o++]??'')!=="\x02")return '';
    $l=ord($der[$o++]??"\0");$v=substr($der,$o,$l);$o+=$l;
    $v=ltrim($v,"\0");
    return str_pad($v,32,"\0",STR_PAD_LEFT);
  };
  $r=$take();$s=$take();
  return (strlen($r)===32&&strlen($s)===32)?$r.$s:'';
}
function vapidJwt(string $aud,array $keys,string $subject):string{
  $head=b64u(json_encode(['typ'=>'JWT','alg'=>'ES256']));
  $body=b64u(json_encode(['aud'=>$aud,'exp'=>time()+43200,'sub'=>$subject],JSON_UNESCAPED_SLASHES));
  $pem=ecPrivatePem(b64ud($keys['privateKey']),b64ud($keys['publicKey']));
  $pk=openssl_pkey_get_private($pem);
  if(!$pk)throw new RuntimeException('не удалось прочитать ключ VAPID');
  $sig='';
  if(!openssl_sign($head.'.'.$body,$sig,$pk,OPENSSL_ALGO_SHA256))
    throw new RuntimeException('не удалось подписать запрос');
  $raw=derToRawSig($sig);
  if($raw==='')throw new RuntimeException('подпись неожиданного вида');
  return $head.'.'.$body.'.'.b64u($raw);
}
/* Шифрование тела по схеме aes128gcm. Возвращает готовое тело запроса. */
function webPushEncrypt(string $payload,string $p256dh,string $auth):array{
  $uaPub=b64ud($p256dh);            // 65 байт, точка на кривой
  $authSecret=b64ud($auth);         // 16 байт
  if(strlen($uaPub)!==65||strlen($authSecret)<16)
    throw new RuntimeException('подписка повреждена');
  /* Своя пара на один запрос: её открытая часть уедет в заголовке. */
  $me=openssl_pkey_new(['curve_name'=>'prime256v1','private_key_type'=>OPENSSL_KEYTYPE_EC]);
  if(!$me)throw new RuntimeException('openssl не создал ключ');
  $d=openssl_pkey_get_details($me);
  $pad=fn(string $v)=>str_pad($v,32,"\0",STR_PAD_LEFT);
  $asPub="\x04".$pad($d['ec']['x']).$pad($d['ec']['y']);
  $shared=openssl_pkey_derive(ecPublicPem($uaPub),$me,32);
  if(!$shared)throw new RuntimeException('не удалось согласовать ключ');
  /* Из общего секрета выводим ключ шифрования и одноразовое число. */
  $prk=hash_hkdf('sha256',$shared,32,"WebPush: info\x00".$uaPub.$asPub,$authSecret);
  $salt=random_bytes(16);
  $cek =hash_hkdf('sha256',$prk,16,"Content-Encoding: aes128gcm\x00",$salt);
  $nonce=hash_hkdf('sha256',$prk,12,"Content-Encoding: nonce\x00",$salt);
  /* 0x02 — признак последней записи, так требует формат. */
  $tag='';
  $ct=openssl_encrypt($payload."\x02",'aes-128-gcm',$cek,OPENSSL_RAW_DATA,$nonce,$tag,'',16);
  if($ct===false)throw new RuntimeException('не удалось зашифровать');
  $body=$salt.pack('N',4096).chr(strlen($asPub)).$asPub.$ct.$tag;
  return ['body'=>$body];
}
/* Кто отправляет — этим полем службы доставки определяют владельца
   ключа. Apple отклоняет несуществующие домены, а в настройках по
   умолчанию стоит owner@nutrimenu.local: с ним подпись не принималась
   и ответ приходил кодом 403. Адрес сайта в этом поле допустим по той
   же спецификации и всегда настоящий. */
function pushSubject():string{
  $site=siteUrl();
  if(preg_match('~^https://[^/]+\.[a-z]{2,}~i',$site))return $site;
  $mail=(string)OWNER_EMAIL;
  return preg_match('~^[^@\s]+@[^@\s]+\.[a-z]{2,}$~i',$mail)?'mailto:'.$mail:'https://nutrimenu.ru';
}

/* Отправка одной подписке. Возвращает код ответа службы. */
function webPushSendRaw(string $endpoint,string $p256dh,string $auth,string $payload,
                        array $keys,string $subject,int $ttl=300):int{
  $enc=webPushEncrypt($payload,$p256dh,$auth);
  $p=parse_url($endpoint);
  $aud=($p['scheme']??'https').'://'.($p['host']??'');
  $jwt=vapidJwt($aud,$keys,$subject);
  $ch=curl_init($endpoint);
  curl_setopt_array($ch,[
    CURLOPT_POST=>true,
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_TIMEOUT=>15,
    CURLOPT_HTTPHEADER=>[
      'Content-Type: application/octet-stream',
      'Content-Encoding: aes128gcm',
      'TTL: '.$ttl,
      'Urgency: high',
      'Authorization: vapid t='.$jwt.',k='.$keys['publicKey'],
    ],
    CURLOPT_POSTFIELDS=>$enc['body'],
  ]);
  $res=curl_exec($ch);
  $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
  $err=curl_error($ch);
  curl_close($ch);
  if($res===false){error_log('push: '.$err);return 0;}
  if($code>=400&&$code!==404&&$code!==410)
    error_log('push '.$code.': '.mb_substr((string)$res,0,200));
  return $code;
}

/* Настройки парами «ключ — значение». */
function settingGet(string $k):?string{
  try{ $q=db()->prepare('SELECT value FROM app_settings WHERE key=?');$q->execute([$k]);
       $v=$q->fetchColumn(); return $v===false?null:(string)$v; }
  catch(Throwable $e){ return null; }
}
function settingSet(string $k,string $v):bool{
  try{ db()->prepare('INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?)
        ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at')
        ->execute([$k,$v,now()]); return true; }
  catch(Throwable $e){ error_log('settingSet: '.$e->getMessage()); return false; }
}

function vapidCreate():array{
  if(!function_exists('openssl_pkey_new'))
    throw new RuntimeException('На сервере нет расширения openssl — без него ключи не создать. Включите его в панели хостинга.');
  $res=@openssl_pkey_new(['curve_name'=>'prime256v1','private_key_type'=>OPENSSL_KEYTYPE_EC]);
  if(!$res){
    $curves=function_exists('openssl_get_curve_names')?openssl_get_curve_names():[];
    throw new RuntimeException(in_array('prime256v1',(array)$curves,true)
      ? 'openssl отказался создать ключ: '.(openssl_error_string()?:'причина не указана')
      : 'openssl на этом сервере собран без кривой prime256v1 — попросите хостинг обновить сборку.');
  }
  $d=openssl_pkey_get_details($res);
  if(!isset($d['ec']['x'],$d['ec']['y'],$d['ec']['d']))
    throw new RuntimeException('openssl не отдал части ключа — нужен PHP 7.1 или новее со свежим openssl.');
  /* Части могут прийти короче 32 байт — дополняем нулями слева,
     иначе браузер не примет подписку. */
  $pad=fn(string $v)=>str_pad($v,32,"\0",STR_PAD_LEFT);
  return [
    'publicKey' =>b64u("\x04".$pad($d['ec']['x']).$pad($d['ec']['y'])),
    'privateKey'=>b64u($pad($d['ec']['d'])),
  ];
}

/** Чего не хватает для push. Пустая строка — всё на месте. */
function vapidBlocker():string{
  if(!function_exists('openssl_pkey_new'))return 'нет расширения openssl';
  if(function_exists('openssl_get_curve_names')&&!in_array('prime256v1',(array)openssl_get_curve_names(),true))
    return 'openssl без кривой prime256v1';
  return '';
}

/** Записать ключи. Возвращает false, если папка недоступна на запись. */
function vapidSave(array $keys):bool{
  $dir=__DIR__.'/../storage';
  if(!is_dir($dir)&&!@mkdir($dir,0775,true))return false;
  $body="<?php\n/* Ключи VAPID для push. Не редактируйте руками: публичный ключ\n"
       ."   знают браузеры подписчиков, и его смена отключает все подписки. */\n"
       ."return ".var_export($keys,true).";\n";
  $file=$dir.'/vapid.php';
  if(!@file_put_contents($file,$body))
    /* Каталог закрыт на запись — кладём в базу, она пишется всегда. */
    return settingSet('vapid',json_encode($keys));
  /* Файл исполняемый, а значит его держит opcache. Без сброса сервер
     ещё долго отдавал бы прежний публичный ключ — подписки при этом
     уже удалены, и уведомления не ушли бы ни старые, ни новые. */
  if(function_exists('opcache_invalidate'))@opcache_invalidate($file,true);
  clearstatcache(true,$file);
  return true;
}

/* Адрес сайта для ссылок в письме: из настроек, иначе из самого запроса. */
function siteUrl():string{
  $c=mailConfig();
  if($c['site_url']!=='')return rtrim($c['site_url'],'/');
  if(APP_URL!=='')return rtrim(APP_URL,'/');
  $https=($_SERVER['HTTPS']??'')!=='' || ($_SERVER['HTTP_X_FORWARDED_PROTO']??'')==='https';
  return ($https?'https://':'http://').($_SERVER['HTTP_HOST']??'localhost');
}
/* Заголовок письма с кириллицей нужно кодировать, иначе почтовые
   программы покажут его набором знаков вопроса. */
function mimeHeader(string $v):string{ return preg_match('/[\x80-\xFF]/',$v) ? '=?UTF-8?B?'.base64_encode($v).'?=' : $v; }

/* Минимальный SMTP: подключение, приветствие, вход, письмо. Целой
   библиотеки ради одного письма в архиве быть не должно. Возвращает
   пустую строку при успехе и текст ошибки — если не отправилось. */
function smtpSend(array $c,string $to,string $subject,string $html,string $text):string{
  $host=$c['host']; $port=(int)$c['port']; $sec=strtolower((string)$c['security']);
  $addr=($sec==='ssl'?'ssl://':'').$host.':'.$port;
  $ctx=stream_context_create(['ssl'=>['SNI_enabled'=>true]]);
  $fp=@stream_socket_client($addr,$errno,$errstr,15,STREAM_CLIENT_CONNECT,$ctx);
  if(!$fp)return 'SMTP: '.$errstr;
  stream_set_timeout($fp,15);
  $read=function()use($fp):string{ $out=''; while(($l=fgets($fp,1024))!==false){ $out.=$l; if(strlen($l)<4||$l[3]===' ')break; } return $out; };
  $cmd=function(string $line,string $expect)use($fp,$read):string{
    if($line!=='')fwrite($fp,$line."\r\n");
    $r=$read();
    return str_starts_with($r,$expect)?'':trim($r);
  };
  $ehlo='EHLO '.($_SERVER['HTTP_HOST']??'localhost');
  if($e=$cmd('','220'))                { fclose($fp); return 'SMTP: '.$e; }
  if($e=$cmd($ehlo,'250'))             { fclose($fp); return 'SMTP: '.$e; }
  if($sec==='tls'){
    if($e=$cmd('STARTTLS','220'))      { fclose($fp); return 'SMTP: '.$e; }
    if(!@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)){ fclose($fp); return 'SMTP: не поднялось шифрование'; }
    if($e=$cmd($ehlo,'250'))           { fclose($fp); return 'SMTP: '.$e; }
  }
  if($c['username']!==''){
    if($e=$cmd('AUTH LOGIN','334'))                        { fclose($fp); return 'SMTP: '.$e; }
    if($e=$cmd(base64_encode($c['username']),'334'))       { fclose($fp); return 'SMTP: неверный логин'; }
    if($e=$cmd(base64_encode((string)$c['password']),'235')){ fclose($fp); return 'SMTP: неверный пароль'; }
  }
  if($e=$cmd('MAIL FROM:<'.$c['from'].'>','250')){ fclose($fp); return 'SMTP: '.$e; }
  if($e=$cmd('RCPT TO:<'.$to.'>','250'))         { fclose($fp); return 'SMTP: '.$e; }
  if($e=$cmd('DATA','354'))                      { fclose($fp); return 'SMTP: '.$e; }
  $b='b'.bin2hex(random_bytes(12));
  $body=
    'From: '.mimeHeader((string)$c['from_name']).' <'.$c['from'].">\r\n".
    'To: <'.$to.">\r\n".
    'Subject: '.mimeHeader($subject)."\r\n".
    'Date: '.date('r')."\r\n".
    'MIME-Version: 1.0'."\r\n".
    'Content-Type: multipart/alternative; boundary="'.$b.'"'."\r\n\r\n".
    '--'.$b."\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($text))."\r\n".
    '--'.$b."\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($html))."\r\n".
    '--'.$b."--\r\n";
  /* Точка в начале строки завершает письмо — удваиваем её. */
  $body=preg_replace('/^\./m','..',$body);
  fwrite($fp,$body."\r\n.\r\n");
  $e=$cmd('','250'); if($e){ fclose($fp); return 'SMTP: '.$e; }
  $cmd('QUIT','221'); fclose($fp);
  return '';
}
/* Единая точка отправки. Пустая строка — письмо ушло. */
function sendMail(string $to,string $subject,string $html,string $text):string{
  $c=mailConfig();
  if(!filter_var($to,FILTER_VALIDATE_EMAIL))return 'Некорректный адрес';
  if($c['host']!=='')return smtpSend($c,$to,$subject,$html,$text);
  $h="From: ".mimeHeader((string)$c['from_name'])." <".$c['from'].">\r\n".
     "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\n";
  return @mail($to,mimeHeader($subject),$html,$h) ? '' : 'Хостинг не смог отправить письмо';
}

/* ---------------------------------------------------------------
   Восстановление пароля.
   --------------------------------------------------------------- */
/* Находим владельца адреса среди всех трёх ролей. */
function userByEmail(string $email):?array{
  foreach(['admin'=>'admins','specialist'=>'specialists','client'=>'clients'] as $type=>$table){
    $q=db()->prepare("SELECT id,name,email,password_hash FROM $table WHERE email=?");
    $q->execute([$email]);
    if($u=$q->fetch())return ['type'=>$type,'row'=>$u];
  }
  return null;
}
/* Письмо со ссылкой. Оформление намеренно простое: почтовые программы
   режут стили, и письмо должно читаться даже совсем без них. */
function resetLetter(string $name,string $link):array{
  $html='<div style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;font-size:16px;line-height:1.55;color:#121820">'
    .'<p>'.htmlspecialchars($name?:'Здравствуйте').', вы просили сменить пароль в '.APP_NAME.'.</p>'
    .'<p><a href="'.htmlspecialchars($link).'" style="display:inline-block;padding:12px 22px;background:#2E7D63;color:#fff;border-radius:999px;text-decoration:none">Задать новый пароль</a></p>'
    .'<p style="color:#5B6572;font-size:14px">Ссылка работает один час и только один раз.<br>'
    .'Если пароль вы менять не просили — просто не открывайте её, старый пароль остался в силе.</p>'
    .'<p style="color:#8B94A0;font-size:13px;word-break:break-all">'.htmlspecialchars($link).'</p></div>';
  $text=($name?:'Здравствуйте').', вы просили сменить пароль в '.APP_NAME.".\n\n".$link
    ."\n\nСсылка работает один час и только один раз.\nЕсли пароль вы менять не просили — просто не открывайте её.\n";
  return [$html,$text];
}
/* Создаёт ссылку и отправляет письмо. Наружу об ошибках не говорим —
   иначе по ответу можно перебрать, какие адреса заведены в сервисе. */
function sendPasswordReset(array $found,string $email,string $ip):string{
  $pdo=db();
  $pdo->exec("DELETE FROM password_resets WHERE expires_at<'".now()."'");
  $raw=token(24);
  $pdo->prepare('INSERT INTO password_resets(token_hash,user_type,user_id,email,requested_ip,created_at,expires_at) VALUES(?,?,?,?,?,?,?)')
      ->execute([hash('sha256',$raw),$found['type'],(int)$found['row']['id'],$email,$ip,now(),gmdate('Y-m-d H:i:s',time()+3600)]);
  [$html,$text]=resetLetter((string)($found['row']['name']??''),siteUrl().'/?reset='.$raw);
  return sendMail($email,'Смена пароля в '.APP_NAME,$html,$text);
}
/* Слишком частые просьбы отсекаем: и адрес, и адрес отправителя. */
function resetThrottled(string $email,string $ip):bool{
  $pdo=db();
  $q=$pdo->prepare("SELECT COUNT(*) FROM password_resets WHERE email=? AND created_at>?");
  $q->execute([$email,gmdate('Y-m-d H:i:s',time()-120)]);
  if((int)$q->fetchColumn()>0)return true;
  $q=$pdo->prepare("SELECT COUNT(*) FROM password_resets WHERE requested_ip=? AND created_at>?");
  $q->execute([$ip,gmdate('Y-m-d H:i:s',time()-3600)]);
  return (int)$q->fetchColumn()>=10;
}
/* Возвращает запись, если ссылка ещё живая и не использована. */
function resetByToken(string $raw):?array{
  $q=db()->prepare('SELECT * FROM password_resets WHERE token_hash=?');
  $q->execute([hash('sha256',$raw)]);
  $r=$q->fetch();
  if(!$r||$r['used_at']||$r['expires_at']<now())return null;
  return $r;
}

/* Платёжный провайдер: интерфейс и заглушка. Отдельным файлом, потому
   что настоящая интеграция встанет туда же, а не в этот и без того
   длинный config. */
require_once __DIR__.'/provider.php';
require_once __DIR__.'/off.php';

function migrate():void{$pdo=db();foreach(glob(__DIR__.'/../migrations/*.sql') as $f){$pdo->exec(file_get_contents($f));}}
migrate();
(function(){$p=db();/* Возвращает true, если колонку действительно добавили: по этому
   признаку заполняем значения по умолчанию ровно один раз. */
$ensure=function($t,$c,$d)use($p){$cols=array_column($p->query("PRAGMA table_info($t)")->fetchAll(),'name');if(in_array($c,$cols,true))return false;$p->exec("ALTER TABLE $t ADD COLUMN $c $d");return true;};$ensure('clients','avatar_url','TEXT');$ensure('clients','birth_year','INTEGER');$ensure('messages','attachment_url','TEXT');$ensure('messages','kind','TEXT');$ensure('messages','call_id','INTEGER');$ensure('dishes','steps','TEXT');$ensure('specialists','profession','TEXT');$ensure('specialists','join_code','TEXT');$ensure('specialists','status','TEXT');$ensure('specialists','verify_status',"TEXT DEFAULT 'none'");$ensure('specialists','verify_note','TEXT');$ensure('specialists','verify_submitted_at','TEXT');$ensure('specialists','verified_at','TEXT');$ensure('specialists','notices_seen_at','TEXT');$ensure('specialists','notices_cleared_at','TEXT');$ensure('specialists','last_seen_at','TEXT');$ensure('specialist_services','duration_min','INTEGER');$ensure('specialist_documents','is_public','INTEGER NOT NULL DEFAULT 0');$freshUnit=$ensure('point_redemptions','reward_id','INTEGER');$ensure('point_redemptions','title','TEXT');$ensure('ingredients','unit',"TEXT DEFAULT 'g'");$ensure('ingredients','piece_g','REAL');$ensure('ingredients','barcode','TEXT');$ensure('ingredients','brand','TEXT');$ensure('ingredients','source',"TEXT DEFAULT 'own'");$ensure('ingredients','per_serving_g','REAL');
/* Свой продукт клиента. Отдельный столбец, а не created_by: тот ссылается
   на специалистов, и клиентский номер в него не лезет — внешний ключ
   честно это и показал. */
$ensure('ingredients','client_id','INTEGER REFERENCES clients(id) ON DELETE CASCADE');
/* Блюдо-однокомпонентник: под ним прячется продукт, который специалист
   назначил клиенту напрямую («150 г индейки»). Позиция меню умеет
   ссылаться только на блюдо, поэтому под такой продукт заводится блюдо
   из одного ингредиента, а этот столбец отличает его от настоящего. */
/* Сотрудники панели. Раньше вход был один на всех — «владелец», и по
   журналу нельзя было отличить, кто именно принял решение. Роль храним
   у самой учётки: у существующих это владелец, иначе первый же вход
   после обновления потерял бы права. */
/* Индивидуальная ставка комиссии. Пусто — значит действует общая:
   договорённость с отдельным специалистом не должна заставлять менять
   правила для всех. */
/* Отложенная рассылка: когда отправить и кому именно. Раньше письмо
   уходило только сразу и только трём готовым адресатам. */
/* Метки блюда: постное, детское, спортивное. Типы приёмов пищи для
   этого не годятся — завтрак не отвечает на вопрос «что тут без мяса». */
$ensure('broadcasts','segment','TEXT');
$ensure('broadcasts','send_at','TEXT');
$ensure('broadcasts','status',"TEXT NOT NULL DEFAULT 'sent'");
/* Продвижение в каталоге: закрепление наверху и снятие с витрины.
   Прятать чужой профиль его же переключателем нельзя — специалист
   включит обратно и не поймёт, что его убрали намеренно; поэтому у
   владельца отдельный признак. */
$ensure('public_profiles','featured',"INTEGER NOT NULL DEFAULT 0");
$ensure('public_profiles','catalog_block',"INTEGER NOT NULL DEFAULT 0");
$ensure('specialists','rate_own','REAL');
$ensure('specialists','rate_catalog','REAL');
/* Откуда человек пришёл. Без этого рекламу оценивать нечем: видно, что
   регистрации есть, а какие из них окупились — нет. */
/* Откуда и с чего вошли: без этого «активные сессии» показать нечего,
   а чужой вход в панели ничем не отличается от своего. */
$ensure('sessions','ip','TEXT');
$ensure('sessions','user_agent','TEXT');
$ensure('sessions','last_seen_at','TEXT');
/* Второй фактор владельца: код на почту при входе. */
$ensure('admins','twofa',"INTEGER NOT NULL DEFAULT 0");
$ensure('admins','twofa_code','TEXT');
$ensure('admins','twofa_until','TEXT');
$ensure('admins','twofa_tries',"INTEGER NOT NULL DEFAULT 0");
$ensure('clients','source','TEXT');
$ensure('specialists','source','TEXT');
$ensure('admins','role',"TEXT NOT NULL DEFAULT 'owner'");
$ensure('admins','status',"TEXT NOT NULL DEFAULT 'active'");
$ensure('admins','created_by','INTEGER');
$ensure('dishes','from_ingredient_id','INTEGER');
/* Индекс ставим здесь, а не отдельным файлом миграции: файлы
   выполняются раньше добавления столбцов, и индекс по ещё не
   существующему столбцу ронял загрузку. */
$p->exec('CREATE INDEX IF NOT EXISTS idx_dishes_from_ing ON dishes(from_ingredient_id)');
/* Поиск по-русски. SQLite сравнивает LIKE без учёта регистра только
   для латиницы: «свёкл» не находил «Свёкла», а «Свёкл» находил. Держим
   рядом свёрнутое имя — строчными и с «ё», приведённой к «е», чтобы
   «свекла» тоже находилась. Заполняем один раз при появлении столбца:
   гонять UPDATE по всему справочнику на каждой загрузке незачем. */
if($ensure('ingredients','name_fold','TEXT')||!(int)$p->query("SELECT COUNT(*) FROM ingredients WHERE name_fold IS NOT NULL")->fetchColumn()){
  $st=$p->prepare('UPDATE ingredients SET name_fold=? WHERE id=?');
  foreach($p->query('SELECT id,name,brand FROM ingredients') as $r)
    $st->execute([foodFold(($r['name']??'').' '.($r['brand']??'')),(int)$r['id']]);
}
  /* Единицы для встроенного списка продуктов: яйца считают штуками, а
     масло меряют миллилитрами. Заполняем один раз, при появлении
     колонки — на продукты специалиста это не влияет. */
  if($freshUnit){
    foreach([['Яйцо куриное','pc',60],['Авокадо','pc',200],['Банан','pc',120],
             ['Яблоко','pc',180],['Огурец','pc',120],['Помидор','pc',120],
             ['Морковь','pc',85],['Оливковое масло','ml',null]] as [$n,$u,$w])
      $p->prepare('UPDATE ingredients SET unit=?,piece_g=? WHERE name=?')->execute([$u,$w,$n]);
  }$ensure('public_profiles','price','INTEGER');$ensure('public_profiles','price_unit','TEXT');$ensure('public_profiles','education','TEXT');$ensure('public_profiles','experience_years','INTEGER');$ensure('public_profiles','specializations','TEXT');$ensure('public_profiles','advantages','TEXT');$ensure('clients','water_goal_ml','INTEGER');$ensure('dishes','photo_thumb_url','TEXT');$ensure('push_subscriptions','platform',"TEXT DEFAULT 'web'");
  /* Деньги по покупке. Снимок ставки и сумм делается в момент оплаты:
     ставку комиссии владелец может поменять завтра, а по вчерашнему
     заказу специалисту причитается то, о чём договаривались вчера. */
  $ensure('client_subscriptions','commission_rate','REAL');
  $ensure('client_subscriptions','commission_kop','INTEGER');
  $ensure('client_subscriptions','payout_kop','INTEGER');
  /* Комиссия платёжного сервиса за приём этого платежа. Она берётся
     сверх нашей, и без отдельной строки наша прибыль в сводке выглядела
     бы завышенной. Пока эквайер не подключён — всегда ноль. */
  $ensure('client_subscriptions','acquirer_fee_kop','INTEGER NOT NULL DEFAULT 0');
  /* Идентификаторы на стороне эквайера. Без них после подключения
     платежей нечем связать нашу покупку с его сделкой, а нашу заявку —
     с его выплатой: разбирать расхождения будет не по чему. */
  $ensure('client_subscriptions','provider_deal_id','TEXT');
  $ensure('payout_requests','provider_payout_id','TEXT');
  $ensure('client_subscriptions','paid_at','TEXT');
  /* Приёмка разовой услуги: специалист отмечает выполнение, с этого
     момента у клиента есть окно на возражение. */
  $ensure('client_subscriptions','done_at','TEXT');
  $ensure('client_subscriptions','accept_due_at','TEXT');
  $ensure('client_subscriptions','accepted_at','TEXT');
  $ensure('client_subscriptions','accepted_by','TEXT');   // client | auto | refund
  /* Сроки и порог вывода — рядом со ставками комиссии, в той же
     единственной строке настроек. */
  $ensure('commission_settings','accept_days','INTEGER NOT NULL DEFAULT 7');
  $ensure('commission_settings','abandon_days','INTEGER NOT NULL DEFAULT 45');
  $ensure('commission_settings','payout_min_kop','INTEGER NOT NULL DEFAULT 100000');
  /* Три состояния, а не переключатель.
       off  — как сейчас: услуга включается по договорённости, движений по
              балансу не возникает вовсе;
       demo — механика эскроу работает целиком, но деньги учебные: экраны
              живые, вывод закрыт, на каждом стоит об этом плашка;
       live — приём платежей подключён, вывод разрешён.
     Между off и live нельзя прыгнуть, не увидев экранов в работе, —
     поэтому среднее состояние и существует. */
  $ensure('commission_settings','payments_mode',"TEXT NOT NULL DEFAULT 'off'");
  /* Когда подписку закрыли досрочно: до этого дня деньги заработаны,
     после — возвращаются клиенту. */
  $ensure('client_subscriptions','ended_at','TEXT');
  /* Клиент не согласен, что услуга выполнена. Деньги остаются
     замороженными, пока спор не разберёт владелец. */
  $ensure('client_subscriptions','disputed_at','TEXT');
  $ensure('client_subscriptions','dispute_note','TEXT');$p->exec("CREATE INDEX IF NOT EXISTS idx_push_platform ON push_subscriptions(platform)");})();

/* Уже созданные демо-базы: доливаем недостающие дни того же меню.
   Трогаем только демо-клиента — чужие меню составляет специалист. */
/* Каталог блюд целиком приходит из data/dishes.json. Прежний блок
   дописывал сюда пару блюд руками, чтобы среди заполнителей было хоть
   что-то настоящее; заполнителей больше нет, и дописывать нечего. */
linkDishPhotos();

(function(){$p=db();
  try{ $q=$p->query("SELECT m.id FROM menus m JOIN clients c ON c.id=m.client_id WHERE c.email='anna@demo.local'");
    foreach($q->fetchAll(PDO::FETCH_COLUMN) as $mid) fillDemoDays((int)$mid);
  }catch(Throwable $e){ /* нет демо-клиента — доливать нечего */ }
})();

/* Фотографии блюд.
   Файлы кладутся в public_html/dishes/ под именами ниже; как только файл
   появился, блюдо получает снимок. Ждать выгрузки через кабинет незачем —
   каталог общий, и снимок у блюда один на всех.
   Своё фото, выставленное руками, не трогаем. */
/* Свой адрес, а не тот, с которого пришёл запрос: приложение стучится
   с адреса сборщика, и ссылка-приглашение получалась ведущей в никуда. */
function selfOrigin():string{
  $https=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO']??'')==='https');
  $host=(string)($_SERVER['HTTP_HOST']??$_SERVER['SERVER_NAME']??'');
  return $host ? ($https?'https://':'http://').$host : '';
}
function linkDishPhotos():void{
  $p=db();
  /* Имя файла у каждого блюда своё и лежит в data/dishes.json —
     держать второй список в коде значит завести месту для расхождения. */
  $want=[];
  foreach(dishesData()['dishes'] as $d)
    if(!empty($d['photo_file']))
      $want[strtolower(pathinfo((string)$d['photo_file'],PATHINFO_FILENAME))]=$d['name'];
  if(!$want)return;

  $dir=__DIR__.'/../dishes';
  if(!is_dir($dir))return;
  /* Смотрим, что на самом деле лежит в папке, а не гадаем про расширение:
     файл приезжает и .png, и .jpeg, и с заглавными буквами, а
     переименовывать его руками — лишний повод ошибиться. */
  $have=[];
  foreach(scandir($dir) ?: [] as $f){
    if($f==='.'||$f==='..')continue;
    $ext=strtolower(pathinfo($f,PATHINFO_EXTENSION));
    if(!in_array($ext,['jpg','jpeg','png','webp'],true))continue;
    $base=strtolower(pathinfo($f,PATHINFO_FILENAME));
    if(!isset($have[$base]))$have[$base]=$f;
  }
  if(!$have)return;
  /* Своё фото, выставленное руками, не трогаем.

     Ссылаемся на сжатую версию, а не на исходник: снимки в папку
     кладут прямо с камеры или из редактора, по 2–4 МБ каждый, и
     каталог из полусотни таких грузится минуту. Оригинал остаётся
     лежать рядом — он тут первоисточник. */
  /* Берём в работу блюда, которым фото ещё не поставлено, и те, чья
     ссылка ведёт на несжатый исходник: вторые остались от установок,
     собранных до появления сжатия, и чинятся сами — отдельной кнопки
     для этого не нужно.

     Считаем варианты только для них. Иначе сжатие запускалось бы на
     каждом запросе к сайту для всех полусотни снимков. */
  $need=[];
  foreach($p->query('SELECT name FROM dishes
                     WHERE photo_url IS NULL OR photo_url=""
                        OR (photo_url LIKE "/dishes/%" AND photo_url NOT LIKE "/dishes/opt/%")') as $r)
    $need[(string)$r['name']]=true;
  if(!$need)return;

  $q=$p->prepare('UPDATE dishes SET photo_url=?, photo_thumb_url=? WHERE name=?');
  /* За один запрос ужимаем немного: полсотни снимков по 3 МБ — это
     минуты работы, и пришедший на сайт человек ждал бы их вместо
     страницы. Остальные подхватятся на следующих запросах: пока идёт
     сжатие, каталог показывает исходники — медленно, но показывает. */
  $budget=3;
  foreach($want as $base=>$name){
    if(!isset($have[$base])||!isset($need[$name]))continue;
    if($budget--<=0)break;
    $v=dishPhotoVariants($have[$base]);
    /* Сжать не вышло (нет GD, битый файл) — отдаём как есть: тяжёлое
       фото лучше, чем пустая карточка. */
    $q->execute($v ? [$v[0],$v[1],$name] : ['/dishes/'.$have[$base],'/dishes/'.$have[$base],$name]);
  }
}

/* Владелец сервиса: отдельная таблица и учётка, создаётся один раз */
(function(){$p=db();
  $p->exec('CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,name TEXT NOT NULL,created_at TEXT NOT NULL)');
  if((int)$p->query('SELECT COUNT(*) FROM admins')->fetchColumn()===0){
    $p->prepare('INSERT INTO admins(email,password_hash,name,created_at) VALUES(?,?,?,?)')
      ->execute([OWNER_EMAIL,password_hash(OWNER_PASSWORD,PASSWORD_DEFAULT),'Владелец',now()]);
  }
})();
/* Миграция: сделать clients.specialist_id nullable (самостоятельные клиенты без специалиста). Выполняется один раз. */
(function(){$p=db();$ti=$p->query("PRAGMA table_info(clients)")->fetchAll();$sp=null;foreach($ti as $c)if($c['name']==='specialist_id')$sp=$c;if($sp&&(int)$sp['notnull']===1){$cols='id,specialist_id,name,email,phone,password_hash,invite_token,sex,birth_year,height_cm,weight_kg,activity_level,goal,target_kcal,target_protein,target_fat,target_carbs,excluded_ingredients,notes,status,created_at,avatar_url';$p->exec('PRAGMA foreign_keys=OFF');$p->beginTransaction();$p->exec("CREATE TABLE clients_new(id INTEGER PRIMARY KEY,specialist_id INTEGER REFERENCES specialists(id) ON DELETE SET NULL,name TEXT NOT NULL,email TEXT,phone TEXT,password_hash TEXT,invite_token TEXT UNIQUE,sex TEXT,birth_year INTEGER,height_cm INTEGER,weight_kg REAL,activity_level TEXT,goal TEXT,target_kcal INTEGER,target_protein REAL,target_fat REAL,target_carbs REAL,excluded_ingredients TEXT,notes TEXT,status TEXT DEFAULT 'active',created_at TEXT NOT NULL,avatar_url TEXT)");$p->exec("INSERT INTO clients_new($cols) SELECT $cols FROM clients");$p->exec('DROP TABLE clients');$p->exec('ALTER TABLE clients_new RENAME TO clients');$p->commit();$p->exec('PRAGMA foreign_keys=ON');}})();
/* Демо-меню на все дни, а не только на первый.
   Иначе на второй день кабинет встречает пустым экраном «меню не назначено»
   — и посмотреть, как он выглядит с едой, уже нельзя.

   День собираем как настоящий: пять приёмов, блюда сдвинуты по кругу,
   порции подогнаны под норму калорий клиента. Копия первого дня целиком
   дала бы восемь блюд и полторы нормы — так меню не составляют. */
function fillDemoDays(int $menuId):void{ $pdo=db();
  $q=$pdo->prepare('SELECT m.days_count,COALESCE(c.target_kcal,1800) tk FROM menus m JOIN clients c ON c.id=m.client_id WHERE m.id=?');
  $q->execute([$menuId]);$m=$q->fetch(); if(!$m)return;
  $days=(int)$m['days_count'];$target=(float)$m['tk']; if($days<2)return;

  /* Только блюда с настоящими названиями: «Домашнее блюдо №9» в демо-меню
     выглядит как недоделка, хотя это заполнитель каталога. */
  $ds=$pdo->query("SELECT id,kcal_100,base_portion_g,meal_types FROM dishes WHERE kcal_100>0 AND name NOT LIKE 'Домашнее блюдо%' ORDER BY id LIMIT 12")->fetchAll();
  if(count($ds)<5)return;
  $meals=['breakfast','snack1','lunch','snack2','dinner'];
  /* Раскладываем по приёмам, для которых блюдо и задумано: овсянка на
     обед — не «разнообразие», а ощущение, что меню собрал не человек.
     Перекусы делят между собой один список: их часто помечают любым. */
  $fit=[];foreach($meals as $mt){$fit[$mt]=[];}
  foreach($ds as $d){ $tags=json_decode((string)$d['meal_types'],true);
    if(!is_array($tags)||!$tags)$tags=$meals;
    foreach($tags as $t){ $t=(string)$t; if(isset($fit[$t]))$fit[$t][]=$d; }
    if(in_array('snack1',$tags,true)&&!in_array('snack2',$tags,true))$fit['snack2'][]=$d;
    if(in_array('snack2',$tags,true)&&!in_array('snack1',$tags,true))$fit['snack1'][]=$d; }
  foreach($meals as $mt) if(!$fit[$mt]) $fit[$mt]=$ds;
  /* Перекусы легче основных приёмов — иначе день выглядит как пять обедов */
  $share=['breakfast'=>0.25,'snack1'=>0.1,'lunch'=>0.35,'snack2'=>0.1,'dinner'=>0.2];

  $has=$pdo->prepare('SELECT COUNT(*) FROM menu_items WHERE menu_id=? AND day_number=?');
  $ins=$pdo->prepare('INSERT INTO menu_items(menu_id,day_number,meal_type,dish_id,portion_g,sort_order) VALUES(?,?,?,?,?,?)');

  for($d=2;$d<=$days;$d++){
    $has->execute([$menuId,$d]); if((int)$has->fetchColumn())continue;
    $used=[];
    foreach($meals as $i=>$mt){
      $pool=$fit[$mt];$n=count($pool);$dish=null;
      /* Одно и то же блюдо дважды за день — самый заметный признак
         сгенерированного меню. Берём следующее свободное из списка. */
      for($k=0;$k<$n;$k++){ $cand=$pool[($d-2+$i+$k)%$n];
        if(!isset($used[$cand['id']])){ $dish=$cand; break; } }
      if(!$dish)$dish=$pool[($d-2+$i)%$n];
      $used[$dish['id']]=true;
      $k100=(float)$dish['kcal_100']; if($k100<=0)continue;
      $want=$target*$share[$mt];
      $g=round($want/$k100*100/10)*10;
      /* Держимся близко к порции, которую задумал автор блюда */
      $base=(float)$dish['base_portion_g']?:250;
      $g=max(round($base*0.5/10)*10,min(round($base*1.5/10)*10,$g));
      $ins->execute([$menuId,$d,$mt,$dish['id'],$g,$i]);
    }
  }
}
/* Предварительная норма калорий и БЖУ по анкете.
   Формула Миффлина—Сан Жеора с коэффициентом активности и поправкой на
   цель — то, чем пользуются нутрициологи для первой прикидки. Специалист
   потом задаёт свои числа; до тех пор клиент видит хоть что-то осмысленное,
   а не 1800 «по умолчанию». */
/* Карточка клиента наружу: хеш пароля и токен приглашения кабинету не
   нужны, а утекают они одинаково легко и в лог, и в отладчик браузера. */
function safeClient(array $c):array{ unset($c['password_hash'],$c['invite_token']); return $c; }
function safeClients(array $rows):array{ return array_map('safeClient',$rows); }

/* --- Списки людей в панели владельца ---
   Поиск и фильтр собираем в одном месте: у специалистов и клиентов
   условия одинаковые, а расходиться им незачем. Имя и почту сравниваем
   в нижнем регистре и с «ё», приведённой к «е», — иначе «Алёна» не
   находится по «алена», а такое имя в базе не редкость. */
/* --- Тексты лендинга ---
   Заголовок на главной и обещание для специалистов меняются чаще, чем
   кто-то готов лезть на хостинг и править php-файл. Значения лежат в
   базе, а в разметке остаются запасные — сайт не должен опустеть, если
   в базе ещё ничего нет. */
const SITE_TEXTS=[
  'home_title'    =>'Заголовок на главной',
  'home_sub'      =>'Подзаголовок на главной',
  'home_cta'      =>'Надпись на кнопке',
  'spec_title'    =>'Заголовок страницы для специалистов',
  'spec_sub'      =>'Подзаголовок для специалистов',
  'catalog_title' =>'Заголовок каталога',
  'contact_email' =>'Почта для связи на сайте',
  'contact_phone' =>'Телефон на сайте',
];
function siteTexts():array{
  $out=[];
  $raw=settingGet('site_texts');
  $db=$raw?(json_decode($raw,true)?:[]):[];
  foreach(SITE_TEXTS as $k=>$label)$out[$k]=trim((string)($db[$k]??''));
  return $out;
}
/** Текст с запасным вариантом: пустое поле в панели ничего не ломает. */
function siteText(string $key,string $fallback=''):string{
  static $t=null; if($t===null)$t=siteTexts();
  $v=trim((string)($t[$key]??''));
  return $v!==''?$v:$fallback;
}
function siteTextsSave(array $in):bool{
  $cur=siteTexts();
  foreach(SITE_TEXTS as $k=>$label)
    if(array_key_exists($k,$in))$cur[$k]=mb_substr(trim((string)$in[$k]),0,300);
  return settingSet('site_texts',json_encode($cur,JSON_UNESCAPED_UNICODE));
}

/* --- Реквизиты организации ---
   Раньше они жили только в config/legal.php: чтобы поменять адрес или
   почту для обращений, приходилось лезть на хостинг и править файл.
   Теперь их ведёт владелец из панели, а файл остаётся запасным
   источником — на случай, если в базе ещё пусто (первый запуск,
   перенос сайта). */
const LEGAL_FIELDS=['operator','inn','ogrn','address','email','site','updated_at'];
function legalData():array{
  $file=[];
  $path=__DIR__.'/legal.php';
  if(is_file($path)){ $v=require $path; if(is_array($v))$file=$v; }
  $db=[];
  $raw=settingGet('legal');
  if($raw){ $v=json_decode($raw,true); if(is_array($v))$db=$v; }
  $out=[];
  foreach(LEGAL_FIELDS as $k){
    $val=trim((string)($db[$k]??''));
    if($val==='')$val=trim((string)($file[$k]??''));
    $out[$k]=$val;
  }
  return $out;
}
function legalSave(array $in):bool{
  $cur=[];
  $raw=settingGet('legal');
  if($raw){ $v=json_decode($raw,true); if(is_array($v))$cur=$v; }
  foreach(LEGAL_FIELDS as $k){
    if(array_key_exists($k,$in))$cur[$k]=mb_substr(trim((string)$in[$k]),0,300);
  }
  $cur['updated_at']=gmdate('Y-m-d');
  return settingSet('legal',json_encode($cur,JSON_UNESCAPED_UNICODE));
}

/* --- Кто что может в панели ---
   0 — раздела не видно, 1 — только смотреть, 2 — можно менять.
   Деньги и системные операции (замена каталога, копии базы, доступы)
   остаются за владельцем: помощник, нанятый отвечать на обращения, не
   должен иметь возможности отправить выплату или стереть каталог. */
const ADMIN_RIGHTS=[
  'overview'=>['owner'=>2,'manager'=>2,'support'=>1],
  'people'  =>['owner'=>2,'manager'=>2,'support'=>1],
  'content' =>['owner'=>2,'manager'=>2,'support'=>0],
  'support' =>['owner'=>2,'manager'=>2,'support'=>2],
  'mailing' =>['owner'=>2,'manager'=>2,'support'=>0],
  'money'   =>['owner'=>2,'manager'=>0,'support'=>0],
  'system'  =>['owner'=>2,'manager'=>0,'support'=>0],
  /* Свои входы и код на почту — про собственную учётную запись, а не
     про сервис: закрыть чужой сеанс со своего же аккаунта должен уметь
     каждый, кому дали доступ в панель. */
  'self'    =>['owner'=>2,'manager'=>2,'support'=>2],
];
const ADMIN_ROLES=['owner'=>'Владелец','manager'=>'Управляющий','support'=>'Поддержка'];

/* Раздел панели по адресу запроса. Новый маршрут без записи здесь
   попадёт в «system» — то есть останется за владельцем. Так безопаснее:
   забытый маршрут закрыт, а не открыт всем. */
function adminSection(string $path):string{
  $p=substr($path,strlen('/admin/'));
  $first=explode('/',$p)[0];
  return match($first){
    'overview','readiness','analytics'            => 'overview',
    'sessions','twofa'                            => 'self',
    'specialists','clients','person','verifications','reviews' => 'people',
    'dishes','ingredients','posts','info','upload','catalog'=> 'content',
    'support'                                     => 'support',
    'broadcasts','push'                           => 'mailing',
    'finance','subscriptions'                     => 'money',
    default                                       => 'system',
  };
}
/* Уровень доступа сотрудника к разделу. */
function adminLevel(string $role,string $section):int{
  return ADMIN_RIGHTS[$section][$role] ?? 0;
}
/* Права на всю панель — интерфейс прячет по ним разделы. */
function adminRights(string $role):array{
  $out=[];
  foreach(ADMIN_RIGHTS as $sec=>$map)$out[$sec]=$map[$role]??0;
  return $out;
}

/* Заметки и обращения человека — в его карточке. Раньше обращение и
   человек жили порознь: из тикета не попасть в профиль, из профиля не
   видно, о чём он уже писал. */
function personNotes(string $kind,int $id):array{
  $st=db()->prepare('SELECT id,author_name,body,created_at FROM person_notes
    WHERE target_type=? AND target_id=? ORDER BY id DESC LIMIT 50');
  $st->execute([$kind,$id]);
  return $st->fetchAll();
}
function personTickets(string $kind,int $id):array{
  $st=db()->prepare("SELECT id,subject,topic,status,created_at,last_reply_at
    FROM support_tickets WHERE author_type=? AND author_id=? ORDER BY id DESC LIMIT 20");
  $st->execute([$kind,$id]);
  return $st->fetchAll();
}

/* --- Журнал действий панели ---
   Пишем сюда всё, что меняет доступ, деньги или общий контент. Запись
   не должна мешать самому действию: упала — действие всё равно
   состоялось, поэтому ошибки глушим. */
function adminLog(string $action,?string $targetType=null,$targetId=null,
                  ?string $targetName=null,?string $note=null):void{
  try{
    $a=$GLOBALS['__auth'] ?? null;
    $name=null;
    if($a&&($a['user_type']??'')==='admin'){
      $name=fetchOne(db(),'SELECT name FROM admins WHERE id=?',[(int)$a['user_id']]);
    }elseif($a&&($a['user_type']??'')==='specialist'){
      $name=fetchOne(db(),'SELECT name FROM specialists WHERE id=?',[(int)$a['user_id']]);
    }
    db()->prepare('INSERT INTO admin_log(actor_type,actor_id,actor_name,action,target_type,target_id,target_name,note,created_at)
      VALUES(?,?,?,?,?,?,?,?,?)')->execute([
      $a['user_type']??'admin', $a?(int)$a['user_id']:null, $name?:null,
      $action, $targetType, $targetId!==null?(int)$targetId:null, $targetName, $note, now(),
    ]);
  }catch(Throwable $e){ /* журнал не важнее действия */ }
}

function adminPeopleFilter(string $alias,array $get):array{
  $cond=[]; $args=[];
  $q=trim((string)($get['q']??''));
  if($q!==''){
    $cond[]="(fold($alias.name) LIKE ? OR fold($alias.email) LIKE ?)";
    $like='%'.foodFold($q).'%';
    $args[]=$like; $args[]=$like;
  }
  $st=(string)($get['status']??'');
  if($st==='blocked')     $cond[]="COALESCE($alias.status,'active')='blocked'";
  elseif($st==='active')  $cond[]="COALESCE($alias.status,'active')<>'blocked'";
  return [$cond?('WHERE '.implode(' AND ',$cond)):'', $args];
}
/* Откуда пришёл человек.
   Берём то, что прислал сам клиент (метка из ссылки), иначе — домен
   страницы, с которой он к нам попал. Длину режем: в метку иногда
   заезжает вся рекламная строка, а нам нужен источник, а не она. */
function signupSource(array $in):?string{
  $v=trim((string)($in['source']??$in['utm_source']??''));
  if($v==='' && !empty($_SERVER['HTTP_REFERER'])){
    $host=parse_url((string)$_SERVER['HTTP_REFERER'],PHP_URL_HOST);
    if($host && stripos((string)$host,(string)parse_url(siteUrl(),PHP_URL_HOST))===false)$v=$host;
  }
  $v=preg_replace('~[^\w\.\-: ]~u','',$v);
  return $v===''?null:mb_substr($v,0,60);
}
/* Поиск по одному полю — для списков содержимого. Свёртка та же, что у
   людей: без регистра и с «ё», приравненной к «е». */
function adminSearchFilter(string $col,array $get):array{
  $q=trim((string)($get['q']??''));
  if($q==='')return ['',[]];
  return ["WHERE fold($col) LIKE ?", ['%'.foodFold($q).'%']];
}
/* Страница списка. Размер держим в разумных рамках: запрос «отдай всё»
   на большой базе кладёт и сервер, и браузер. */
function adminPage(array $get,int $per=50):array{
  $per=max(10,min(200,(int)($get['limit']??$per)));
  $page=max(1,(int)($get['page']??1));
  return [$per,($page-1)*$per,$page];
}
/* Одно число по запросу с параметрами. */
function fetchOne(PDO $pdo,string $sql,array $args=[]){
  $st=$pdo->prepare($sql); $st->execute($args); return $st->fetchColumn();
}
function estimateTargets(array $a):array{
  $sex=($a['sex']??'f')==='m'?'m':'f';
  $w=(float)($a['weight_kg']??0); $h=(float)($a['height_cm']??0); $age=(int)($a['age']??0);
  if($w<=0||$h<=0||$age<=0) return [];
  $bmr=10*$w+6.25*$h-5*$age+($sex==='m'?5:-161);
  $k=['low'=>1.2,'light'=>1.375,'medium'=>1.55,'high'=>1.725,'athlete'=>1.9][$a['activity_level']??'medium']??1.55;
  $kcal=$bmr*$k;
  $goal=(string)($a['goal']??'');
  if(mb_stripos($goal,'снижен')!==false) $kcal*=0.85;
  elseif(mb_stripos($goal,'набор')!==false||mb_stripos($goal,'масс')!==false) $kcal*=1.12;
  $kcal=(int)round(max(1200,min(4000,$kcal))/10)*10;
  /* Белок от веса, жир — четверть калорийности, остальное углеводы */
  $protein=round(min(2.0,max(1.4,$sex==='m'?1.8:1.6))*$w);
  $fat=round($kcal*0.27/9);
  $carbs=round(max(0,($kcal-$protein*4-$fat*9)/4));
  return ['target_kcal'=>$kcal,'target_protein'=>$protein,'target_fat'=>$fat,'target_carbs'=>$carbs];
}
/**
 * Резервная копия базы.
 *
 * Копировать файл базы обычным cp нельзя: при включённом WAL часть
 * свежих записей лежит в отдельном файле, и такая «копия» окажется
 * обрезанной ровно на последних изменениях. Штатный способ SQLite —
 * VACUUM INTO: он собирает целостный файл из работающей базы.
 *
 * Живёт здесь, а не в cron/backup.php, потому что копию снимают и из
 * панели владельца: на shared-хостинге консоли обычно нет.
 */
function makeBackup(int $keep=14):array{
  $dir=__DIR__.'/../storage/backups';
  if(!is_dir($dir) && !mkdir($dir,0700,true) && !is_dir($dir))
    return ['error'=>'Не удалось создать storage/backups — проверьте права на папку storage'];
  $ht=$dir.'/.htaccess';
  if(!is_file($ht))@file_put_contents($ht,"Deny from all\n<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n");

  /* Имя с точностью до секунды: два запуска подряд попадают в одну
     секунду, и SQLite отказывается писать в существующий файл. */
  $stamp=gmdate('Y-m-d-His');
  $name='equa-'.$stamp.'.sqlite';
  for($i=2; is_file($dir.'/'.$name); $i++) $name='equa-'.$stamp.'-'.$i.'.sqlite';
  $path=$dir.'/'.$name;

  try{ db()->exec('VACUUM INTO '.db()->quote($path)); }
  catch(Throwable $e){ return ['error'=>'Копия не снялась: '.$e->getMessage()]; }
  @chmod($path,0600);

  /* Копия, которая не открывается, хуже отсутствия копии — на неё
     рассчитывают. Проверяем сразу. */
  try{
    $chk=new PDO('sqlite:'.$path,null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    $ok=(string)$chk->query('PRAGMA integrity_check')->fetchColumn();
    if($ok!=='ok')throw new RuntimeException($ok);
    $n=(int)$chk->query('SELECT COUNT(*) FROM specialists')->fetchColumn();
  }catch(Throwable $e){
    @unlink($path);
    return ['error'=>'Копия повреждена и удалена: '.$e->getMessage()];
  }

  $all=glob($dir.'/equa-*.sqlite')?:[];
  sort($all);
  foreach(array_slice($all,0,max(0,count($all)-$keep)) as $old)@unlink($old);
  return ['name'=>$name,'size'=>filesize($path),'specialists'=>$n,'kept'=>min(count($all),$keep)];
}

/* ======================================================================
   Каталог блюд.

   Блюда, состав, рецепты и КБЖУ лежат в data/dishes.json — это выгрузка
   рабочей таблицы, а не выдумка программы.

   КБЖУ блюда считается из состава, а не берётся из таблицы. Причина не
   в недоверии к таблице, а в том, что второго набора чисел в сервисе
   быть не должно: клиент двигает ползунок граммовки, специалист меняет
   состав, сборщик меню подбирает порцию — всё это считается по
   продуктам. Числа, лежащие рядом и не пересчитываемые, разойдутся с
   этим на первой же правке, и в карточке будет одно, а в итоге дня
   другое.

   Числа таблицы остаются в файле как контрольные: импорт сверяет с ними
   свой расчёт и в отчёте называет блюда, где расхождение больше 10%, —
   это повод посмотреть строку в таблице, а не молча выбрать за автора.
   ====================================================================== */
function dishesData():array{
  static $d=null;
  if($d!==null)return $d;
  $f=__DIR__.'/../data/dishes.json';
  if(!is_file($f))return $d=['dishes'=>[],'ingredients'=>[]];
  $j=json_decode((string)file_get_contents($f),true);
  return $d=is_array($j)?$j+['dishes'=>[],'ingredients'=>[]]:['dishes'=>[],'ingredients'=>[]];
}

/**
 * Продукты по названию: существующие обновляем, недостающие заводим.
 *
 * Сверяем имена в PHP, а не запросом. Встроенный lower() у SQLite умеет
 * только латиницу: lower('Молоко') — это по-прежнему 'Молоко'. Поиск
 * «как есть, без учёта регистра» на русских названиях им не сделать, и
 * добавленное специалистом «молоко» разошлось бы с нашим «Молоко» в два
 * разных продукта — с разными числами и одним и тем же смыслом.
 */
function ensureIngredients(array $list):array{
  $pdo=db(); $map=[];
  $known=[];
  foreach($pdo->query('SELECT id,name FROM ingredients') as $r)
    $known[mb_strtolower(trim((string)$r['name']))]=(int)$r['id'];
  $ins=$pdo->prepare('INSERT INTO ingredients(name,category,kcal,protein,fat,carbs,fiber,cooked_ratio,unit,piece_g,is_public,created_at)
                      VALUES(?,?,?,?,?,?,0,1,?,?,1,?)');
  $upd=$pdo->prepare('UPDATE ingredients SET category=?,kcal=?,protein=?,fat=?,carbs=?,unit=?,piece_g=? WHERE id=?');
  foreach($list as $x){
    $id=$known[mb_strtolower(trim((string)$x['name']))]??0;
    $args=[$x['category'],$x['kcal'],$x['protein'],$x['fat'],$x['carbs'],$x['unit']??'g',$x['piece_g']??null];
    if($id) $upd->execute(array_merge($args,[$id]));
    else {
      $ins->execute(array_merge([$x['name']],$args,[now()]));
      $id=(int)$pdo->lastInsertId();
      $known[mb_strtolower(trim((string)$x['name']))]=$id;
    }
    $map[$x['key']]=$id;
  }
  return $map;
}

/**
 * Загрузить каталог из data/dishes.json.
 *
 * $replace — снести прежний каталог целиком. Это удаляет и все меню,
 * которые на него ссылались: блюдо, на которое ссылается меню, просто
 * так не убрать, а меню без блюд бессмысленно. Поэтому режим вызывается
 * руками из tools/import-dishes.php, а не сам по себе.
 */
function importDishes(bool $replace=false):array{
  $pdo=db();
  $data=dishesData();
  if(!$data['dishes'])return ['error'=>'data/dishes.json не найден или пуст'];

  $lostMenus=0;
  $pdo->beginTransaction();
  try{
    if($replace){
      $lostMenus=(int)$pdo->query('SELECT COUNT(*) FROM menus')->fetchColumn();
      /* Порядок важен: menu_items ссылаются на dishes без каскада. */
      $pdo->exec('DELETE FROM menu_items');
      $pdo->exec('DELETE FROM menus');
      $pdo->exec('DELETE FROM dish_tags');
      $pdo->exec('DELETE FROM dish_ingredients');
      $pdo->exec('DELETE FROM dishes');
    }
    $ing=ensureIngredients($data['ingredients']);

    /* КБЖУ здесь не пишется: его посчитает recalc_dish() по составу,
       когда состав уже будет на месте. Одна функция — один писатель. */
    $find=$pdo->prepare('SELECT id FROM dishes WHERE name=?');
    $ins=$pdo->prepare('INSERT INTO dishes(name,meal_types,cook_minutes,instructions,steps,photo_url,is_public,created_at)
                        VALUES(?,?,?,?,?,?,1,?)');
    $upd=$pdo->prepare('UPDATE dishes SET meal_types=?,instructions=?,steps=?,is_public=1 WHERE id=?');
    $delI=$pdo->prepare('DELETE FROM dish_ingredients WHERE dish_id=?');
    $delT=$pdo->prepare('DELETE FROM dish_tags WHERE dish_id=?');
    $addI=$pdo->prepare('INSERT INTO dish_ingredients(dish_id,ingredient_id,grams,sort_order) VALUES(?,?,?,?)');
    $addT=$pdo->prepare('INSERT OR IGNORE INTO dish_tags(dish_id,tag) VALUES(?,?)');

    $added=$updated=0; $diffs=[]; $gaps=[];
    foreach($data['dishes'] as $d){
      $find->execute([$d['name']]);
      $id=(int)($find->fetchColumn()?:0);
      /* Рецепт хранится и сплошным текстом, и шагами: первый нужен для
         поиска и печати, вторые — экрану «Как готовить». */
      $steps=!empty($d['steps'])
        ? json_encode(array_map(fn($t)=>['text'=>$t],$d['steps']),JSON_UNESCAPED_UNICODE)
        : null;
      if($id){
        $upd->execute([json_encode($d['meals'],JSON_UNESCAPED_UNICODE),$d['instructions'],$steps,$id]);
        $updated++;
      }else{
        $ins->execute([$d['name'],json_encode($d['meals'],JSON_UNESCAPED_UNICODE),null,$d['instructions'],$steps,null,now()]);
        $id=(int)$pdo->lastInsertId();
        $added++;
      }
      $delI->execute([$id]); $delT->execute([$id]);
      $lost=[];
      foreach($d['ingredients'] as $i=>$x){
        if(!isset($ing[$x['name']])){ $lost[]=$x['name']; continue; }
        $addI->execute([$id,$ing[$x['name']],$x['grams'],$i]);
      }
      foreach($d['tags'] as $t)$addT->execute([$id,$t]);
      recalc_dish($id);

      /* Сверка с таблицей. Продукт, которого не нашлось в справочнике,
         молча урезал бы блюдо — про такое говорим отдельно и всегда. */
      if($lost) $gaps[]=['name'=>$d['name'],'missing'=>$lost];
      $q=$pdo->prepare('SELECT kcal_100,base_portion_g FROM dishes WHERE id=?');
      $q->execute([$id]); $got=$q->fetch();
      $mine=(float)$got['kcal_100']*(float)$got['base_portion_g']/100;
      $book=(float)($d['kcal']??0);
      if($book>0 && abs($mine-$book)/$book>0.10)
        $diffs[]=['name'=>$d['name'],'calc'=>round($mine),'book'=>round($book)];
    }
    /* При полной замене подчищаем осиротевшие продукты: их не осталось
       ни в одном блюде и нет в файле. Трогаем только заведённые самим
       импортом — то, что специалист добавил своей рукой, не наше. */
    $orphans=0;
    if($replace){
      $keep=array_values($ing);
      $in=$keep?implode(',',array_map('intval',$keep)):'0';
      $st=$pdo->query("DELETE FROM ingredients
        WHERE created_by IS NULL AND id NOT IN ($in)
          AND id NOT IN (SELECT ingredient_id FROM dish_ingredients)");
      $orphans=$st->rowCount();
    }
    $pdo->commit();
  }catch(Throwable $e){
    if($pdo->inTransaction())$pdo->rollBack();
    return ['error'=>$e->getMessage()];
  }
  linkDishPhotos();
  return ['added'=>$added,'updated'=>$updated,'ingredients'=>count($ing),
          'menus_removed'=>$lostMenus,'orphans_removed'=>$orphans,
          'diffs'=>$diffs,'gaps'=>$gaps];
}

/**
 * Пересчитать КБЖУ всех блюд по их составу.
 *
 * Нужно, когда правили справочник продуктов: блюдо хранит КБЖУ на 100 г
 * готовым числом, иначе каталог и меню считали бы сумму по составу на
 * каждый запрос. Это кэш, и после правки справочника он устаревает.
 *
 * Блюда без состава не трогаем: у них считать нечего, а обнулить их
 * КБЖУ значит потерять то, что специалист ввёл руками.
 */
/**
 * Состав и теги блюда — общая часть создания и правки из панели владельца.
 *
 * Состав переписывается целиком, а не правится построчно: у блюда нет
 * своего порядка строк помимо присланного, и «дописать одну» тут значит
 * гадать, какая строка какой соответствует.
 *
 * Вызывать внутри транзакции: без состава блюдо посчитается в ноль.
 */
function adminSaveDishParts(int $dishId,array $in):void{
  $pdo=db();
  if(isset($in['ingredients'])){
    $pdo->prepare('DELETE FROM dish_ingredients WHERE dish_id=?')->execute([$dishId]);
    $add=$pdo->prepare('INSERT INTO dish_ingredients(dish_id,ingredient_id,grams,sort_order) VALUES(?,?,?,?)');
    $i=0;
    foreach($in['ingredients'] as $x){
      $iid=(int)($x['ingredient_id']??0); $g=(float)($x['grams']??0);
      if($iid<=0||$g<=0)continue;      // пустая строка формы — не состав
      $add->execute([$dishId,$iid,$g,$i++]);
    }
    if(!$i) throw new RuntimeException('В составе не осталось ни одного продукта');
  }
  if(isset($in['tags'])){
    $pdo->prepare('DELETE FROM dish_tags WHERE dish_id=?')->execute([$dishId]);
    $add=$pdo->prepare('INSERT OR IGNORE INTO dish_tags(dish_id,tag) VALUES(?,?)');
    foreach((array)$in['tags'] as $t){ $t=trim((string)$t); if($t!=='')$add->execute([$dishId,$t]); }
  }
}

/* ======================================================================
   Техподдержка.

   Обращение и переписка по нему. Пишут клиенты и специалисты, отвечает
   владелец. Отдельно от чата специалиста с клиентом: там разговор про
   питание, здесь — про сервис, и смешивать их нельзя ни по смыслу, ни
   по доступу (переписку клиента со специалистом владелец не читает).
   ====================================================================== */

/** Темы обращения. Список короткий — длинный никто не читает. */
const SUPPORT_TOPICS = [
  'account' => 'Вход и учётная запись',
  'menu'    => 'Меню и блюда',
  'spec'    => 'Специалист и клиенты',
  'bug'     => 'Что-то не работает',
  'other'   => 'Другое',
];

/** Имя автора обращения — для очереди у владельца. */
function ticketAuthor(string $type,int $id):array{
  $t=$type==='specialist'?'specialists':'clients';
  $q=db()->prepare("SELECT name,email FROM $t WHERE id=?");
  $q->execute([$id]); $r=$q->fetch();
  return ['name'=>$r['name']??'Удалённый пользователь','email'=>$r['email']??null];
}

/** Переписка по обращению, по порядку. */
function ticketThread(int $tid):array{
  $q=db()->prepare('SELECT id,from_admin,body,read_at,created_at FROM support_messages WHERE ticket_id=? ORDER BY id');
  $q->execute([$tid]); return $q->fetchAll();
}

/**
 * Ответ владельца: письмо и уведомление в приложении.
 *
 * Обращение часто про то, что человек не может войти, — тогда
 * уведомление в приложении он не увидит, и письмо здесь не запасной
 * канал, а основной.
 */
function notifyTicketReply(array $ticket,string $body):void{
  $pdo=db();
  $who=ticketAuthor((string)$ticket['author_type'],(int)$ticket['author_id']);
  $title='Ответ поддержки: '.$ticket['subject'];
  if($ticket['author_type']==='specialist')
    $pdo->prepare('INSERT INTO specialist_notices(specialist_id,type,title,body,created_at) VALUES(?,?,?,?,?)')
        ->execute([(int)$ticket['author_id'],'support',$title,$body,now()]);
  else
    $pdo->prepare('INSERT INTO notifications(client_id,type,title,body,created_at) VALUES(?,?,?,?,?)')
        ->execute([(int)$ticket['author_id'],'support',$title,$body,now()]);
  if($who['email']){
    [$html,$text]=plainLetter('Вы писали в поддержку: «'.$ticket['subject'].'».',$body,
      'Ответить можно в приложении, раздел «Поддержка».');
    try{ sendMail((string)$who['email'],$title,$html,$text); }
    catch(Throwable $e){ error_log('notifyTicketReply: '.$e->getMessage()); }
  }
}

/* ======================================================================
   Рассылка владельца.

   Отправляется в два места сразу: уведомлением в приложении и письмом.
   Уведомление увидит тот, кто зайдёт; письмо — тот, кто не зайдёт.

   Письма шлём по одному и считаем неудачи, а не падаем на первой:
   у половины адресатов почта может не принять, и это не повод лишить
   рассылки остальных. Что не дошло — видно в отчёте.
   ====================================================================== */
/* Отложенная рассылка.
   Письмо в три часа ночи читают хуже, чем в десять утра, а сидеть и
   ждать нужного часа глупо. Запись ждёт своего времени, а отправляет её
   тот же крон, что рассылает напоминания. */
function scheduleBroadcast(string $audience,string $title,string $body,bool $byEmail,
                           string $segment,string $sendAt):array{
  $title=trim($title); $body=trim($body);
  if($title===''||$body==='')return ['error'=>'Заголовок и текст обязательны'];
  $ts=strtotime($sendAt);
  if(!$ts)return ['error'=>'Не понял дату отправки'];
  if($ts<time()-60)return ['error'=>'Это время уже прошло'];
  db()->prepare('INSERT INTO broadcasts(audience,segment,title,body,by_email,recipients,emails_sent,emails_failed,status,send_at,created_at)
     VALUES(?,?,?,?,?,0,0,0,?,?,?)')
    ->execute([$audience,$segment?:null,$title,$body,$byEmail?1:0,'planned',
               gmdate('Y-m-d H:i:s',$ts),now()]);
  return ['planned_at'=>gmdate('Y-m-d H:i:s',$ts)];
}
/* Отправить всё, чей срок наступил. Зовётся из крона. */
function runPlannedBroadcasts():int{
  $pdo=db();
  $rows=$pdo->query("SELECT * FROM broadcasts WHERE status='planned' AND send_at<=datetime('now')")->fetchAll();
  $done=0;
  foreach($rows as $b){
    /* Помечаем сразу: если отправка оборвётся на середине, второй раз
       то же письмо людям не уйдёт. */
    $upd=$pdo->prepare("UPDATE broadcasts SET status='sending' WHERE id=? AND status='planned'");
    $upd->execute([(int)$b['id']]);
    if(!$upd->rowCount())continue;
    $r=sendBroadcast((string)$b['audience'],(string)$b['title'],(string)$b['body'],
                     !empty($b['by_email']),(string)($b['segment']??''));
    $pdo->prepare("UPDATE broadcasts SET status='sent',recipients=?,emails_sent=?,emails_failed=? WHERE id=?")
        ->execute([(int)($r['recipients']??0),(int)($r['emails_sent']??0),(int)($r['emails_failed']??0),(int)$b['id']]);
    $done++;
  }
  return $done;
}

/* Кому уходит рассылка.
   Кроме трёх общих адресатов есть сегменты: письмо «вернитесь, вы давно
   не отмечали» имеет смысл только тем, кто действительно не отмечал.
   Раньше такое приходилось слать всем подряд. */
const BROADCAST_SEGMENTS=[
  'no_specialist'=>'Клиенты без специалиста',
  'silent'       =>'Клиенты, молчащие 14 дней',
  'menu_no_log'  =>'Есть меню, но ни одной отметки',
];
function broadcastClientsSql(string $segment):string{
  return match($segment){
    'no_specialist'=>'SELECT id,email FROM clients WHERE specialist_id IS NULL',
    'silent'       =>"SELECT id,email FROM clients c WHERE NOT EXISTS(
                        SELECT 1 FROM meal_logs l WHERE l.client_id=c.id
                        AND l.logged_at>=datetime('now','-14 day'))",
    'menu_no_log'  =>"SELECT id,email FROM clients c
                      WHERE EXISTS(SELECT 1 FROM menus m WHERE m.client_id=c.id AND m.status='published')
                        AND NOT EXISTS(SELECT 1 FROM meal_logs l WHERE l.client_id=c.id)",
    default        =>'SELECT id,email FROM clients',
  };
}
function sendBroadcast(string $audience,string $title,string $body,bool $byEmail,string $segment=''):array{
  $pdo=db();
  $title=trim($title); $body=trim($body);
  if($title===''||$body==='')return ['error'=>'Заголовок и текст обязательны'];
  if($segment!==''&&!isset(BROADCAST_SEGMENTS[$segment]))return ['error'=>'Неизвестный сегмент'];
  if($segment!=='')$audience='clients';          /* сегменты бывают только у клиентов */
  if(!in_array($audience,['specialists','clients','all'],true))return ['error'=>'Неизвестный получатель'];

  [$html,$text]=plainLetter($title,$body,'Это письмо от команды '.APP_NAME.'.');
  $n=$sent=$failed=0;

  if($audience==='specialists'||$audience==='all'){
    $note=$pdo->prepare('INSERT INTO specialist_notices(specialist_id,type,title,body,created_at) VALUES(?,?,?,?,?)');
    foreach($pdo->query('SELECT id,email FROM specialists') as $r){
      $note->execute([(int)$r['id'],'broadcast',$title,$body,now()]); $n++;
      if($byEmail&&$r['email']){
        try{ sendMail((string)$r['email'],$title,$html,$text); $sent++; }
        catch(Throwable $e){ $failed++; error_log('broadcast: '.$e->getMessage()); }
      }
    }
  }
  if($audience==='clients'||$audience==='all'){
    $note=$pdo->prepare('INSERT INTO notifications(client_id,type,title,body,created_at) VALUES(?,?,?,?,?)');
    foreach($pdo->query(broadcastClientsSql($segment)) as $r){
      $note->execute([(int)$r['id'],'broadcast',$title,$body,now()]); $n++;
      if($byEmail&&$r['email']){
        try{ sendMail((string)$r['email'],$title,$html,$text); $sent++; }
        catch(Throwable $e){ $failed++; error_log('broadcast: '.$e->getMessage()); }
      }
    }
  }
  $pdo->prepare('INSERT INTO broadcasts(audience,segment,title,body,by_email,recipients,emails_sent,emails_failed,status,created_at)
                 VALUES(?,?,?,?,?,?,?,?,?,?)')
      ->execute([$audience,$segment?:null,$title,$body,$byEmail?1:0,$n,$sent,$failed,'sent',now()]);
  return ['recipients'=>$n,'emails_sent'=>$sent,'emails_failed'=>$failed,
          'broadcast_id'=>(int)$pdo->lastInsertId()];
}

function recalcAllDishes():array{
  $pdo=db();
  $ids=$pdo->query('SELECT DISTINCT dish_id FROM dish_ingredients')->fetchAll(PDO::FETCH_COLUMN);
  $moved=0;
  $before=$pdo->prepare('SELECT kcal_100,base_portion_g FROM dishes WHERE id=?');
  foreach($ids as $id){
    $before->execute([(int)$id]); $b=$before->fetch();
    $was=(float)$b['kcal_100']*(float)$b['base_portion_g']/100;
    recalc_dish((int)$id);
    $before->execute([(int)$id]); $a=$before->fetch();
    $now=(float)$a['kcal_100']*(float)$a['base_portion_g']/100;
    if(abs($now-$was)>1) $moved++;
  }
  $empty=(int)$pdo->query('SELECT COUNT(*) FROM dishes WHERE id NOT IN (SELECT dish_id FROM dish_ingredients)')->fetchColumn();
  return ['recalculated'=>count($ids),'changed'=>$moved,'no_recipe'=>$empty];
}

/**
 * Убрать демонстрационные учётки, оставив одного специалиста и одного клиента.
 *
 * Живёт здесь, а не только в скрипте: папка tools/ закрыта от веба, и на
 * хостинге без SSH запустить её нечем. Владелец делает то же самое кнопкой
 * в своей панели.
 *
 * $apply=false только считает, ничего не трогая, — чтобы кнопка сначала
 * показала, что именно исчезнет.
 */
function cleanupDemo(bool $apply=false, bool $keepCatalog=false):array{
  $pdo=db();
  $keepSpec=(int)$pdo->query('SELECT id FROM specialists ORDER BY id LIMIT 1')->fetchColumn();
  if(!$keepSpec)return ['error'=>'В базе нет ни одного специалиста'];
  $q=$pdo->prepare('SELECT id,name FROM clients WHERE specialist_id=? ORDER BY id LIMIT 1');
  $q->execute([$keepSpec]); $keepRow=$q->fetch();
  $keepClient=$keepRow?(int)$keepRow['id']:0;
  $q=$pdo->prepare('SELECT name,email FROM specialists WHERE id=?'); $q->execute([$keepSpec]); $sp=$q->fetch();

  $delSpecs=array_map('intval',$pdo->query("SELECT id FROM specialists WHERE id<>$keepSpec")->fetchAll(PDO::FETCH_COLUMN));
  if($keepCatalog){
    $show=array_map('intval',$pdo->query("SELECT id FROM specialists WHERE email LIKE 'pro%@nutrimenu.local'")->fetchAll(PDO::FETCH_COLUMN));
    $delSpecs=array_values(array_diff($delSpecs,$show));
  }
  $delClients=array_map('intval',$pdo->query("SELECT id FROM clients WHERE id<>$keepClient")->fetchAll(PDO::FETCH_COLUMN));

  $out=[
    'keep_specialist'=>['id'=>$keepSpec,'name'=>$sp['name']??'','email'=>$sp['email']??''],
    'keep_client'=>$keepClient?['id'=>$keepClient,'name'=>$keepRow['name']]:null,
    'delete_specialists'=>count($delSpecs),
    'delete_clients'=>count($delClients),
    'applied'=>false,
  ];
  if(!$apply||(!$delSpecs&&!$delClients))return $out;

  /* Копия базы до удаления: вернуть — переименовать файл обратно. */
  $bak=DB_PATH.'.before-cleanup-'.date('Ymd-His');
  if(!@copy(DB_PATH,$bak))return $out+['error'=>'Не удалось создать копию базы — удаление отменено'];
  $out['backup']=basename($bak);

  $CT=['menus','meal_logs','messages','weight_logs','notifications','client_onboarding','client_preferences',
    'meal_log_feedback','progress_measurements','progress_photos','shopping_items','specialist_notes',
    'client_checkins','home_products','nutrition_programs','point_redemptions','calls','client_attribution',
    'water_logs','client_allergies','client_meds','client_labs','client_recommendations','specialist_reviews',
    'client_pantry','client_tasks'];
  $ST=['menus','menu_templates','public_profiles','specialist_notes','nutrition_programs','catalog_leads',
    'calls','client_attribution','specialist_services','client_recommendations','specialist_documents',
    'specialist_reviews','specialist_notices','client_tasks','specialist_rewards'];
  $has=fn(string $t):bool=>(bool)$pdo->query("SELECT 1 FROM sqlite_master WHERE type='table' AND name=".$pdo->quote($t))->fetchColumn();

  $pdo->beginTransaction();
  try{
    if($delClients){
      $in=implode(',',$delClients);
      foreach($CT as $t) if($has($t)) $pdo->exec("DELETE FROM $t WHERE client_id IN ($in)");
      if($has('menu_items')) $pdo->exec("DELETE FROM menu_items WHERE menu_id NOT IN (SELECT id FROM menus)");
      if($has('menu_item_replacements')) $pdo->exec("DELETE FROM menu_item_replacements WHERE menu_item_id NOT IN (SELECT id FROM menu_items)");
      if($has('sessions')) $pdo->exec("DELETE FROM sessions WHERE user_type='client' AND user_id IN ($in)");
      if($has('push_subscriptions')) $pdo->exec("DELETE FROM push_subscriptions WHERE user_type='client' AND user_id IN ($in)");
      $pdo->exec("DELETE FROM clients WHERE id IN ($in)");
    }
    if($delSpecs){
      $in=implode(',',$delSpecs);
      foreach($ST as $t) if($has($t)) $pdo->exec("DELETE FROM $t WHERE specialist_id IN ($in)");
      if($has('sessions')) $pdo->exec("DELETE FROM sessions WHERE user_type='specialist' AND user_id IN ($in)");
      if($has('push_subscriptions')) $pdo->exec("DELETE FROM push_subscriptions WHERE user_type='specialist' AND user_id IN ($in)");
      $pdo->exec("DELETE FROM specialists WHERE id IN ($in)");
    }
    $pdo->commit();
  }catch(Throwable $e){
    if($pdo->inTransaction())$pdo->rollBack();
    return $out+['error'=>'Ошибка, ничего не удалено: '.$e->getMessage()];
  }
  $out['applied']=true;
  $out['left_specialists']=(int)$pdo->query('SELECT COUNT(*) FROM specialists')->fetchColumn();
  $out['left_clients']=(int)$pdo->query('SELECT COUNT(*) FROM clients')->fetchColumn();
  return $out;
}

function seed_demo():void{$pdo=db();if((int)$pdo->query('SELECT COUNT(*) FROM specialists')->fetchColumn()===0){$pdo->prepare('INSERT INTO specialists(email,password_hash,name,plan,created_at) VALUES(?,?,?,?,?)')->execute(['demo@nutrimenu.local',password_hash('password',PASSWORD_DEFAULT),'Максим','free',now()]);}
/* Справочник продуктов приходит вместе с каталогом блюд из
   data/dishes.json. Прежний засев доливал его до 250 строк вида
   «Руккола · 31» с выдуманными числами — рукколу он записывал в орехи и
   давал ей 18 г белка. В блюдах такие строки не использовались, но
   специалист видел их в выборе состава и мог собрать блюдо на выдумке. */
/* Каталог блюд — из data/dishes.json, а не из шаблонов в коде.
   Прежний засев доливал базу до сотни строками «Домашнее блюдо №N» с
   выдуманным составом: в меню такие блюда попадали наравне с настоящими
   и выглядели как брак. Теперь на пустой базе загружается настоящий
   каталог, а пополнять его — задача специалиста. */
if((int)$pdo->query('SELECT COUNT(*) FROM dishes')->fetchColumn()===0) importDishes(false);
if((int)$pdo->query('SELECT COUNT(*) FROM clients')->fetchColumn()===0){$sid=(int)$pdo->query('SELECT id FROM specialists ORDER BY id LIMIT 1')->fetchColumn();$pdo->prepare('INSERT INTO clients(specialist_id,name,email,password_hash,sex,birth_year,height_cm,weight_kg,goal,target_kcal,target_protein,target_fat,target_carbs,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$sid,'Анна Петрова','anna@demo.local',password_hash('password',PASSWORD_DEFAULT),'f',(int)date('Y')-32,168,67.4,'Снижение веса',1800,110,60,190,'active',now()]);$cid=(int)$pdo->lastInsertId();$pdo->prepare('INSERT INTO menus(client_id,specialist_id,title,start_date,days_count,status,published_at,created_at) VALUES(?,?,?,?,?,?,?,?)')->execute([$cid,$sid,'Меню Анны · 7 дней',date('Y-m-d'),7,'published',now(),now()]);$mid=(int)$pdo->lastInsertId();$ds=$pdo->query('SELECT id,name,base_portion_g FROM dishes ORDER BY id LIMIT 8')->fetchAll();$meal=['breakfast','snack1','lunch','snack2','dinner','breakfast','lunch'];$mi=$pdo->prepare('INSERT INTO menu_items(menu_id,day_number,meal_type,dish_id,portion_g,sort_order) VALUES(?,?,?,?,?,?)');foreach($ds as $i=>$d)$mi->execute([$mid,1,$meal[$i%count($meal)],$d['id'],round((float)$d['base_portion_g']?:250),$i]);fillDemoDays($mid);
 // демо-прогресс Анны: вес, замеры, отметки питания (чтобы график и метрики были живыми)
 $iw=$pdo->prepare('INSERT OR IGNORE INTO weight_logs(client_id,weight_kg,measured_on) VALUES(?,?,?)');foreach([[35,69.8],[28,69.0],[21,68.3],[14,67.9],[7,67.4]] as $w){$iw->execute([$cid,$w[1],date('Y-m-d',time()-$w[0]*86400)]);}
 $im=$pdo->prepare('INSERT OR IGNORE INTO progress_measurements(client_id,measured_on,waist_cm,hips_cm,chest_cm) VALUES(?,?,?,?,?)');$im->execute([$cid,date('Y-m-d',time()-30*86400),74,98,90]);$im->execute([$cid,date('Y-m-d',time()-7*86400),72,96,89]);
 $mids=$pdo->query('SELECT id FROM menu_items WHERE menu_id='.$mid.' ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);$il=$pdo->prepare('INSERT OR IGNORE INTO meal_logs(menu_item_id,client_id,status,logged_at) VALUES(?,?,?,?)');foreach($mids as $k=>$miid){$il->execute([$miid,$cid,$k===2?'skipped':'eaten',date('Y-m-d H:i:s',time()-($k%3)*3600-1800)]);}
 $mm=$pdo->prepare('INSERT INTO messages(client_id,author_type,body,created_at) VALUES(?,?,?,?)');$mm->execute([$cid,'specialist','Анна, добрый день! Отправила вам меню на неделю 🙂',date('Y-m-d H:i:s',time()-7200)]);$mm->execute([$cid,'client','Мария, спасибо! Можно ли заменить ужин на что-то без рыбы?',date('Y-m-d H:i:s',time()-3600)]);
}
/* Массовку из двадцати трёх клиентов здесь больше не заводим. Для показа
   продукта плотный список был полезен, для работы — нет: специалист
   открывает «Клиентов» и видит два десятка чужих имён, среди которых
   теряются свои. Кто уже получил их при установке — убирает скриптом
   tools/cleanup-demo.php. */
// Публичный профиль основного демо-специалиста + витрина каталога
$pdo->prepare("INSERT INTO public_profiles(specialist_id,slug,bio,city,education,experience_years,specializations,advantages,is_public) SELECT id,'maxim','Помогаю прийти к форме без жёстких диет — через привычки и сбалансированный рацион.','Москва','РНИМУ им. Пирогова, нутрициология',8,'Снижение веса, ЖКТ, вегетарианство','Индивидуальные меню и еженедельные созвоны',1 FROM specialists WHERE email='demo@nutrimenu.local' AND NOT EXISTS(SELECT 1 FROM public_profiles pp WHERE pp.specialist_id=specialists.id)")->execute();
/* Пять выдуманных специалистов для витрины каталога тоже убраны. Живым
   людям каталог с несуществующими нутрициологами обещает то, чего нет, а
   пустой каталог честно говорит, что специалистов пока не набралось. */
$pdo->prepare("UPDATE specialists SET avatar_url='https://i.pravatar.cc/512?img=68' WHERE email='demo@nutrimenu.local' AND (avatar_url IS NULL OR avatar_url='')")->execute();
/* Витрина каталога — демо-данные, и в каталог теперь пускают только
   проверенных. Отмечаем ровно эти учётки, чтобы витрина не опустела;
   на настоящие регистрации это не распространяется — они проходят
   проверку у владельца, как и положено.
   Условие «поле ещё пустое» важно: иначе снятая владельцем отметка
   возвращалась бы сама при следующем же запросе. */
$pdo->exec("UPDATE specialists SET verify_status='verified',verified_at=datetime('now')
            WHERE email='demo@nutrimenu.local'
              AND (verify_status IS NULL OR verify_status='')");

}
seed_demo();

/* Досбор атрибуции. Backfill в миграции 009 отрабатывает до seed_demo(), а на
   боевом сервере — до появления новых клиентов, если связь создали в обход
   attributeClient(). Проверка дешёвая: составной UNIQUE(client_id,specialist_id)
   уже индекс, и при отсутствии пропусков запрос ничего не находит. */
(function(){$p=db();
  $q=$p->query("SELECT 1 FROM clients c WHERE c.specialist_id IS NOT NULL AND NOT EXISTS(
      SELECT 1 FROM client_attribution a WHERE a.client_id=c.id AND a.specialist_id=c.specialist_id) LIMIT 1");
  if($q->fetchColumn())
    $p->exec("INSERT OR IGNORE INTO client_attribution(client_id,specialist_id,source,linked_at)
      SELECT id,specialist_id,'unknown',created_at FROM clients WHERE specialist_id IS NOT NULL");
})();

/**
 * Дневная норма воды в миллилитрах.
 * Заданная клиентом важнее расчётной; расчёт — 30 мл на килограмм веса.
 */
function waterGoal(int $clientId): int {
  $q=db()->prepare('SELECT water_goal_ml,weight_kg FROM clients WHERE id=?');
  $q->execute([$clientId]); $r=$q->fetch();
  if($r && (int)$r['water_goal_ml']>0) return (int)$r['water_goal_ml'];
  $kg=(float)($r['weight_kg']??0);
  if($kg<=0) return 2000;
  return max(1500, min(4000, (int)(round($kg*30/100)*100)));
}
