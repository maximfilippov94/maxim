<?php
/**
 * Open Food Facts — магазинные товары со штрихкодами.
 *
 * Свой справочник — это сырые и базовые продукты: курица, гречка,
 * творог. Их достаточно, чтобы отметить «свёкла и греческий йогурт».
 * Но человек чаще ест не «йогурт», а «Активиа 2,9%» из пачки со
 * штрихкодом, и вот эти позиции берём из Open Food Facts.
 *
 * Правила разбора взяты из официальной схемы полей проекта
 * (docs/api/ref/schemas/product_nutrition.yaml), а не по памяти:
 *   • брать поля с суффиксом `_100g` — они уже приведены к 100 г
 *     в стандартных единицах, в отличие от полей без суффикса,
 *     которые могут быть «на порцию» (см. nutrition_data_per);
 *   • пропускать товары с no_nutrition_data = "on" — таких тысячи;
 *   • энергия в ккал лежит в `energy-kcal_100g`, а `energy_100g` —
 *     это килоджоули, и перепутать их значит завысить всё в 4 раза.
 *
 * Чужие данные заносят добровольцы, поэтому каждая строка проходит ту
 * же проверку «ккал сходятся с БЖУ», что и свой файл. Не сошлось —
 * товар не берём: неверное КБЖУ в дневнике хуже, чем его отсутствие.
 */
declare(strict_types=1);

const OFF_BASE = 'https://world.openfoodfacts.org';
/* Сервис просит представляться — иначе режет запросы. */
const OFF_UA = 'EQUA/1.0 (nutrimenu.ru)';

/** Категории Open Food Facts на наши полки. Что не угадалось — в «Магазинные товары». */
function offCategory(array $tags): string {
  $map = [
    'yogurts'=>'Молочные','dairies'=>'Молочные','cheeses'=>'Молочные','milks'=>'Молочные',
    'breads'=>'Хлеб и выпечка','biscuits-and-cakes'=>'Сладкое','chocolates'=>'Сладкое',
    'sweet-snacks'=>'Сладкое','confectioneries'=>'Сладкое',
    'beverages'=>'Напитки','waters'=>'Напитки','juices'=>'Напитки',
    'meats'=>'Мясо и птица','poultry'=>'Мясо и птица','sausages'=>'Колбасы и деликатесы',
    'fishes'=>'Рыба и морепродукты','seafood'=>'Рыба и морепродукты',
    'cereals-and-potatoes'=>'Крупы и гарниры','pastas'=>'Крупы и гарниры','rice'=>'Крупы и гарниры',
    'legumes'=>'Бобовые','nuts'=>'Орехи и семена','vegetables'=>'Овощи','fruits'=>'Фрукты и ягоды',
    'fats'=>'Масла и жиры','vegetable-oils'=>'Масла и жиры','sauces'=>'Соусы и прочее',
    'eggs'=>'Яйца','frozen-foods'=>'Готовое и полуфабрикаты','meals'=>'Готовое и полуфабрикаты',
  ];
  foreach ($tags as $t) {
    $t = preg_replace('/^[a-z]{2}:/', '', (string)$t);
    if (isset($map[$t])) return $map[$t];
  }
  return 'Магазинные товары';
}

/**
 * Один товар из ответа Open Food Facts в нашу строку справочника.
 * Вернёт null, если брать нечего — это не ошибка, а обычное дело.
 */
function offRow(array $p): ?array {
  if (($p['no_nutrition_data'] ?? '') === 'on') return null;
  $n = $p['nutriments'] ?? [];
  if (!is_array($n)) return null;

  $num = function($v): ?float {
    if ($v === null || $v === '') return null;
    return is_numeric($v) ? (float)$v : null;
  };
  $kcal = $num($n['energy-kcal_100g'] ?? null);
  /* Килоджоули — запасной путь, если ккал не заполнили. */
  if ($kcal === null) { $kj = $num($n['energy-kj_100g'] ?? null); if ($kj !== null) $kcal = $kj / 4.184; }
  if ($kcal === null) return null;

  $prot = $num($n['proteins_100g'] ?? null) ?? 0.0;
  $fat  = $num($n['fat_100g'] ?? null) ?? 0.0;
  $carb = $num($n['carbohydrates_100g'] ?? null) ?? 0.0;
  $fib  = $num($n['fiber_100g'] ?? null) ?? 0.0;

  $name = trim((string)($p['product_name_ru'] ?? $p['product_name'] ?? ''));
  if ($name === '' || mb_strlen($name) > 120) return null;
  $brand = trim(explode(',', (string)($p['brands'] ?? ''))[0]);

  if ($kcal < 0 || $kcal > 950) return null;
  if ($prot + $fat + $carb > 101) return null;
  if (!foodKcalPlausible($kcal, $prot, $fat, $carb, $fib)) return null;

  $code = preg_replace('/\D+/', '', (string)($p['code'] ?? ''));
  if ($code === '') return null;

  return [
    'name'     => $brand !== '' && mb_stripos($name, $brand) === false ? "$name, $brand" : $name,
    'brand'    => $brand !== '' ? $brand : null,
    'barcode'  => $code,
    'category' => offCategory((array)($p['categories_tags'] ?? [])),
    'kcal'     => round($kcal, 1),
    'protein'  => round($prot, 1),
    'fat'      => round($fat, 1),
    'carbs'    => round($carb, 1),
    'fiber'    => round($fib, 1),
    'serving'  => is_numeric($p['serving_quantity'] ?? null) ? (float)$p['serving_quantity'] : null,
  ];
}

/** Запрос к Open Food Facts. Возвращает [данные, ошибка]. */
function offFetch(string $url): array {
  $ctx = stream_context_create(['http'=>[
    'method'=>'GET','timeout'=>20,
    'header'=>"User-Agent: ".OFF_UA."\r\nAccept: application/json\r\n",
    'ignore_errors'=>true,
  ]]);
  $raw = @file_get_contents($url, false, $ctx);
  if ($raw === false) return [null, 'Open Food Facts недоступен с этого сервера'];
  $j = json_decode($raw, true);
  if (!is_array($j)) return [null, 'Ответ Open Food Facts не разобрался'];
  return [$j, null];
}

/** Товар по штрихкоду. */
function offByBarcode(string $code): ?array {
  $code = preg_replace('/\D+/', '', $code);
  if ($code === '' || strlen($code) > 20) return null;
  $fields = 'code,product_name,product_name_ru,brands,categories_tags,nutriments,no_nutrition_data,serving_quantity';
  [$j, $err] = offFetch(OFF_BASE."/api/v2/product/$code?fields=$fields");
  if ($err || (int)($j['status'] ?? 0) !== 1 || !is_array($j['product'] ?? null)) return null;
  return offRow($j['product']);
}

/** Сохранить строку Open Food Facts в справочник. Вернёт id. */
function offStore(array $r): int {
  $pdo = db();
  $q = $pdo->prepare('SELECT id FROM ingredients WHERE barcode=?');
  $q->execute([$r['barcode']]);
  $id = (int)$q->fetchColumn();
  if ($id) return $id;
  /* Тёзка без штрихкода — не тот же товар: «Йогурт» из нашего файла и
     «Йогурт, Данон» из магазина живут рядом. Совпадение имени целиком
     всё же схлопываем, чтобы не плодить дубли. */
  $q = $pdo->prepare('SELECT id FROM ingredients WHERE lower(name)=lower(?) AND barcode IS NULL');
  $q->execute([$r['name']]);
  if ($id = (int)$q->fetchColumn()) {
    $pdo->prepare('UPDATE ingredients SET barcode=?, brand=COALESCE(brand,?), source=? WHERE id=?')
        ->execute([$r['barcode'], $r['brand'], 'off', $id]);
    return $id;
  }
  $pdo->prepare('INSERT INTO ingredients(name,name_fold,category,kcal,protein,fat,carbs,fiber,unit,is_public,source,barcode,brand,per_serving_g,created_at)
                 VALUES(?,?,?,?,?,?,?,?,"g",1,"off",?,?,?,?)')
      ->execute([$r['name'],foodFold($r['name'].' '.(string)$r['brand']),$r['category'],
                 $r['kcal'],$r['protein'],$r['fat'],$r['carbs'],$r['fiber'],
                 $r['barcode'],$r['brand'],$r['serving'],now()]);
  return (int)$pdo->lastInsertId();
}
