# EQUA — платежи, комиссия и выплаты

Модель: клиент платит специалисту через сервис, сервис удерживает комиссию.
Ставка зависит от того, кто привёл клиента.

**Состояние на сентябрь 2026.** Учётная часть написана целиком: баланс,
заморозка, приёмка, споры, заявки на вывод, экраны у всех трёх ролей.
Настоящих денег через неё не проходит — эквайер не подключён. Переключатель
режима в панели владельца («Ещё → Деньги»):

| Режим | Что происходит |
|---|---|
| `off` (по умолчанию) | как раньше: услуга включается по договорённости, движений по балансу нет |
| `demo` | механика работает целиком на учебных суммах, вывод закрыт, на экранах стоит плашка |
| `live` | эквайер подключён, вывод разрешён |

Между `off` и `live` нельзя прыгнуть, не увидев экранов в работе — для этого
среднее состояние и существует.

---

## 1. Семь решений, которые определяют всё остальное

**1.1. Деньги — целые копейки в `INTEGER`.** Никаких `REAL` и рублей с точкой.
`0.1 + 0.2 != 0.3` в любом языке с плавающей точкой, а расхождение в копейку
на сверке с банком стоит часов разбирательств. Все поля называются `*_kop`,
чтобы никто не перепутал единицу.

**1.2. Ставка и сумма комиссии фиксируются в заказе.** Не ссылкой на
настройки, а числом, в момент создания заказа. Владелец завтра поменяет
ставку — прошлые заказы обязаны остаться такими, какими их видел клиент.
Пересчитываемая задним числом комиссия — это спор со специалистом, который
вы проиграете, потому что доказать нечем.

**1.3. Атрибуция клиента фиксируется при связывании, а не при оплате.**
Пришёл из каталога — записали. Специалист позвал по коду — записали. Через
полгода источник уже не восстановить. **Сейчас в базе этого нет** —
`clients.specialist_id` есть, а откуда взялась связь, неизвестно. Это первое,
что надо добавить, до всей остальной схемы.

**1.4. Мы не кошелёк.** Сплит на стороне эквайера: деньги делятся при
зачислении, наша доля падает нам, доля специалиста — ему. Приём чужих денег
на свой счёт с последующим переводом — это 115-ФЗ и заблокированный счёт.
Наши таблицы ведут **учёт**, а не хранят чужие средства.

**1.5. Всё идемпотентно.** У платежа — `idempotence_key`, у вебхука —
уникальный `event_id`. Платёжный провайдер шлёт повторы, это норма, а не сбой.
Без этого один платёж однажды зачислится дважды.

**1.6. Скидку за баллы платит сервис, а не специалист.** Промокоды из
`point_redemptions` — это ваша маркетинговая акция. Специалист получает свою
полную цену, скидка вычитается из вашей комиссии. Иначе вы раздаёте скидки за
чужой счёт, и первый же специалист, который это заметит, уйдёт.
Ограничение: скидка не может превышать комиссию.

**1.7. Ничего не удаляем.** Только статусы. Финансовые записи неизменяемы:
отмена — это новый статус, возврат — новая запись.

---

## 2. Схема данных

Стиль существующей базы: `id INTEGER PRIMARY KEY AUTOINCREMENT`,
`created_at TEXT` в UTC, статусы строками.

> **Чем написанное отличается от этого раздела.** Отдельной таблицы `orders`
> в коде нет: её роль играет `client_subscriptions` (миграция 024) — там
> уже лежит покупка со снимком названия, цены и периода, и заводить рядом
> вторую таблицу о том же значило бы держать две правды. Поля, которые
> ниже описаны у заказа, добавлены к ней: `commission_rate`,
> `commission_kop`, `payout_kop`, `acquirer_fee_kop`, `paid_at`, `done_at`,
> `accept_due_at`, `accepted_at`, `accepted_by`, `disputed_at`, `ended_at`,
> `provider_deal_id`. Таблица `payments` появится вместе с эквайером: пока
> платежей нет, писать в неё нечего. Всё остальное ниже — как описано.
>
> Чего в этом разделе не было вовсе: **`balance_entries`** — реестр движений
> баланса. Баланс не хранится, а считается суммой движений, и выписка
> специалисту — это они же. У движения два столбца со знаком (`held_kop`,
> `avail_kop`), потому что разморозка — одно событие, которое убавляет
> замороженное и прибавляет доступное; двумя строками пришлось бы следить,
> чтобы они не разъехались.

### 2.1. Атрибуция — откуда клиент

```sql
CREATE TABLE client_attribution(
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id      INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  specialist_id  INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  source         TEXT NOT NULL,   -- catalog | invite | self
  lead_id        INTEGER REFERENCES catalog_leads(id),
  linked_at      TEXT NOT NULL,
  UNIQUE(client_id, specialist_id)
);
```

Пара «клиент + специалист», а не просто клиент: клиент может сменить
специалиста, и для нового источник будет другой.

* `catalog` — пришёл через каталог или по лиду. Повышенная ставка.
* `invite` — специалист позвал по `join_code` или ссылке-приглашению.
* `self` — зарегистрировался сам, специалиста выбрал позже вручную.

`invite` и `self` считаются «своими» и идут по базовой ставке.

### 2.2. Прайс специалиста

```sql
CREATE TABLE specialist_services(
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id  INTEGER NOT NULL REFERENCES specialists(id) ON DELETE CASCADE,
  title          TEXT NOT NULL,        -- «Ведение · месяц», «Разбор анализов»
  description    TEXT,
  kind           TEXT NOT NULL,        -- one_time | subscription
  price_kop      INTEGER NOT NULL CHECK(price_kop > 0),
  period_days    INTEGER,              -- только для subscription, обычно 30
  is_active      INTEGER NOT NULL DEFAULT 1,
  sort_order     INTEGER NOT NULL DEFAULT 0,
  created_at     TEXT NOT NULL
);
CREATE INDEX idx_services_spec ON specialist_services(specialist_id, is_active);
```

Существующее `public_profiles.price` — витринная цена «от», для карточки в
каталоге. Она остаётся как есть, для маркетинга. Платят по
`specialist_services`.

Услуги не удаляются, а гасятся `is_active = 0`: на них ссылаются старые заказы.

### 2.3. Заказ

```sql
CREATE TABLE orders(
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id       INTEGER NOT NULL REFERENCES clients(id),
  specialist_id   INTEGER NOT NULL REFERENCES specialists(id),
  service_id      INTEGER REFERENCES specialist_services(id),

  -- снимки на момент заказа: услугу могут переименовать или удалить
  title           TEXT NOT NULL,
  kind            TEXT NOT NULL,        -- one_time | subscription

  amount_kop      INTEGER NOT NULL,     -- сколько платит клиент
  discount_kop    INTEGER NOT NULL DEFAULT 0,
  redemption_id   INTEGER REFERENCES point_redemptions(id),

  source          TEXT NOT NULL,        -- снимок атрибуции
  commission_rate REAL NOT NULL,        -- снимок ставки: 0.10 / 0.25
  commission_kop  INTEGER NOT NULL,     -- снимок в деньгах
  payout_kop      INTEGER NOT NULL,     -- сколько причитается специалисту

  status          TEXT NOT NULL DEFAULT 'awaiting_payment',
  period_start    TEXT,                 -- для subscription
  period_end      TEXT,

  created_at      TEXT NOT NULL,
  paid_at         TEXT,
  canceled_at     TEXT
);
CREATE INDEX idx_orders_client ON orders(client_id, status);
CREATE INDEX idx_orders_spec   ON orders(specialist_id, status);
```

**Как считаются деньги:**

```
base            = service.price_kop
discount_kop    = min(скидка по промокоду, commission_base)
amount_kop      = base − discount_kop          ← платит клиент
commission_base = base × commission_rate
commission_kop  = commission_base − discount_kop   ← остаётся сервису
payout_kop      = base − commission_base           ← уходит специалисту
```

Обратите внимание: `payout_kop` считается от `base`, а не от `amount_kop`.
Специалист получает свою цену независимо от вашей скидки — это решение 1.6.

Инвариант, который должен проверяться тестом:
`amount_kop == commission_kop + payout_kop`.

**Статусы заказа:**

```
awaiting_payment ──► paid ──► refunded
        │
        ├──► canceled     (клиент отменил или истёк срок оплаты)
        └──► failed       (оплата не прошла)
```

### 2.4. Платежи

Одному заказу может соответствовать несколько попыток оплаты.

```sql
CREATE TABLE payments(
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id            INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  provider            TEXT NOT NULL DEFAULT 'yookassa',
  provider_payment_id TEXT UNIQUE,
  idempotence_key     TEXT NOT NULL UNIQUE,
  amount_kop          INTEGER NOT NULL,
  status              TEXT NOT NULL,   -- pending | waiting_for_capture | succeeded | canceled
  payment_method      TEXT,            -- bank_card | sbp | …
  saved_method_id     TEXT,            -- для автосписаний по подписке
  confirmation_url    TEXT,
  error_code          TEXT,
  error_text          TEXT,
  created_at          TEXT NOT NULL,
  updated_at          TEXT
);
```

### 2.5. Вебхуки

```sql
CREATE TABLE payment_events(
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  provider     TEXT NOT NULL,
  event_id     TEXT NOT NULL,
  event_type   TEXT,
  payload      TEXT NOT NULL,     -- сырое тело, как пришло
  processed_at TEXT,
  created_at   TEXT NOT NULL,
  UNIQUE(provider, event_id)
);
```

Сырое тело храним всегда. Когда через полгода клиент скажет «я платил», а в
`orders` пусто — это единственное, что позволит разобраться.

`UNIQUE(provider, event_id)` + `INSERT OR IGNORE` и есть защита от повторов:
если вставка не прошла, событие уже обработано, выходим.

### 2.6. Выплаты

При сплите деньги уходят специалисту сразу, но реестр всё равно нужен: для
сверки, для отчётности и на случай, если провайдер сплит не поддержит и
придётся платить вручную.

```sql
CREATE TABLE payouts(
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  specialist_id     INTEGER NOT NULL REFERENCES specialists(id),
  amount_kop        INTEGER NOT NULL,
  status            TEXT NOT NULL,  -- pending | sent | paid | failed
  provider_payout_id TEXT,
  period_from       TEXT,
  period_to         TEXT,
  error_text        TEXT,
  created_at        TEXT NOT NULL,
  paid_at           TEXT
);
CREATE TABLE payout_orders(
  payout_id  INTEGER NOT NULL REFERENCES payouts(id) ON DELETE CASCADE,
  order_id   INTEGER NOT NULL REFERENCES orders(id),
  amount_kop INTEGER NOT NULL,
  PRIMARY KEY(payout_id, order_id)
);
```

`payout_orders` с составным ключом гарантирует, что один заказ не попадёт в
две выплаты.

### 2.7. Реквизиты специалиста

```sql
CREATE TABLE specialist_payout_details(
  specialist_id         INTEGER PRIMARY KEY REFERENCES specialists(id) ON DELETE CASCADE,
  legal_type            TEXT,      -- self_employed | ip | individual
  inn                   TEXT,
  account_masked        TEXT,      -- последние 4 знака для показа в интерфейсе
  provider_recipient_id TEXT,      -- идентификатор получателя у эквайера
  agreement_accepted_at TEXT,      -- когда принят агентский договор
  verified              INTEGER NOT NULL DEFAULT 0,
  updated_at            TEXT
);
```

**Полные реквизиты у себя не храним.** Счёт живёт у платёжного провайдера, у
нас — только `provider_recipient_id` и маска для интерфейса. Меньше данных —
меньше ответственности по 152-ФЗ и нечего утекать.

Пока `verified = 0` или нет `agreement_accepted_at` — услуги специалиста
нельзя оплатить.

### 2.8. Настройки комиссии

```sql
CREATE TABLE commission_settings(
  id                  INTEGER PRIMARY KEY CHECK(id = 1),
  rate_own            REAL NOT NULL DEFAULT 0.10,
  rate_catalog        REAL NOT NULL DEFAULT 0.25,
  catalog_period_days INTEGER NOT NULL DEFAULT 90,
  updated_at          TEXT
);
```

Одна строка, `CHECK(id = 1)` не даст завести вторую.

Ставка заказа выбирается так:

```
источник ≠ catalog                                      → rate_own
источник = catalog, прошло < catalog_period_days от linked_at → rate_catalog
источник = catalog, прошло больше                        → rate_own
```

---

## 3. API

Все суммы в ответах — в копейках, поля `*_kop`. Форматирование в рубли —
задача интерфейса.

### 3.1. Специалист

| Метод | Путь | Что делает |
|---|---|---|
| `GET` | `/specialist/services` | свой прайс |
| `POST` | `/specialist/services` | добавить услугу |
| `PATCH` | `/specialist/services/{id}` | изменить |
| `DELETE` | `/specialist/services/{id}` | погасить (`is_active = 0`) |
| `GET` | `/specialist/orders?status=&from=&to=` | заказы |
| `GET` | `/specialist/earnings` | оборот, комиссия, к выплате, выплачено |
| `GET` | `/specialist/payout-details` | реквизиты и статус проверки |
| `PATCH` | `/specialist/payout-details` | заполнить реквизиты |
| `POST` | `/specialist/agreement/accept` | принять агентский договор |

`GET /specialist/earnings`:

```json
{
  "period": {"from": "2026-09-01", "to": "2026-09-30"},
  "turnover_kop": 12500000,
  "commission_kop": 1875000,
  "payout_kop": 10625000,
  "paid_out_kop": 8000000,
  "pending_kop": 2625000,
  "orders": 41,
  "by_source": {"catalog": 12, "own": 29}
}
```

### 3.2. Клиент

| Метод | Путь | Что делает |
|---|---|---|
| `GET` | `/client/services` | прайс своего специалиста |
| `POST` | `/client/orders` | создать заказ и платёж |
| `GET` | `/client/orders` | свои заказы и статусы |
| `GET` | `/client/orders/{id}` | один заказ |
| `POST` | `/client/orders/{id}/cancel` | отменить неоплаченный |
| `POST` | `/client/subscription/cancel` | отключить автопродление |

`POST /client/orders` — тело `{"service_id": 12, "redemption_id": 3}`:

```json
{
  "order": {"id": 108, "title": "Ведение · месяц",
            "amount_kop": 450000, "discount_kop": 50000,
            "status": "awaiting_payment"},
  "payment": {"confirmation_url": "https://yoomoney.ru/checkout/..."}
}
```

Клиент уходит по `confirmation_url`, возвращается на `/app/?order=108`.
**Оплаченным заказ считается только по вебхуку**, никогда — по возврату
пользователя на страницу. Возврат в браузере подделывается тривиально.

### 3.3. Вебхук

| Метод | Путь |
|---|---|
| `POST` | `/payments/webhook` |

Без авторизации, поэтому защита другая:

1. проверить, что IP в списке сетей провайдера;
2. записать событие в `payment_events` через `INSERT OR IGNORE`;
3. если `rowCount() == 0` — повтор, ответить `200` и выйти;
4. запросить статус платежа **у провайдера по API**, не доверяя телу запроса;
5. перевести заказ в `paid`, проставить `paid_at`, для подписки — период;
6. ответить `200`.

Пункт 4 обязателен. Тело вебхука — это утверждение постороннего о том, что вам
заплатили; верить ему на слово нельзя.

Всегда отвечать `200` после записи события: иначе провайдер будет слать
повторы, а проблема — на нашей стороне и от повторов не решится.

### 3.4. Владелец

| Метод | Путь | Что делает |
|---|---|---|
| `GET` | `/admin/finance?from=&to=` | оборот, комиссия, к выплате |
| `GET` | `/admin/commission` | текущие ставки |
| `PATCH` | `/admin/commission` | изменить (на будущие заказы) |
| `GET` | `/admin/orders?status=&specialist_id=` | все заказы |
| `GET` | `/admin/payouts` | реестры выплат |
| `POST` | `/admin/payouts` | сформировать реестр за период |
| `POST` | `/admin/orders/{id}/refund` | возврат |

Именно эти цифры закроют блок «Чего здесь нет» в сводке владельца — теми
самыми настоящими числами.

---

## 4. Подписки

Для `kind = subscription`:

* при первой оплате сохраняем `saved_method_id`;
* `period_end = period_start + period_days`;
* cron за день до конца создаёт новый заказ и списывает автоплатежом;
* не прошло — три попытки с интервалом в сутки, потом заказ `failed`,
  доступ к меню не отключаем сразу, а показываем предупреждение;
* отмена автопродления не отменяет оплаченный период.

Комиссия у каждого продления считается заново: если 90 дней каталожной ставки
истекли, продление уже идёт по базовой.

---

## 5. Порядок работ

1. ~~**`client_attribution` и заполнение источника при связывании.**~~ **Сделано.**
   Миграция `009_payments_foundation.sql`, источник пишется во всех четырёх
   точках связывания, существующие 26 связей помечены `unknown`.
2. ~~Прайс специалиста: таблица, API, экран.~~ **Сделано.** «Ещё → Мои услуги»
   у специалиста, «Ещё → Услуги и цены» у клиента. Оплаты нет, это витрина.
3. ~~**Учётная часть: баланс, заморозка, приёмка, выплаты.**~~ **Сделано.**
   Миграция `025_balance.sql`: реестр движений `balance_entries`, реквизиты,
   заявки на вывод, связь заявки со сделками. Логика — в `config.php`
   (`subPay`, `balanceAccrue`, `balanceOf`). Экраны: «Ещё → Баланс» у
   специалиста в вебе и приложении, карточка приёмки у клиента, «Ещё → Деньги»
   у владельца. Проверка логики — `balance-test.php`, 22 сценария, включая
   прошедшие дни, молчание клиента и отказ в выплате.
4. ~~**Слой провайдера, журналы, подбор сделок.**~~ **Сделано.**
   `config/provider.php` — интерфейс из четырёх операций (открыть сделку,
   разобрать уведомление, закрыть сделки и выплатить, вернуть) и заглушка
   `StubProvider`. Миграция `026_payments_journal.sql` — журналы `payments` и
   `webhooks` с уникальным ключом по событию: повторное уведомление, которое
   эквайеры шлют всегда, не задвоит заморозку. `payoutPick()` раскладывает
   заявку на конкретные покупки в порядке разморозки и заполняет
   `payout_orders`; отказ в выплате их освобождает. Приём уведомлений —
   `POST /payments/webhook/{provider}`, без авторизации: эквайер наших токенов
   не носит, подлинность проверяет подпись в `parseWebhook`.
5. Договор с ЮKassa или Т-Банком, сплит, тестовый магазин.
6. Настоящий провайдер: класс рядом со `StubProvider`, ключи в
   `config/payments.php` (в поставку не входит, как `mail.php`), боевой платёж
   на 10 ₽ самому себе. Учёт при этом не меняется — в этом и был смысл слоя.
7. Подписки и автоплатежи — последними, они сложнее всего.

Пункты 1 и 2 можно делать хоть сейчас, они ни от чего не зависят и ничего не
ломают.

---

## 5a. Что выяснилось про эквайеров

Проверено по открытым источникам в сентябре 2026. **Тарифы и точные лимиты
нужно подтверждать у менеджера банка**: ниже то, что написано на их страницах,
а не то, что нам пообещают в договоре.

**ЮKassa, «Безопасная сделка».** Сделана под C2C-площадки, включая сервисы
подбора специалистов. Деньги удерживаются на специальном счёте **до трёх
месяцев**. Подключение — через персонального менеджера, API v3.

**Т-Банк, «Мультирасчёты»** (безопасная сделка и сплитование в одном сервисе).
Заморозка на счёте покупателя или банка, выплата продавцу — **до двух
месяцев**. Если через **6 дней** покупатель не подтвердил получение, а площадка
не сняла заморозку, деньги уходят на транзитный счёт банка и лежат там до 60
дней. Работает без расчётного счёта, зачисление на следующий день.

Три следствия для нашей схемы:

1. **Ограничение «7 дней» относилось к обычному холдированию карты, а не к
   этим сервисам.** У обоих настоящий эскроу на два-три месяца. Поэтому
   подписка ограничена месяцем (проверка в `serviceInput`): месяц укладывается
   с запасом, три — впритык, а по подписке на полгода незаработанную часть уже
   нечем было бы вернуть.
2. **Посуточной разморозки у банка нет.** Он умеет только «закрыть сделку и
   выплатить». Значит наш посуточный учёт — единственный способ это сделать, и
   это ровно то, что делает `balanceAccrue()`.
3. **Эскроу и автоматические чеки самозанятого вместе не идут.** ЮKassa
   регистрирует чеки в «Моём налоге» сама, но в документации прямо сказано:
   при Безопасной сделке и Сплитовании чеки регистрируются вручную. Это
   отдельный вопрос к решению, а не деталь интеграции.

Ещё одно место, которое всплывёт при подключении: эквайер закрывает не «сумму»,
а конкретные сделки. Чтобы перевести специалисту 5 400 ₽, надо знать, из каких
покупок они сложились. Под это заведены `payout_orders` (составной ключ против
двойной выплаты), `client_subscriptions.provider_deal_id` и
`payout_requests.provider_payout_id` — сейчас пустые, заполнять их будет
интеграция.

---

## 6. Что нужно от вас, а не от кода

* договор с ЮKassa или Т-Банком, включённый сплит;
* агентский договор со специалистами — текст оферты;
* решение по чекам: при Безопасной сделке ЮKassa их автоматически не
  регистрирует (см. 5a), значит либо самозанятый пробивает сам через «Мой
  налог», либо нужен отдельный механизм;
* политика возвратов: за сколько дней, кто платит комиссию при возврате;
* что происходит с оплаченным ведением, если специалист ушёл с платформы.

Последний вопрос — не юридическая формальность. Клиент заплатил за месяц,
специалист исчез: деньги уже у него, а претензия придёт к вам.
