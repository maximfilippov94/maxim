<?php
http_response_code(200);
/* Заголовок страницы ведёт владелец из панели; в разметке остаётся
   запасной вариант — пустое поле не должно опустошать сайт. */
require_once __DIR__.'/config/config.php';
$H=fn(string $k,string $d)=>htmlspecialchars(siteText($k,$d),ENT_QUOTES,'UTF-8');
?><!doctype html>
<html lang="ru"><head><link rel="icon" type="image/png" sizes="32x32" href="/icon-32.png"><link rel="icon" type="image/svg+xml" href="/icon.svg">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Каталог специалистов — EQUA</title>
<meta name="description" content="Найдите нутрициолога, тренера или коуча: рейтинги, цены, образование и специализации. Персональное питание с личным специалистом.">
<style>
:root{--accent:#19B95B;--accent-strong:#0FA958;--accent-050:#eafaf0;--ink:#0f1a14;--ink-2:#475247;--ink-3:#8a968c;--line:#e6ebe6;--line-2:#f0f3f0;--panel:#fff;--panel-2:#f6f9f6;--sh:0 10px 30px rgba(16,40,24,.08)}
*{box-sizing:border-box;margin:0;padding:0}
body{font:15px/1.5 'Manrope',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;color:var(--ink);background:var(--panel-2);-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}
.ic{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
header.top{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.92);backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.top-in{max-width:1120px;margin:0 auto;padding:14px 20px;display:flex;align-items:center;justify-content:space-between}
.logo{font-weight:800;font-size:19px;display:flex;align-items:center;gap:8px}
.logo b{color:var(--accent-strong)}
.logo .mk{width:30px;height:30px;border-radius:9px;background:var(--accent-050);color:var(--accent-strong);display:grid;place-items:center}
.back{color:var(--ink-2);font-weight:600;font-size:14px}
.wrap{max-width:1120px;margin:0 auto;padding:32px 20px 70px}
.head h1{font-size:30px;font-weight:800;letter-spacing:-.02em}
.head p{color:var(--ink-2);margin-top:6px;max-width:640px}
.controls{display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin:22px 0 26px}
.chips{display:flex;gap:8px;flex-wrap:wrap}
.chip{padding:9px 16px;border-radius:999px;border:1.5px solid var(--line);background:#fff;font-weight:600;font-size:14px;color:var(--ink-2);cursor:pointer;transition:.15s}
.chip:hover{border-color:var(--accent)}
.chip.active{background:var(--accent);border-color:var(--accent);color:#fff}
.search{margin-left:auto;display:flex;align-items:center;gap:8px;background:#fff;border:1.5px solid var(--line);border-radius:12px;padding:9px 14px;min-width:240px}
.search input{border:none;outline:none;font:inherit;width:100%;background:none}
.search .ic{color:var(--ink-3);flex:none}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px}
.card{background:#fff;border:1px solid var(--line);border-radius:20px;padding:0;overflow:hidden;box-shadow:var(--sh);display:flex;flex-direction:column;transition:transform .16s,box-shadow .16s}
.card:hover{transform:translateY(-4px);box-shadow:0 20px 46px rgba(16,40,24,.14)}
.photo-wrap{position:relative;width:100%;aspect-ratio:1/1;background:var(--panel-2);cursor:pointer}
.photo{width:100%;height:100%;object-fit:cover;display:block}
.photo-fallback{width:100%;height:100%;display:grid;place-items:center;color:#fff;font-weight:800;font-size:76px}
.photo-role{position:absolute;top:12px;left:12px;font-size:12px;font-weight:700;padding:5px 11px;border-radius:999px;background:rgba(255,255,255,.92);color:var(--accent-strong);backdrop-filter:blur(6px)}
.photo-rating{position:absolute;top:12px;right:12px;display:flex;align-items:center;gap:4px;font-size:13px;font-weight:800;color:#fff;background:rgba(15,26,20,.55);padding:5px 10px;border-radius:999px;backdrop-filter:blur(6px)}
.photo-rating .star{color:#fbbf24}
.body{padding:18px 20px 20px;display:flex;flex-direction:column;flex:1}
.c-name{font-size:19px;font-weight:800;cursor:pointer}.c-name:hover{color:var(--accent-strong)}
.c-name-row{display:flex;align-items:center;gap:6px}
.vfd{display:inline-flex;align-items:center;gap:4px;font-size:12px;font-weight:700;color:var(--accent-strong);background:var(--accent-050);border-radius:999px;padding:3px 9px;white-space:nowrap}
.vfd .ic{width:14px;height:14px;stroke-width:2.4}
.c-sub{color:var(--ink-3);font-size:13px;font-weight:600;margin-top:2px}
.bio{color:var(--ink-2);font-size:14px;margin:12px 0 12px;flex:1}
.meta{display:flex;flex-direction:column;gap:8px;font-size:13.5px;margin-bottom:12px}
.meta .row{display:flex;gap:9px;align-items:flex-start;color:var(--ink-2)}
.meta .ic{width:17px;height:17px;color:var(--ink-3);flex:none;margin-top:1px}
.meta .row b{color:var(--ink)}
.specs{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}
.spec{font-size:12px;font-weight:600;padding:4px 10px;border-radius:999px;background:var(--panel-2);color:var(--ink-2);border:1px solid var(--line-2)}
.adv{background:var(--accent-050);border-radius:12px;padding:11px 13px;font-size:13px;color:#166534;margin-bottom:16px;display:flex;gap:8px}
.adv .ic{color:var(--accent-strong);width:17px;height:17px;flex:none;margin-top:1px}
.c-foot{margin-top:auto}
.price{font-size:17px;font-weight:800;margin-bottom:12px}.price span{font-size:12px;color:var(--ink-3);font-weight:600}
.foot-btns{display:grid;grid-template-columns:auto 1fr;gap:8px}
.btn{background:var(--accent);color:#fff;border:none;border-radius:12px;padding:12px 20px;font:inherit;font-weight:700;cursor:pointer;transition:.15s;text-align:center}
.btn:hover{background:var(--accent-strong)}
.btn.ghost{background:#fff;border:1.5px solid var(--line);color:var(--ink-2)}
.btn.ghost:hover{border-color:var(--accent);color:var(--accent-strong);background:#fff}
.empty{grid-column:1/-1;text-align:center;padding:70px 20px;color:var(--ink-3)}
.modal{position:fixed;inset:0;background:rgba(10,20,14,.45);display:grid;place-items:center;padding:20px;z-index:60}
.sheet{background:#fff;border-radius:20px;padding:26px;max-width:420px;width:100%;box-shadow:0 30px 70px rgba(0,0,0,.3)}
.sheet h2{font-size:20px;font-weight:800;margin-bottom:4px}
.sheet p.sub{color:var(--ink-2);font-size:14px;margin-bottom:16px}
.sheet label{display:block;font-size:13px;font-weight:600;color:var(--ink-2);margin-bottom:12px}
.sheet input,.sheet textarea{width:100%;margin-top:5px;padding:11px 13px;border:1.5px solid var(--line);border-radius:11px;font:inherit;outline:none}
.sheet input:focus,.sheet textarea:focus{border-color:var(--accent)}
.sheet .row2{display:flex;gap:12px}.sheet .row2>label{flex:1}
.ok-msg{text-align:center;padding:10px 0}
.ok-msg .big{width:56px;height:56px;border-radius:50%;background:var(--accent-050);color:var(--accent-strong);display:grid;place-items:center;margin:0 auto 12px}
.err{color:#dc2626;font-size:13px;margin-bottom:10px}
@media(max-width:560px){.head h1{font-size:24px}.search{margin-left:0;width:100%}.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<header class="top"><div class="top-in">
  <a class="logo" href="/"><span class="mk"><svg class="ic" viewBox="0 0 24 24"><path d="M17 7c1.5-1.5 3-1.4 4-1-.4 1-.4 2.5-1.9 4M14.5 6.5 18 10 9 19c-2 2-6 2-6.5 1.5S4 15 6 13z"/></svg></span><b>EQUA</b></a>
  <a class="back" href="/">← На главную</a>
</div></header>
<div class="wrap">
  <div class="head">
    <h1><?= $H('catalog_title','Каталог специалистов') ?></h1>
    <p>Нутрициологи, тренеры и коучи, которые ведут питание клиентов в EQUA. Смотрите рейтинг, цену, образование и записывайтесь напрямую.</p>
  </div>
  <div class="controls">
    <div class="chips" id="chips">
      <button class="chip active" data-p="">Все</button>
      <button class="chip" data-p="nutritionist">Нутрициологи</button>
      <button class="chip" data-p="trainer">Тренеры</button>
      <button class="chip" data-p="coach">Коучи</button>
    </div>
    <div class="search"><svg class="ic" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.2-3.2"/></svg><input id="q" placeholder="Имя, город или направление…"></div>
  </div>
  <div class="grid" id="grid"><div class="empty">Загрузка…</div></div>
</div>
<div id="modalRoot"></div>
<script>
var PROF={nutritionist:'Нутрициолог',trainer:'Тренер',coach:'Коуч'};
var IC={cart:'',cal:'M3.5 5h17v16h-17zM3.5 9.5h17M8 3v4M16 3v4',pin:'M12 21s7-5.3 7-11a7 7 0 1 0-14 0c0 5.7 7 11 7 11ZM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z',clock:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 8v4l3 2',grad:'M12 3 2 8l10 5 10-5-10-5ZM6 10.5V15c0 1.7 2.7 3 6 3s6-1.3 6-3v-4.5',spark:'M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z',users:'M9 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM3.5 19c.7-3.2 2.6-5 5.5-5s4.8 1.8 5.5 5',check:'m5 12 4.5 4.5L19 7',shield:'M12 3l7 2.5v5.2c0 4.3-2.9 7.6-7 9.3-4.1-1.7-7-5-7-9.3V5.5L12 3ZM8.8 11.8l2.2 2.2 4.2-4.2'};
function svg(n){return '<svg class="ic" viewBox="0 0 24 24"><path d="'+(IC[n]||'')+'"/></svg>';}
function plural(n,f){var a=Math.abs(n)%100,b=a%10;var w=a>4&&a<21?f[2]:b===1?f[0]:b>1&&b<5?f[1]:f[2];return n+' '+w;}
function esc(s){return (s==null?'':String(s)).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function hue(name){var s=0;for(var i=0;i<(name||'').length;i++)s+=name.charCodeAt(i);return s%360;}
var state={p:'',q:''};
function load(){
  var url='/api/v1/catalog?profession='+encodeURIComponent(state.p)+'&q='+encodeURIComponent(state.q);
  fetch(url).then(function(r){return r.json();}).then(function(j){render(j.specialists||[]);}).catch(function(){document.getElementById('grid').innerHTML='<div class="empty">Не удалось загрузить каталог</div>';});
}
function render(list){
  var g=document.getElementById('grid');
  if(!list.length){g.innerHTML='<div class="empty">Никого не нашлось. Попробуйте изменить фильтр.</div>';return;}
  g.innerHTML=list.map(function(s){
    var prof='specialist.php?slug='+encodeURIComponent(s.slug||'');
    var h=hue(s.name),mono=esc((s.name||'·').trim()[0]||'·').toUpperCase();
    var photo=s.avatar_url
      ? '<img class="photo" src="'+esc(s.avatar_url)+'" alt="'+esc(s.name)+'" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'grid\'"><div class="photo-fallback" style="display:none;background:linear-gradient(135deg,hsl('+h+' 60% 55%),hsl('+((h+40)%360)+' 60% 48%))">'+mono+'</div>'
      : '<div class="photo-fallback" style="background:linear-gradient(135deg,hsl('+h+' 60% 55%),hsl('+((h+40)%360)+' 60% 48%))">'+mono+'</div>';
    var specs=(s.specializations||'').split(',').map(function(x){return x.trim();}).filter(Boolean).slice(0,3);
    return '<div class="card">'+
      '<div class="photo-wrap" onclick="location.href=\''+prof+'\'">'+photo+
        '<span class="photo-role">'+esc(PROF[s.profession]||'Специалист')+'</span>'+
        (s.rating?'<span class="photo-rating"><span class="star">★</span>'+s.rating+'</span>':'')+
      '</div>'+
      '<div class="body">'+
        '<div class="c-name-row"><div class="c-name" onclick="location.href=\''+prof+'\'">'+esc(s.name)+'</div>'+(+s.verified===1?'<span class="vfd" title="EQUA проверила диплом и сертификаты">'+svg('shield')+'Проверен</span>':'')+'</div>'+
        '<div class="c-sub">'+[s.city?esc(s.city):'',s.experience_years?'опыт '+s.experience_years+' лет':'',(+s.reviews_count>0?plural(+s.reviews_count,['отзыв','отзыва','отзывов']):'отзывов пока нет')].filter(Boolean).join(' · ')+'</div>'+
        (s.bio?'<div class="bio">'+esc(s.bio)+'</div>':'<div class="bio"></div>')+
        (s.education?'<div class="meta"><div class="row">'+svg('grad')+'<span>'+esc(s.education)+'</span></div></div>':'')+
        (specs.length?'<div class="specs">'+specs.map(function(x){return '<span class="spec">'+esc(x)+'</span>';}).join('')+'</div>':'')+
        (s.advantages?'<div class="adv">'+svg('spark')+'<span>'+esc(s.advantages)+'</span></div>':'')+
        '<div class="c-foot"><div class="price">'+(s.price?s.price+' ₽ <span>/ '+esc(s.price_unit||'мес')+'</span>':'<span>Цена по запросу</span>')+'</div>'+
        '<div class="foot-btns"><a class="btn ghost" href="'+prof+'">Профиль</a>'+
        '<button class="btn" onclick="lead('+s.id+',&quot;'+esc(s.name).replace(/"/g,'&quot;')+'&quot;)">Записаться</button></div></div></div></div>';
  }).join('');
}
function lead(id,name){
  document.getElementById('modalRoot').innerHTML='<div class="modal" onclick="if(event.target===this)closeM()"><div class="sheet">'+
    '<h2>Записаться к специалисту</h2><p class="sub">'+esc(name)+' свяжется с вами по указанному контакту.</p>'+
    '<div id="lerr"></div>'+
    '<label>Ваше имя<input id="l_name"></label>'+
    '<label>Телефон или мессенджер<input id="l_contact" placeholder="+7… или @username"></label>'+
    '<label>Комментарий (необязательно)<textarea id="l_msg" rows="3" placeholder="Ваша цель, вопросы…"></textarea></label>'+
    '<button class="btn" style="width:100%" onclick="sendLead('+id+')">Отправить заявку</button>'+
    '<button class="btn" style="width:100%;background:#eef2ee;color:#475247;margin-top:8px" onclick="closeM()">Отмена</button>'+
    '</div></div>';
}
function closeM(){document.getElementById('modalRoot').innerHTML='';}
function sendLead(id){
  var name=(document.getElementById('l_name').value||'').trim();
  var contact=(document.getElementById('l_contact').value||'').trim();
  if(!name||!contact){document.getElementById('lerr').innerHTML='<div class="err">Укажите имя и контакт</div>';return;}
  fetch('/api/v1/catalog/'+id+'/lead',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name,contact:contact,message:(document.getElementById('l_msg').value||'')})})
   .then(function(r){return r.json().then(function(j){return {ok:r.ok,j:j};});})
   .then(function(res){if(!res.ok)throw new Error(res.j.error||'Ошибка');
     document.querySelector('.sheet').innerHTML='<div class="ok-msg"><div class="big">'+svg('check')+'</div><h2>Заявка отправлена!</h2><p class="sub">Специалист свяжется с вами в ближайшее время.</p><button class="btn" style="width:100%" onclick="closeM()">Готово</button></div>';
   }).catch(function(e){document.getElementById('lerr').innerHTML='<div class="err">'+esc(e.message)+'</div>';});
}
document.getElementById('chips').addEventListener('click',function(e){var b=e.target.closest('.chip');if(!b)return;state.p=b.dataset.p;[].forEach.call(this.querySelectorAll('.chip'),function(x){x.classList.toggle('active',x===b);});load();});
var t;document.getElementById('q').addEventListener('input',function(){clearTimeout(t);state.q=this.value;t=setTimeout(load,250);});
load();
</script>
</body></html>
