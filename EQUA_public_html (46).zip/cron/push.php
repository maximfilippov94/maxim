<?php
declare(strict_types=1);

/* Только из планировщика, не из браузера. Рядом лежит .htaccess с
   «Deny from all», но он молчит на nginx и на чужой конфигурации, а
   открытый снаружи скрипт копий — это способ забить диск чужими
   руками. Проверка в самом файле не зависит от веб-сервера. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

/* Планировщик хостинга шлёт владельцу всё, что скрипт напечатал. При
   запуске раз в минуту любая болтовня превращается в полторы тысячи
   писем в сутки — например, замечание библиотеки push об отсутствии
   расширения GMP, которое она выводит на каждом запуске.
   
   Своего обработчика достаточно и там, где display_errors выключить
   не дают: он забирает сообщение себе и в поток не пишет ничего.
   Ошибки при этом не теряются — уходят в лог хостинга. */
ini_set('display_errors','0');
ini_set('log_errors','1');
/* Без своего файла error_log() в консоли пишет в stderr — то есть
   ровно туда, откуда планировщик берёт текст для письма. */
ini_set('error_log',__DIR__.'/../storage/cron.log');
error_reporting(E_ALL);
set_error_handler(static function(int $no,string $msg,string $file='',int $line=0):bool{
  /* Замечание библиотеки push об отсутствии GMP приходит на каждом
     запуске и ни о чём не говорит: без расширения она просто считает
     медленнее. В логе от него была бы каша из полутора тысяч строк
     в сутки. */
  if(str_contains($msg,'GMP or BCMath')) return true;
  error_log(sprintf('cron/push: %s in %s:%d',$msg,$file,$line));
  return true;   // сообщение обработано, печатать его не нужно
});
require __DIR__.'/../config/config.php';
/* Шифрование и подпись делает сам PHP: каталог vendor планировщику
   больше не нужен, и его отсутствие на сервере не оставит людей без
   напоминаний. Ключи создаются сами при первом обращении. */
$keys=vapidKeys();
if(!$keys){fwrite(STDERR,"Не удалось создать ключи push — проверьте расширение openssl.\n");exit(1);}
$pdo=db();$now=new DateTimeImmutable('now',new DateTimeZone(getenv('EQUA_TIMEZONE')?:getenv('NUTRIMENU_TIMEZONE')?:'Europe/Moscow'));$hm=$now->format('H:i');$day=$now->format('Y-m-d');
/* ---------------------------------------------------------------
   Ранний выход.

   Скрипт стоит в планировщике раз в минуту — это 1440 запусков в
   сутки, — а работа у него есть в считанные из них. Полный обход
   клиентов и специалистов стоит около сотни запросов к базе, и
   гонять их вхолостую на shared-хостинге незачем.

   Уходим сразу в двух случаях: слать некому (нет ни одной подписки)
   или слать нечего (время не совпало ни с одним напоминанием, и меню
   никто только что не опубликовал).
   --------------------------------------------------------------- */
if((int)$pdo->query('SELECT COUNT(*) FROM push_subscriptions')->fetchColumn()===0) exit;

/* Часы напоминаний зашиты ниже по коду; здесь их список для проверки,
   есть ли вообще повод просыпаться. Меняя время там, поправьте и тут. */
/* Планировщик у хостера стоит раз в пять минут, а не раз в минуту:
   ровного совпадения с «08:30» ждать нельзя, иначе напоминание о
   завтраке не уйдёт ни разу. Совпадением считаем попадание в
   пятиминутное окно после отметки, а чтобы оно не ушло дважды,
   каждое напоминание отмечается в push_events. */
$marks=['08:00','08:30','10:00','11:00','13:00','16:30','19:00'];
$hit=null;
foreach($marks as $m){
  $t=strtotime($day.' '.$m);
  if($now->getTimestamp()>=$t && $now->getTimestamp()<$t+300){$hit=$m;break;}
}
/* Меню и отметки питания ищем за то же окно, что и период запуска:
   при кроне раз в пять минут окно в две минуты теряло три из них. */
$WIN=360;
$freshMenu=(int)$pdo->query("SELECT COUNT(*) FROM menus WHERE status='published'
  AND published_at >= '".gmdate('Y-m-d H:i:s',time()-$WIN)."'")->fetchColumn();
$freshLogs=(int)$pdo->query("SELECT COUNT(*) FROM meal_logs
  WHERE logged_at >= datetime('now','-".$WIN." seconds')")->fetchColumn();
/* Ранний выход только когда работы нет совсем. Раньше он стоял до
   проверки отметок питания, и уведомления о них не уходили никогда —
   кроме пяти минут в сутки, совпавших с напоминанием. */
if($hit===null && !$freshMenu && !$freshLogs) exit;
$hm=$hit??$hm;
/* Одно напоминание в сутки на человека: окно в пять минут иначе
   накрыло бы два запуска подряд. */
function markOnce(PDO $pdo,string $key):bool{
  $ins=$pdo->prepare('INSERT OR IGNORE INTO push_events(event_key,created_at) VALUES(?,?)');
  $ins->execute([$key,now()]);
  return $ins->rowCount()>0;
}

function quiet(string $hm,string $start,string $end):bool{if($start<$end)return $hm>=$start&&$hm<$end;return $hm>=$start||$hm<$end;}
/* Одно и то же напоминание уходит двумя дорогами: в браузер — очередью
   Web Push, в приложение — службой Expo. Второй путь работает и без
   vendor с ключами VAPID, поэтому стоит отдельно. */
function sendToUser(string $type,int $uid,string $title,string $body,string $url,$unused=null,string $screen=''):void{
  pushSend($type,$uid,$title,$body,$url,'nutrimenu',$screen);
}
$clients=$pdo->query('SELECT c.*,m.id menu_id,m.start_date,m.days_count FROM clients c LEFT JOIN menus m ON m.client_id=c.id AND m.status="published" AND m.id=(SELECT MAX(id) FROM menus mm WHERE mm.client_id=c.id AND mm.status="published")')->fetchAll();
foreach($clients as $c){ensurePrefs('client',(int)$c['id']);$q=$pdo->prepare('SELECT * FROM notification_preferences WHERE user_type="client" AND user_id=?');$q->execute([$c['id']]);$p=$q->fetch();if(!$p||quiet($hm,$p['quiet_start'],$p['quiet_end']))continue;$dayNo=$c['menu_id']?max(1,min((int)$c['days_count'],(int)floor((strtotime($day)-strtotime($c['start_date']))/86400)+1)):1; /* Пять приёмов, а не три: перекусы были в дне, но напоминаний о них
   не приходило. Переключателя у перекусов свой нет — они идут вместе
   с завтраком и ужином, чтобы не плодить тумблеров.

   Напоминание уходит и без меню: дневник работает сам по себе, и
   человеку, который просто записывает съеденное, оно нужно не меньше.
   Разница только в тексте: с меню видно, что именно сегодня по плану. */
$mealMap=[
  '08:30'=>['breakfast','Завтрак','Пора позавтракать 🍳','breakfast'],
  '11:00'=>['snack1','Перекус','Время перекуса 🍎','breakfast'],
  '13:00'=>['lunch','Обед','Время обеда 🍽','lunch'],
  '16:30'=>['snack2','Перекус','Время перекуса 🍎','dinner'],
  '19:00'=>['dinner','Ужин','Время ужина 🍽','dinner'],
];
if(isset($mealMap[$hm])&&((int)$p[$mealMap[$hm][3]])&&markOnce($pdo,'meal:'.$c['id'].':'.$day.':'.$hm)){
  [$mt,$label,$msg]=$mealMap[$hm];
  $dish='';
  if($c['menu_id']){
    $q=$pdo->prepare('SELECT d.name FROM menu_items mi JOIN dishes d ON d.id=mi.dish_id
                      WHERE mi.menu_id=? AND mi.day_number=? AND mi.meal_type=? ORDER BY mi.sort_order LIMIT 1');
    $q->execute([$c['menu_id'],$dayNo,$mt]);
    $dish=(string)($q->fetchColumn()?:'');
  }
  sendToUser('client',(int)$c['id'],$label,
    $dish?($msg.' Сегодня: '.$dish):($msg.' Не забудьте отметить в дневнике.'),
    '/app/',null,'/client');
}
if($hm==='08:00'&&(int)$p['weight']&&markOnce($pdo,'weight:'.$c['id'].':'.$day))sendToUser('client',(int)$c['id'],'Время прогресса ⚖','Добавьте сегодняшний вес, чтобы видеть динамику.','/app/',null,'/weight');
if((int)$p['menu_updates']&&$c['menu_id']){ $q=$pdo->prepare('SELECT published_at FROM menus WHERE id=?');$q->execute([$c['menu_id']]);$pub=$q->fetchColumn();if($pub&&$pub>=gmdate('Y-m-d H:i:s',time()-$WIN)&&markOnce($pdo,'menu:'.$c['menu_id'].':'.$pub))sendToUser('client',(int)$c['id'],'Меню обновлено ✨','Специалист опубликовал или обновил ваше меню.','/app/',null,'/client/week');}
}
$specialists=$pdo->query('SELECT id,name FROM specialists')->fetchAll();
foreach($specialists as $s){ensurePrefs('specialist',(int)$s['id']);$q=$pdo->prepare('SELECT * FROM notification_preferences WHERE user_type="specialist" AND user_id=?');$q->execute([$s['id']]);$p=$q->fetch();if(!$p||quiet($hm,$p['quiet_start'],$p['quiet_end']))continue;/* Сообщения здесь больше не разбираются: push по ним уходит прямо из
   маршрута отправки, мгновенно. Планировщик раз в пять минут доставлял
   бы их с опозданием, а половину терял вовсе. */
if((int)$p['meal_logs']){ $q=$pdo->prepare('SELECT ml.id,c.name,ml.status FROM meal_logs ml JOIN clients c ON c.id=ml.client_id WHERE c.specialist_id=? AND ml.logged_at>=datetime("now","-".$WIN." seconds") ORDER BY ml.logged_at DESC LIMIT 5');$q->execute([$s['id']]);foreach($q->fetchAll() as $lr){$ek='meal_log:'.$lr['id'];$ins=$pdo->prepare('INSERT OR IGNORE INTO push_events(event_key,created_at) VALUES(?,?)');$ins->execute([$ek,now()]);if($ins->rowCount())sendToUser('specialist',(int)$s['id'],'Обновление питания 🍽',$lr['name'].($lr['status']==='eaten'?' отметил блюдо.':' пропустил блюдо.'),'/app/',null,'/sp/clients');}}
if((int)$p['client_inactive']&&$hm==='10:00'&&markOnce($pdo,'inactive:'.$s['id'].':'.$day)){ $q=$pdo->prepare('SELECT COUNT(*) FROM clients c WHERE c.specialist_id=? AND c.status="active" AND (SELECT MAX(logged_at) FROM meal_logs ml WHERE ml.client_id=c.id) < datetime("now","-2 day")');$q->execute([$s['id']]);$n=(int)$q->fetchColumn();if($n)sendToUser('specialist',(int)$s['id'],'Фокус на сегодня',''.$n.' клиент(а) не отмечают питание 2+ дня.','/app/',null,'/sp/clients');}}

/* ============================================================
   САМИ СОБОЙ: удержание и отложенные рассылки

   До сих пор всё, что удерживало человека, требовало живого участия:
   заметить, что он пропал, и написать. Эти сценарии делают то же самое
   без нас — но ровно один раз на человека и случай, чтобы напоминание
   не превратилось в назойливость.

   Все три работают раз в сутки в 11:00 и отмечаются в push_events:
   повторный запуск крона в ту же минуту ничего не продублирует.
   ============================================================ */
if($hm==='11:00'){
  /* 1. Клиент перестал отмечать еду — три дня тишины. */
  $q=$pdo->query("SELECT c.id,c.name FROM clients c
    WHERE c.status='active'
      AND EXISTS(SELECT 1 FROM meal_logs l WHERE l.client_id=c.id)
      AND (SELECT MAX(logged_at) FROM meal_logs l WHERE l.client_id=c.id)
          BETWEEN datetime('now','-4 day') AND datetime('now','-3 day')");
  foreach($q->fetchAll() as $c){
    if(!markOnce($pdo,'winback:'.$c['id'].':'.$day))continue;
    sendToUser('client',(int)$c['id'],'Вернёмся к дневнику?',
      'Вы не отмечали еду три дня. Пара нажатий — и специалист снова видит, как идут дела.',
      '/app/',null,'/client');
  }

  /* 2. Зарегистрировался и второй день без специалиста. Ждать дольше
        бессмысленно: без специалиста сервис для клиента почти пуст. */
  $q=$pdo->query("SELECT id,name FROM clients
    WHERE specialist_id IS NULL AND status='active'
      AND created_at BETWEEN datetime('now','-3 day') AND datetime('now','-2 day')");
  foreach($q->fetchAll() as $c){
    if(!markOnce($pdo,'nospec:'.$c['id']))continue;
    sendToUser('client',(int)$c['id'],'Выберите специалиста',
      'В каталоге есть проверенные нутрициологи — с меню от специалиста дневник начинает работать по-настоящему.',
      '/app/',null,'/client/find');
  }

  /* 3. Меню заканчивается через два дня — предупреждаем специалиста,
        пока он ещё успевает составить следующее. */
  $q=$pdo->query("SELECT m.id,m.specialist_id,c.name client_name
    FROM menus m JOIN clients c ON c.id=m.client_id
    WHERE m.status='published' AND m.start_date IS NOT NULL AND m.days_count>0
      AND date(m.start_date,'+'||m.days_count||' day') = date('now','+2 day')");
  foreach($q->fetchAll() as $m){
    if(!markOnce($pdo,'menuend:'.$m['id']))continue;
    sendToUser('specialist',(int)$m['specialist_id'],'Меню скоро кончится',
      'У клиента «'.$m['client_name'].'» меню заканчивается через два дня.',
      '/app/',null,'/sp/clients');
  }
}

/* Запланированные рассылки: время наступило — отправляем. */
try{ runPlannedBroadcasts(); }catch(Throwable $e){ error_log('broadcast cron: '.$e->getMessage()); }

/* ============================================================
   Письма владельцу: сводка дел и итоги недели.

   Заявка на вывод и обращение без ответа лежат ровно до тех пор, пока
   владелец не откроет панель, — а открывает он её не каждый день.
   Поэтому сводка приходит письмом, но только если делам есть о чём
   сообщить; час выбран тот же, что у автосценариев.

   Оба письма ограничены изнутри (mailOwnerThrottled), поэтому повторный
   запуск планировщика в ту же минуту ничего не продублирует даже там,
   где cron настроен дважды.
   ============================================================ */
if($hm==='10:00' && settingGet('report_digest')!=='0'){
  try{ ownerDigest(); }catch(Throwable $e){ error_log('owner digest: '.$e->getMessage()); }
}
if(settingGet('report_weekly')==='1'){
  $wd=(int)(settingGet('report_weekday')??1);            // 1 — понедельник
  $hr=(int)(settingGet('report_hour')??10);
  if((int)$now->format('N')===$wd && (int)$now->format('G')===$hr){
    try{ sendWeeklyReport(); }catch(Throwable $e){ error_log('weekly report: '.$e->getMessage()); }
  }
}

/* Отписки чистит сама отправка: она видит код ответа службы. */
