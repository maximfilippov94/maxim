<?php http_response_code(200); ?><!doctype html>
<html lang="ru"><head><link rel="icon" type="image/png" sizes="32x32" href="/icon-32.png"><link rel="icon" type="image/svg+xml" href="/icon.svg">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Специалист — EQUA</title>
<meta name="description" content="Профиль специалиста EQUA: опыт, образование, специализации и запись на консультацию.">
<style>
:root{--accent:#19B95B;--accent-strong:#0FA958;--accent-050:#eafaf0;--ink:#0f1a14;--ink-2:#475247;--ink-3:#8a968c;--line:#e6ebe6;--line-2:#f0f3f0;--panel-2:#f6f9f6;--sh:0 10px 30px rgba(16,40,24,.08)}
*{box-sizing:border-box;margin:0;padding:0}
body{font:15px/1.55 'Manrope',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;color:var(--ink);background:var(--panel-2);-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}
.ic{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
header.top{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.92);backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.top-in{max-width:1000px;margin:0 auto;padding:14px 20px;display:flex;align-items:center;justify-content:space-between}
.logo{font-weight:800;font-size:19px;display:flex;align-items:center;gap:8px}.logo b{color:var(--accent-strong)}
.logo .mk{width:30px;height:30px;border-radius:9px;background:var(--accent-050);color:var(--accent-strong);display:grid;place-items:center}
.back{color:var(--ink-2);font-weight:600;font-size:14px}
.wrap{max-width:1000px;margin:0 auto;padding:28px 20px 80px}
.hero{display:grid;grid-template-columns:340px 1fr;gap:30px;align-items:start}
.photo-col{position:sticky;top:92px}
.photo-wrap{position:relative;width:100%;aspect-ratio:1/1;border-radius:22px;overflow:hidden;box-shadow:var(--sh);background:var(--panel-2)}
.photo{width:100%;height:100%;object-fit:cover;display:block}
.photo-fallback{width:100%;height:100%;display:grid;place-items:center;color:#fff;font-weight:800;font-size:110px}
.price-card{background:#fff;border:1px solid var(--line);border-radius:18px;padding:18px;margin-top:16px;box-shadow:var(--sh)}
.price-card .p{font-size:24px;font-weight:800}.price-card .p span{font-size:13px;color:var(--ink-3);font-weight:600}
.price-card .btn{width:100%;margin-top:12px}
.role-badge{display:inline-block;font-size:13px;font-weight:700;padding:5px 12px;border-radius:999px;background:var(--accent-050);color:var(--accent-strong);margin-bottom:12px}
.badges{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:12px}
.badges .role-badge{margin-bottom:0}
.vfd{display:inline-flex;align-items:center;gap:5px;font-size:13px;font-weight:700;padding:5px 12px;border-radius:999px;background:var(--accent-050);color:var(--accent-strong)}
.vfd .ic{width:15px;height:15px;stroke-width:2.3}
.docs{display:flex;flex-direction:column;gap:10px}
.doc{display:flex;gap:11px;align-items:flex-start;background:#fff;border:1px solid var(--line);border-radius:14px;padding:13px 15px}
.doc .ic{color:var(--accent-strong);flex:none;margin-top:2px}
.doc b{display:block;font-size:14.5px}
.doc small{color:var(--ink-3);font-size:13px}
.docs-note{color:var(--ink-3);font-size:13px;margin-top:10px}
h1{font-size:34px;font-weight:800;letter-spacing:-.02em;line-height:1.1}
.rating{display:flex;align-items:center;gap:8px;margin-top:12px;font-weight:700}
.rating.no{color:var(--ink-3);font-weight:600}
.muted{color:var(--ink-2)}
.rating .star{color:#f59e0b;font-size:18px}.rating small{color:var(--ink-3);font-weight:600}
.facts{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0 8px}
.fact{display:flex;align-items:center;gap:9px;background:#fff;border:1px solid var(--line);border-radius:13px;padding:11px 14px;font-size:14px;font-weight:600}
.fact .ic{width:18px;height:18px;color:var(--accent-strong)}
.fact b{font-weight:800}
.sect{margin-top:28px}
.sect h2{font-size:19px;font-weight:800;margin-bottom:12px}
.sect p{color:var(--ink-2);font-size:15px}
.card{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px 20px}
.adv{background:var(--accent-050);border-radius:14px;padding:16px 18px;color:#166534;display:flex;gap:10px}
.adv .ic{color:var(--accent-strong);flex:none}
.specs{display:flex;flex-wrap:wrap;gap:8px}
.spec{font-size:13.5px;font-weight:600;padding:7px 14px;border-radius:999px;background:#fff;border:1px solid var(--line);color:var(--ink-2)}
.reviews{display:grid;gap:12px}
.review{background:#fff;border:1px solid var(--line);border-radius:15px;padding:16px 18px}
.review .stars{color:#f59e0b;font-size:14px}
.review p{margin:8px 0;color:var(--ink);font-size:14.5px}
.review .by{font-size:13px;color:var(--ink-3);font-weight:600}
.demo-note{color:var(--ink-3);font-size:12px;margin-top:8px}
/* modal */
.modal{position:fixed;inset:0;background:rgba(10,20,14,.45);display:grid;place-items:center;padding:20px;z-index:60}
.sheet{background:#fff;border-radius:20px;padding:26px;max-width:420px;width:100%;box-shadow:0 30px 70px rgba(0,0,0,.3)}
.sheet h2{font-size:20px;font-weight:800;margin-bottom:4px}
.sheet p.sub{color:var(--ink-2);font-size:14px;margin-bottom:16px}
.sheet label{display:block;font-size:13px;font-weight:600;color:var(--ink-2);margin-bottom:12px}
.sheet input,.sheet textarea{width:100%;margin-top:5px;padding:11px 13px;border:1.5px solid var(--line);border-radius:11px;font:inherit;outline:none}
.sheet input:focus,.sheet textarea:focus{border-color:var(--accent)}
.btn{background:var(--accent);color:#fff;border:none;border-radius:12px;padding:12px 20px;font:inherit;font-weight:700;cursor:pointer;transition:.15s;text-align:center;display:inline-block}
.btn:hover{background:var(--accent-strong)}
.ok-msg{text-align:center;padding:10px 0}.ok-msg .big{width:56px;height:56px;border-radius:50%;background:var(--accent-050);color:var(--accent-strong);display:grid;place-items:center;margin:0 auto 12px}
.err{color:#dc2626;font-size:13px;margin-bottom:10px}
.loading,.notfound{text-align:center;padding:90px 20px;color:var(--ink-3)}
@media(max-width:760px){.hero{grid-template-columns:1fr;gap:20px}.photo-col{position:static}.photo-wrap{max-width:300px;margin:0 auto}h1{font-size:27px}}
</style>
</head>
<body>
<header class="top"><div class="top-in">
  <a class="logo" href="/"><span class="mk"><svg class="ic" viewBox="0 0 24 24"><path d="M17 7c1.5-1.5 3-1.4 4-1-.4 1-.4 2.5-1.9 4M14.5 6.5 18 10 9 19c-2 2-6 2-6.5 1.5S4 15 6 13z"/></svg></span><b>EQUA</b></a>
  <a class="back" href="/catalog.php">← В каталог</a>
</div></header>
<div class="wrap" id="root"><div class="loading">Загрузка…</div></div>
<div id="modalRoot"></div>
<script>
var PROF={nutritionist:'Нутрициолог',trainer:'Тренер',coach:'Коуч'};
var IC={pin:'M12 21s7-5.3 7-11a7 7 0 1 0-14 0c0 5.7 7 11 7 11ZM12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z',clock:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 8v4l3 2',grad:'M12 3 2 8l10 5 10-5-10-5ZM6 10.5V15c0 1.7 2.7 3 6 3s6-1.3 6-3v-4.5',users:'M9 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM3.5 19c.7-3.2 2.6-5 5.5-5s4.8 1.8 5.5 5',spark:'M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z',check:'m5 12 4.5 4.5L19 7',shield:'M12 3l7 2.5v5.2c0 4.3-2.9 7.6-7 9.3-4.1-1.7-7-5-7-9.3V5.5L12 3ZM8.8 11.8l2.2 2.2 4.2-4.2'};
function svg(n){return '<svg class="ic" viewBox="0 0 24 24"><path d="'+(IC[n]||'')+'"/></svg>';}
function plural(n,f){var a=Math.abs(n)%100,b=a%10;var w=a>4&&a<21?f[2]:b===1?f[0]:b>1&&b<5?f[1]:f[2];return n+' '+w;}
function dmy(v){if(!v)return '';var d=new Date(String(v).replace(' ','T'));
  return isNaN(+d)?String(v):d.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'});}
function esc(s){return (s==null?'':String(s)).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
function hue(name){var s=0;for(var i=0;i<(name||'').length;i++)s+=name.charCodeAt(i);return s%360;}
var SP=null;
function qs(k){return new URLSearchParams(location.search).get(k)||'';}
function load(){
  var slug=qs('slug');
  if(!slug){document.getElementById('root').innerHTML='<div class="notfound">Специалист не указан. <a href="/catalog.php" style="color:var(--accent-strong)">Открыть каталог</a></div>';return;}
  fetch('/api/v1/public/specialists/'+encodeURIComponent(slug)).then(function(r){if(!r.ok)throw 0;return r.json();}).then(function(j){SP=j.specialist;render(SP);}).catch(function(){document.getElementById('root').innerHTML='<div class="notfound">Профиль не найден или скрыт. <a href="/catalog.php" style="color:var(--accent-strong)">Вернуться в каталог</a></div>';});
}
function render(s){
  document.title=esc(s.name)+' — EQUA';
  var h=hue(s.name),mono=esc((s.name||'·').trim()[0]||'·').toUpperCase();
  var photo=s.avatar_url
    ? '<img class="photo" src="'+esc(s.avatar_url)+'" alt="'+esc(s.name)+'" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'grid\'"><div class="photo-fallback" style="display:none;background:linear-gradient(135deg,hsl('+h+' 60% 55%),hsl('+((h+40)%360)+' 60% 48%))">'+mono+'</div>'
    : '<div class="photo-fallback" style="background:linear-gradient(135deg,hsl('+h+' 60% 55%),hsl('+((h+40)%360)+' 60% 48%))">'+mono+'</div>';
  var specs=(s.specializations||'').split(',').map(function(x){return x.trim();}).filter(Boolean);
  var docs=s.documents||[];
  var DK={diploma:'Диплом',course:'Курс',certificate:'Сертификат',license:'Лицензия'};
  var reviews=s.reviews||[];
  document.getElementById('root').innerHTML=
    '<div class="hero"><div class="photo-col"><div class="photo-wrap">'+photo+'</div>'+
      '<div class="price-card"><div class="p">'+(s.price?s.price+' ₽ <span>/ '+esc(s.price_unit||'мес')+'</span>':'<span>Цена по запросу</span>')+'</div>'+
      '<button class="btn" onclick="lead()">Записаться на консультацию</button></div></div>'+
    '<div class="info"><div class="badges"><span class="role-badge">'+esc(PROF[s.profession]||'Специалист')+'</span>'+(+s.verified===1?'<span class="vfd">'+svg('shield')+'Проверен EQUA</span>':'')+'</div>'+
      '<h1>'+esc(s.name)+'</h1>'+
      (s.rating?'<div class="rating"><span class="star">★</span> '+s.rating+' <small>· '+plural(s.reviews_count||0,['отзыв','отзыва','отзывов'])+'</small></div>':'<div class="rating no"><small>Отзывов пока нет</small></div>')+
      '<div class="facts">'+
        (s.city?'<div class="fact">'+svg('pin')+esc(s.city)+'</div>':'')+
        (s.experience_years?'<div class="fact">'+svg('clock')+'Опыт <b>'+s.experience_years+' лет</b></div>':'')+
        (s.active_clients?'<div class="fact">'+svg('users')+'<b>'+s.active_clients+'</b> клиентов сейчас</div>':'')+
      '</div>'+
      (s.advantages?'<div class="sect"><div class="adv">'+svg('spark')+'<span>'+esc(s.advantages)+'</span></div></div>':'')+
      (s.bio?'<div class="sect"><h2>О специалисте</h2><div class="card"><p>'+esc(s.bio)+'</p></div></div>':'')+
      (s.education?'<div class="sect"><h2>Образование</h2><div class="card"><p>'+esc(s.education)+'</p></div></div>':'')+
      (docs.length?'<div class="sect"><h2>Подтверждённые документы</h2><div class="docs">'+docs.map(function(d){
        return '<div class="doc">'+svg('grad')+'<div><b>'+esc(d.title)+'</b><small>'+[DK[d.kind]||'Документ',esc(d.issuer||''),esc(d.issued_on||'')].filter(Boolean).join(' · ')+'</small></div></div>';
      }).join('')+'</div><div class="docs-note">Оригиналы проверила команда EQUA. Сами сканы не публикуются.</div></div>':'')+
      (specs.length?'<div class="sect"><h2>Специализации</h2><div class="specs">'+specs.map(function(x){return '<span class="spec">'+esc(x)+'</span>';}).join('')+'</div></div>':'')+
      '<div class="sect"><h2>Отзывы</h2>'+(reviews.length
        ? '<div class="reviews">'+reviews.map(function(r){
            return '<div class="review"><div class="stars">'+'★★★★★'.slice(0,r.rating)+'</div>'+
              (r.body?'<p>'+esc(r.body)+'</p>':'')+
              '<div class="by">'+esc(r.author)+' · '+dmy(r.created_at)+'</div></div>';
          }).join('')+'</div>'
        : '<div class="card"><p class="muted">Отзывов пока нет. Их оставляют клиенты, которых ведёт специалист.</p></div>')+'</div>'+
    '</div></div>';
}
function lead(){
  document.getElementById('modalRoot').innerHTML='<div class="modal" onclick="if(event.target===this)closeM()"><div class="sheet">'+
    '<h2>Записаться к специалисту</h2><p class="sub">'+esc(SP.name)+' свяжется с вами по указанному контакту.</p><div id="lerr"></div>'+
    '<label>Ваше имя<input id="l_name"></label>'+
    '<label>Телефон или мессенджер<input id="l_contact" placeholder="+7… или @username"></label>'+
    '<label>Комментарий (необязательно)<textarea id="l_msg" rows="3" placeholder="Ваша цель, вопросы…"></textarea></label>'+
    '<button class="btn" style="width:100%" onclick="sendLead()">Отправить заявку</button>'+
    '<button class="btn" style="width:100%;background:#eef2ee;color:#475247;margin-top:8px" onclick="closeM()">Отмена</button></div></div>';
}
function closeM(){document.getElementById('modalRoot').innerHTML='';}
function sendLead(){
  var name=(document.getElementById('l_name').value||'').trim();
  var contact=(document.getElementById('l_contact').value||'').trim();
  if(!name||!contact){document.getElementById('lerr').innerHTML='<div class="err">Укажите имя и контакт</div>';return;}
  fetch('/api/v1/catalog/'+SP.id+'/lead',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:name,contact:contact,message:(document.getElementById('l_msg').value||'')})})
   .then(function(r){return r.json().then(function(j){return {ok:r.ok,j:j};});})
   .then(function(res){if(!res.ok)throw new Error(res.j.error||'Ошибка');
     document.querySelector('.sheet').innerHTML='<div class="ok-msg"><div class="big">'+svg('check')+'</div><h2>Заявка отправлена!</h2><p class="sub">Специалист свяжется с вами в ближайшее время.</p><button class="btn" style="width:100%" onclick="closeM()">Готово</button></div>';
   }).catch(function(e){document.getElementById('lerr').innerHTML='<div class="err">'+esc(e.message)+'</div>';});
}
load();
</script>
</body></html>
