<?php
/**
 * Восстановление доступа владельца.
 *
 * Учётка владельца создаётся один раз — при первом обращении к сайту, из
 * значений OWNER_EMAIL и OWNER_PASSWORD, которые стояли в конфиге в тот
 * момент. Если их поменяли позже, пароль в базе остался прежним, и
 * вспомнить его бывает нечем.
 *
 * Страница открывается только тогда, когда рядом лежит файл-ключ
 * storage/owner-reset. Создать его может лишь тот, у кого есть доступ к
 * файлам сайта, — этого достаточно, чтобы считать человека владельцем.
 * Пароль по такому ключу не подберёшь: без файла страница отвечает 404,
 * а после смены пароля ключ удаляется сам.
 *
 * Как пользоваться:
 *   1. В файловом менеджере хостинга создайте пустой файл
 *      storage/owner-reset
 *   2. Откройте https://ваш-домен/owner-reset.php
 *   3. Задайте новый пароль. Файл-ключ удалится автоматически.
 */
declare(strict_types=1);
require __DIR__.'/config/config.php';

$keyFile = __DIR__.'/storage/owner-reset';

/* Ключа нет — страницы нет. Ни намёка на то, что она вообще есть. */
if (!is_file($keyFile)) {
  http_response_code(404);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Не найдено.\n";
  exit;
}
/* Забытый ключ не должен остаться дверью навсегда. */
if (time() - filemtime($keyFile) > 3600) {
  @unlink($keyFile);
  http_response_code(410);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Файл-ключ устарел и удалён. Создайте storage/owner-reset заново.\n";
  exit;
}

$pdo = db();
$admin = $pdo->query('SELECT id,email,name FROM admins ORDER BY id LIMIT 1')->fetch();
$msg = '';
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim((string)($_POST['email'] ?? ''));
  $pass  = (string)($_POST['password'] ?? '');
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $msg = 'Проверьте адрес почты.';
  } elseif (mb_strlen($pass) < 8 || !preg_match('/\d/', $pass) || !preg_match('/[a-zA-Zа-яА-Я]/u', $pass)) {
    $msg = 'Пароль — от 8 символов, хотя бы одна буква и одна цифра.';
  } else {
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    if ($admin) {
      $pdo->prepare('UPDATE admins SET email=?,password_hash=? WHERE id=?')
          ->execute([$email, $hash, (int)$admin['id']]);
    } else {
      $pdo->prepare('INSERT INTO admins(email,password_hash,name,created_at) VALUES(?,?,?,?)')
          ->execute([$email, $hash, 'Владелец', now()]);
    }
    /* Старые входы обрываем: если паролем кто-то успел воспользоваться,
       его сессия должна закончиться вместе с паролем. */
    $pdo->prepare('DELETE FROM sessions WHERE user_type=?')->execute(['admin']);
    @unlink($keyFile);
    $done = true;
  }
}
?><!doctype html>
<html lang="ru"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Доступ владельца — <?= htmlspecialchars(APP_NAME) ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font:15px/1.55 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;
  background:#0f1418;color:#e7ecf0;display:grid;place-items:center;min-height:100dvh;padding:20px}
.box{width:100%;max-width:460px;background:#171e24;border:1px solid #26313a;border-radius:18px;padding:28px}
h1{font-size:21px;margin-bottom:6px}
p.sub{color:#93a1ad;margin-bottom:20px}
label{display:block;font-size:13px;color:#93a1ad;margin:14px 0 6px}
input{width:100%;padding:12px 14px;border-radius:12px;border:1px solid #2c3843;
  background:#0f1418;color:#e7ecf0;font:inherit}
button{width:100%;margin-top:20px;padding:13px;border:0;border-radius:12px;
  background:#2E7D63;color:#fff;font:inherit;font-weight:600;cursor:pointer}
button:hover{background:#359173}
.err{margin-top:14px;color:#e2564d;font-size:14px}
.ok{color:#4ec08d}
code{background:#0f1418;border:1px solid #2c3843;border-radius:6px;padding:1px 6px;font-size:13px}
.note{margin-top:18px;color:#93a1ad;font-size:13px;line-height:1.5}
a{color:#4ec08d}
</style></head><body>
<div class="box">
<?php if ($done): ?>
  <h1 class="ok">Готово</h1>
  <p class="sub">Пароль владельца изменён, файл-ключ удалён.</p>
  <p class="note">Заходите на <a href="/app/">/app/</a> с новым адресом и паролем.
     Чтобы сменить пароль в следующий раз, файл создавать не нужно — в панели
     есть «Ещё» → «Сменить пароль владельца».</p>
<?php else: ?>
  <h1>Доступ владельца</h1>
  <p class="sub">
    <?= $admin
      ? 'Сейчас учётка заведена на <code>'.htmlspecialchars((string)$admin['email']).'</code>. Если этот адрес верный, а пароль не подходит — задайте новый.'
      : 'Учётки владельца в базе ещё нет. Задайте адрес и пароль — она будет создана.' ?>
  </p>
  <form method="post">
    <label>Почта владельца</label>
    <input name="email" type="email" required
           value="<?= htmlspecialchars((string)($admin['email'] ?? OWNER_EMAIL)) ?>">
    <label>Новый пароль</label>
    <input name="password" type="password" required
           placeholder="от 8 символов, буква и цифра" autocomplete="new-password">
    <button>Сохранить и войти заново</button>
  </form>
  <?php if ($msg): ?><div class="err"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <p class="note">Страница работает, только пока рядом лежит файл
     <code>storage/owner-reset</code>. После смены пароля он удаляется, и
     страница снова отвечает «не найдено».</p>
<?php endif; ?>
</div>
</body></html>
