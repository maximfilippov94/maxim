<?php
/**
 * Убрать демонстрационные учётки из консоли.
 *
 * Делает ровно то же, что кнопка «Убрать демо-учётки» в панели владельца:
 * обе вызывают cleanupDemo() из config/config.php, чтобы правила удаления
 * не разошлись между двумя копиями кода.
 *
 *   php tools/cleanup-demo.php                 — показать, что удалит
 *   php tools/cleanup-demo.php --yes           — удалить
 *   php tools/cleanup-demo.php --yes --keep-catalog
 *                                              — оставить витрину каталога
 *
 * Нет доступа к консоли — делайте это кнопкой: «Ещё» → «Каталог блюд» →
 * «Убрать демо-учётки».
 */
require __DIR__.'/../config/config.php';

$apply=in_array('--yes',$argv,true);
$keep =in_array('--keep-catalog',$argv,true);
$r=cleanupDemo($apply,$keep);

if(!empty($r['error'])){ fwrite(STDERR,$r['error']."\n"); exit(1); }

echo "Остаются:\n";
echo "  специалист #{$r['keep_specialist']['id']} — {$r['keep_specialist']['name']} <{$r['keep_specialist']['email']}>\n";
echo $r['keep_client'] ? "  клиент #{$r['keep_client']['id']} — {$r['keep_client']['name']}\n" : "  клиентов нет\n";
echo "\nБудет удалено: специалистов {$r['delete_specialists']}, клиентов {$r['delete_clients']}\n";
if($keep) echo "Витрина каталога (pro1…pro5) остаётся.\n";

if(!$r['delete_specialists'] && !$r['delete_clients']){ echo "\nБаза уже чистая.\n"; exit(0); }
if(!$apply){ echo "\nЭто предварительный показ. Чтобы удалить, добавьте ключ --yes\n"; exit(0); }

echo "\nКопия базы: {$r['backup']}\n";
echo "Готово.\n";
echo "  специалистов: {$r['left_specialists']}\n";
echo "  клиентов:     {$r['left_clients']}\n";
echo "Блюда, продукты и настройки не тронуты.\n";
