<?php
/**
 * Проверка настроек входа через Apple, Google и VK.
 *
 *   php tools/oauth-check.php equa.ru
 *
 * Домен нужен, чтобы напечатать точные адреса возврата — их вписывают
 * в кабинете провайдера, и опечатка там даёт ошибку уже после согласия
 * пользователя, когда искать её труднее всего.
 */
declare(strict_types=1);
require __DIR__.'/../config/config.php';

$domain = $argv[1] ?? '';
$origin = $domain !== ''
  ? (preg_match('#^https?://#', $domain) ? rtrim($domain, '/') : 'https://'.rtrim($domain, '/'))
  : '';

$file = __DIR__.'/../config/oauth.php';
echo "Файл ключей: ", is_file($file) ? "есть ($file)" : "НЕТ — скопируйте config/oauth.sample.php в config/oauth.php", "\n\n";

$cfg = oauthConfig();
$need = [
  'google' => ['client_id' => 'Client ID', 'client_secret' => 'Client secret'],
  'vk'     => ['client_id' => 'ID приложения'],
  'apple'  => ['client_id' => 'Services ID', 'team_id' => 'Team ID',
               'key_id' => 'Key ID', 'private_key' => 'содержимое .p8'],
];

foreach ($need as $p => $fields) {
  $have = $cfg[$p] ?? [];
  $miss = [];
  foreach ($fields as $k => $label) if (empty($have[$k])) $miss[] = $label;
  $ready = oauthReady($p);
  printf("%-7s %s\n", $p, $ready ? 'готов — кнопка показывается' : 'не хватает: '.implode(', ', $miss));
  if ($origin !== '')
    echo "        адрес возврата: $origin/api/v1/auth/oauth/$p/callback\n";
}

echo "\nАдреса возврата в приложение (список targets):\n";
$targets = $cfg['targets'] ?? [];
if (!$targets) echo "  пусто — вход из приложения работать не будет\n";
foreach ($targets as $k => $v) echo "  $k → $v\n";

/* Ключ Apple подписывается прямо здесь: ошибку в .p8 иначе видно только
   в момент живого входа, и выглядит она как «не выдал токен». */
if (oauthReady('apple')) {
  try { appleClientSecret(); echo "\nКлюч Apple: подпись собирается\n"; }
  catch (Throwable $e) { echo "\nКлюч Apple: ОШИБКА — ".$e->getMessage()."\n"; }
}

if ($origin !== '' && !str_starts_with($origin, 'https://'))
  echo "\nВНИМАНИЕ: ни один провайдер не разрешает возврат по http — нужен сертификат.\n";

echo "\nПровайдеры, которые сейчас увидит приложение: ",
  oauthProviders() ? implode(', ', oauthProviders()) : 'ни одного', "\n";
