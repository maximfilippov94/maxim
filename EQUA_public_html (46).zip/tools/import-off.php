<?php
/**
 * Импорт магазинных товаров из Open Food Facts.
 *
 *   php tools/import-off.php --selftest            проверить разбор без сети
 *   php tools/import-off.php --country=russia --pages=5 --apply
 *   php tools/import-off.php --barcode=4680019620015 --apply
 *
 * Без --apply ничего не пишется: сначала видно, сколько строк прошло
 * проверку и сколько отсеялось. Отсев — норма: карточки в Open Food
 * Facts заполняют добровольцы, у части нет КБЖУ вовсе.
 *
 * Запускать на боевом сервере: у рабочей среды разработчика выход на
 * openfoodfacts.org закрыт политикой сети.
 */
declare(strict_types=1);
require __DIR__.'/../config/config.php';

$opt = [];
foreach (array_slice($argv, 1) as $a) {
  if (preg_match('/^--([a-z-]+)(?:=(.*))?$/', $a, $m)) $opt[$m[1]] = $m[2] ?? '1';
}
$apply = isset($opt['apply']);

/* ---------- Проверка разбора без сети ----------
   Данные собраны по официальной схеме полей: энергия в ккал лежит в
   energy-kcal_100g, килоджоули — в energy_100g, и подмена одного
   другим завысила бы калорийность вчетверо. Проверяем и это. */
if (isset($opt['selftest'])) {
  $cases = [
    ['берём обычный товар', [
      'code'=>'4680019620015','product_name_ru'=>'Йогурт греческий 2%','brands'=>'Село Зелёное',
      'categories_tags'=>['en:dairies','en:yogurts'],
      'nutriments'=>['energy-kcal_100g'=>73,'proteins_100g'=>9,'fat_100g'=>2,'carbohydrates_100g'=>3.6],
    ], true],
    ['без КБЖУ — пропускаем', [
      'code'=>'111','product_name'=>'Нечто','no_nutrition_data'=>'on','nutriments'=>[],
    ], false],
    ['пустые нутриенты — пропускаем', [
      'code'=>'222','product_name'=>'Нечто','nutriments'=>[],
    ], false],
    ['килоджоули переводим в ккал', [
      'code'=>'333','product_name'=>'Печенье','nutriments'=>
        ['energy-kj_100g'=>1828,'proteins_100g'=>6.5,'fat_100g'=>14.4,'carbohydrates_100g'=>71.4],
    ], true],
    ['ккал не сходятся с БЖУ — отбрасываем', [
      'code'=>'444','product_name'=>'Опечатка','nutriments'=>
        ['energy-kcal_100g'=>900,'proteins_100g'=>1,'fat_100g'=>1,'carbohydrates_100g'=>1],
    ], false],
    ['без штрихкода — пропускаем', [
      'code'=>'','product_name'=>'Развес','nutriments'=>['energy-kcal_100g'=>50,'proteins_100g'=>1,'fat_100g'=>0,'carbohydrates_100g'=>11],
    ], false],
    ['без названия — пропускаем', [
      'code'=>'555','product_name'=>'','nutriments'=>['energy-kcal_100g'=>50,'proteins_100g'=>1,'fat_100g'=>0,'carbohydrates_100g'=>11],
    ], false],
  ];
  $fail = 0;
  foreach ($cases as [$title, $p, $want]) {
    $got = offRow($p) !== null;
    printf("  %-4s %s\n", $got === $want ? 'ok' : 'НЕТ', $title);
    if ($got !== $want) $fail++;
  }
  /* Перевод килоджоулей проверяем числом, а не фактом «взяли». */
  $r = offRow($cases[3][1]);
  $kcal = $r['kcal'] ?? 0;
  $ok = abs($kcal - 437) < 2;
  printf("  %-4s 1828 кДж это %s ккал (ждём около 437)\n", $ok ? 'ok' : 'НЕТ', $kcal);
  if (!$ok) $fail++;
  /* Категория и бренд. */
  $r = offRow($cases[0][1]);
  $ok = ($r['category'] ?? '') === 'Молочные';
  printf("  %-4s категория «%s» (ждём «Молочные»)\n", $ok ? 'ok' : 'НЕТ', $r['category'] ?? '—');
  if (!$ok) $fail++;
  $ok = ($r['name'] ?? '') === 'Йогурт греческий 2%, Село Зелёное';
  printf("  %-4s имя «%s»\n", $ok ? 'ok' : 'НЕТ', $r['name'] ?? '—');
  if (!$ok) $fail++;

  echo $fail ? "\nНе прошло: $fail\n" : "\nРазбор в порядке.\n";
  exit($fail ? 2 : 0);
}

/* ---------- Один штрихкод ---------- */
if (!empty($opt['barcode'])) {
  $r = offByBarcode((string)$opt['barcode']);
  if (!$r) { fwrite(STDERR, "Не нашлось либо не прошло проверку.\n"); exit(1); }
  printf("%s — %s ккал, Б %s Ж %s У %s [%s]\n", $r['name'],$r['kcal'],$r['protein'],$r['fat'],$r['carbs'],$r['category']);
  if ($apply) { $id = offStore($r); echo "Сохранено, id $id\n"; }
  else echo "Это разбор без записи. Добавьте --apply.\n";
  exit(0);
}

/* ---------- Пачкой по стране ---------- */
$country = $opt['country'] ?? 'russia';
$pages   = max(1, min(200, (int)($opt['pages'] ?? 3)));
$size    = max(10, min(100, (int)($opt['size'] ?? 100)));
$fields  = 'code,product_name,product_name_ru,brands,categories_tags,nutriments,no_nutrition_data,serving_quantity';

$took = 0; $skipped = 0; $stored = 0;
for ($page = 1; $page <= $pages; $page++) {
  $url = OFF_BASE."/api/v2/search?countries_tags_en=".rawurlencode($country)
       ."&page=$page&page_size=$size&fields=$fields";
  [$j, $err] = offFetch($url);
  if ($err) { fwrite(STDERR, "Страница $page: $err\n"); break; }
  $list = $j['products'] ?? [];
  if (!$list) break;
  foreach ($list as $p) {
    $r = offRow((array)$p);
    if (!$r) { $skipped++; continue; }
    $took++;
    if ($apply) { offStore($r); $stored++; }
  }
  echo "страница $page: взято $took, отсеяно $skipped\n";
  /* Сервис просит не частить. */
  usleep(700000);
}
echo "\nПодошло: $took, отсеяно: $skipped".($apply ? ", записано: $stored" : " (без записи, добавьте --apply)")."\n";
