# -*- coding: utf-8 -*-
"""Фоновые слои под стекло: app/bg-dark.jpg и app/bg-light.jpg.

   Тёмная тема: снимок листвы размывается и подмешивается к цвету фона —
   формы угадываются, панели есть что размывать.

   Светлая: снимок служит только формой. Осветлять его бесполезно — в
   тенях листвы нет зелени, и получается грязно-серый; вместо этого по
   яркости смешиваются два заданных светлых оттенка. Оттенки намеренно
   близки к белому: светлая тема строится на белых карточках, и фон
   насыщеннее них перетягивает внимание на себя.

   Запуск из корня сайта:  python3 tools/make-bg.py
"""
from PIL import Image, ImageFilter, ImageEnhance

SRC = 'auth-leaves.jpg'
SIZE = (760, 1350)
BLUR = 22

src = Image.open(SRC).convert('RGB')

dark = src.resize(SIZE, Image.LANCZOS).filter(ImageFilter.GaussianBlur(BLUR))
dark = ImageEnhance.Color(dark).enhance(0.85)
dark = Image.blend(dark, Image.new('RGB', SIZE, (0x12, 0x18, 0x20)), 0.58)
dark.save('app/bg-dark.jpg', quality=84, optimize=True, progressive=True)

# Мятный #C9E2D6 оказался слишком насыщенным: фон спорил с белыми
# карточками и лез вперёд вместо того, чтобы лежать позади. Берём тон
# почти белый, с едва заметным зелёным подтоном, и размываем сильнее —
# формы листьев остаются, цвет уходит на задний план.
MINT, WHITE, GAMMA, BLUR_L = (0xE9, 0xF0, 0xEC), (0xFF, 0xFF, 0xFF), 0.85, 34
grey = src.resize(SIZE, Image.LANCZOS).filter(ImageFilter.GaussianBlur(BLUR_L)).convert('L')
light = Image.new('RGB', SIZE)
gp, lp = grey.load(), light.load()
for y in range(SIZE[1]):
    for x in range(SIZE[0]):
        t = (gp[x, y] / 255) ** GAMMA
        lp[x, y] = tuple(round(MINT[i] + (WHITE[i] - MINT[i]) * t) for i in range(3))
light.save('app/bg-light.jpg', quality=86, optimize=True, progressive=True)
print('готово: app/bg-dark.jpg, app/bg-light.jpg')
