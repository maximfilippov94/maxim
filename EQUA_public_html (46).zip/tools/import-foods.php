<?php
/**
 * Наполнение справочника продуктов из data/foods.csv.
 *
 * Зачем отдельный файл, а не миграция: справочник владелец правит
 * руками через кабинет, и перезаписывать его правки при каждой
 * загрузке страницы нельзя. Запуск — осознанное действие.
 *
 *   php tools/import-foods.php --check    только проверить файл
 *   php tools/import-foods.php --apply    залить в базу
 *
 * Проверка машинная, а не на глаз: калорийность обязана сходиться с
 * белками, жирами и углеводами. Считаем вилку, а не одно число —
 * в разных таблицах клетчатка то входит в углеводы, то нет:
 *   верх = 4Б + 9Ж + 4У
 *   низ  = 4Б + 9Ж + 4(У − клетчатка)
 * Значение вне вилки с запасом — опечатка, и её надо увидеть здесь,
 * а не в дневнике клиента через месяц.
 */
declare(strict_types=1);
require __DIR__.'/../config/config.php';

/* Есть калории вне белков, жиров и углеводов: спирт даёт около 7 ккал
   на грамм, уксусная кислота — около 3,5. Для таких строк вилка не
   работает. Список именной и короткий: исключение по категории целиком
   спрятало бы вместе с ними и настоящие опечатки. */
const NO_MACRO_KCAL = [
  'Пиво светлое','Вино сухое красное','Вино сухое белое',
  'Уксус бальзамический','Уксус яблочный',
];

$mode = $argv[1] ?? '--check';
if (!in_array($mode, ['--check','--apply'], true)) {
  fwrite(STDERR, "Укажите --check или --apply\n"); exit(1);
}

$file = __DIR__.'/../data/foods.csv';
if (!is_file($file)) { fwrite(STDERR, "Нет файла $file\n"); exit(1); }

$rows = []; $bad = []; $seen = []; $line = 0;
foreach (file($file, FILE_IGNORE_NEW_LINES) as $raw) {
  $line++;
  $raw = trim($raw);
  if ($raw === '' || str_starts_with($raw, '#')) continue;
  $c = explode('|', $raw);
  if (count($c) < 8) { $bad[] = "строка $line: нужно 8–9 полей, пришло ".count($c); continue; }
  [$name,$cat,$kcal,$p,$f,$cb,$fib,$unit] = array_map('trim', array_slice($c, 0, 8));
  $piece = isset($c[8]) ? trim($c[8]) : '';

  if ($name === '')                       { $bad[] = "строка $line: пустое название"; continue; }
  if (isset($seen[mb_strtolower($name)])) { $bad[] = "строка $line: «$name» уже был в строке ".$seen[mb_strtolower($name)]; continue; }
  $seen[mb_strtolower($name)] = $line;
  foreach (['ккал'=>$kcal,'белок'=>$p,'жир'=>$f,'углеводы'=>$cb,'клетчатка'=>$fib] as $k=>$v) {
    if (!is_numeric($v)) { $bad[] = "строка $line «$name»: $k — не число «$v»"; continue 2; }
  }
  $kcal=(float)$kcal; $p=(float)$p; $f=(float)$f; $cb=(float)$cb; $fib=(float)$fib;
  if (!in_array($unit, ['g','pc'], true)) { $bad[] = "строка $line «$name»: единица «$unit», ждём g или pc"; continue; }
  if ($unit === 'pc' && ($piece === '' || !is_numeric($piece) || (float)$piece <= 0)) {
    $bad[] = "строка $line «$name»: штучный продукт без веса штуки"; continue;
  }
  if ($p + $f + $cb > 101) { $bad[] = "строка $line «$name»: Б+Ж+У = ".round($p+$f+$cb,1)." г на 100 г"; continue; }
  if ($kcal < 0 || $kcal > 950) { $bad[] = "строка $line «$name»: $kcal ккал вне разумного"; continue; }

  if (!in_array($name, NO_MACRO_KCAL, true) && !foodKcalPlausible($kcal,$p,$f,$cb,$fib)) {
    $bad[] = sprintf('строка %d «%s»: %g ккал не сходится с БЖУ (вилка %g…%g)',
                     $line, $name, $kcal,
                     round(4*$p + 9*$f + 4*max(0,$cb-$fib)), round(4*$p + 9*$f + 4*$cb));
    continue;
  }
  $rows[] = compact('name','cat','kcal','p','f','cb','fib','unit') + ['piece'=>$piece===''?null:(float)$piece];
}

echo "Прочитано: ".count($rows)." продуктов\n";
if ($bad) {
  echo "Замечаний: ".count($bad)."\n";
  foreach ($bad as $b) echo "  $b\n";
  if ($mode === '--apply') { fwrite(STDERR, "Не заливаю: сначала почините файл.\n"); exit(2); }
}
if ($mode === '--check') { echo $bad ? "" : "замечаний нет\n"; exit($bad ? 2 : 0); }

$pdo = db();
$pdo->beginTransaction();

/* Старые записи лежали в общей категории «Белок». Раскладываем их по
   тем же полкам, что и новые: иначе курица и куриная грудка окажутся
   в разных разделах одного справочника. */
$FIX = [
  'Говядина'=>'Мясо и птица','Индейка'=>'Мясо и птица','Курица'=>'Мясо и птица',
  'Фарш индейки'=>'Мясо и птица','Креветки'=>'Рыба и морепродукты','Лосось'=>'Рыба и морепродукты',
  'Треска'=>'Рыба и морепродукты','Тунец'=>'Рыба и морепродукты',
  'Яйцо'=>'Яйца','Яичный белок'=>'Яйца','Протеин, порошок'=>'Напитки',
];
$fx = $pdo->prepare('UPDATE ingredients SET category=? WHERE name=? AND category=?');
foreach ($FIX as $n=>$cat) $fx->execute([$cat, $n, 'Белок']);

$sel = $pdo->prepare('SELECT id FROM ingredients WHERE lower(name)=lower(?)');
$ins = $pdo->prepare('INSERT INTO ingredients(name,name_fold,category,kcal,protein,fat,carbs,fiber,unit,piece_g,is_public,source,created_at)
                      VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?)');
/* Существующие не перетираем вслепую: у владельца могли быть свои
   правки. Обновляем только то, что пусто, — категорию, клетчатку,
   единицу и вес штуки. КБЖУ уже заведённого продукта не трогаем. */
$upd = $pdo->prepare('UPDATE ingredients
                         SET category = COALESCE(NULLIF(category,""), ?),
                             fiber    = COALESCE(fiber, ?),
                             unit     = COALESCE(NULLIF(unit,""), ?),
                             piece_g  = COALESCE(piece_g, ?)
                       WHERE id=?');
$added = 0; $touched = 0;
foreach ($rows as $r) {
  $sel->execute([$r['name']]);
  $id = (int)$sel->fetchColumn();
  if ($id) { $upd->execute([$r['cat'], $r['fib'], $r['unit'], $r['piece'], $id]); $touched++; }
  else {
    $ins->execute([$r['name'],foodFold($r['name']),$r['cat'],$r['kcal'],$r['p'],$r['f'],$r['cb'],$r['fib'],$r['unit'],$r['piece'],'own',now()]);
    $added++;
  }
}
/* Свёрнутые имена держим в согласии с именами: правка категории или
   добавление нового продукта не должны оставлять поиск слепым. */
$pdo->prepare('UPDATE ingredients SET name_fold=NULL')->execute();
$fold=$pdo->prepare('UPDATE ingredients SET name_fold=? WHERE id=?');
foreach ($pdo->query('SELECT id,name,brand FROM ingredients') as $r)
  $fold->execute([foodFold(($r['name']??'').' '.($r['brand']??'')), (int)$r['id']]);
$pdo->commit();

$total = (int)$pdo->query('SELECT COUNT(*) FROM ingredients')->fetchColumn();
echo "Добавлено: $added, дополнено: $touched\n";
echo "Всего в справочнике: $total\n";
