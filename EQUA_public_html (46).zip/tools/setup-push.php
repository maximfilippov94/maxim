<?php
/**
 * Сгенерировать ключи VAPID для push-уведомлений.
 *
 * То же самое делает кнопка в панели владельца: «Ещё» → «Уведомления».
 * Здесь — на случай, если удобнее из консоли.
 *
 * Пересоздание ключей отключает все существующие подписки: браузеры
 * подписаны на прежний публичный ключ. Поэтому если ключи уже есть,
 * скрипт останавливается и требует явного --force.
 */
declare(strict_types=1);
require __DIR__.'/../config/config.php';

$force=in_array('--force',$_SERVER['argv']??[],true);
if(vapidKeys()!==null && !$force){
  echo "Ключи уже есть. Пересоздание отключит все подписки.\n";
  echo "Если это осознанно — повторите с --force.\n";
  exit(2);
}

/* Генерируем сами, без vendor: библиотека нужна только для отправки. */
try{ $keys=vapidCreate(); }
catch(\Throwable $e){ fwrite(STDERR,"Не удалось создать ключи: ".$e->getMessage()."\n"); exit(1); }
if(!vapidSave($keys)){ fwrite(STDERR,"Не удалось записать storage/vapid.php — проверьте права на папку\n"); exit(1); }
@chmod(__DIR__.'/../storage/vapid.php',0640);
@unlink(__DIR__.'/../storage/vapid.json');
echo "Готово: ключи в storage/vapid.php\n";
if($force) echo "Прежние подписки больше не получат уведомлений — люди включат их заново.\n";
