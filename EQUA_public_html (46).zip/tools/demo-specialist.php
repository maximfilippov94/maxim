<?php
/**
 * Демонстрационный специалист для каталога.
 *
 * Нужен, чтобы посмотреть, как выглядит заполненная карточка: фото,
 * проверенный паспорт, рассказ о себе, услуги с ценами, образование,
 * опыт и отзывы. На пустом каталоге этого не увидеть, а заводить всё
 * это руками через кабинет — полчаса работы.
 *
 * Запуск:
 *   php tools/demo-specialist.php --add      завести (повторный запуск ничего не портит)
 *   php tools/demo-specialist.php --remove   убрать вместе с отзывами и авторами
 *
 * ВАЖНО: это витрина, а не живой человек. Клиент, выбравший его в
 * каталоге, подключится к аккаунту, за которым никого нет. Перед
 * запуском сайта уберите: --remove, либо «Ещё → Уборка демо-данных»
 * в кабинете владельца.
 *
 * Отзывы написаны для показа и подписаны демо-клиентами. Настоящий
 * рейтинг считается из настоящих отзывов — refreshRating() ниже
 * пересчитывает его по строкам в базе, а не проставляет числом.
 */
declare(strict_types=1);
require __DIR__.'/../config/config.php';

const DEMO_EMAIL   = 'pro-demo@nutrimenu.local';
const DEMO_CLIENTS = ['rev-demo-1@nutrimenu.local','rev-demo-2@nutrimenu.local','rev-demo-3@nutrimenu.local'];

$mode = $argv[1] ?? '';
if (!in_array($mode, ['--add','--remove'], true)) {
  fwrite(STDERR, "Укажите --add или --remove\n");
  exit(1);
}

$pdo = db();

/* ---------- Убрать ---------- */
if ($mode === '--remove') {
  $q = $pdo->prepare('SELECT id FROM specialists WHERE email=?');
  $q->execute([DEMO_EMAIL]);
  $sid = (int)$q->fetchColumn();
  if (!$sid) { echo "Демо-специалиста нет — убирать нечего.\n"; exit(0); }

  $pdo->beginTransaction();
  foreach (['specialist_reviews','specialist_documents','specialist_services','public_profiles'] as $t) {
    $pdo->prepare("DELETE FROM $t WHERE specialist_id=?")->execute([$sid]);
  }
  /* Клиенты-авторы заводились только ради отзывов — уходят вместе с ними. */
  $in = implode(',', array_fill(0, count(DEMO_CLIENTS), '?'));
  $pdo->prepare("DELETE FROM clients WHERE email IN ($in)")->execute(DEMO_CLIENTS);
  $pdo->prepare('DELETE FROM specialists WHERE id=?')->execute([$sid]);
  $pdo->commit();
  echo "Демо-специалист убран.\n";
  exit(0);
}

/* ---------- Завести ---------- */
$BIO = 'Работаю с питанием при заболеваниях ЖКТ и с восстановлением пищевого '
     . 'поведения. Начинаю с разбора дневника питания и анализов, дальше собираю '
     . 'меню, которое вы действительно будете готовить: без экзотики и без готовки '
     . 'по два часа. Веду в чате каждый день, меню правим по ходу — если блюдо не '
     . 'пошло, меняем его, а не заставляем себя есть. Не работаю с детьми до 12 лет '
     . 'и не назначаю лекарства: это к врачу.';

$EDU = "Нутрициология, РНИМУ им. Н. И. Пирогова, 2016\n"
     . "Клиническая диетология, РМАНПО, 2019\n"
     . "FODMAP-протокол, Monash University, 2021\n"
     . "Расстройства пищевого поведения, Институт клинической психологии, 2023";

$SERVICES = [
  ['Разбор питания',       'Дневник питания, анализы, разбор привычек и план на месяц', 'one_time',     350000, null, 60],
  ['Контрольная встреча',  'Сверка результатов и правка меню',                          'one_time',     200000, null, 45],
  ['Ведение · месяц',      'Меню, корректировки, чат и созвоны',                        'subscription',1200000,  30, null],
  ['Пробная неделя',       'Меню на неделю и чат — посмотреть, подходим ли друг другу',  'subscription', 350000,   7, null],
];

$REVIEWS = [
  ['Ольга Ветрова',  5, 'Три месяца — минус 8 кг и пропала изжога. Меню простое, готовлю за полчаса, продукты из обычного магазина.'],
  ['Игорь Панин',    5, 'Отвечает в чате в тот же день. Меню переделывали дважды под мой график со сменами — ни разу не услышал «терпите».'],
  ['Светлана Дорн',  4, 'Всё по делу, но первые две недели перестраиваться было тяжело. Предупреждала об этом сразу, претензий нет.'],
];

$pdo->beginTransaction();

$q = $pdo->prepare('SELECT id FROM specialists WHERE email=?');
$q->execute([DEMO_EMAIL]);
$sid = (int)$q->fetchColumn();

if (!$sid) {
  $pdo->prepare('INSERT INTO specialists(email,password_hash,name,profession,plan,created_at,status,verify_status,verified_at,last_seen_at)
                 VALUES(?,?,?,?,?,?,?,?,?,?)')
      ->execute([DEMO_EMAIL, password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT),
                 'Екатерина Лаврова', 'nutritionist', 'free',
                 gmdate('Y-m-d H:i:s', time() - 2*365*86400), 'active', 'verified', now(),
                 gmdate('Y-m-d H:i:s', time() - 900)]);
  $sid = (int)$pdo->lastInsertId();
} else {
  /* «В сети сегодня» должно быть сегодня и при повторном запуске. */
  $pdo->prepare("UPDATE specialists SET verify_status='verified', verified_at=COALESCE(verified_at,?), last_seen_at=? WHERE id=?")
      ->execute([now(), gmdate('Y-m-d H:i:s', time() - 900), $sid]);
}

$pdo->prepare('INSERT OR REPLACE INTO public_profiles(specialist_id,slug,bio,city,rating,reviews_count,is_public,education,experience_years,specializations)
               VALUES(?,?,?,?,0,0,1,?,?,?)')
    ->execute([$sid, 'ekaterina-lavrova', $BIO, 'Москва', $EDU, 9, 'ЖКТ, пищевое поведение, вес']);

$svc = $pdo->prepare('SELECT id FROM specialist_services WHERE specialist_id=? AND title=?');
$ins = $pdo->prepare('INSERT INTO specialist_services(specialist_id,title,description,kind,price_kop,period_days,duration_min,is_active,sort_order,created_at)
                      VALUES(?,?,?,?,?,?,?,1,?,?)');
foreach ($SERVICES as $i => [$t,$d,$k,$p,$days,$dur]) {
  $svc->execute([$sid,$t]);
  if (!$svc->fetchColumn()) $ins->execute([$sid,$t,$d,$k,$p,$days,$dur,$i,now()]);
}

/* Паспорт даёт отметку «личность проверена» — сам скан наружу не
   отдаётся никогда, поэтому файла у демо-записи и нет. */
$doc = $pdo->prepare('SELECT id FROM specialist_documents WHERE specialist_id=? AND title=?');
$dins= $pdo->prepare("INSERT INTO specialist_documents(specialist_id,kind,title,issuer,issued_on,file_url,status,is_public,reviewed_at,created_at)
                      VALUES(?,?,?,?,?,NULL,'approved',0,?,?)");
foreach ([
  ['passport','Паспорт РФ','МВД России','2015-04-02'],
  ['diploma','Нутрициология, РНИМУ им. Н. И. Пирогова','РНИМУ им. Н. И. Пирогова','2016-06-30'],
  ['course','FODMAP-протокол','Monash University','2021-03-11'],
] as [$k,$t,$iss,$on]) {
  $doc->execute([$sid,$t]);
  if (!$doc->fetchColumn()) $dins->execute([$sid,$k,$t,$iss,$on,now(),now()]);
}

/* Один отзыв — один клиент: в базе стоит уникальный ключ на пару
   «специалист + клиент», и без отдельных авторов трёх отзывов не будет. */
$cq = $pdo->prepare('SELECT id FROM clients WHERE email=?');
$cin= $pdo->prepare('INSERT INTO clients(specialist_id,name,email,password_hash,goal,status,created_at) VALUES(NULL,?,?,?,?,?,?)');
$rq = $pdo->prepare('SELECT id FROM specialist_reviews WHERE specialist_id=? AND client_id=?');
$rin= $pdo->prepare("INSERT INTO specialist_reviews(specialist_id,client_id,rating,body,status,created_at,updated_at)
                     VALUES(?,?,?,?,'published',?,?)");
foreach ($REVIEWS as $i => [$name,$rate,$body]) {
  $email = DEMO_CLIENTS[$i];
  $cq->execute([$email]);
  $cid = (int)$cq->fetchColumn();
  if (!$cid) {
    $cin->execute([$name,$email,password_hash(bin2hex(random_bytes(16)),PASSWORD_DEFAULT),'Снижение веса','active',now()]);
    $cid = (int)$pdo->lastInsertId();
  }
  $rq->execute([$sid,$cid]);
  if (!$rq->fetchColumn()) {
    $at = gmdate('Y-m-d H:i:s', time() - (30 + $i*25)*86400);
    $rin->execute([$sid,$cid,$rate,$body,$at,$at]);
  }
}

$pdo->commit();

/* Рейтинг считаем по строкам отзывов, а не проставляем числом:
   цифра, не сходящаяся со списком под ней, — это подделка рейтинга. */
refreshRating($sid);

$q = $pdo->prepare('SELECT rating,reviews_count FROM public_profiles WHERE specialist_id=?');
$q->execute([$sid]); $p = $q->fetch();

echo "Демо-специалист заведён: Екатерина Лаврова (id $sid)\n";
echo "  рейтинг ".($p['rating'] ?? '—')." по ".(int)($p['reviews_count'] ?? 0)." отзывам\n";
echo "  каталог: /app/ → Ещё → Выбрать специалиста\n";
echo "\nЭто витрина, а не живой человек: клиент, выбравший его, подключится\n";
echo "к аккаунту, за которым никого нет. Перед запуском уберите:\n";
echo "  php tools/demo-specialist.php --remove\n";
