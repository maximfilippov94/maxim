<?php
/**
 * Проверка почты: отправляет пробное письмо и печатает, что ответил
 * сервер. Без неё «письмо не пришло» ничем не отличается от «письмо
 * ушло в спам», а это разные поломки.
 *
 *   php tools/mail-check.php вы@почта.ru
 */
declare(strict_types=1);
require __DIR__.'/../config/config.php';

$to = $argv[1] ?? '';
$file = __DIR__.'/../config/mail.php';
echo "Файл настроек: ", is_file($file) ? "есть ($file)" : "НЕТ — письма пойдут через mail() хостинга", "\n";

$c = mailConfig();
echo "Отправитель:   ", $c['from'] ?: '(не задан)', "\n";
echo "Способ:        ", $c['host'] !== ''
  ? "SMTP {$c['host']}:{$c['port']}".($c['security'] ? " ({$c['security']})" : '').($c['username'] !== '' ? ", вход как {$c['username']}" : ', без входа')
  : "mail() хостинга", "\n";
echo "Ссылки в письме: ", siteUrl(), "/?reset=...\n\n";

if ($to === '') {
  echo "Укажите адрес, чтобы отправить пробное письмо:\n  php tools/mail-check.php вы@почта.ru\n";
  exit(0);
}
if (!filter_var($to, FILTER_VALIDATE_EMAIL)) { echo "«$to» — это не адрес почты.\n"; exit(1); }

[$html, $text] = resetLetter('Проверка', siteUrl().'/?reset=proba');
$err = sendMail($to, 'Проверка почты '.APP_NAME, $html, $text);
if ($err === '') {
  echo "Письмо отправлено на $to. Если через пару минут его нет — посмотрите в «Спаме».\n";
  exit(0);
}
echo "Не отправилось: $err\n";
echo $c['host'] === ''
  ? "Хостинг не умеет mail(). Заполните config/mail.php — SMTP работает почти везде.\n"
  : "Проверьте host, порт, security и пароль. Для Яндекса и Gmail нужен пароль приложения, а не от почты.\n";
exit(1);
