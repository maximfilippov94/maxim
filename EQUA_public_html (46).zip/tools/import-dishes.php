<?php
/**
 * Загрузка каталога блюд из data/dishes.json.
 *
 * Без ключей — дополняет: новые блюда добавляются, существующие с тем же
 * названием обновляются составом, рецептом и КБЖУ. Ничего не теряется.
 *
 *   php tools/import-dishes.php
 *
 * С ключом --replace — сносит прежний каталог целиком. Вместе с блюдами
 * уходят и все меню: меню ссылается на блюдо, и убрать блюдо, оставив
 * меню, нельзя — а меню без блюд бессмысленно. Поэтому режим требует
 * второго ключа и сначала показывает, что именно будет потеряно.
 *
 *   php tools/import-dishes.php --replace          # покажет и остановится
 *   php tools/import-dishes.php --replace --yes    # выполнит
 *
 * Перед --replace на рабочем сервере снимите копию: php cron/backup.php
 */
declare(strict_types=1);
require __DIR__.'/../config/config.php';

$argv = $_SERVER['argv'] ?? [];
$replace = in_array('--replace', $argv, true);
$yes     = in_array('--yes', $argv, true);

$data = dishesData();
if (!$data['dishes']) {
  fwrite(STDERR, "data/dishes.json не найден или пуст\n");
  exit(1);
}
printf("В файле: блюд %d, продуктов %d\n", count($data['dishes']), count($data['ingredients']));

$pdo = db();
$dishes = (int)$pdo->query('SELECT COUNT(*) FROM dishes')->fetchColumn();
$menus  = (int)$pdo->query('SELECT COUNT(*) FROM menus')->fetchColumn();
printf("Сейчас в базе: блюд %d, меню %d\n", $dishes, $menus);

if ($replace && !$yes) {
  echo "\n--replace удалит ВСЕ блюда ($dishes) и ВСЕ меню ($menus), включая\n";
  echo "составленные специалистами. Отменить это можно только из копии базы.\n";
  echo "Снимите копию (php cron/backup.php) и повторите с --yes.\n";
  exit(2);
}

$r = importDishes($replace);
if (isset($r['error'])) {
  fwrite(STDERR, "Не загрузилось: {$r['error']}\n");
  exit(1);
}
printf("Готово. Добавлено %d, обновлено %d, продуктов в справочнике %d.\n",
  $r['added'], $r['updated'], $r['ingredients']);
printf("КБЖУ посчитано из состава каждого блюда.\n");

/* Продукт, которого не нашлось в справочнике, вырезает себя из блюда
   молча: состав станет короче, а КБЖУ — меньше. Это не предупреждение,
   а ошибка данных, и говорить о ней надо в лоб. */
foreach($r['gaps'] as $g)
  printf("  ! %s: нет в справочнике — %s\n", $g['name'], implode(', ',$g['missing']));

/* Числа таблицы — контрольные. Расхождение больше 10% значит, что в
   строке таблицы состав и КБЖУ не сходятся между собой; выбирать за
   автора мы не станем, но и молчать об этом нельзя. */
if($r['diffs']){
  printf("\nСостав расходится с КБЖУ таблицы больше чем на 10%% (%d):\n", count($r['diffs']));
  /* printf считает байты, а не буквы: с кириллицей его выравнивание
     разъезжается. Дополняем сами. */
  $pad=fn(string $t,int $n)=>$t.str_repeat(' ',max(1,$n-mb_strlen($t)));
  foreach($r['diffs'] as $d)
    printf("  %s состав %4d ккал, в таблице %4d\n", $pad($d['name'],36), $d['calc'], $d['book']);
  echo "Считаем по составу. Если верна таблица — поправьте граммовку в ней.\n";
}
if ($r['menus_removed']) printf("Удалено меню: %d.\n", $r['menus_removed']);
if (!empty($r['orphans_removed']))
  printf("Убрано неиспользуемых продуктов: %d.\n", $r['orphans_removed']);

/* Фото — отдельной строкой: их кладут в папку отдельно от импорта, и
   молча пропущенный снимок потом ищут долго. */
$q = $pdo->query("SELECT COUNT(*) FROM dishes WHERE photo_url IS NULL OR photo_url=''");
$noPhoto = (int)$q->fetchColumn();
if ($noPhoto) {
  printf("Без фотографии: %d. Положите файлы в папку dishes/ — имена в столбце\n", $noPhoto);
  echo "«Файл фото» таблицы; они подхватятся сами при следующем запросе.\n";
} else {
  echo "Фотографии на месте у всех блюд.\n";
}
