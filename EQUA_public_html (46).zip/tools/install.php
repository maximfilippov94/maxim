<?php
declare(strict_types=1);
require __DIR__.'/../config/config.php';

echo "EQUA database initialized.\n";
echo "Demo specialist: demo@nutrimenu.local / password\n";
echo "Demo client: anna@demo.local / password\n";
echo "Database: ".DB_PATH."\n";
