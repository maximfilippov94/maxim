<?php
/**
 * Страница для нутрициологов.
 *
 * Весь остальной сайт говорит с клиентом: «найдите специалиста». Этой
 * стороне рынка сказать было нечего — кнопка «Я специалист» вела прямо
 * в форму входа, без единого слова о том, зачем сюда идти.
 *
 * Страница нужна прежде всего для личной переписки: ссылку кидают
 * нутрициологу вместо пересказа голосом. Поэтому она короткая и
 * заканчивается одним действием — регистрацией.
 */
declare(strict_types=1);
/* Заголовок ведёт владелец из панели, запасной вариант — в разметке. */
require_once __DIR__.'/config/config.php';
$H=fn(string $k,string $d)=>htmlspecialchars(siteText($k,$d),ENT_QUOTES,'UTF-8');
require_once __DIR__.'/config/config.php';

/* Числа берём из базы, а не пишем руками: обещать «сто блюд», когда их
   пятьдесят, — плохое начало разговора с профессионалом. */
$pdo = db();
$dishes = (int)$pdo->query('SELECT COUNT(*) FROM dishes WHERE is_public=1')->fetchColumn();
$ingredients = (int)$pdo->query('SELECT COUNT(*) FROM ingredients WHERE is_public=1')->fetchColumn();
?><!doctype html>
<html lang="ru"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#F5F6F7">
<title>Нутрициологам — <?= htmlspecialchars(APP_NAME) ?></title>
<meta name="description" content="Ведите клиентов в одном месте: меню на неделю, каталог блюд с КБЖУ, дневник клиента, чат и прогресс. Каталог специалистов приводит новых клиентов.">
<link rel="manifest" href="/manifest.json">
<link rel="apple-touch-icon" href="/icon-180.png">
<link rel="icon" type="image/png" sizes="32x32" href="/icon-32.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="/landing.css">
<style>
/* Страница живёт на токенах лендинга — цвета, тени и радиусы оттуда,
   чтобы это читалось как тот же сайт. Здесь только своя раскладка. */
.sp-wrap{max-width:1120px;margin:0 auto;padding:0 24px}
.sp-hero{padding:120px 0 72px}
.sp-hero h1{
  font-family:'Plus Jakarta Sans',sans-serif;
  font-weight:800;font-size:clamp(38px,6vw,68px);line-height:1.04;
  letter-spacing:-.03em;margin:18px 0 20px;max-width:15ch;text-wrap:balance;
}
.sp-hero h1 em{font-style:normal;color:var(--g)}
.sp-lead{font-size:clamp(17px,2vw,20px);line-height:1.55;color:var(--ink-2);max-width:52ch;margin:0 0 32px}
.sp-cta{display:flex;flex-wrap:wrap;gap:12px;align-items:center}
.sp-cta .note{font-size:14px;color:var(--ink-3)}

/* Проблема — до того, как перечислять возможности: специалист должен
   узнать в описании свой вторник, иначе список функций ему безразличен. */
.sp-pain{
  background:var(--surf);border-radius:var(--r-out);
  padding:40px;box-shadow:var(--amb-sm);margin:8px 0 72px;
}
.sp-pain h2{font-family:'Plus Jakarta Sans',sans-serif;font-size:clamp(24px,3vw,32px);
  font-weight:700;letter-spacing:-.02em;margin:0 0 22px;line-height:1.15}
.sp-pain ul{margin:0;padding:0;list-style:none;display:grid;gap:14px;
  grid-template-columns:repeat(auto-fit,minmax(240px,1fr))}
.sp-pain li{padding-left:26px;position:relative;color:var(--ink-2);line-height:1.5}
.sp-pain li::before{content:"—";position:absolute;left:0;color:var(--g);font-weight:700}

.sp-sec{padding:0 0 76px}
.sp-sec>h2{font-family:'Plus Jakarta Sans',sans-serif;font-size:clamp(26px,3.4vw,40px);
  font-weight:700;letter-spacing:-.025em;line-height:1.1;margin:0 0 12px;max-width:20ch;text-wrap:balance}
.sp-sec>.sub{color:var(--ink-2);font-size:17px;line-height:1.55;max-width:58ch;margin:0 0 34px}

/* Возможности. Размер плитки — по весу: то, ради чего специалист
   останется, крупнее того, что просто приятно иметь. */
.sp-grid{display:grid;gap:16px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
  /* По содержимому, а не по высоте ряда: широкая плитка вмещает текст
     в меньшее число строк и вытягивалась пустотой под ним. */
  align-items:start}
.sp-card{
  background:var(--surf);border-radius:var(--r-in);padding:28px;
  box-shadow:var(--amb-sm);display:flex;flex-direction:column;gap:9px;
}
.sp-card.wide{grid-column:span 2}
/* Во всю строку — чтобы последняя плитка не стояла в ряду одна,
   оставив рядом пустое место. */
.sp-card.full{grid-column:1/-1}
@media (max-width:720px){.sp-card.wide{grid-column:span 1}}
.sp-card h3{font-family:'Plus Jakarta Sans',sans-serif;font-size:19px;font-weight:700;
  letter-spacing:-.01em;margin:0;line-height:1.25}
.sp-card p{margin:0;color:var(--ink-2);line-height:1.55;font-size:15.5px}
.sp-card .num{
  font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;
  font-size:34px;line-height:1;color:var(--g);letter-spacing:-.02em;
  font-variant-numeric:tabular-nums;margin-bottom:2px;
}

/* Верификация — то, чем площадка отличается от объявления в соцсети.
   Поэтому она не плитка в общем ряду, а отдельный блок. */
.sp-verify{
  background:linear-gradient(142deg,#3F9C79 0%,#2E7D63 52%,#245F4C 100%);
  color:#fff;border-radius:var(--r-out);padding:44px;box-shadow:var(--amb);
}
.sp-verify h2{font-family:'Plus Jakarta Sans',sans-serif;font-size:clamp(24px,3vw,34px);
  font-weight:700;letter-spacing:-.02em;margin:0 0 14px;line-height:1.15;color:#fff}
.sp-verify p{margin:0 0 14px;line-height:1.6;color:rgba(255,255,255,.9);max-width:56ch}
.sp-verify p:last-child{margin-bottom:0}
.sp-verify b{color:#fff}

/* Как начать — настоящая последовательность, поэтому нумерована. */
.sp-steps{display:grid;gap:18px;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));counter-reset:s}
.sp-step{counter-increment:s;padding-top:16px;border-top:2px solid var(--g-100)}
.sp-step::before{
  content:counter(s);display:block;
  font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:15px;
  color:var(--g);margin-bottom:8px;
}
.sp-step h3{font-family:'Plus Jakarta Sans',sans-serif;font-size:18px;font-weight:700;
  margin:0 0 6px;line-height:1.3}
.sp-step p{margin:0;color:var(--ink-2);line-height:1.55;font-size:15.5px}

.sp-final{
  background:var(--surf);border-radius:var(--r-out);padding:52px 44px;
  box-shadow:var(--amb);text-align:center;margin-bottom:84px;
}
.sp-final h2{font-family:'Plus Jakarta Sans',sans-serif;font-size:clamp(26px,3.6vw,40px);
  font-weight:700;letter-spacing:-.025em;margin:0 0 12px;line-height:1.12;text-wrap:balance}
.sp-final p{color:var(--ink-2);font-size:17px;line-height:1.55;margin:0 auto 28px;max-width:46ch}
.sp-final .sp-cta{justify-content:center}

@media (max-width:640px){
  .sp-hero{padding:96px 0 52px}
  .sp-pain,.sp-verify{padding:28px}
  .sp-final{padding:36px 24px}
}
</style>
</head>
<body>

<div class="grain" aria-hidden="true"></div>

<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<symbol id="leaf" viewBox="0 0 24 24"><path d="M5 19c0-8 6-14 14-14 0 8-6 14-14 14ZM5 19c4-2 7-5 9-9"/></symbol>
<symbol id="arr" viewBox="0 0 24 24"><path d="M6 18 18 6M9 6h9v9"/></symbol>
</defs></svg>

<header class="island" id="island">
  <a class="logo" href="/"><?php include __DIR__.'/partials/logo.php' ?></a>
  <nav class="isl-menu">
    <a href="/">Клиентам</a>
    <a href="#what">Возможности</a>
    <a href="#verify">Проверка</a>
    <a href="#start">Как начать</a>
    <a href="/catalog.php">Каталог</a>
  </nav>
  <div class="isl-cta">
    <a class="btn o plain" href="/app/">Вход</a>
    <a class="btn p" href="/app/"><span class="cap">Регистрация</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
    <button class="burger" id="burger" aria-label="Меню" aria-expanded="false"><i></i><i></i></button>
  </div>
</header>

<!-- На узких экранах меню в шапке скрывается: разделы уезжают сюда. -->
<nav class="sheetnav" id="sheetnav">
  <a href="/">Клиентам</a>
  <a href="#what">Возможности</a>
  <a href="#verify">Проверка документов</a>
  <a href="#start">Как начать</a>
  <a href="/catalog.php">Каталог специалистов</a>
  <a href="/app/">Вход</a>
  <a class="btn p" href="/app/"><span class="cap">Зарегистрироваться</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
</nav>

<main id="main">
<div class="sp-wrap">

  <section class="sp-hero">
    <span class="eyebrow"><svg class="i"><use href="#leaf"/></svg> Нутрициологам и тренерам</span>
    <h1><?= siteText('spec_title','')!=='' ? $H('spec_title','') : 'Ведите клиентов, <em>а не таблицы</em>' ?></h1>
    <p class="sp-lead">
      Меню на неделю, каталог блюд с посчитанным КБЖУ, дневник клиента, чат
      и прогресс — в одном месте. Клиент видит меню в телефоне и отмечает,
      что съел. Вы видите, что происходит, не спрашивая.
    </p>
    <div class="sp-cta">
      <a class="btn p" href="/app/"><span class="cap">Начать бесплатно</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
      <span class="note">Регистрация — пара минут. Проверка документов — до суток.</span>
    </div>
  </section>

  <section class="sp-pain">
    <h2>Если это про вас — дальше можно читать</h2>
    <ul>
      <li>Меню в Word, расчёты в Excel, переписка в мессенджере, фото весов там же — и всё это по каждому клиенту.</li>
      <li>КБЖУ пересчитываете руками каждый раз, когда меняете граммовку.</li>
      <li>Не знаете, соблюдает клиент меню или нет, пока сам не расскажет.</li>
      <li>Новые клиенты приходят только из сарафанного радио.</li>
    </ul>
  </section>

  <section class="sp-sec" id="what">
    <h2>Что вы получаете</h2>
    <p class="sub">Не «платформа с искусственным интеллектом», а конкретные вещи, которые убирают ручную работу из вашего дня.</p>

    <div class="sp-grid">

      <article class="sp-card wide">
        <h3>Меню на неделю за один заход</h3>
        <p>Собираете день из блюд, двигаете граммовку — КБЖУ пересчитывается сразу.
        Готовое меню можно сохранить шаблоном и применить к следующему клиенту.
        Есть сборка под цели: программа набирает день под нужные калории и БЖУ,
        обходя аллергии и исключения клиента. Это черновик, который вы правите, а не решение за вас.</p>
      </article>

      <article class="sp-card">
        <div class="num"><?= $dishes ?></div>
        <h3>блюд в общем каталоге</h3>
        <p>С фотографиями, составом и пошаговыми рецептами. Плюс <?= $ingredients ?> продуктов
        в справочнике — из них КБЖУ и считается. Своё блюдо добавляется за минуту.</p>
      </article>

      <article class="sp-card">
        <h3>Клиент в телефоне</h3>
        <p>Видит меню на день, отмечает съеденное, ведёт вес, воду и замеры,
        присылает фото прогресса. Вы видите то же самое в своей карточке клиента.</p>
      </article>

      <article class="sp-card">
        <h3>Список покупок сам</h3>
        <p>Собирается из меню на неделю: продукты сложены по категориям, с граммовкой.
        Клиент отмечает, что уже есть дома, — это уходит из списка.</p>
      </article>

      <article class="sp-card">
        <h3>Чат внутри работы</h3>
        <p>Переписка с клиентом рядом с его меню и прогрессом, а не в общем мессенджере
        вперемешку с личным. С голосовыми и вложениями.</p>
      </article>

      <article class="sp-card full">
        <h3>Новые клиенты из каталога</h3>
        <p>Ваша карточка с образованием, специализациями, ценой и настоящими отзывами
        видна в каталоге. Клиент оставляет заявку — она приходит вам.
        Отзывы и рейтинг считаются только по тем клиентам, с которыми вы действительно работали:
        накрутить их нельзя, и потому им верят.</p>
      </article>

    </div>
  </section>

  <section class="sp-sec" id="verify">
    <div class="sp-verify">
      <h2>Мы проверяем документы. Это в ваших интересах</h2>
      <p>Клиент, который ищет нутрициолога, не может отличить специалиста с образованием
      от человека, прошедшего вебинар. Поэтому он либо не решается, либо идёт по знакомым.</p>
      <p>Перед публикацией в каталоге мы смотрим диплом или сертификаты. <b>До одобрения
      карточка не показывается никому.</b> Прошли проверку — рядом с именем стоит отметка,
      и она значит ровно то, что значит: документы видел живой человек.</p>
      <p>Ответ по документам — <b>в течение суток в будни</b>. Отказ приходит с причиной,
      а не молча.</p>
    </div>
  </section>

  <section class="sp-sec" id="start">
    <h2>Как начать</h2>
    <p class="sub">От регистрации до первого клиента с готовым меню — обычно один вечер.</p>
    <div class="sp-steps">
      <article class="sp-step">
        <h3>Зарегистрируйтесь</h3>
        <p>Почта и пароль. Заполните карточку: образование, опыт, специализации, цена.</p>
      </article>
      <article class="sp-step">
        <h3>Пришлите документы</h3>
        <p>Диплом или сертификаты — фотографией. Мы отвечаем в течение суток.</p>
      </article>
      <article class="sp-step">
        <h3>Пригласите клиента</h3>
        <p>По коду или ссылке. Заполняете цели, собираете меню — клиент видит его у себя.</p>
      </article>
    </div>
  </section>

  <section class="sp-final">
    <h2>Попробуйте на одном клиенте</h2>
    <p>Этого достаточно, чтобы понять, экономит это вам время или нет.
    Сейчас, пока сервис в запуске, доступ бесплатный.</p>
    <div class="sp-cta">
      <a class="btn p" href="/app/"><span class="cap">Зарегистрироваться</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
      <a class="btn o" href="/catalog.php"><span class="cap">Посмотреть каталог</span></a>
    </div>
  </section>

</div>
</main>

<footer><div class="wrap">
  <div class="foot">
    <a class="logo" href="/"><?php include __DIR__.'/partials/logo.php' ?></a>
    <nav><a href="/">Клиентам</a><a href="/catalog.php">Каталог специалистов</a><a href="/app/">Вход</a><a href="/privacy">Конфиденциальность</a><a href="/terms">Условия</a></nav>
    <span class="cp">© <?= date('Y') ?> EQUA</span>
  </div>
</div></footer>

<script src="/nav.js"></script>
</body></html>
