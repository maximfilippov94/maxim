/* ==========================================================================
   EQUA — SPA (нутрициолог + клиент). Все данные реальные через /api/v1.
   ========================================================================== */
const A={token:localStorage.nm_token||'',type:localStorage.nm_type||'',user:null,
  client:null,menu:null,items:[],day:1,tab:'menu',drawerItem:null,
  dishes:[],ingredients:[],favs:JSON.parse(localStorage.nm_favs||'[]'),ptab:'weight'};
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const R=n=>Math.round(n||0);
const kg=v=>v==null?'—':(Math.round(v*10)/10+'').replace('.',',');
/* Полоса вверху вместо молчания: пока запрос идёт, видно, что программа
   работает. Зажигаем её только через 220 мс — быстрые ответы мигали бы
   чаще, чем читались. Обрыв связи отличаем от ошибки сервера: человеку
   важно понять, чинить ли ему интернет. */
let _net=0,_netT=null;
function netStart(){ if(++_net===1&&!_netT)_netT=setTimeout(()=>{_netT=null;document.documentElement.classList.add('busy')},220) }
function netEnd(){ if(--_net>0)return; _net=0; if(_netT){clearTimeout(_netT);_netT=null} document.documentElement.classList.remove('busy') }
async function api(path,opt={}){const h={};if(!(opt.body instanceof FormData))h['Content-Type']='application/json';if(A.token)h.Authorization='Bearer '+A.token;
  netStart();
  let r;
  try{ r=await fetch('/api/v1'+path,{...opt,headers:{...h,...(opt.headers||{})}}) }
  catch(e){ throw Object.assign(Error('Нет связи с сервером. Проверьте интернет.'),{offline:true}) }
  finally{ netEnd() }
  let j={};try{j=await r.json()}catch{}if(!r.ok)throw Object.assign(Error(j.error||'Ошибка сервера'),{status:r.status});return j}
const reduceMotion=()=>window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const EASE='cubic-bezier(.2,.8,.2,1)';
function fx(el){
  if(!el||reduceMotion()||!el.animate)return;
  /* После жеста экран приезжает с той стороны, куда вели пальцем, — иначе
     свайп ощущается как нажатие кнопки, а не как перелистывание. */
  const d=A._swipeDir||0; A._swipeDir=0;
  const from=d? 'translateX('+(d*22)+'px)' : 'translateY(8px)';
  el.animate([{opacity:0,transform:from},{opacity:1,transform:'none'}],{duration:d?240:260,easing:EASE})}

/* Листание вкладок жестом, как пейджер в приложении. Порядок берём у самой
   панели, поэтому правило одно на все три роли и не разъезжается с ней. */
/* Safari на iPhone держит панель адреса поверх страницы: элементы,
   прижатые к низу окна, уезжают под неё, и нижняя навигация пропадает —
   это видно, когда сайт открыт в браузере, а не запущен с домашнего
   экрана. Меряем видимую часть окна и поднимаем панель на разницу.
   Клавиатуру исключаем: её подъём считается отдельно и панель при ней
   не всплывает. */
function trackViewport(){
  const vv=window.visualViewport;
  const root=document.documentElement;
  if(!vv){root.style.setProperty('--vv-bottom','0px');root.style.setProperty('--kb','0px');return}
  /* Клавиатуру опознаём не по одной высоте выреза: Safari при ней ещё и
     подпихивает страницу вверх, вырез становится похож на панель адреса,
     и чат укорачивался вдвое — поле ввода зависало в середине экрана.
     Верный признак — курсор стоит в поле ввода. */
  const typing=()=>{const a=document.activeElement;
    return !!a&&(a.tagName==='INPUT'||a.tagName==='TEXTAREA'||a.isContentEditable)};
  const set=()=>{
    const gap=Math.round(root.clientHeight-(vv.height+vv.offsetTop));
    const kb=typing()&&gap>80;
    /* Видимая часть окна в чистом виде: чату проще опереться на неё, чем
       вычитать из высоты экрана панель, вырез и клавиатуру по очереди. */
    root.style.setProperty('--vvh',Math.round(vv.height)+'px');
    root.style.setProperty('--vvt',Math.round(vv.offsetTop)+'px');
    /* Панели, которые всплывают над краем окна: клавиатура сюда не
       входит — при ней они не нужны. */
    root.style.setProperty('--vv-bottom',(!kb&&gap>0&&gap<140?gap:0)+'px');
    root.style.setProperty('--kb',(kb?gap:0)+'px');
    document.body.classList.toggle('kb-open',kb);
  };
  vv.addEventListener('resize',set);
  vv.addEventListener('scroll',set);
  addEventListener('orientationchange',()=>setTimeout(set,250));
  addEventListener('focusin',()=>setTimeout(set,60));
  addEventListener('focusout',()=>setTimeout(set,60));
  set();
}
trackViewport();
/* Возврат свайпом вправо — привычка с телефона: тянуть от левого края,
   чтобы закрыть карточку. Кнопку «назад» при этом искать не надо.
   Работает только там, где такая кнопка есть: на корневых экранах
   свайп по-прежнему листает вкладки. */
function swipeBackTarget(){
  return document.querySelector('.msgr.show-thread .thread-back')
      || document.querySelector('.navbar .nb-back')
      || document.querySelector('.chat-top .chat-close')
      || document.querySelector('.navbar button:first-child');
}
function initSwipe(){
  let x0=0,y0=0,t0=0,armed=false;
  const skip='.wd-strip,.chip-row,.filter-row,.seg-tabs,.seg-mini,.ptabs,.dish-filters,'
            +'.cal,.msgr,.portion-range,input,textarea,select,.tabbar,.week-strip';
  addEventListener('pointerdown',e=>{
    armed=false;
    if(e.pointerType==='mouse')return;
    const t=e.target;
    if(!t.closest||!t.closest(SHELL_MAIN))return;
    if(t.closest(skip))return;
    x0=e.clientX;y0=e.clientY;t0=Date.now();armed=true;
  },{passive:true});
  addEventListener('pointerup',e=>{
    if(!armed)return; armed=false;
    const dx=e.clientX-x0, dy=e.clientY-y0;
    if(Date.now()-t0>600)return;
    if(Math.abs(dx)<64||Math.abs(dx)<Math.abs(dy)*1.6)return;
    /* Свайп вправо — «назад». Край экрана больше не обязателен: на
       карточке листать нечего, она открыта поверх вкладки, и требовать
       начать жест ровно у рамки — лишняя точность. Где кнопки возврата
       нет (корневые вкладки), свайп по-прежнему листает вкладки. */
    if(dx>0){
      const back=swipeBackTarget();
      if(back){A._swipeDir=-1;back.click();return}
    }
    const nav=document.querySelector('.pillnav'); if(!nav)return;
    const items=[...nav.querySelectorAll('.pill-item')];
    const i=items.findIndex(b=>b.classList.contains('active'));
    const j=i+(dx<0?1:-1);
    if(i<0||j<0||j>=items.length)return;
    A._swipeDir=dx<0?1:-1;
    items[j].click();
  },{passive:true});
}
initSwipe();
/* Нажатие на «назад» — тот же возврат, что и свайп, и выглядеть должен
   так же. Ловим его в одном месте, а не расставляем пометку по всем
   вызовам: кнопок возврата на экранах десятки. */
addEventListener('click',e=>{
  const t=e.target;
  if(t&&t.closest&&t.closest('.nb-back,.chat-close,.thread-back,.viewer-top .close'))A._swipeDir=-1;
},true);
function stagger(el){if(!el||reduceMotion()||!el.animate)return;[...el.children].slice(0,16).forEach((c,i)=>c.animate([{opacity:0,transform:'translateY(9px)'},{opacity:1,transform:'none'}],{duration:300,delay:i*32,easing:EASE,fill:'backwards'}))}
const MEAL={breakfast:'Завтрак',snack1:'Перекус',lunch:'Обед',snack2:'Перекус',dinner:'Ужин'};
const MEAL_ORDER=['breakfast','snack1','lunch','snack2','dinner'];
/* Блюдо без фотографии.
   Раньше сюда подставлялась одна из пяти стоковых картинок по остатку от
   деления id: у греческого йогурта оказывалась паста, у творога — курица.
   Снимок, показывающий не то блюдо, хуже отсутствия снимка, поэтому
   вместо него — спокойная заглушка с тарелкой. */
/* Заглушка без заливки: фон даёт тема через CSS. С вписанным тёмным
   прямоугольником она оставалась чёрным квадратом на светлой карточке.
   Контур полупрозрачный — читается и на тёмном, и на светлом. */
const DISH_PLACEHOLDER="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="180">'+
  '<g fill="none" stroke="#8A94A3" stroke-opacity=".55" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">'+
  '<path d="M88 82h64a4 4 0 0 1 4 4.4 36 36 0 0 1-72 0 4 4 0 0 1 4-4.4Z"/>'+
  '<path d="M108 71c0-5.6 4-7.6 4-12.4M123.6 71c0-5.6 4-7.6 4-12.4"/></g></svg>');
const foodImg=()=>DISH_PLACEHOLDER;
/* Фото блюда в двух размерах. В списке и сетке плитка шириной 100–200
   точек, и грузить туда снимок на 1100 — это мегабайты трафика ради
   картинки размером с ноготь. Крупная версия остаётся карточке. */
const dishThumb=o=>o?.photo_thumb_url||o?.photo_url||DISH_PLACEHOLDER;
const dishPhoto=o=>o?.photo_url||DISH_PLACEHOLDER;
function timeFor(t){return {breakfast:'08:30',snack1:'11:00',lunch:'14:00',snack2:'16:30',dinner:'19:00'}[t]||''}

/* ---------- icons ---------- */
/* ============================================================
   NUTRIMENU ICON SYSTEM
   Единая сетка 24×24, штрих 1.75, скруглённые окончания,
   оптическая масса в поле 4…20. Геометрия + мягкая органика.
   ============================================================ */
const IC={
  spark:'M12 3.3l1.9 4.6 4.6 1.9-4.6 1.9L12 16.3l-1.9-4.6L5.5 9.8l4.6-1.9ZM18.4 14.4c.3 1.5.8 2 2.3 2.3-1.5.3-2 .8-2.3 2.3-.3-1.5-.8-2-2.3-2.3 1.5-.3 2-.8 2.3-2.3Z',

/* --- Навигация --- */
home:'M4.2 10.7 11.1 4.6a1.4 1.4 0 0 1 1.8 0l6.9 6.1M6.4 9.6v8.9a1.7 1.7 0 0 0 1.7 1.7h7.8a1.7 1.7 0 0 0 1.7-1.7V9.6M9.9 20.2v-4.4a2.1 2.1 0 0 1 4.2 0v4.4',
users:'M9.2 10.6a3.1 3.1 0 1 0 0-6.2 3.1 3.1 0 0 0 0 6.2ZM3.6 19.6c0-3.3 2.5-5.4 5.6-5.4s5.6 2.1 5.6 5.4M16.4 5.1a3.1 3.1 0 0 1 0 5.9M18 14.6c1.7.7 2.7 2.2 2.7 4.3',
user:'M12 11.6a3.7 3.7 0 1 0 0-7.4 3.7 3.7 0 0 0 0 7.4ZM4.8 20.2a7.2 7.2 0 0 1 14.4 0',
chat:'M20.4 11.6a7.9 7.9 0 0 1-11.3 7.2L3.6 20.4l1.6-5.3a7.9 7.9 0 1 1 15.2-3.5Z',
chart:'M4.4 4.6v13.9a1.5 1.5 0 0 0 1.5 1.5h13.7M8.6 16.4v-3.1a.9.9 0 0 1 1.8 0v3.1M13 16.4V9.2a.9.9 0 0 1 1.8 0v7.2M17.4 16.4v-4.9a.9.9 0 0 1 1.8 0v4.9',
trend:'M3.8 16.6 9.2 11l3.4 3.4 7.6-7.6M20.2 6.8h-4.6M20.2 6.8v4.6',
cog:'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6ZM12 4.4v1.7M12 17.9v1.7M19.6 12h-1.7M6.1 12H4.4M17.4 6.6l-1.2 1.2M7.8 16.2l-1.2 1.2M17.4 17.4l-1.2-1.2M7.8 7.8 6.6 6.6',
layers:'M11.4 4.1 4.3 7.6a.7.7 0 0 0 0 1.2l7.1 3.5a1.4 1.4 0 0 0 1.2 0l7.1-3.5a.7.7 0 0 0 0-1.2l-7.1-3.5a1.4 1.4 0 0 0-1.2 0ZM4.3 12.6l7.1 3.5a1.4 1.4 0 0 0 1.2 0l7.1-3.5M4.3 16.7l7.1 3.5a1.4 1.4 0 0 0 1.2 0l7.1-3.5',
grad:'M12 3.9 3.4 8.1 12 12.3l8.6-4.2ZM6.8 10.1v4.4c0 1.7 2.3 3 5.2 3s5.2-1.3 5.2-3v-4.4M20.6 8.1v5.2',
shield:'M12 3.2 19 5.7v5.2c0 4.3-2.9 7.6-7 9.3-4.1-1.7-7-5-7-9.3V5.7L12 3.2ZM8.8 11.8l2.2 2.2 4.2-4.2',

/* --- Еда --- */
bowl:'M3.8 10.6h16.4a8.2 8.2 0 0 1-8.2 8.2 8.2 8.2 0 0 1-8.2-8.2ZM8.4 7.4c0-1 .8-1.6.8-2.6M12 7.4c0-1 .8-1.6.8-2.6M15.6 7.4c0-1 .8-1.6.8-2.6',
food:'M4 11.4h16a1 1 0 0 1 1 1.1 9 9 0 0 1-18 0 1 1 0 0 1 1-1.1ZM9 8.6c0-1.4 1-1.9 1-3.1M12.9 8.6c0-1.4 1-1.9 1-3.1',
breakfast:'M5.6 9.2h10.6v5.1a5.3 5.3 0 0 1-10.6 0V9.2ZM16.2 10.6h1.7a2.2 2.2 0 0 1 0 4.4h-1.7M9 6.6c0-1.1.7-1.5.7-2.4M13 6.6c0-1.1.7-1.5.7-2.4M4.6 20.1h12.6',
lunch:'M7.2 3.9v5.6a2.2 2.2 0 0 0 4.4 0V3.9M9.4 9.5v10.6M16.5 3.9c-1.5 1.1-2.2 2.6-2.2 4.5 0 1.6.7 2.6 2.2 3v8.7',
dinner:'M3.6 17.6h16.8M5.3 17.6a6.7 6.7 0 0 1 13.4 0M12 7V4.8M10.7 4.8h2.6',
carrot:'M17.2 7.3c1.4-1.5 2.9-1.4 3.8-1-.4 1-.4 2.4-1.8 3.9M14.6 6.7 17.9 10 9.4 18.7c-1.9 1.9-5.7 1.9-6.2 1.4S3.9 15.3 5.8 13.4l8.8-6.7M11.2 10.2l1.9 1.9M8.8 12.7l1.9 1.9',
replace:'M4.2 9.3h11.4M12.6 6.3l3 3-3 3M19.8 15.4H8.4M11.4 12.4l-3 3 3 3',

/* --- Действия --- */
plus:'M12 5.2v13.6M5.2 12h13.6',
add:'M12 5.4v13.2M5.4 12h13.2',
check:'M5.4 12.6 9.8 17l8.8-9.4',
x:'M6.6 6.6 17.4 17.4M17.4 6.6 6.6 17.4',
close:'M6.2 6.2 17.8 17.8M17.8 6.2 6.2 17.8',
edit:'M4.4 19.6h4l10-10a2 2 0 0 0-2.8-2.8l-10 10ZM14.4 5.6l4 4',
trash:'M5.4 7.4h13.2M9.7 7.4V5.9a1.4 1.4 0 0 1 1.4-1.4h1.8a1.4 1.4 0 0 1 1.4 1.4v1.5M7 7.4l.7 11.1a1.6 1.6 0 0 0 1.6 1.5h5.4a1.6 1.6 0 0 0 1.6-1.5L17 7.4M10.5 11v5.4M13.5 11v5.4',
send:'M20.4 3.6 3.6 10.4l6.6 2.9 2.9 6.6ZM10.2 13.3 20.4 3.6',
save:'M12 4.6v9.2M8.6 10.4 12 13.8l3.4-3.4M4.9 15.1v3.3a1.7 1.7 0 0 0 1.7 1.7h10.8a1.7 1.7 0 0 0 1.7-1.7v-3.3',
publish:'M12 14.2V4.8M8.6 8.2 12 4.8l3.4 3.4M4.9 15.1v3.3a1.7 1.7 0 0 0 1.7 1.7h10.8a1.7 1.7 0 0 0 1.7-1.7v-3.3',
copy:'M9.4 9.4h9.1a1.4 1.4 0 0 1 1.4 1.4v9.1H9.4a1.4 1.4 0 0 1-1.4-1.4V9.4ZM5.5 14.9V5.5a1.4 1.4 0 0 1 1.4-1.4h9.4',
filter:'M4.6 5.9h14.8l-5.5 6.5v5.4l-3.8 2.1v-7.5L4.6 5.9Z',
search:'M11 17.9a6.9 6.9 0 1 0 0-13.8 6.9 6.9 0 0 0 0 13.8ZM16 16l3.6 3.6',
camera:'M5.4 8.4h2.4l1.4-2.1h5.6l1.4 2.1h2.4a1.5 1.5 0 0 1 1.5 1.5v8.2a1.5 1.5 0 0 1-1.5 1.5H5.4a1.5 1.5 0 0 1-1.5-1.5V9.9a1.5 1.5 0 0 1 1.5-1.5ZM12 16.4a2.9 2.9 0 1 0 0-5.8 2.9 2.9 0 0 0 0 5.8Z',
clip:'M19 11.4 12 18.4a4.2 4.2 0 0 1-6-6l7.6-7.6a2.8 2.8 0 0 1 4 4l-7.6 7.6a1.4 1.4 0 0 1-2-2l7-7',
cart:'M3.2 4.4h2.1l2.2 9.8a1.6 1.6 0 0 0 1.6 1.3h7.5a1.6 1.6 0 0 0 1.6-1.2l1.4-5.9H6.2M9.6 19.6a1.1 1.1 0 1 0 0-2.2 1.1 1.1 0 0 0 0 2.2ZM17.2 19.6a1.1 1.1 0 1 0 0-2.2 1.1 1.1 0 0 0 0 2.2Z',

/* --- Направление --- */
chevr:'M9.5 5.8 15.7 12l-6.2 6.2',
chevl:'m14.4 5.9-6 6.1 6 6.1',
chevd:'m5.9 9.6 6.1 6 6.1-6',
back:'M14.5 5.8 8.3 12l6.2 6.2',
forward:'M9.6 5.9 15.6 12l-6 6.1',
kebab:'M12 6.6a1 1 0 1 0 0-2 1 1 0 0 0 0 2ZM12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2ZM12 19.4a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z',
more:'M12 5.6h.01M12 12h.01M12 18.4h.01',
menu:'M8.6 7.2h10.8M8.6 12h10.8M8.6 16.8h7.4M4.7 7.2h.01M4.7 12h.01M4.7 16.8h.01',

/* --- Статусы и данные --- */
bell:'M12 4a5.5 5.5 0 0 0-5.5 5.5c0 3.3-.7 5.1-1.4 6.1a.6.6 0 0 0 .5.9h12.8a.6.6 0 0 0 .5-.9c-.7-1-1.4-2.8-1.4-6.1A5.5 5.5 0 0 0 12 4ZM9.9 18.6a2.1 2.1 0 0 0 4.2 0',
cal:'M5.5 6.4h13a1.9 1.9 0 0 1 1.9 1.9v10.4a1.9 1.9 0 0 1-1.9 1.9h-13a1.9 1.9 0 0 1-1.9-1.9V8.3a1.9 1.9 0 0 1 1.9-1.9ZM3.6 11h16.8M8.2 3.6v4M15.8 3.6v4',
clock:'M12 20.6a8.6 8.6 0 1 0 0-17.2 8.6 8.6 0 0 0 0 17.2ZM12 7.4V12l3.1 1.9',
weight:'M6.2 8.4h11.6l1.6 11.2H4.6ZM12 4.4a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z',
warn:'M10.6 5.2 3.7 17.3a1.6 1.6 0 0 0 1.4 2.4h13.8a1.6 1.6 0 0 0 1.4-2.4L13.4 5.2a1.6 1.6 0 0 0-2.8 0ZM12 10.1v4M12 17h.01',
warning:'M10.6 5.2 3.7 17.3a1.6 1.6 0 0 0 1.4 2.4h13.8a1.6 1.6 0 0 0 1.4-2.4L13.4 5.2a1.6 1.6 0 0 0-2.8 0ZM12 10.1v4M12 17h.01',
info:'M12 20.6a8.6 8.6 0 1 0 0-17.2 8.6 8.6 0 0 0 0 17.2ZM12 11.2v5.2M12 7.9h.01',
lock:'M6.6 10.4h10.8a1.6 1.6 0 0 1 1.6 1.6v7a1.6 1.6 0 0 1-1.6 1.6H6.6A1.6 1.6 0 0 1 5 19v-7a1.6 1.6 0 0 1 1.6-1.6ZM8.2 10.4V7.8a3.8 3.8 0 0 1 7.6 0v2.6',
unlock:'M6.4 10.9h11.2a1.3 1.3 0 0 1 1.3 1.3v6.7a1.3 1.3 0 0 1-1.3 1.3H6.4a1.3 1.3 0 0 1-1.3-1.3v-6.7a1.3 1.3 0 0 1 1.3-1.3ZM8.6 10.9V8.2a3.4 3.4 0 0 1 6.6-1.1M12 14.6v2.2',
doc:'M6.4 3.9h6.9l5 5v11.2a1.3 1.3 0 0 1-1.3 1.3H6.4a1.3 1.3 0 0 1-1.3-1.3V5.2a1.3 1.3 0 0 1 1.3-1.3ZM13.2 3.9v4.8h4.8M8.4 13.4h7.2M8.4 16.6h4.8',
star:'M12 3.8l2.5 5.3 5.7.8-4.1 4 1 5.7-5.1-2.7-5.1 2.7 1-5.7-4.1-4 5.7-.8Z',
heart:'M12 20s-7.6-4.6-7.6-9.6a4.2 4.2 0 0 1 7.6-2.4 4.2 4.2 0 0 1 7.6 2.4c0 5-7.6 9.6-7.6 9.6Z',
flame:'M12 3.6s5.4 4 5.4 8.8a5.4 5.4 0 0 1-10.8 0c0-2 1.2-3.4 1.2-3.4s.6 1.6 1.8 1.6c1.4 0 2.4-4 2.4-7Z',
gift:'M4.4 11.4h15.2v8a1.6 1.6 0 0 1-1.6 1.6H6a1.6 1.6 0 0 1-1.6-1.6ZM3.6 7.6h16.8v3.8H3.6ZM12 7.6V21M12 7.6C10.6 4.4 8.8 3 7.4 3.6c-1.6.7-1.4 3.3 4.6 4M12 7.6c1.4-3.2 3.2-4.6 4.6-4 1.6.7 1.4 3.3-4.6 4',
trophy:'M7.6 4h8.8v5a4.4 4.4 0 0 1-8.8 0ZM7.6 5.6H5a1 1 0 0 0-1 1c0 2 1.4 3.6 3.6 3.8M16.4 5.6H19a1 1 0 0 1 1 1c0 2-1.4 3.6-3.6 3.8M9.6 20.4h4.8M12 13.4v7',
coin:'M12 20.6a8.6 8.6 0 1 0 0-17.2 8.6 8.6 0 0 0 0 17.2ZM12 7.4v9.2M9.8 10c0-1.1 1-1.6 2.2-1.6s2.2.5 2.2 1.5c0 2.2-4.4 1.1-4.4 3.3 0 1 1 1.6 2.2 1.6s2.2-.5 2.2-1.6',
dot:'M12 12h.01',
sparkle:'M12 4.2c.6 3.3 1.7 4.4 5 5-3.3.6-4.4 1.7-5 5-.6-3.3-1.7-4.4-5-5 3.3-.6 4.4-1.7 5-5ZM18.4 14.4c.3 1.5.8 2 2.3 2.3-1.5.3-2 .8-2.3 2.3-.3-1.5-.8-2-2.3-2.3 1.5-.3 2-.8 2.3-2.3Z',
/* Контуры из приложения (src/ui/Icon.tsx): на iPhone оно рисует их
   системными SF Symbols, а вне iOS — этими же путями. Веб берёт их,
   потому что SF Symbols в браузере недоступны. */
device:'M7.6 3.5h8.8a1.9 1.9 0 0 1 1.9 1.9v13.2a1.9 1.9 0 0 1-1.9 1.9H7.6a1.9 1.9 0 0 1-1.9-1.9V5.4a1.9 1.9 0 0 1 1.9-1.9ZM10.7 17.7h2.6',
drop:'M12 3.4s5.8 6.2 5.8 10a5.8 5.8 0 0 1-11.6 0c0-3.8 5.8-10 5.8-10Z',
exit:'M14.6 8.2V5.9a1.9 1.9 0 0 0-1.9-1.9H6.3a1.9 1.9 0 0 0-1.9 1.9v12.2a1.9 1.9 0 0 0 1.9 1.9h6.4a1.9 1.9 0 0 0 1.9-1.9v-2.3M9.8 12h9.8M16.6 8.8 19.8 12l-3.2 3.2',
eye:'M2.6 12S6.4 5.8 12 5.8 21.4 12 21.4 12 17.6 18.2 12 18.2 2.6 12 2.6 12ZM12 14.8a2.8 2.8 0 1 0 0-5.6 2.8 2.8 0 0 0 0 5.6Z',
eyeoff:'M4 4l16 16M9.6 9.7a2.8 2.8 0 0 0 3.9 3.9M6.5 6.7C4.1 8.3 2.6 12 2.6 12s3.8 6.2 9.4 6.2c1.6 0 3-.5 4.2-1.2M17.9 15A13 13 0 0 0 21.4 12S17.6 5.8 12 5.8c-.8 0-1.5.1-2.2.3',
mail:'M4.4 5.8h15.2a1.6 1.6 0 0 1 1.6 1.6v9.2a1.6 1.6 0 0 1-1.6 1.6H4.4a1.6 1.6 0 0 1-1.6-1.6V7.4a1.6 1.6 0 0 1 1.6-1.6ZM3.2 7l8.8 6 8.8-6',
mic:'M12 3.6a2.6 2.6 0 0 1 2.6 2.6v5.2a2.6 2.6 0 0 1-5.2 0V6.2A2.6 2.6 0 0 1 12 3.6ZM6 11a6 6 0 0 0 12 0M12 17v3.4M9 20.4h6',
moon:'M20.4 14.8A8.7 8.7 0 0 1 9.2 3.6a8.7 8.7 0 1 0 11.2 11.2Z',
pause:'M9.4 5.6v12.8M14.6 5.6v12.8',
play:'M8 5.4 18.4 12 8 18.6Z',
sun:'M12 16.4a4.4 4.4 0 1 0 0-8.8 4.4 4.4 0 0 0 0 8.8ZM12 2.5v2.1M12 19.4v2.1M4.3 4.3l1.5 1.5M18.2 18.2l1.5 1.5M2.5 12h2.1M19.4 12h2.1M4.3 19.7l1.5-1.5M18.2 5.8l1.5-1.5',
tag:'M11.2 3.6H19a1.4 1.4 0 0 1 1.4 1.4v7.8a1.4 1.4 0 0 1-.4 1l-7.8 7.8a1.4 1.4 0 0 1-2 0l-7-7a1.4 1.4 0 0 1 0-2l7.8-7.8a1.4 1.4 0 0 1 1-.4ZM16.1 8.8a.9.9 0 1 0 0-1.8.9.9 0 0 0 0 1.8Z',
target:'M12 20.6a8.6 8.6 0 1 0 0-17.2 8.6 8.6 0 0 0 0 17.2ZM12 16.3a4.3 4.3 0 1 0 0-8.6 4.3 4.3 0 0 0 0 8.6ZM12 13.1a1.1 1.1 0 1 0 0-2.2 1.1 1.1 0 0 0 0 2.2Z',
video:'M4.3 7.6a2 2 0 0 1 2-2h7.2a2 2 0 0 1 2 2v8.8a2 2 0 0 1-2 2H6.3a2 2 0 0 1-2-2ZM15.5 10.9l3.4-2.4a.7.7 0 0 1 1.1.6v5.8a.7.7 0 0 1-1.1.6l-3.4-2.4Z'};
function icon(n){return `<svg viewBox="0 0 24 24" class="ic"><path d="${IC[n]||IC.home}"/></svg>`}

/* ---------- shared UI ---------- */
function av(name,cls='',url){
  /* Как Face в приложении: круг, мягкая зелёная подложка и буква акцентом.
     Разноцветные градиенты по хешу имени превращали список в мозаику. */
  const c=(name||'·').trim()[0]||'·';
  const img=url?`<img src="${esc(url)}" alt="" loading="lazy" onerror="this.remove()">`:'';
  return `<span class="avatar ${cls}${url?' has-photo':''}">${esc(c.toUpperCase())}${img}</span>`}
function ring(pct,size=64,label){pct=Math.max(0,Math.min(100,R(pct)));const th=size>=64?9:7;return `<div class="ring2" style="width:${size}px;height:${size}px;--tp:${pct};--rin:${size/2-th}px"><b>${label??pct+'%'}</b></div>`}
/* Полосы Б/Ж/У показывают одно и то же — долю от цели, поэтому и цвет у
   них один. Три разных цвета были украшением: они спорили с красным и
   жёлтым, которыми в интерфейсе отмечено «внимание» и «тревога».
   Цвет здесь означает ровно одно: норма или перебор. */
function macroCol(cur,tg){return (tg&&cur/tg>1.05)?'var(--warn)':'var(--mp)'}
function macroBars(cur,tg){const rows=[['Белки',cur.protein,tg.protein,macroCol(cur.protein,tg.protein)],['Жиры',cur.fat,tg.fat,macroCol(cur.fat,tg.fat)],['Углеводы',cur.carbs,tg.carbs,macroCol(cur.carbs,tg.carbs)]];return `<div class="mbars">${rows.map(([l,c,t,col])=>`<div class="mbar"><span class="ml">${l}</span><span class="mt"><i style="width:100%;transform:scaleX(${t?Math.min(1,c/t):0});background:${col}"></i></span><span class="mv num">${R(c)} <em>/ ${R(t)||'—'} г</em></span></div>`).join('')}</div>`}
function pill(text,tone=''){return `<span class="tag2 ${tone}">${esc(text)}</span>`}
function activityLabel(ts){if(!ts)return 'нет активности';const d=Math.floor((Date.now()-new Date(ts.replace(' ','T')+'Z').getTime())/86400000);if(d<=0)return 'Сегодня';if(d===1)return 'Вчера';return d+' дн. назад'}
/* «Ещё» — обычный экран, поэтому «назад» просто открывает его. */
function spBackToMore(){spMore()}
function clBackToMore(){clMore()}
function navBar(title,back,right){
  /* NavBar приложения: заголовок по центру, «назад» слева, действие справа.
     Крупный заголовок остаётся только на двух корневых экранах — «Сегодня»
     и «Главная», как в приложении. */
  return `<div class="navbar"><button class="nb-back" onclick="${back||'history.back()'}" aria-label="Назад">${icon('back')}</button><h2>${esc(title||'')}</h2><div class="nb-right">${right||''}</div></div>`}
function agoLabel(ts){
  /* Один в один с ago() приложения: сервер отдаёт время по Гринвичу без
     пометки, иначе браузер прочитает его как местное и всё уедет в будущее. */
  if(!ts)return '—';
  const d=new Date(String(ts).replace(' ','T')+(/[Zz+]/.test(ts)?'':'Z'));
  if(isNaN(+d))return '—';
  const min=Math.floor((Date.now()-+d)/60000);
  if(min<1)return 'только что';
  if(min<60)return min+' '+plural(min,['минуту','минуты','минут'])+' назад';
  const h=Math.floor(min/60);
  if(h<24)return h+' '+plural(h,['час','часа','часов'])+' назад';
  const days=Math.floor(h/24);
  if(days===1)return 'вчера';
  if(days<7)return days+' '+plural(days,['день','дня','дней'])+' назад';
  return d.toLocaleDateString('ru-RU',{day:'numeric',month:'long'});
}
function timeShort(ts){if(!ts)return '';const d=new Date(/[TZ]/.test(ts)?ts:ts.replace(' ','T')+'Z'),now=new Date();if(isNaN(d))return '';if(d.toDateString()===now.toDateString())return ('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2);if(Math.floor((now-d)/86400000)===1)return 'Вчера';return ('0'+d.getDate()).slice(-2)+'.'+('0'+(d.getMonth()+1)).slice(-2)}

/* ---------- auth ---------- */
/* Логотип EQUA вектором прямо в разметке: буквы наследуют currentColor,
   поэтому в тёмной теме он белый, в светлой — тёмный, без второго файла.
   Зелёный штрих в «Q» по брендбуку не меняется никогда. */
const LOGO_WORD='M5950 4484 c-469 -43 -824 -151 -1155 -354 -520 -319 -878 -783 -1010 -1310 -82 -330 -70 -736 31 -1039 50 -151 149 -348 239 -476 111 -157 323 -365 480 -471 353 -238 667 -356 1130 -425 143 -22 630 -19 770 5 61 10 113 20 117 22 9 6 -41 74 -207 284 -66 84 -143 183 -172 219 -153 195 -154 196 -208 199 -153 7 -338 43 -460 89 -435 161 -696 464 -769 892 -52 304 22 647 192 891 156 226 341 380 598 497 203 94 392 128 659 120 199 -6 289 -20 438 -68 412 -132 709 -442 818 -854 30 -113 32 -130 33 -305 1 -201 -16 -314 -70 -456 l-25 -66 98 -115 c54 -63 109 -129 122 -147 14 -17 52 -62 86 -101 33 -38 114 -134 180 -212 65 -79 121 -143 125 -143 12 0 88 86 151 170 358 475 452 1110 254 1716 -60 183 -167 381 -305 564 -200 263 -495 494 -823 642 -352 159 -656 225 -1067 232 -113 2 -225 2 -250 0z M8862 4372 c-17 -11 -19 -2371 -2 -2527 45 -419 251 -767 600 -1014 118 -84 173 -115 327 -185 193 -88 368 -138 653 -186 162 -28 573 -39 771 -21 297 28 595 105 845 219 481 220 777 562 893 1032 48 195 51 297 51 1534 l0 1155 -533 1 -534 0 -6 -712 c-4 -392 -7 -902 -7 -1133 0 -545 -10 -632 -85 -788 -96 -199 -298 -355 -567 -436 -250 -76 -578 -65 -812 29 -232 92 -409 263 -485 470 -46 126 -45 85 -51 1355 l-5 1210 -520 2 c-286 2 -526 -1 -533 -5z M14953 4373 c-16 -3 -39 -35 -84 -116 -34 -62 -83 -150 -109 -197 -26 -47 -76 -137 -110 -200 -35 -63 -99 -180 -143 -260 -44 -80 -121 -221 -172 -315 -51 -93 -134 -246 -185 -340 -51 -93 -123 -226 -160 -295 -37 -69 -95 -177 -130 -240 -241 -444 -980 -1834 -980 -1844 0 -3 268 -5 596 -4 l595 3 149 280 149 280 1055 3 1055 2 26 -47 c14 -27 81 -154 149 -283 l123 -235 606 -3 c482 -2 607 0 607 10 0 15 -129 288 -390 823 -351 720 -1299 2593 -1451 2866 l-59 106 -77 7 c-82 7 -1024 6 -1060 -1z m616 -1245 c43 -90 168 -345 276 -568 332 -682 345 -708 345 -719 0 -8 -214 -11 -730 -11 -401 0 -730 2 -730 5 0 6 460 907 470 920 4 6 67 128 140 273 72 144 136 262 141 262 5 0 45 -73 88 -162z M63 4363 l-23 -4 0 -1894 0 -1893 63 -6 c78 -7 3447 -7 3505 1 l42 5 0 418 0 418 -42 6 c-24 3 -439 6 -923 5 -484 0 -1048 0 -1252 1 l-373 0 0 305 0 305 918 2 c504 1 960 1 1013 -1 53 -2 111 0 128 4 l31 7 0 429 0 429 -1042 2 -1043 3 -3 293 -2 292 1230 0 1230 0 0 440 0 440 -1717 -1 c-945 -1 -1728 -4 -1740 -6z';
const LOGO_MARK='M5746 2190 c-58 -7 -85 -37 -86 -92 0 -45 12 -60 309 -423 117 -143 246 -300 286 -350 40 -49 198 -243 351 -430 347 -425 475 -582 578 -712 47 -59 96 -109 116 -120 32 -17 77 -18 593 -21 l557 -2 0 23 c0 13 -23 51 -52 88 -197 244 -397 486 -807 978 -90 108 -240 288 -334 401 -94 113 -191 229 -216 259 -25 30 -66 79 -90 110 -24 31 -63 77 -85 102 -23 25 -61 70 -85 99 -77 92 -65 90 -558 94 -235 1 -450 0 -477 -4z';
function logoSvg(cls){return `<svg class="logo ${cls||''}" viewBox="0 0 1803 453" role="img" aria-label="EQUA">`+
  `<g transform="translate(0,453) scale(0.1,-0.1)"><path fill="currentColor" d="${LOGO_WORD}"/>`+
  `<path fill="#2E7D63" d="${LOGO_MARK}"/></g></svg>`}

/* --- Вход через Apple, Google и VK ------------------------------------
   Кнопку показываем только если сервер сказал, что провайдер настроен:
   ключи заполняются в config/oauth.php, и до этого кнопке делать нечего. */
const OAUTH_TITLE={apple:'Продолжить с Apple',google:'Продолжить с Google',vk:'Продолжить с VK'};
const OAUTH_MARK={
  apple:'<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M16.4 12.6c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.5-.2-2.8.8-3.6.8-.7 0-1.9-.8-3.1-.8-1.6 0-3 .9-3.8 2.3-1.6 2.8-.4 7 1.2 9.3.8 1.1 1.7 2.4 2.9 2.3 1.2 0 1.6-.7 3-.7s1.8.7 3 .7c1.3 0 2.1-1.1 2.8-2.2.9-1.3 1.3-2.6 1.3-2.6s-2.4-.9-2.3-3.8ZM14 5.9c.6-.8 1.1-1.9 1-3-1 0-2.1.6-2.8 1.4-.6.7-1.1 1.8-1 2.9 1.1.1 2.2-.5 2.8-1.3Z"/></svg>',
  google:'<svg viewBox="0 0 48 48" width="17" height="17"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.6l6.7-6.7C35.6 2.6 30.2.5 24 .5 14.6.5 6.5 5.9 2.6 13.7l7.8 6.1C12.3 14 17.6 9.5 24 9.5Z"/><path fill="#4285F4" d="M46.6 24.6c0-1.6-.1-3.1-.4-4.6H24v9.1h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.2-10.1 7.2-17.5Z"/><path fill="#FBBC05" d="M10.4 28.6c-.5-1.5-.8-3-.8-4.6s.3-3.1.8-4.6l-7.8-6.1C.9 16.5 0 20.1 0 24s.9 7.5 2.6 10.7l7.8-6.1Z"/><path fill="#34A853" d="M24 47.5c6.2 0 11.5-2 15.4-5.6l-7.5-5.8c-2.1 1.4-4.8 2.2-7.9 2.2-6.4 0-11.7-4.5-13.6-10.3l-7.8 6.1C6.5 42.1 14.6 47.5 24 47.5Z"/></svg>',
  vk:'<svg viewBox="0 0 24 24" width="19" height="19"><path fill="currentColor" d="M12.9 17.3c-5.4 0-8.7-3.8-8.8-10h2.7c.1 4.6 2.2 6.5 3.8 6.9V7.3h2.6v3.9c1.6-.2 3.3-2 3.9-3.9h2.5c-.4 2.3-2.1 4.1-3.3 4.8 1.2.6 3.1 2.2 3.9 5.2h-2.8c-.6-1.9-2.1-3.4-4.2-3.6v3.6h-.3Z"/></svg>'};
async function renderOauth(){
  const box=$('#oauth');if(!box)return;
  let list=[];try{list=(await api('/auth/providers')).providers||[]}catch(e){}
  if(!list.length)return;
  box.innerHTML=`<div class="oauth-sep"><i></i><span>или</span><i></i></div>`+
    list.map(p=>`<a class="oauth-btn" href="/api/v1/auth/oauth/${p}/start?target=web">${OAUTH_MARK[p]||''}<span>${OAUTH_TITLE[p]||p}</span></a>`).join('');
}
/* Сервер возвращает пользователя со своим токеном в адресе — забираем его
   и сразу вычищаем строку, чтобы токен не остался в истории браузера. */
function pickupOauthReturn(){
  const q=new URLSearchParams(location.search);
  const t=q.get('token'),e=q.get('auth_error'),r=q.get('reset');
  if(t)saveAuth({token:t,user_type:q.get('user_type')||'client'});
  if(e)A._authError=e;
  /* Ссылка из письма о пароле: код тоже убираем из адреса. */
  if(r)A._resetToken=r;
  if(t||e||r)history.replaceState(null,'',location.pathname);
}

/* Ссылки на документы под кнопками входа и регистрации: без них нельзя
   ни в App Store, ни по закону о персональных данных. */
function legalNote(){return `<p class="legal-note">Продолжая, вы соглашаетесь с <a href="/terms" target="_blank" rel="noopener">условиями использования</a> и <a href="/privacy" target="_blank" rel="noopener">политикой конфиденциальности</a>, включая обработку данных о здоровье.</p>`}

/* Оболочка входа и регистрации по AuthShell приложения: кадр с листьями и
   белый логотип сверху, ниже тёмный лист с формой. Экран одинаков в обеих
   темах — снимок тёмный, и тёмная надпись на нём не читалась бы. */
function authShell(body,back){
  return `<div class="auth2"><div class="auth2-photo">
    <div class="auth2-brand">${logoSvg('auth2-logo')}<span>ПИТАНИЕ<br>ДВИЖЕНИЕ<br>РЕЗУЛЬТАТ</span></div>
    ${back?`<button class="auth2-back" onclick="${back}" aria-label="Назад">${icon('back')}</button>`:''}
  </div><div class="auth2-sheet">${body}</div></div>`}
/* Поле с иконкой слева — как Field в приложении. */
function authField(ic,inner){return `<div class="auth2-field">${icon(ic)}${inner}</div>`}
function login(){go(authShell(`<h1 class="auth2-h1">Вход в аккаунт</h1>
<form onsubmit="doLogin(event)">
${authField('mail','<input id="email" type="email" placeholder="Почта" value="demo@nutrimenu.local" required>')}
${authField('lock','<input id="pass" type="password" placeholder="Пароль" value="password" required>')}
<div id="err"></div>
<button class="auth2-btn">Войти</button></form>
<button class="auth2-link" onclick="forgotForm()">Забыли пароль?</button>
<div id="oauth"></div>
<div class="auth2-foot">Нет аккаунта? <button class="auth2-accent" onclick="registerChoice()">Создать</button></div>
${legalNote()}
<div class="demo">Демо-специалист: demo@nutrimenu.local · password &nbsp;·&nbsp; Клиент: anna@demo.local · password</div>`));
  if(A._authError){$('#err').innerHTML=`<div class="error">${esc(A._authError)}</div>`;A._authError=null}
  renderOauth()}
/* Регистрация в два шага: сперва кто вы, потом своя анкета.
   Раньше форма заводила только специалиста, а клиента мог создать
   лишь он сам — прийти в сервис самостоятельно было нельзя. */
/* Роль выбирают один раз — на registerChoice. Раньше отсюда открывался
   второй такой же выбор, и «Я специалист» приходилось нажимать дважды. */
function registerForm(){regSpecForm()}
function pickWho(r){A._regRole=r;r==='client'?regClientForm():regSpecForm()}
function regSpecForm(){A._regProf='nutritionist';
  go(authShell(`<h1 class="auth2-h1">Создать рабочее пространство</h1>
<form onsubmit="doRegister(event)">
<div class="auth2-label">Кто вы?</div>
<div class="chip-row auth2-chips" id="rolepick">${[['nutritionist','Нутрициолог'],['trainer','Тренер'],['coach','Коуч']].map(([k,l])=>`<button type="button" class="chip ${k==='nutritionist'?'active':''}" data-r="${k}" onclick="pickRole('${k}')">${l}</button>`).join('')}</div>
${authField('user','<input id="rname" placeholder="Имя" required>')}
${authField('mail','<input id="remail" type="email" placeholder="Почта" required>')}
${authField('lock','<input id="rpass" type="password" placeholder="Пароль, от 8 знаков" minlength="8" required>')}
<div id="err"></div>
<button class="auth2-btn">Начать бесплатно</button></form>
<p class="auth2-note small">Фото профиля можно добавить позже в настройках.</p>`,"registerChoice()"))}
function regClientForm(){
  go(authShell(`<h1 class="auth2-h1">Анкета клиента</h1>
<p class="auth2-note">По ней посчитаем предварительную норму — специалист потом уточнит.</p>
<form onsubmit="doRegister(event)">
${authField('user','<input id="rname" placeholder="Имя" required>')}
${authField('mail','<input id="remail" type="email" placeholder="Почта" required>')}
${authField('lock','<input id="rpass" type="password" placeholder="Пароль, от 8 знаков" minlength="8" required>')}
<div class="auth2-grid">
  <label>Пол<select id="rsex"><option value="f">Женский</option><option value="m">Мужской</option></select></label>
  <label>Возраст<input id="rage" type="number" min="10" max="99"></label>
  <label>Рост, см<input id="rheight" type="number" min="100" max="230"></label>
  <label>Вес, кг<input id="rweight" type="number" step="0.1" min="30" max="300"></label>
</div>
<label class="auth2-sel">Цель<select id="rgoal"><option>Снижение веса</option><option>Поддержание</option><option>Набор массы</option><option>Здоровье и энергия</option></select></label>
<label class="auth2-sel">Сколько двигаетесь<select id="ract"><option value="low">Сидячий образ</option><option value="light">1–2 тренировки в неделю</option><option value="medium" selected>3–4 тренировки в неделю</option><option value="high">5–6 тренировок в неделю</option><option value="athlete">Спорт каждый день</option></select></label>
<div id="err"></div>
<button class="auth2-btn">Создать аккаунт</button></form>
${legalNote()}`,"registerChoice()"))}
/* Забыли пароль. Ответ сервера одинаков для любого адреса, поэтому и
   экран показываем один: «письмо в пути» — без намёка, есть ли аккаунт. */
function forgotForm(){
  go(authShell(`<h1 class="auth2-h1">Забыли пароль?</h1>
<p class="auth2-note">Пришлём на почту ссылку, по которой можно задать новый.</p>
<form onsubmit="doForgot(event)">
${authField('mail','<input id="fg_email" type="email" placeholder="Почта" required>')}
<div id="err"></div>
<button class="auth2-btn">Прислать ссылку</button></form>`,"login()"))}
async function doForgot(e){e.preventDefault();
  const b=e.target.querySelector('button');b.disabled=true;b.textContent='Отправляем…';
  try{const j=await api('/auth/forgot',{method:'POST',body:JSON.stringify({email:$('#fg_email').value})});
    go(authShell(`<h1 class="auth2-h1">Проверьте почту</h1><p class="auth2-note">${esc(j.message||'')}</p><button class="auth2-btn" onclick="login()">Вернуться ко входу</button>`))}
  catch(x){b.disabled=false;b.textContent='Прислать ссылку';$('#err').innerHTML=`<div class="error">${esc(x.message)}</div>`}}

/* Экран из письма. Ссылку проверяем до формы: истёкшую честнее
   объяснить сразу, чем после придуманного пароля. */
async function resetForm(t){
  A._resetToken=t;
  try{await api('/auth/reset/'+encodeURIComponent(t))}
  catch(x){return go(authShell(`<h1 class="auth2-h1">Ссылка не работает</h1><p class="auth2-note">${esc(x.message)}</p><button class="auth2-btn" onclick="forgotForm()">Прислать новую</button>`))}
  go(authShell(`<h1 class="auth2-h1">Новый пароль</h1><p class="auth2-note">От 8 символов, с буквой и цифрой. Прежние входы на других устройствах закроются.</p><form onsubmit="doReset(event)"><label>Пароль<input id="rs_pass" type="password" minlength="8" required></label><div id="err"></div><button class="auth2-btn">Сохранить и войти</button></form>`))}
async function doReset(e){e.preventDefault();
  try{const j=await api('/auth/reset',{method:'POST',body:JSON.stringify({token:A._resetToken,password:$('#rs_pass').value})});
    A._resetToken=null;saveAuth(j);route()}
  catch(x){$('#err').innerHTML=`<div class="error">${esc(x.message)}</div>`}}

function pickRole(r){A._regProf=r;document.querySelectorAll('#rolepick .role-opt').forEach(b=>b.classList.toggle('active',b.dataset.r===r))}
async function doLogin(e){
  e.preventDefault();
  const email=$('#email').value, pass=$('#pass').value;
  try{
    const j=await api('/auth/login',{method:'POST',body:JSON.stringify({email,password:pass})});
    /* У панели может быть включён вход по коду: токена ещё нет, сначала
       письмо. Пароль держим в памяти вкладки — второй шаг проверяет его
       заново, чтобы код сам по себе входа не давал. */
    if(j.need_code){ A._twofa={email,pass}; loginCode(j.message||''); return }
    saveAuth(j); route();
  }catch(x){ $('#err').innerHTML=`<div class="error">${esc(x.message)}</div>` }
}
/* Экран ввода кода. Отдельный, а не поле в той же форме: человек уходит
   в почту и возвращается, и форма с паролем к этому моменту уже лишняя. */
function loginCode(msg){
  go(authShell(`<h1 class="auth2-h1">Код из письма</h1>
<p class="auth2-note">${esc(msg||'Мы отправили код на вашу почту.')}</p>
<form onsubmit="doLoginCode(event)">
${authField('lock','<input id="tf_code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="000000" required>')}
<div id="err"></div>
<button class="auth2-btn">Войти</button></form>
<p class="auth2-note small">Письмо не пришло — проверьте папку «Спам».
  Код живёт десять минут, после этого войдите заново.</p>`,"A._twofa=null;login()"));
  const f=$('#tf_code'); if(f)f.focus();
}
async function doLoginCode(e){
  e.preventDefault();
  const t=A._twofa||{};
  try{
    const j=await api('/auth/login/code',{method:'POST',body:JSON.stringify({
      email:t.email,password:t.pass,code:$('#tf_code').value})});
    A._twofa=null; saveAuth(j); route();
  }catch(x){ $('#err').innerHTML=`<div class="error">${esc(x.message)}</div>` }
}
async function doRegister(e){e.preventDefault();const base={name:$('#rname').value,email:$('#remail').value,password:$('#rpass').value,source:signupSource()};let body;
 if(A._regRole==='client'){const num=id=>{const v=+($(id)?.value||0);return v>0?v:null};body={...base,role:'client',profile:{sex:$('#rsex')?.value||'f',age:num('#rage'),height_cm:num('#rheight'),weight_kg:num('#rweight'),activity_level:$('#ract')?.value||'medium',goal:$('#rgoal')?.value||''}};}
 else body={...base,role:'specialist',profession:A._regProf||'nutritionist'};
 try{const j=await api('/auth/register',{method:'POST',body:JSON.stringify(body)});saveAuth(j);route()}catch(x){$('#err').innerHTML=`<div class="error">${esc(x.message)}</div>`}}
function saveAuth(j){A.token=j.token;A.type=j.user_type;localStorage.nm_token=A.token;localStorage.nm_type=A.type}
/* Удаление аккаунта — из интерфейса, а не письмом в поддержку. Спрашиваем
   дважды: второй вопрос требует набрать слово, потому что отменить нельзя. */
async function deleteAccount(role){
  const what=role==='client'
    ? 'Исчезнут анкета, дневник питания, вес и замеры, фотографии прогресса и переписка со специалистом.'
    : 'Исчезнут ваш профиль, шаблоны меню и услуги. Клиенты останутся со своими данными, но без специалиста.';
  if(!confirm('Удалить аккаунт?\n\n'+what+'\n\nВосстановить будет нельзя.'))return;
  const word=prompt('Наберите УДАЛИТЬ, чтобы подтвердить');
  if((word||'').trim().toUpperCase()!=='УДАЛИТЬ')return;
  try{await api('/'+role+'/account',{method:'DELETE'});logout()}
  catch(e){toast(e.message,'err')}
}

function logout(){localStorage.removeItem('nm_token');localStorage.removeItem('nm_type');A.token='';A.user=null;login()}
const PROF={nutritionist:'Нутрициолог',trainer:'Тренер',coach:'Коуч'};
function profOf(){return A.user?.profession||'nutritionist'}
function clientsTitle(){return profOf()==='trainer'?'Подопечные':'Клиенты'}
function clientAcc(){return profOf()==='trainer'?'подопечного':'клиента'}
function catalogWord(){return profOf()==='trainer'?'тренеров':profOf()==='coach'?'коучей':'нутрициологов'}
function clientNom(){return profOf()==='trainer'?'подопечный':'клиент'}

/* ======================================================================
   SPECIALIST
   ====================================================================== */
/* Непрочитанные сообщения в навигации.
   Раньше в разметке бокового меню стояла цифра 12 — она была вписана
   руками при вёрстке и не двигалась никогда: ни когда сообщения
   приходили, ни когда их читали. Считаем по тем же данным, которые
   экраны и так загружают, и обновляем значок на месте, не перерисовывая
   весь экран. */
function unreadOf(cs){return (cs||[]).reduce((s,c)=>s+(+c.unread||0),0)}
function setUnread(n){
  A.unread=Math.max(0,n|0);
  document.querySelectorAll('[data-nav="chat"]').forEach(btn=>{
    let el=btn.querySelector('.nav-badge');
    if(!A.unread){if(el)el.remove();return}
    if(!el){
      el=document.createElement(btn.classList.contains('pill-item')?'i':'b');
      el.className='nav-badge'+(btn.classList.contains('pill-item')?' num':'');
      btn.appendChild(el);
    }
    el.textContent=A.unread>99?'99+':A.unread;
  });
}
function spShell(body,active){const nav=[['home','Главная',"spHome()"],['clients',clientsTitle(),"spClients()"],['dishes','База блюд',"spDishes()"],['templates','Шаблоны',"spTemplates()"],['chat','Чат',"spChatList()",A.unread||0],['analytics','Аналитика',"spAnalytics()"],['more','Ещё',"spMore()"]];
return `<div class="shell"><div class="layout"><aside class="side"><div class="side-top"><div class="brand side-logo">${logoSvg("side-logo-svg")}</div></div><nav class="nav">${nav.map(([ic,l,fn,b])=>`<button class="${active===ic||(ic==='more'&&active==='settings')?'active':''}" data-nav="${ic}" onclick="${fn}">${icon(ic==='clients'?'users':ic==='dishes'?'bowl':ic==='templates'?'layers':ic==='ingredients'?'carrot':ic==='analytics'?'chart':ic==='settings'?'cog':ic==='more'?'kebab':ic)}<span>${l}</span>${b?`<b class="nav-badge">${b}</b>`:''}</button>`).join('')}</nav><button class="side-user" onclick="spProfile()">${av(A.user?.name||'М','sm',A.user?.avatar_url)}<div><strong>${esc(A.user?.name||'Специалист')}</strong><span>${PROF[profOf()]}</span></div>${icon('chevd')}</button></aside><main class="main">${body}</main></div><nav class="bottom pillnav"><button class="pill-item ${active==='home'?'active':''}" onclick="spHome()">${icon('home')}<span>Главная</span></button><button class="pill-item ${active==='clients'?'active':''}" onclick="spClients()">${icon('users')}<span>${clientsTitle()}</span></button><button class="pill-item ${active==='chat'?'active':''}" data-nav="chat" onclick="spChatList()">${icon('chat')}<span>Чат</span>${A.unread?`<i class="nav-badge num">${A.unread>99?'99+':A.unread}</i>`:''}</button><button class="pill-item ${['dishes','templates','analytics','settings','more'].includes(active)?'active':''}" onclick="spMore()">${icon('kebab')}<span>Ещё</span></button></nav><!-- Кнопка создания стоит рядом с панелью, а не внутри неё: панель
     размывает фон, а элемент с backdrop-filter задаёт своим
     потомкам с position:fixed новую систему координат — кнопка
     съезжала внутрь панели и накрывала последний пункт. --><button class="nav-fab" onclick="spQuickAdd()" aria-label="Создать">${icon('plus')}</button></div>`}

async function spHome(){const d=await api('/specialist/dashboard');const msgN=d.unread_messages;A.unread=msgN|0;let leads=[];try{leads=(await api('/specialist/leads')).leads}catch(e){}const newLeads=leads.filter(l=>!l.read_at);const _h=new Date().getHours();const _greet=_h<5?'Доброй ночи':_h<12?'Доброе утро':_h<18?'Добрый день':'Добрый вечер';const _nm=(A.user?.name||'').split(' ')[0];
const plan=[];
if(msgN)plan.push(['info','chat',`${msgN} ${plural(msgN,['сообщение','сообщения','сообщений'])} без ответа`,'Ответить','spChatList()']);
if(newLeads.length)plan.push(['good','gift',`${newLeads.length} ${plural(newLeads.length,['новая заявка','новые заявки','новых заявок'])} из каталога`,'Смотреть','spNotifications()']);
const needMenu=(d.no_menu||0)+(d.menus_ending||0);
if(needMenu)plan.push(['warm','menu',`${needMenu} ${plural(needMenu,['клиенту нужно','клиентам нужно','клиентам нужно'])} меню`,'Открыть',"spClients()"]);
if(d.attention.length)plan.push(['crit','flame',`${d.attention.length} ${plural(d.attention.length,['клиент требует','клиента требуют','клиентов требуют'])} внимания`,'Показать',"spClients('attention')"]);
go(spShell(`<div class="scr-head"><div class="greet"><div><p class="muted eyebrow-date">${new Date().toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long'})}</p><h1>${_greet}${_nm?', '+esc(_nm):''}</h1></div></div><div class="head-icons"><button class="icon-circle" aria-label="Уведомления" onclick="spNotifications()">${icon('bell')}</button><button class="head-av" onclick="spProfile()">${av(A.user?.name||'N','',A.user?.avatar_url)}</button></div></div>
<div class="dash-top"><div class="today-plan"><div class="tp-head"><h2>План на сегодня</h2>${plan.length?`<span class="tp-count">${plan.length} ${plural(plan.length,['задача','задачи','задач'])}</span>`:''}</div>${plan.length?`<div class="plan-list">${plan.map(([cl,ic,txt,btn,fn])=>`<button class="plan-row" onclick="${fn}"><span class="plan-ic ${cl}">${icon(ic)}</span><span class="plan-txt">${txt}</span><span class="plan-btn">${btn}${icon('chevr')}</span></button>`).join('')}</div>`:`<div class="plan-clear"><span class="plan-ic good">${icon('check')}</span><div><b>Всё под контролем</b><span>На сегодня срочных задач нет — можно заняться меню</span></div></div>`}</div>
<div class="stat-grid">
  <div class="stat card ${d.attention.length?'crit':''}"><div class="stat-ic crit">${icon('bell')}</div><div><b class="num">${d.attention.length}</b><span>Требуют внимания</span></div></div>
  <button class="stat card" onclick="spChatList()"><div class="stat-ic info">${icon('chat')}</div><div><b class="num">${msgN}</b><span>Новые сообщения</span></div></button>
  <div class="stat card"><div class="ring-wrap">${ring(d.avg_adherence??0,52,(d.avg_adherence==null?'—':d.avg_adherence+'%'))}</div><div><b class="num">${d.avg_adherence==null?'—':d.avg_adherence+'%'}</b><span>Средняя приверженность</span></div></div>
  <div class="stat card"><div class="stat-ic good">${icon('trend')}</div><div><b class="num">${d.avg_weight_delta==null?'—':(d.avg_weight_delta>0?'+':'')+kg(d.avg_weight_delta)+' кг'}</b><span>Динамика веса · 30 дней</span></div></div>
</div></div>
<div class="panel-title"><h2>Требуют внимания</h2><button class="link" onclick="spClients('attention')">Смотреть все</button></div>
<div class="attention-list">${d.attention.length?d.attention.map(c=>{const r=c.reasons[0]||'';const sev=/сообщ/i.test(r)?'msg':/вес/i.test(r)?'weight':'meal';const ic=sev==='msg'?'chat':sev==='weight'?'trend':'flame';const st=sev==='msg'?'st-online':'st-attention';return `<div class="attention-card sev-${sev}" onclick="spClient(${c.id})">${av(c.name,'sm '+st,c.avatar_url)}<div class="grow"><strong>${esc(c.name)}</strong><span class="att-reason ${sev}">${icon(ic)}<em>${esc(r)}</em></span></div><div class="att-actions"><button class="att-act" title="Написать" onclick="event.stopPropagation();spClient(${c.id},'chat')">${icon('chat')}</button></div><small class="att-when">${activityLabel(c.last_meal)}</small></div>`}).join(''):`<div class="empty small">Все клиенты активны 👌</div>`}</div>`,'home'));stagger($('.attention-list'));spPaintNotices()}

async function spClients(filter='all'){A.cpage=1;const j=await api('/specialist/clients');A.clientsCache=j.clients;A.unread=unreadOf(j.clients);const cs=j.clients;window.__spfilter=filter;const attn=cs.filter(c=>c.unread||(c.last_activity&&(Date.now()-new Date(c.last_activity.replace(' ','T')+'Z'))>1728e5)||!c.last_activity);const unread=cs.filter(c=>c.unread);
go(spShell(`<div class="scr-head"><div><h1>${clientsTitle()}</h1></div><div class="head-icons"><button class="icon-circle" aria-label="Уведомления" onclick="spNotifications()">${icon('bell')}</button><button class="icon-circle" aria-label="Чат с клиентами" onclick="spChatList()">${icon('chat')}${unread.length?`<i class="cbadge">${unread.length}</i>`:''}</button><button class="primary green" onclick="clientModal()">${icon('plus')}<span>Добавить ${clientAcc()}</span></button></div></div>
<div class="clients-grid">
 <section class="col-main">
  <div class="search-line"><div class="searchbox">${icon('search')}<input id="cq" placeholder="Поиск ${clientAcc()}…" oninput="spFilterClients()"></div></div>
  <div class="filter-row" id="cfilters">${[['all','Все '+clientsTitle().toLowerCase(),cs.length],['attention','Требуют внимания',attn.length],['unread','Новые сообщения',unread.length],['inactive','Без активности',cs.filter(c=>!c.last_activity).length]].map(([k,l,n])=>`<button class="filter-pill ${filter===k?'active':''}" onclick="spClients('${k}')"><span class="fp-label">${l}</span><b>${n}</b>${icon('chevd')}</button>`).join('')}</div>
  <div id="clientlist" class="client-list"></div>
  <div class="listrow"><div class="listfoot muted" id="listfoot"></div><div class="pager" id="pager"></div></div>
 </section>
 <aside class="col-side">
  <div class="quick card"><div class="quick-ic crit">${icon('bell')}</div><div class="quick-b"><b class="num">${attn.length}</b><span>Требуют внимания</span></div><button class="secondary sm" onclick="spClients('attention')">Показать</button></div>
  <div class="quick card"><div class="quick-ic info">${icon('chat')}</div><div class="quick-b"><b class="num">${unread.length}</b><span>Новые сообщения</span></div><button class="secondary sm" onclick="spChatList()">Открыть чат</button></div>
  <div class="quick-cta card"><div class="quick-ic soft">${icon('layers')}</div><strong>Создавайте меню быстрее</strong><p>Используйте шаблоны и копирование дней, чтобы экономить время.</p><button class="secondary sm" onclick="spTemplates()">Перейти к шаблонам</button></div>
 </aside>
</div>`,'clients'));spRenderClients();spPaintNotices()}
function spFilterClients(){A.cpage=1;spRenderClients()}
function pageControls(cur,pages){const out=[];for(let i=1;i<=pages;i++)if(i===1||i===pages||Math.abs(i-cur)<=1)out.push(i);let html='',prev=0;out.forEach(i=>{if(i-prev>1)html+='<span class="pg-dots">…</span>';html+=`<button class="pg ${i===cur?'on':''}" onclick="A.cpage=${i};spRenderClients()">${i}</button>`;prev=i});return html}
function spRenderClients(){let cs=A.clientsCache||[];const f=window.__spfilter||'all';const q=($('#cq')?.value||'').toLowerCase();if(f==='attention')cs=cs.filter(c=>c.unread||!c.last_activity||(Date.now()-new Date(c.last_activity.replace(' ','T')+'Z'))>1728e5);if(f==='unread')cs=cs.filter(c=>c.unread);if(f==='inactive')cs=cs.filter(c=>!c.last_activity);if(q)cs=cs.filter(c=>(c.name||'').toLowerCase().includes(q));const per=8,total=cs.length,pages=Math.max(1,Math.ceil(total/per));if(!A.cpage||A.cpage>pages)A.cpage=1;const page=A.cpage,slice=cs.slice((page-1)*per,page*per);if($('#listfoot'))$('#listfoot').textContent=`Показано ${slice.length} из ${total}`;$('#clientlist').innerHTML=slice.length?slice.map(c=>{
  /* Карточка как Row в приложении: имя и цель сверху, три метки снизу.
     Прежняя однострочная запись сжимала имя до многоточия ради кольца,
     которое в половине случаев показывало прочерк. */
  /* «Отметки» показывают, сколько приёмов из плана клиент вообще отметил.
     Раньше здесь стояла доля съеденного среди отмеченных, и человек,
     отметивший один приём из двадцати пяти, показывал 100 %. */
  const mk=c.marked_pct;
  const marked=c.planned7?`${c.logged7||0} из ${c.planned7}`:'—';
  const mtone=mk==null?'':mk>=70?'g':mk>=35?'a':'r';
  const sub=[c.goal,c.weight_kg?kg(c.weight_kg)+' кг':null].filter(Boolean).join(' · ')||'—';
  const tag=(l,v,tone)=>`<div class="cc-tag${tone?' t-'+tone:''}"><i>${l}</i><span>${esc(v)}</span></div>`;
  return `<button class="client-card" onclick="spClient(${c.id})">
    <div class="cc-top">${av(c.name,'',c.avatar_url)}<div class="grow"><strong>${esc(c.name)}${c.streak>=2?`<i class="streak-mini" title="${c.streak} ${plural(c.streak,['день','дня','дней'])} подряд">${icon('flame')}${c.streak}</i>`:''}</strong><span class="muted">${esc(sub)}</span></div>${c.unread?`<b class="cc-unread">${c.unread}</b>`:''}${icon('chevr')}</div>
    <div class="cc-tags">${tag('Меню',c.menu_status==='published'?'опубликовано':'нет')}${tag('Отметки',marked,mtone)}${tag('Заходил',agoLabel(c.last_activity))}</div>
  </button>`}).join(''):`<div class="empty small">Никого не найдено</div>`;
if($('#pager'))$('#pager').innerHTML=pages>1?pageControls(page,pages):'';stagger($('#clientlist'))}

function clientModal(){showModal(`<div class="sheet-head"><div><div class="eyebrow">Новый ${clientNom()}</div><h2>Добавить ${clientAcc()}</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><form onsubmit="saveClient(event)" class="formgrid"><label class="full">Имя<input id="cname" required placeholder="Анна Петрова"></label><label>Email<input id="cemail" type="email"></label><label>Телефон<input id="cphone"></label><label>Цель<input id="cgoal" placeholder="Снижение веса"></label><label>Ккал<input id="ckcal" type="number" value="1800"></label><label>Белки, г<input id="cp" type="number" value="110"></label><label>Жиры, г<input id="cf" type="number" value="60"></label><label>Углеводы, г<input id="cc" type="number" value="190"></label><button class="primary wide full">Создать ${clientNom()==="подопечный"?"подопечного":"клиента"}</button></form>`)}
async function saveClient(e){e.preventDefault();try{const j=await api('/specialist/clients',{method:'POST',body:JSON.stringify({name:$('#cname').value,email:$('#cemail').value,phone:$('#cphone').value,goal:$('#cgoal').value,target_kcal:+$('#ckcal').value,target_protein:+$('#cp').value,target_fat:+$('#cf').value,target_carbs:+$('#cc').value})});closeModal();showInvite(j.invite_url,j.invite_token);spClients()}catch(x){toast(x.message,'err')}}
function showInvite(url,token){showModal(`<div class="sheet-head"><div><div class="eyebrow">Готово</div><h2>Приглашение клиента</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><p class="lead">Передайте клиенту ссылку — при первом входе он задаст пароль.</p><div class="invitebox">${esc(url||location.origin+'/invite.html?token='+token)}</div><button class="primary wide" onclick="navigator.clipboard&&navigator.clipboard.writeText('${esc(url||'')}');this.textContent='Скопировано ✓'">Скопировать ссылку</button>`)}

/* ---- client detail with tabs ---- */
async function spClient(id,tab='overview'){
  /* Карточка клиента по образцу sp/Client.tsx: «назад» в шапке, аватар с
     именем и одной строкой примет, три компактных действия и пилюли
     вкладок. «Здоровье» и «Чат» в приложении — не вкладки, а действия:
     там они открываются отдельными экранами, и держать их в одном ряду
     с «Обзором» значит путать разделы карточки с переходами наружу. */
  const c=await api('/specialist/clients/'+id);A.client=c.client;A.clientSub=c.subscription||null;A.tab=tab;const cl=A.client;
  const age=cl.birth_year?(new Date().getFullYear()-cl.birth_year):null;
  /* Возраст, рост и вес специалист держит в голове при каждом разговоре —
     значит они принадлежат шапке, а не вкладке «Цели» в двух переходах
     отсюда. Цель ведёт строку: с неё начинается любой разбор. */
  const sub=[cl.goal,
             age?age+' '+plural(age,['год','года','лет']):null,
             cl.height_cm?cl.height_cm+' см':null,
             cl.weight_kg?kg(cl.weight_kg)+' кг':null].filter(Boolean).join(' · ')||'—';
  const tabs=[['overview','Обзор'],['menu','Меню'],['tasks','Задания'],['progress','Прогресс']];
  const act=(ic,label,fn)=>`<button class="cact" onclick="${fn}">${icon(ic)}<span>${label}</span></button>`;
  go(spShell(`${navBar('',"spClients()")}
<div class="chead"><span class="avatar xl">${esc((cl.name||'·').trim()[0].toUpperCase())}${cl.avatar_url?`<img src="${esc(cl.avatar_url)}" alt="" onerror="this.remove()">`:''}</span>
  <div class="grow"><h2>${esc(cl.name)}</h2><span class="muted">${esc(sub)}</span></div></div>
<div class="cacts">${act('chat','Написать',`spClient(${id},'chat')`)}${act('target','Цели',`spClient(${id},'profile')`)}${act('heart','Здоровье',`spClient(${id},'health')`)}</div>
<div class="chip-row ctabs">${tabs.map(([k,l])=>`<button class="chip ${tab===k?'active':''}" onclick="spClient(${id},'${k}')">${l}</button>`).join('')}</div>
${tab==='overview'?'<div id="ch-engage" class="ch-engage"></div>':''}
<div id="tabbody" class="tabbody">${skel(3)}</div>`,'clients'));
  /* Полоса вовлечённости относится к обзору: на «Меню» и «Заданиях» она
     занимала первый экран, отодвигая то, ради чего вкладку открыли. */
  if(tab==='overview')spPaintEngage(id);
  if(tab==='overview')spTabOverview();else if(tab==='menu')spTabMenu();
  else if(tab==='health')spTabHealth();else if(tab==='tasks')spTabTasks();
  else if(tab==='profile')spTabProfile();else if(tab==='progress')spTabProgress();
  else if(tab==='chat')spTabChat();else spTabActivity()}
/* ---------------------------------------------------------------
   Здоровье клиента: аллергии, препараты и БАДы, анализы, рекомендации.
   Специалист ведёт записи, клиент их только читает.
   --------------------------------------------------------------- */
const ALLERGY_KINDS={allergy:'Аллергия',intolerance:'Непереносимость',avoid:'Избегать'};
const MED_KINDS={medicine:'Препарат',supplement:'БАД',vitamin:'Витамин'};
/* Даты здесь важны всегда, время — никогда. */
function hDay(v){if(!v)return '';const d=new Date(String(v).replace(' ','T'));
  return isNaN(+d)?String(v):d.toLocaleDateString('ru-RU',{day:'numeric',month:'long',year:'numeric'})}
const today10=()=>new Date().toISOString().slice(0,10);

/* Своё здоровье клиент видит целиком, но не правит: записи ведёт
   специалист, иначе история рекомендаций перестанет быть историей. */
async function clHealth(){
  let h={allergies:[],meds:[],labs:[],recommendations:[]};
  try{h=await api('/client/health')}catch(e){}
  const empty=t=>`<div class="empty small">${t}</div>`;
  go(clShell(`${clHead('Здоровье','',"clProfile()")}
    <div class="health">
      ${foldCard('ch_alg','Аллергии',`
        <div class="h-list">${h.allergies.length?h.allergies.map(a=>`
          <div class="h-row"><div class="grow"><strong>${esc(a.title)}</strong>
            <span class="muted">${esc(ALLERGY_KINDS[a.kind]||a.kind)}${a.note?' · '+esc(a.note):''}</span></div></div>`).join('')
          :empty('Специалист пока не отметил аллергий')}</div>`,cnt(h.allergies.length,'нет'))}

      ${foldCard('ch_med','Препараты и БАДы',`
        <div class="h-list">${h.meds.length?h.meds.map(m=>{const act=!m.ended_on;return `
          <div class="h-row ${act?'':'done'}"><div class="grow"><strong>${esc(m.title)}</strong>
            <span class="muted">${[MED_KINDS[m.kind]||m.kind,m.dosage,m.schedule].filter(Boolean).map(esc).join(' · ')}</span>
            <span class="muted">${act?('принимаете'+(m.started_on?' с '+hDay(m.started_on):'')):'закончили '+hDay(m.ended_on)}</span></div></div>`}).join('')
          :empty('Пока ничего не добавлено')}</div>`,cnt(h.meds.length,'нет'))}

      ${foldCard('ch_lab','Анализы',`
        <div class="h-list">${h.labs.length?h.labs.map(l=>`
          <div class="h-row"><div class="grow"><strong>${esc(l.title)}</strong>
            <span class="muted">${hDay(l.taken_on||l.created_at)}</span></div>
            ${l.file_url?`<button class="linkbtn" onclick="hOpenLab('${esc(l.file_url)}','${esc(l.title)}')">Открыть</button>`:''}</div>`).join('')
          :empty('Анализы пока не добавлены')}</div>`,cnt(h.labs.length,'нет'))}

      ${foldCard('ch_rec','Рекомендации',`
        <div class="h-list">${h.recommendations.length?h.recommendations.map(r=>`
          <div class="h-row rec"><div class="grow"><p>${esc(r.body)}</p>
            <span class="muted">${hDay(r.created_at)}</span></div></div>`).join('')
          :empty('Рекомендаций пока нет')}</div>`,cnt(h.recommendations.length,'нет'))}
    </div>`,'more'));
}

/* Системное «файл не выбран» не говорит человеку ничего: показываем имя
   того, что он выбрал, прямо в поле. */
/* Подпись раздела: сколько внутри записей. Сворачивать разделы без этого
   бессмысленно — пришлось бы открывать каждый, чтобы узнать, пуст ли он. */
const cnt=(n,zero)=>n?n+' '+plural(n,['запись','записи','записей']):(zero||'пусто');
function hFileName(el){
  const lab=el.closest('.h-file'); if(!lab)return;
  const f=el.files&&el.files[0];
  lab.querySelector('span').textContent=f?f.name:'Прикрепить файл';
  lab.classList.toggle('on',!!f);
}
async function spTabHealth(){
  const id=A.client.id;
  let h={allergies:[],meds:[],labs:[],recommendations:[]};
  try{h=await api('/specialist/clients/'+id+'/health')}catch(e){}
  A._health=h;
  $('#tabbody').innerHTML=`<div class="health">
    ${foldCard('sh_alg','Аллергии и непереносимости',`
      <p class="muted small">Это ограничения по здоровью, а не вкусы: их учитывает подбор блюд.</p>
      <form class="h-add" onsubmit="hAddAllergy(event,${id})">
        <select id="h_akind">${Object.entries(ALLERGY_KINDS).map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select>
        <input id="h_atitle" placeholder="Например, арахис" required>
        <button class="primary">${icon('plus')}<span>Добавить</span></button>
      </form>
      <div class="h-list">${h.allergies.length?h.allergies.map(a=>`
        <div class="h-row"><div class="grow"><strong>${esc(a.title)}</strong>
          <span class="muted">${esc(ALLERGY_KINDS[a.kind]||a.kind)}${a.note?' · '+esc(a.note):''}</span></div>
          <button class="linkbtn danger" onclick="hDel('allergies',${a.id},${id})">Убрать</button></div>`).join('')
        :'<div class="empty small">Пока ничего</div>'}</div>
    `,cnt(h.allergies.length,'нет'))}

    ${foldCard('sh_med','Препараты, БАДы и витамины',`
      <p class="muted small">Курс не удаляют, а закрывают датой — история приёма остаётся.</p>
      <form class="h-add wrap" onsubmit="hAddMed(event,${id})">
        <select id="h_mkind">${Object.entries(MED_KINDS).map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select>
        <input id="h_mtitle" placeholder="Название" required>
        <input id="h_mdose" placeholder="Дозировка">
        <input id="h_msched" placeholder="Когда принимать">
        <button class="primary">${icon('plus')}<span>Добавить</span></button>
      </form>
      <div class="h-list">${h.meds.length?h.meds.map(m=>{const act=!m.ended_on;return `
        <div class="h-row ${act?'':'done'}"><div class="grow"><strong>${esc(m.title)}</strong>
          <span class="muted">${[MED_KINDS[m.kind]||m.kind,m.dosage,m.schedule].filter(Boolean).map(esc).join(' · ')}</span>
          <span class="muted">${act?('принимает'+(m.started_on?' с '+hDay(m.started_on):'')):'закончил '+hDay(m.ended_on)}</span></div>
          ${act?`<button class="linkbtn" onclick="hFinishMed(${m.id},${id})">Курс закончен</button>`:''}
          <button class="linkbtn danger" onclick="hDel('meds',${m.id},${id})">Убрать</button></div>`}).join('')
        :'<div class="empty small">Пока пусто</div>'}</div>
    `,cnt(h.meds.length,'нет'))}

    ${foldCard('sh_lab','Анализы',`
      <p class="muted small">Файл хранится как есть: показатели по строкам не разбираются, решение принимает человек.</p>
      <form class="h-add wrap" onsubmit="hAddLab(event,${id})">
        <input id="h_ltitle" placeholder="Например, общий анализ крови" required>
        <input id="h_ldate" type="date" value="${today10()}">
        <label class="h-file">${icon('clip')}<span>Прикрепить файл</span>
          <input id="h_lfile" type="file" accept="application/pdf,image/*" onchange="hFileName(this)"></label>
        <button class="primary">${icon('plus')}<span>Добавить</span></button>
      </form>
      <div class="h-list">${h.labs.length?h.labs.map(l=>`
        <div class="h-row"><div class="grow"><strong>${esc(l.title)}</strong>
          <span class="muted">${hDay(l.taken_on||l.created_at)}</span></div>
          ${l.file_url?`<button class="linkbtn" onclick="hOpenLab('${esc(l.file_url)}','${esc(l.title)}')">Открыть</button>`:'<span class="muted small">без файла</span>'}
          <button class="linkbtn danger" onclick="hDel('labs',${l.id},${id})">Убрать</button></div>`).join('')
        :'<div class="empty small">Анализов пока нет</div>'}</div>
    `,cnt(h.labs.length,'нет'))}

    ${foldCard('sh_rec','История рекомендаций',`
      <p class="muted small">Это видит клиент.</p>
      <form class="h-add col" onsubmit="hAddRec(event,${id})">
        <textarea id="h_rbody" rows="3" placeholder="Что рекомендовали и почему" required></textarea>
        <button class="primary wide">Записать</button>
      </form>
      <div class="h-list">${h.recommendations.length?h.recommendations.map(r=>`
        <div class="h-row rec"><div class="grow"><p>${esc(r.body)}</p><span class="muted">${hDay(r.created_at)}</span></div>
          <button class="linkbtn danger" onclick="hDel('recommendations',${r.id},${id})">Убрать</button></div>`).join('')
        :'<div class="empty small">Пока пусто</div>'}</div>
    `,cnt(h.recommendations.length,'нет'))}
  </div>`;
}

async function hAddAllergy(e,id){e.preventDefault();
  try{await api('/specialist/clients/'+id+'/allergies',{method:'POST',
    body:JSON.stringify({title:$('#h_atitle').value,kind:$('#h_akind').value})});spTabHealth()}
  catch(x){toast(x.message,'err')}}

async function hAddMed(e,id){e.preventDefault();
  try{await api('/specialist/clients/'+id+'/meds',{method:'POST',body:JSON.stringify({
    title:$('#h_mtitle').value,kind:$('#h_mkind').value,
    dosage:$('#h_mdose').value||null,schedule:$('#h_msched').value||null,started_on:today10()})});spTabHealth()}
  catch(x){toast(x.message,'err')}}

async function hFinishMed(mid,id){
  try{await api('/specialist/meds/'+mid,{method:'PATCH',body:JSON.stringify({ended_on:today10()})});spTabHealth()}
  catch(x){toast(x.message,'err')}}

/* Анализ уходит формой: файл и подписи одним запросом. */
async function hAddLab(e,id){e.preventDefault();
  const fd=new FormData();
  fd.append('title',$('#h_ltitle').value);
  fd.append('taken_on',$('#h_ldate').value||'');
  const f=$('#h_lfile').files[0]; if(f)fd.append('file',f);
  try{await api('/specialist/clients/'+id+'/labs',{method:'POST',body:fd});spTabHealth()}
  catch(x){toast(x.message,'err')}}

/* Файл за проверкой прав: качаем с токеном в заголовке и показываем на
   месте. Токен в адресе осел бы в истории браузера, поэтому ссылка
   временная.

   Снимок анализа раньше открывался новой вкладкой — человек уходил из
   приложения в браузер и возвращался кнопкой «назад». Картинку
   показываем прямо поверх экрана; всё остальное (PDF и прочее) браузер
   по-прежнему открывает сам — рисовать свой просмотрщик PDF незачем. */
async function hOpenLab(url,name){
  try{
    /* file_url приходит уже с /api/v1 — берём его как есть. */
    const r=await fetch(url,{headers:{Authorization:'Bearer '+A.token}});
    if(!r.ok)throw new Error(r.status===403?'Нет доступа к файлу':'Файл не открылся');
    const blob=await r.blob();
    const href=URL.createObjectURL(blob);
    if(/^image\//.test(blob.type)){ showViewer(href,name||'Файл'); return }
    window.open(href,'_blank');
    setTimeout(()=>URL.revokeObjectURL(href),60000);
  }catch(x){toast(x.message,'err')}}

/* Просмотр картинки поверх экрана: снимок анализа, фото из чата, фото
   прогресса — всё открывается одинаково. Закрывается по фону, крестику
   и Escape, чтобы не искать выход. */
function showViewer(src,title){
  closeModal();
  const m=document.createElement('div');
  m.className='modal viewer';m.id='modal';
  m.innerHTML=`<div class="viewer-top"><span>${esc(title||'')}</span>
      <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <img src="${src}" alt="${esc(title||'Изображение')}">`;
  m.addEventListener('click',e=>{if(e.target===m||e.target.tagName==='IMG')closeModal()});
  document.body.appendChild(m);
  const esc2=e=>{if(e.key==='Escape'){closeModal();removeEventListener('keydown',esc2)}};
  addEventListener('keydown',esc2);
}

async function hAddRec(e,id){e.preventDefault();
  try{await api('/specialist/clients/'+id+'/recommendations',{method:'POST',
    body:JSON.stringify({body:$('#h_rbody').value})});spTabHealth()}
  catch(x){toast(x.message,'err')}}

async function hDel(kind,rid,id){
  if(!confirm('Убрать запись?'))return;
  try{await api('/specialist/'+kind+'/'+rid,{method:'DELETE'});spTabHealth()}
  catch(x){toast(x.message,'err')}}

/* Задания клиенту. Зашитые «отметить приёмы» и «записать вес» — правила
   сервиса; здесь специалист ставит личные: сдать анализы, пройти шаги,
   приготовить по рецепту и прислать фото. */
async function spTabTasks(){
  const id=A.client.id;
  let j={tasks:[]};
  try{j=await api('/specialist/clients/'+id+'/tasks')}catch(e){}
  const st={open:['В работе','d-wait'],done:['Выполнено','d-ok'],cancelled:['Отменено','d-bad']};
  $('#tabbody').innerHTML=`<div class="health">
    <div class="card pad">
      <h3>Новое задание</h3>
      <p class="muted small">Задание с фотоотчётом клиент не закроет без снимка.</p>
      <form class="v-add" onsubmit="spAddTask(event,${id})">
        <label>Что нужно сделать<input id="tk_t" placeholder="Сдать общий анализ крови" required></label>
        <label>Пояснение<input id="tk_n" placeholder="Натощак, до конца недели"></label>
        <div class="formgrid">
          <label>Вид<select id="tk_k"><option value="simple">Обычное</option><option value="photo">С фотоотчётом</option></select></label>
          <label>Баллы<input id="tk_p" type="number" value="20" min="0" max="500"></label>
        </div>
        <label>Срок<input id="tk_d" type="date"></label>
        <button class="primary green">Поставить задание</button>
      </form>
    </div>
    <div class="card pad">
      <h3>Задания</h3>
      <div class="h-list">${j.tasks.length?j.tasks.map(t=>{
        const [l,c]=st[t.status]||st.open;
        return `<div class="h-row">
          <div class="grow"><strong>${esc(t.title)}</strong>
            <span class="muted small">${[t.kind==='photo'?'с фотоотчётом':'',t.points+' б.',t.due_on?'до '+esc(hDay(t.due_on)):''].filter(Boolean).join(' · ')}</span>
            ${t.note?`<span class="muted small">${esc(t.note)}</span>`:''}
            ${t.comment?`<span class="muted small">Ответ клиента: ${esc(t.comment)}</span>`:''}</div>
          ${t.photo_url?`<img class="ptask-photo" src="${esc(t.photo_url)}" alt="">`:''}
          <span class="d-chip ${c}">${l}</span>
          ${t.status==='open'?`<button class="linkbtn danger" onclick="spCancelTask(${t.id},${id})">Отменить</button>`:''}
        </div>`}).join(''):'<div class="empty small">Заданий пока нет</div>'}</div>
    </div>
  </div>`;
}
async function spAddTask(e,id){e.preventDefault();
  try{
    await api('/specialist/clients/'+id+'/tasks',{method:'POST',body:JSON.stringify({
      title:$('#tk_t').value,note:$('#tk_n').value,
      kind:$('#tk_k').value,points:+$('#tk_p').value||0,due_on:$('#tk_d').value||''})});
    spTabTasks();
  }catch(x){toast(x.message,'err')}}
async function spCancelTask(tid,id){
  if(!confirm('Отменить задание?'))return;
  try{await api('/specialist/tasks/'+tid,{method:'DELETE'});spTabTasks()}
  catch(x){toast(x.message,'err')}}

async function spTabOverview(){const id=A.client.id;let j={},g={};try{j=await api('/specialist/clients/'+id+'/profile')}catch(e){}try{g=await api('/specialist/clients/'+id+'/engagement')}catch(e){}const c=j.client||A.client,p=j.preferences||{};const arr=v=>{try{return JSON.parse(v||'[]')||[]}catch{return[]}};const likes=arr(p.likes),dis=arr(p.dislikes),exc=arr(p.excluded);const week=(g&&g.week)||[];const adh=(g&&g.adh)||{};
/* Кольцо считаем от плана, а не от отметок: доля съеденного среди
   отмеченных льстит клиенту, который почти ничего не отмечал. */
const avg=adh.eaten_pct!=null?adh.eaten_pct:null;
const adhWord=adh.planned?(avg>=80?'Отличная':avg>=55?'Хорошая':'Требует внимания'):'Меню не опубликовано';
/* Вывод красим по смыслу: «требует внимания» зелёным читалось как
   похвала, и специалист пролистывал мимо. */
/* Когда меню не опубликовано, показываем не кольцо с прочерком и семь
   пустых столбиков, а объяснение и путь дальше: график, который ничего
   не измеряет, специалисту читать незачем. */
/* Семь пустых дорожек — это не график, а рамка от графика: если ни за
   один день нет данных, показывать нечего. */
const adhTone=!adh.planned?'none':avg>=80?'g':avg>=55?'a':'r';const prefCard=(cls,ic,title,list)=>`<div class="ovp ${cls}"><span class="ovp-ic">${icon(ic)}</span><b>${title}</b><span class="ovp-val">${list.length?esc(list.join(', ')):'не указано'}</span></div>`;
$('#tabbody').innerHTML=`<div class="ov">
${A.clientSub?`<div class="card pad sub-lite"><div class="eyebrow">Услуга</div>
  <div class="sub-top"><strong>${esc(A.clientSub.title)}</strong>
  <b class="num">${rub(A.clientSub.price_kop)}</b></div>
  <div class="sub-left t-${subTone(A.clientSub)}">${icon('clock')}<span>${esc(subLeft(A.clientSub))}</span>
  ${A.clientSub.expires_at?`<i class="num">до ${esc(dmy(A.clientSub.expires_at.slice(0,10)))}</i>`:''}</div></div>`:''}
<div class="card flat ovrows">${[
  /* Вес переехал в шапку карточки, к возрасту и росту — здесь остаётся
     то, по чему со специалистом связываются. */
  ['Почта',c.email||'—'],['Телефон',c.phone||'—']]
  .map(([l,v])=>`<div class="ovrow"><span>${l}</span><b>${esc(String(v))}</b></div>`).join('')}</div>
<div class="card pad"><h3>Целевые показатели</h3><div class="targets">${[['ккал',c.target_kcal,''],['Белки',c.target_protein,'г'],['Жиры',c.target_fat,'г'],['Углеводы',c.target_carbs,'г']].map(([l,v,u])=>`<div class="tgt"><b class="num">${v||'—'}${u&&v?'<i>'+u+'</i>':''}</b><span>${l}</span></div>`).join('')}</div></div>
<div class="card pad"><h3>Приверженность меню</h3>${adh.planned?`<div class="ov-adh"><div class="ov-ring">${ring(avg||0,104,(avg==null?'—':avg+'%'))}</div><div class="ov-adh-txt t-${adhTone}"><b>${adhWord}</b><span class="muted">съедено из ${adh.planned} ${plural(adh.planned,['приёма','приёмов','приёмов'])} плана за 7 дней</span></div>
<div class="adh-split">
  <div class="as g"><b class="num">${adh.eaten}</b><span>съел</span></div>
  <div class="as a"><b class="num">${adh.skipped}</b><span>не ел</span></div>
  <div class="as r"><b class="num">${adh.unlogged}</b><span>не отметил</span></div>
</div>${adh.unlogged>adh.logged?`<p class="adh-note muted">Большую часть приёмов клиент не отмечал. Это молчание, а не отказ от меню: сначала стоит спросить, открывает ли он программу.</p>`:''}${week.some(d=>d.pct!=null)?`<div class="wa-bars ov-bars">${week.map(d=>{const pp=d.pct;const k=pp==null?'none':pp>=80?'g':pp>=55?'a':'r';return `<div class="wa-col"><div class="wa-track"><i class="${k}" style="height:${pp==null?4:Math.max(6,pp)}%"></i></div><span>${esc(d.label)}</span></div>`}).join('')}</div>`:''}</div>`:`<div class="adh-none">${icon('menu')}<div class="grow"><b>Меню ещё не опубликовано</b><span class="muted">Приверженность появится, когда клиент начнёт отмечать приёмы из плана</span></div><button class="secondary sm" onclick="spClient(${id},'menu')">Перейти к меню</button></div>`}</div>
<div class="card pad"><h3>Предпочтения в питании</h3><div class="ovp-grid">${prefCard('like','check','Любит',likes)}${prefCard('dislike','x','Не любит',dis)}${prefCard('excl','bell','Ограничения',exc)}</div></div>
<button class="ov-more" onclick="spClient(${id},'activity')">${icon('edit')}<span>Заметки и активность клиента</span>${icon('chevr')}</button>
</div>`}
async function spPaintEngage(id){let g;try{g=await api('/specialist/clients/'+id+'/engagement')}catch(e){return}const el=$('#ch-engage');if(!el)return;const heat=g.streak>=7?'hot':g.streak>=3?'warm':g.streak>=1?'ok':'cold';const unlocked=g.achievements.filter(a=>a.unlocked).length;el.innerHTML=`<div class="engage-strip"><div class="eng-item ${heat}"><div class="eng-ic">${icon('flame')}</div><div><b>${g.streak}</b><span>${plural(g.streak,['день','дня','дней'])} подряд</span></div></div><div class="eng-item"><div class="eng-ic coin">${icon('coin')}</div><div><b>${g.balance}</b><span>баллов · ур. ${g.level}</span></div></div><div class="eng-item"><div class="eng-ic">${icon('check')}</div><div><b>${g.eaten}</b><span>отмечено приёмов</span></div></div><div class="eng-item"><div class="eng-ic">${icon('trophy')}</div><div><b>${unlocked}/${g.achievements.length}</b><span>достижений</span></div></div><div class="eng-badges">${g.achievements.map(a=>`<span class="ach-mini ${a.unlocked?'on':''}" title="${esc(a.label)}">${icon(a.unlocked?a.icon:'lock')}</span>`).join('')}</div></div>`}
function weekAdhChart(week){if(!week||!week.length)return '';const vals=week.filter(d=>d.pct!=null);const avg=vals.length?Math.round(vals.reduce((s,d)=>s+d.pct,0)/vals.length):null;return `<div class="week-adh card"><div class="wa-head"><div><span class="wa-title">Приверженность меню</span><small class="muted">за 7 дней</small></div><b class="wa-avg num">${avg==null?'—':avg+'%'}</b></div><div class="wa-bars">${week.map(d=>{const p=d.pct;const cl=p==null?'none':p>=80?'g':p>=55?'a':'r';return `<div class="wa-col"><div class="wa-track"><i class="${cl}" style="height:${p==null?4:Math.max(6,p)}%" title="${d.label}: ${p==null?'нет данных':p+'%'}"></i></div><span>${esc(d.label)}</span></div>`}).join('')}</div></div>`}

async function spTabMenu(){const id=A.client.id;const ms=await api('/specialist/menus?client_id='+id);let menu=ms.menus[0];if(!menu){$('#tabbody').innerHTML=`<div class="empty"><h3>Меню ещё нет</h3><p>Создайте первое меню для клиента.</p><div class="empty-btns"><button class="primary" onclick="spNewMenu()">${icon('plus')} Создать меню</button></div></div>`;return}
const mp=await api('/specialist/menus/'+menu.id);A.menu=mp.menu;A.items=mp.items;A.day=A.day||1;spRenderMenu()}
/* ---------------------------------------------------------------
   СБОРКА МЕНЮ ПОД ЦЕЛИ
   Черновик, а не решение за специалиста: программа набирает блюда так,
   чтобы день сходился по калориям и не содержал запрещённого клиенту.
   Состав тарелки и сочетаемость остаются человеку, поэтому меню
   создаётся черновиком, а расхождения показываются прямо в отчёте.
   --------------------------------------------------------------- */
const GEN_MEALS=[['breakfast','Завтрак'],['snack1','Перекус'],['lunch','Обед'],['snack2','Полдник'],['dinner','Ужин']];

/* Подбор меню под цели временно убран из интерфейса: калькулятор ещё
   дорабатывается. Экран и серверная генерация целы — вернуть кнопки
   в пустое состояние вкладки «Меню» и в список действий, и всё оживёт. */
function spGenSheet(){
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Меню</div><h2>Собрать под цели</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="spGenerate(event)">
    <p class="muted small" style="margin:0 0 12px">Блюда подберём под калории клиента и его ограничения. Получится черновик — вы его правите и публикуете.</p>
    <div class="formgrid">
      <label>Дней<input id="gn_d" type="number" value="7" min="1" max="31"></label>
      <label>Начало<input id="gn_s" type="date" value="${today10()}"></label>
    </div>
    <div class="field-label">Приёмы пищи</div>
    <div class="gen-meals">${GEN_MEALS.map(([k,l])=>
      `<label class="gen-meal"><input type="checkbox" class="gn_m" value="${k}" checked><span>${l}</span></label>`).join('')}</div>
    <button class="primary green wide">Собрать</button>
  </form>`);
}
async function spGenerate(e){e.preventDefault();
  const meals=[...document.querySelectorAll('.gn_m:checked')].map(x=>x.value);
  if(!meals.length){toast('Оставьте хотя бы один приём пищи','err');return}
  const btn=e.target.querySelector('button');btn.disabled=true;btn.textContent='Собираем…';
  try{
    const j=await api('/specialist/clients/'+A.client.id+'/menu/generate',{method:'POST',
      body:JSON.stringify({days_count:+$('#gn_d').value||7,start_date:$('#gn_s').value,meals})});
    closeModal();
    spGenReport(j);
  }catch(x){btn.disabled=false;btn.textContent='Собрать';toast(x.message,'err')}
}
/* Отчёт показываем до того, как специалист откроет меню: расхождение по
   жирам или белку виднее числом, чем при пролистывании семи дней. */
function spGenReport(j){
  const sign=v=>v==null?'':(v>0?'+':'')+v;
  showModal(`<div class="sheet-head"><div><div class="eyebrow">Черновик готов</div><h2>Что получилось</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal();spTabMenu()">${icon('x')}</button></div>
  <p class="muted small">Меню сохранено черновиком — проверьте и опубликуйте.</p>
  <div class="gen-q">${(j.quality||[]).map(q=>`<div class="gq gq-${q.verdict}"><span class="gq-l">${esc(q.label)}</span><b>${esc(q.text)}</b><span class="num gq-n">${q.avg} / ${q.goal} ${esc(q.unit)}${q.verdict==='ok'?'':` · ${q.pct>0?'+':''}${q.pct}%`}</span></div>`).join('')}</div>
  ${(j.warnings||[]).map(w=>`<div class="v-note">${esc(w)}</div>`).join('')}
  <div class="gen-days">${j.days.map(d=>`<div class="gen-day">
    <b>День ${d.day}</b>
    <span class="num">${d.kcal} ккал <i class="${Math.abs(d.kcal_diff)>100?'off':''}">${sign(d.kcal_diff)}</i></span>
    <span class="muted small num">Б ${d.protein}${d.protein_diff!=null?` (${sign(d.protein_diff)})`:''} · Ж ${d.fat}${d.fat_diff!=null?` (${sign(d.fat_diff)})`:''} · У ${d.carbs}${d.carbs_diff!=null?` (${sign(d.carbs_diff)})`:''}</span>
  </div>`).join('')}</div>
  <button class="primary green wide" onclick="closeModal();spTabMenu()">Открыть меню</button>`);
}

async function spNewMenu(){const x=await api('/specialist/menus',{method:'POST',body:JSON.stringify({client_id:A.client.id,title:'Меню Анны · 7 дней',days_count:7})});A.day=1;spTabMenu()}
function spRenderMenu(){const m=A.menu;const items=A.items.filter(x=>+x.day_number===A.day);const tg={protein:+m.target_protein||0,fat:+m.target_fat||0,carbs:+m.target_carbs||0};const tot={kcal:0,protein:0,fat:0,carbs:0};items.forEach(x=>['kcal','protein','fat','carbs'].forEach(k=>tot[k]+=+x.nutrition[k]||0));const tk=+m.target_kcal||0;const pct=tk?tot.kcal/tk*100:0;
/* Публикация и инструменты меню жили в шапке карточки и висели там на
   всех вкладках, включая «Задания» и «Прогресс». Их место — рядом с самим
   меню, как в приложении. */
$('#tabbody').innerHTML=`<div class="menu-top"><button class="primary green" onclick="spPublishCurrent()">${icon('check')} Опубликовать меню</button><button class="icon-circle" aria-label="Действия с меню" onclick="spMenuTools()" title="Действия с меню">${icon('kebab')}</button></div>
<div class="menu-wrap"><div class="menu-left">
${(()=>{const weeks=Math.ceil(m.days_count/7);const wk=Math.min(weeks,Math.max(1,Math.ceil(A.day/7)));const wStart=(wk-1)*7+1,wEnd=Math.min(m.days_count,wk*7);const rA=addDays(m.start_date,wStart-1),rB=addDays(m.start_date,wEnd-1);return `<div class="menu-bar"><div class="weeknav">${weeks>1?`<button class="wk-arrow" onclick="spGoWeek(${wk-1})" ${wk<=1?'disabled':''}>${icon('chevl')}</button>`:''}<div class="daterange">${icon('cal')} ${fmtD(rA)} – ${fmtD(rB)}${weeks>1?` · Неделя ${wk}/${weeks}`:` · ${m.days_count} дн.`}</div>${weeks>1?`<button class="wk-arrow" onclick="spGoWeek(${wk+1})" ${wk>=weeks?'disabled':''}>${icon('chevr')}</button>`:''}</div><button class="ghost sm" onclick="spCopyDay()">${icon('copy')} Копировать день</button></div>
<div class="daystrip">${Array.from({length:wEnd-wStart+1},(_,i)=>{const dn=wStart+i;const dt=addDays(m.start_date,dn-1);const wd=dt?WD_SHORT[new Date(dt+'T00:00:00').getDay()].toUpperCase():'';
   return `<button class="day ${A.day===dn?'active':''}${dt&&isToday(dt)?' day-today':''}" onclick="A.day=${dn};spRenderMenu()"><small>${wd||'ДЕНЬ'}</small><b>${dt?+dt.slice(8,10):dn}</b>${dt&&isToday(dt)?'<i>сегодня</i>':''}</button>`}).join('')}</div>`})()}
<div class="kcard card"><div class="kcard-top">${ring(pct,64,R(pct)+'%')}<div class="kcal-main"><b class="num">${R(tot.kcal)}</b> <span class="num">/ ${tk||'—'} ккал</span><small>${tk?R(pct)+'% от дневной цели':''}</small></div></div>${macroBars(tot,tg)}</div>
<div class="meals-grid">${MEAL_ORDER.map(mt=>{const arr=items.filter(x=>x.meal_type===mt);return `<div class="meal-sec"><div class="meal-h"><b>${MEAL[mt]}</b><small>${timeFor(mt)}</small></div>${arr.map(spDishRow).join('')}<div class="add-row"><button class="add-dish" onclick="spAddDish('${mt}')">${icon('plus')} Блюдо</button><button class="add-dish" onclick="spAddFood('${mt}')">${icon('plus')} Продукт</button></div></div>`}).join('')}</div>
</div>
<aside class="menu-drawer" id="drawer">${A.drawerItem?spDrawerHTML():`<div class="drawer-empty">${icon('bowl')}<p>Выберите блюдо, чтобы посмотреть состав и порцию</p></div>`}</aside></div>`}
function spDishRow(x){const done=x.log_status==='eaten',skip=x.log_status==='skipped';return `<button class="dish-row ${A.drawerItem&&A.drawerItem.id===x.id?'sel':''}" onclick="spOpenDrawer(${x.id})"><span class="thumb" style="background-image:url(${esc(dishThumb(x))})"></span><div class="grow"><strong>${esc(x.dish_name)}</strong><span class="num">${R(x.portion_g)} г</span><div class="mm num">Б ${R(x.nutrition.protein)} · Ж ${R(x.nutrition.fat)} · У ${R(x.nutrition.carbs)}</div></div><div class="dk"><b class="num">${R(x.nutrition.kcal)}</b><small>ккал</small></div>${done?`<span class="chk done">${icon('check')}</span>`:skip?`<span class="chk skip">${icon('x')}</span>`:`<span class="kebab" onclick="event.stopPropagation();spItemMenu(${x.id})">${icon('kebab')}</span>`}</button>`}
function spOpenDrawer(iid){A.drawerItem=A.items.find(x=>x.id===iid);if(window.innerWidth<900){spDrawerModal()}else{spRenderMenu()}}
function spDrawerHTML(){const x=A.drawerItem;return `<button class="drawer-x" aria-label="Закрыть" onclick="closeModal();A.drawerItem=null;spRenderMenu()">${icon('x')}</button><div class="drawer-photo" style="background-image:url(${esc(dishPhoto(x))})"></div><h2>${esc(x.dish_name)}</h2><p class="dgram num" id="dw_g">${R(x.portion_g)} г</p><div class="dcal num" id="dw_kcal">${R(x.nutrition.kcal)} ккал</div><div class="dmac num" id="dw_mac">Б ${R(x.nutrition.protein)} · Ж ${R(x.nutrition.fat)} · У ${R(x.nutrition.carbs)}</div><div class="sect">Порция</div><input class="slider2" type="range" min="30" max="1000" step="5" value="${R(x.portion_g)}" oninput="spPortion(this.value)"><div class="slider-ends"><span>30 г</span><span id="pg" class="num">${R(x.portion_g)} г</span><span>1000 г</span></div><button class="primary wide" onclick="spSavePortion(${x.id})">Сохранить порцию</button><div class="sect">Состав блюда</div><div id="drawer-ings" class="muted small">Загрузка…</div><button class="link wide" onclick="spDishRecipe(${x.dish_id})">Показать рецепт</button><button class="dangerbtn wide" onclick="spDeleteItem(${x.id})">Удалить блюдо</button>`}
async function spDrawerModal(){showModal(`<div class="drawer-modal">${spDrawerHTML()}</div>`);spLoadIngs()}
async function spLoadIngs(){
  if(!A.drawerItem)return;
  try{
    const d=(await api('/specialist/dishes/'+A.drawerItem.dish_id)).dish;
    /* Держим исходный состав и выход блюда: состав в справочнике задан на
       свой выход, а в меню стоит другая порция — пересчитывать надо от
       них, а не от того, что сейчас на экране. */
    A.drawerIngs={base:+d.base_portion_g||0,list:d.ingredients||[]};
    spPaintIngs();
  }catch(e){const el=$('#drawer-ings');if(el)el.innerHTML='<p class="muted small">Состав не загрузился.</p>'}
}
/* Состав пересчитываем под текущую граммовку: 130 г лосося в порции 515 г
   превращаются в 65 г, если специалист поставил 258. */
function spPaintIngs(){
  const el=$('#drawer-ings'),src=A.drawerIngs,x=A.drawerItem;
  if(!el||!src||!x)return;
  const cur=+($('.slider2')?.value)||+x.portion_g||0;
  const base=src.base||+x.base_portion_g||0;
  const k=base?cur/base:1;
  el.innerHTML=src.list.length
    ?`<ul class="complist">${src.list.map(i=>`<li><span>${esc(i.ingredient_name)}</span><b class="num">${R(i.grams*k)} г</b></li>`).join('')}</ul>`
    :'<p class="muted small">Состав не указан.</p>';
}
/* Раньше ползунок считал коэффициент и никуда его не применял: менялась
   только подпись, а калории, БЖУ и состав оставались от прежней порции —
   специалист сохранял граммовку, глядя на чужие числа. */
function spPortion(v){
  const x=A.drawerItem; if(!x)return;
  v=Math.max(0,+v||0);
  const k=+x.portion_g?v/+x.portion_g:0, n=x.nutrition||{};
  const set=(id,t)=>{const e=document.getElementById(id);if(e)e.textContent=t};
  set('pg',R(v)+' г');
  set('dw_g',R(v)+' г');
  set('dw_kcal',R((n.kcal||0)*k)+' ккал');
  set('dw_mac',`Б ${R((n.protein||0)*k)} · Ж ${R((n.fat||0)*k)} · У ${R((n.carbs||0)*k)}`);
  spPaintIngs();
}
async function spSavePortion(iid){const v=+$('.slider2').value;await api('/specialist/menu-items/'+iid,{method:'PATCH',body:JSON.stringify({portion_g:v})});closeModal();const mp=await api('/specialist/menus/'+A.menu.id);A.items=mp.items;A.drawerItem=A.items.find(x=>x.id===iid);spRenderMenu()}
async function spDeleteItem(iid){if(!confirm('Удалить блюдо?'))return;await api('/specialist/menu-items/'+iid,{method:'DELETE'});closeModal();A.drawerItem=null;const mp=await api('/specialist/menus/'+A.menu.id);A.items=mp.items;spRenderMenu()}
function spItemMenu(iid){A.drawerItem=A.items.find(x=>x.id===iid);spDrawerModal()}
// after drawer opens on desktop, load ingredients
const _spRenderMenu=spRenderMenu;spRenderMenu=function(){_spRenderMenu();fx($('.menu-left'));if(A.drawerItem&&window.innerWidth>=900)spLoadIngs()}

async function spAddDish(mt){if(!A.dishes.length){const j=await api('/specialist/dishes');A.dishes=j.dishes}A.catMeal=mt;A.catFilter='all';A.catQ='';showModal(`<div class="catalog"><div class="sheet-head"><div><div class="eyebrow">${MEAL[mt]}</div><h2>Добавить блюдо</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="searchbox full">${icon('search')}<input id="dq" placeholder="Поиск блюда…" oninput="A.catQ=this.value;spRenderCatalog()"></div><div class="chip-row">${[['all','Все'],['fav','Избранное'],['breakfast','Завтрак'],['lunch','Обед'],['dinner','Ужин'],['snack1','Перекус']].map(([k,l])=>`<button class="chip" data-f="${k}" onclick="A.catFilter='${k}';spRenderCatalog()">${l}</button>`).join('')}</div><div id="catlist" class="cat-list"></div></div>`);spRenderCatalog()}
function spRenderCatalog(){const q=(A.catQ||'').toLowerCase();document.querySelectorAll('.catalog .chip').forEach(b=>b.classList.toggle('active',b.dataset.f===A.catFilter));let ds=A.dishes.filter(d=>!q||d.name.toLowerCase().includes(q));if(A.catFilter==='fav')ds=ds.filter(d=>A.favs.includes(d.id));else if(['breakfast','lunch','dinner','snack1'].includes(A.catFilter))ds=ds.filter(d=>{try{return (JSON.parse(d.meal_types||'[]')||[]).includes(A.catFilter)}catch{return true}});$('#catlist').innerHTML=ds.slice(0,60).map(d=>`<div class="cat-row"><span class="thumb" style="background-image:url(${esc(dishThumb(d))})"></span><div class="grow" onclick="spDishPreview(${d.id})"><strong>${esc(d.name)}</strong><div class="mm num">Б ${R(d.protein_100)} · Ж ${R(d.fat_100)} · У ${R(d.carbs_100)} · ${R(d.kcal_100)} ккал/100г</div></div><button class="star ${A.favs.includes(d.id)?'on':''}" onclick="spFav(${d.id})">${icon('star')}</button><button class="add-round" onclick="spDishPreview(${d.id})">${icon('plus')}</button></div>`).join('')||`<div class="empty small">Ничего не найдено</div>`;stagger($('#catlist'))}
/* Окно блюда из каталога показывало фото, ползунок и КБЖУ — и всё.
   Решение «ставить ли это блюдо» принимают по составу и способу
   приготовления, а за ними приходилось закрывать окно и искать блюдо в
   базе. Теперь состав и рецепт здесь же, и состав пересчитывается вместе
   с граммовкой. */
async function spDishPreview(did){
  const d=A.dishes.find(x=>x.id===did); if(!d){spChooseDish(did);return}
  const base=R(d.base_portion_g)||250;
  A.previewDish=null;
  showModal(`<div class="sheet-head"><div><div class="eyebrow">${MEAL[A.catMeal]||'Блюдо'}</div><h2>${esc(d.name)}</h2></div><button class="close" aria-label="Закрыть" onclick="spAddDish(A.catMeal)">${icon('x')}</button></div><div class="drawer-photo" style="background-image:url(${esc(dishPhoto(d))})"></div><div class="portion-box"><div class="portion-top"><span>Порция</span><b class="num"><span id="pv_g">${base}</span> г</b></div><input id="pv_slider" class="portion-range" type="range" min="30" max="600" step="10" value="${base}" oninput="spPreviewCalc(${did})"></div><div class="macro-row" id="pv_macros"></div><div id="pv_comp"><div class="sect">Состав блюда</div><p class="muted small">Загрузка…</p></div><button class="primary green wide" onclick="spChooseDish(${did},+$('#pv_slider').value)">${icon('plus')} Добавить в меню</button>`);
  spPreviewCalc(did);
  try{
    A.previewDish=(await api('/specialist/dishes/'+did)).dish;
    spPaintPreview();
  }catch(e){
    const el=$('#pv_comp'); if(el)el.innerHTML='<div class="sect">Состав блюда</div><p class="muted small">Не удалось загрузить состав.</p>';
  }
}
function spPaintPreview(){
  const el=$('#pv_comp'),d=A.previewDish; if(!el||!d)return;
  const cur=+($('#pv_slider')?.value)||+d.base_portion_g||250;
  const base=+d.base_portion_g||cur;
  const k=base?cur/base:1;
  let steps=[]; try{steps=JSON.parse(d.steps||'[]')||[]}catch(e){}
  const ings=d.ingredients||[];
  el.innerHTML=`<div class="sect">Состав блюда</div>
    ${ings.length?`<ul class="complist">${ings.map(i=>`<li><span>${esc(i.ingredient_name)}</span><b class="num">${R(i.grams*k)} г</b></li>`).join('')}</ul>`
      :'<p class="muted small">Состав не указан.</p>'}
    ${steps.length?`<div class="sect">Как готовить${d.cook_minutes?` · ${d.cook_minutes} мин`:''}</div><div class="recipe-steps">${steps.map((st,i)=>`<div class="rstep">${st.photo_url?`<div class="rstep-photo" style="background-image:url(${esc(st.photo_url)})"></div>`:''}<div class="rstep-body"><b>Шаг ${i+1}</b><p>${esc(st.text||'')}</p></div></div>`).join('')}</div>`
      :(d.instructions?`<div class="sect">Как готовить${d.cook_minutes?` · ${d.cook_minutes} мин`:''}</div><p class="lead">${esc(d.instructions)}</p>`:'')}`;
}
function spPreviewCalc(did){const d=A.dishes.find(x=>x.id===did);const g=+($('#pv_slider')?.value||d.base_portion_g||250);const f=g/100;$('#pv_g').textContent=g;const m=[['Ккал',R(d.kcal_100*f)],['Белки',R(d.protein_100*f)+' г'],['Жиры',R(d.fat_100*f)+' г'],['Углеводы',R(d.carbs_100*f)+' г']];$('#pv_macros').innerHTML=m.map(([l,v])=>`<div class="macro-cell"><b class="num">${v}</b><span>${l}</span></div>`).join('');spPaintPreview()}
function spFav(id){const i=A.favs.indexOf(id);if(i>=0)A.favs.splice(i,1);else A.favs.push(id);localStorage.nm_favs=JSON.stringify(A.favs);spRenderCatalog()}
/* ---------- Назначение продукта ----------
   Не всё в меню — рецепт: «150 г индейки» или банан на перекус
   назначаются продуктом, а не блюдом. Лист устроен так же, как дневник
   у клиента: поиск, выбор, граммовка. */
const SPFOOD={meal:'lunch',found:[],q:''};
function spAddFood(mt){
  SPFOOD.meal=mt;SPFOOD.found=[];SPFOOD.q='';
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">${MEAL[mt]}</div><h2>Добавить продукт</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <div id="spf_wrap" class="food-searchrow">
    <input id="spf_q" placeholder="Найти продукт" autocomplete="off" oninput="spFoodSearch(this.value)">
  </div>
  <div id="spf_found" class="food-found"></div>`);
  spFoodSearch('');
}
let _spfT=null;
function spFoodSearch(q){
  SPFOOD.q=q;
  clearTimeout(_spfT);
  _spfT=setTimeout(async()=>{
    try{ const j=await api('/specialist/ingredients?limit=40&q='+encodeURIComponent(q.trim()));
         SPFOOD.found=(j.ingredients||j.foods||[]).slice(0,40); }
    catch(e){ SPFOOD.found=[] }
    spFoodPaint();
  },q.trim()?220:0);
}
function spFoodPaint(){
  const el=$('#spf_found');if(!el)return;
  if(!SPFOOD.found.length){
    el.innerHTML='<p class="muted small">'+(SPFOOD.q.trim()?'Такого продукта нет в справочнике.':'Начните вводить название.')+'</p>';
    return;
  }
  el.innerHTML=SPFOOD.found.map((f,i)=>`<button class="food-row" onclick="spFoodPick(${i})">
    <div class="grow"><strong>${esc(f.name)}</strong>
      <small>${R(f.kcal)} ккал · Б ${f.protein} Ж ${f.fat} У ${f.carbs} / 100 г</small></div>
    ${icon('plus')}</button>`).join('');
}
/* Граммовку спрашиваем тут же, шагом внутри того же листа: продукт без
   веса в меню бесполезен, а второе окно поверх сносит первое. */
function spFoodPick(i){
  const f=SPFOOD.found[i],box=$('#spf_found');if(!f||!box)return;
  const wrap=$('#spf_wrap');if(wrap)wrap.hidden=true;
  box.innerHTML=`<div class="food-gram">
    <button class="textbtn" onclick="spFoodBack()">${icon('chevl')} К поиску</button>
    <div class="food-gram-name"><strong>${esc(f.name)}</strong>
      <small>${R(f.kcal)} ккал · Б ${f.protein} Ж ${f.fat} У ${f.carbs} / 100 г</small></div>
    <label>Сколько, граммов<input id="spf_g" type="number" inputmode="numeric" min="1" max="5000"
      value="${R(f.per_serving_g)||100}"></label>
    <div class="chip-row">${[50,100,150,200].map(n=>`<button class="chip" onclick="$('#spf_g').value=${n}">${n} г</button>`).join('')}</div>
    <button class="primary green wide" onclick="spFoodAdd(${f.id})">Добавить в меню</button></div>`;
}
function spFoodBack(){ const wrap=$('#spf_wrap');if(wrap)wrap.hidden=false; spFoodPaint(); }
async function spFoodAdd(ingId){
  const g=Math.round(+($('#spf_g')?.value||0));
  if(!(g>0&&g<=5000)){toast('Вес — от 1 до 5000 г','err');return}
  try{
    await api('/specialist/menus/'+A.menu.id+'/items',{method:'POST',body:JSON.stringify({
      day_number:A.day,meal_type:SPFOOD.meal,ingredient_id:ingId,portion_g:g})});
    closeModal();
    const mp=await api('/specialist/menus/'+A.menu.id);
    A.items=mp.items;spRenderMenu();
  }catch(e){toast(e.message,'err')}
}

async function spChooseDish(did,portion){const d=A.dishes.find(x=>x.id===did);const p=portion||R(d?.base_portion_g)||250;await api('/specialist/menus/'+A.menu.id+'/items',{method:'POST',body:JSON.stringify({day_number:A.day,meal_type:A.catMeal,dish_id:did,portion_g:p})});closeModal();const mp=await api('/specialist/menus/'+A.menu.id);A.items=mp.items;spRenderMenu()}
async function spDishRecipe(did){const j=await api('/specialist/dishes/'+did);const d=j.dish;let steps=[];try{steps=JSON.parse(d.steps||'[]')||[]}catch(e){}showModal(`<div class="sheet-head"><div><div class="eyebrow">${d.cook_minutes||'—'} мин</div><h2>${esc(d.name)}</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="drawer-photo" style="background-image:url(${esc(dishPhoto(d))})"></div><div class="dmac num" style="margin:8px 0 2px">${R(d.kcal_100)} ккал · Б ${R(d.protein_100)} · Ж ${R(d.fat_100)} · У ${R(d.carbs_100)} / 100 г</div><div class="sect">Состав</div><ul class="complist">${d.ingredients.map(i=>`<li><span>${esc(i.ingredient_name)}</span><b class="num">${R(i.grams)} г</b></li>`).join('')}</ul>${steps.length?`<div class="sect">Как готовить</div><div class="recipe-steps">${steps.map((s,i)=>`<div class="rstep">${s.photo_url?`<div class="rstep-photo" style="background-image:url(${esc(s.photo_url)})"></div>`:''}<div class="rstep-body"><b>Шаг ${i+1}</b><p>${esc(s.text||'')}</p></div></div>`).join('')}</div>`:(d.instructions?`<div class="sect">Как готовить</div><p class="lead">${esc(d.instructions)}</p>`:'')}${d.created_by&&d.created_by===A.user?.id?`<div class="modal-actions"><button class="secondary" onclick="spDishEditor(${d.id})">Редактировать</button><button class="dangerbtn" onclick="spDeleteDish(${d.id})">Удалить</button></div>`:''}`)}
async function spDishEditor(id){if(!A.ingredients.length){try{A.ingredients=(await api('/specialist/ingredients')).ingredients}catch(e){}}let d=null;if(id)d=(await api('/specialist/dishes/'+id)).dish;const rows=((d&&d.ingredients&&d.ingredients.length)?d.ingredients:[{}]).map(ingRow).join('');let steps=[];try{steps=JSON.parse(d?.steps||'[]')||[]}catch(e){}if(!steps.length)steps=[{}];showModal(`<div class="sheet-head"><div><div class="eyebrow">${id?'Редактирование':'Новое блюдо'}</div><h2>${id?esc(d.name):'Своё блюдо'}</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><form onsubmit="spSaveDish(event,${id||0})"><div class="dish-cover" id="dishcover" style="${d?.photo_url?`background-image:url(${esc(d.photo_url)})`:''}"><input type="file" accept="image/*" hidden onchange="spCoverPhoto(this)"><input type="hidden" id="d_photo" value="${esc(d?.photo_url||'')}"><button type="button" class="cover-btn" onclick="this.parentElement.querySelector('input[type=file]').click()">${icon('camera')} ${d?.photo_url?'Изменить фото':'Заглавное фото'}</button></div><label>Название<input id="d_n" required value="${esc(d?.name||'')}"></label><div class="formgrid"><label>Время, мин<input id="d_t" type="number" value="${d?.cook_minutes||15}"></label><label>Тип приёма<select id="d_m">${[['breakfast','Завтрак'],['lunch','Обед'],['dinner','Ужин'],['snack1','Перекус']].map(([v,l])=>`<option value="${v}">${l}</option>`).join('')}</select></label></div><div class="sect editrow">Состав<button type="button" class="link" onclick="spAddIngRow()">${icon('plus')} ингредиент</button></div><div id="ingrows">${rows}</div><div class="dish-macros" id="dishmacros"></div><div class="sect editrow">Как готовить<button type="button" class="link" onclick="spAddStep()">${icon('plus')} шаг</button></div><div id="steprows">${steps.map(stepRow).join('')}</div><label>Теги (через запятую)<input id="d_tags" placeholder="быстро, бюджетно"></label><button class="primary wide">${id?'Сохранить блюдо':'Создать блюдо'}</button></form>`);recalcDish()}
function ingRow(x){x=x||{};const nm=x.ingredient_id?(((A.ingredients||[]).find(a=>a.id==x.ingredient_id)||{}).name||''):'';return `<div class="ingrow"><div class="ing-pick"><span class="ing-sic">${icon('search')}</span><input class="ing-search" data-ingname autocomplete="off" placeholder="Найдите продукт…" value="${esc(nm)}" oninput="ingFilter(this)" onfocus="ingFilter(this)" onblur="ingBlur(this)"><input type="hidden" data-ing value="${x.ingredient_id||''}"><div class="ing-drop" hidden></div></div><div class="ing-g"><input data-g type="number" min="1" value="${x.grams||100}" oninput="recalcDish()"><i>г</i></div><button type="button" class="iconbtn" onclick="this.closest('.ingrow').remove();recalcDish()">${icon('x')}</button></div>`}
function ingFilter(inp){const q=inp.value.trim().toLowerCase();const drop=inp.parentElement.querySelector('.ing-drop');const list=(A.ingredients||[]).filter(a=>!q||(a.name||'').toLowerCase().includes(q)).slice(0,40);drop.innerHTML=list.length?list.map(a=>`<button type="button" class="ing-opt" onmousedown="event.preventDefault();ingPick(this,${a.id})"><span>${esc(a.name)}</span><small class="num">${R(a.kcal)} ккал · Б${R(a.protein)} Ж${R(a.fat)} У${R(a.carbs)}</small></button>`).join(''):'<div class="ing-opt none muted">Ничего не найдено</div>';drop.hidden=false}
function ingPick(btn,id){const a=(A.ingredients||[]).find(x=>x.id==id);const pick=btn.closest('.ing-pick');pick.querySelector('[data-ing]').value=id;pick.querySelector('[data-ingname]').value=a?a.name:'';pick.querySelector('.ing-drop').hidden=true;recalcDish()}
function ingBlur(inp){setTimeout(()=>{const d=inp.parentElement&&inp.parentElement.querySelector('.ing-drop');if(d)d.hidden=true},160)}
function spAddIngRow(){$('#ingrows').insertAdjacentHTML('beforeend',ingRow({}));recalcDish()}
function recalcDish(){let g=0,k=0,p=0,f=0,c=0;document.querySelectorAll('#ingrows .ingrow').forEach(r=>{const id=+r.querySelector('[data-ing]').value;const gr=+r.querySelector('[data-g]').value||0;const a=(A.ingredients||[]).find(x=>x.id==id);if(!a||!gr)return;g+=gr;k+=(+a.kcal||0)*gr/100;p+=(+a.protein||0)*gr/100;f+=(+a.fat||0)*gr/100;c+=(+a.carbs||0)*gr/100});const el=$('#dishmacros');if(!el)return;if(!g){el.innerHTML='<div class="dm-empty muted small">Добавьте продукты — калорийность и КБЖУ посчитаются автоматически</div>';return}const per=x=>R(x/g*100);el.innerHTML=`<div class="dm-grid"><div class="dm-cell kcal"><b class="num">${R(k)}</b><span>ккал всего</span></div><div class="dm-cell"><b class="num">${R(p)}<i>г</i></b><span>Белки</span></div><div class="dm-cell"><b class="num">${R(f)}<i>г</i></b><span>Жиры</span></div><div class="dm-cell"><b class="num">${R(c)}<i>г</i></b><span>Углеводы</span></div><div class="dm-cell out"><b class="num">${R(g)}<i>г</i></b><span>Выход</span></div></div><div class="dm-per num">На 100 г: <b>${per(k)}</b> ккал · Б ${per(p)} · Ж ${per(f)} · У ${per(c)}</div>`}
function stepRow(s){s=s||{};return `<div class="step-row"><div class="step-photo" style="${s.photo_url?`background-image:url(${esc(s.photo_url)})`:''}"><input type="file" accept="image/*" hidden onchange="spStepPhoto(this)"><input type="hidden" data-sphoto value="${esc(s.photo_url||'')}"><button type="button" class="step-cam" onclick="this.parentElement.querySelector('input[type=file]').click()">${s.photo_url?'':icon('camera')}</button></div><textarea data-step placeholder="Опишите шаг приготовления…">${esc(s.text||'')}</textarea><button type="button" class="iconbtn" onclick="this.closest('.step-row').remove()">${icon('x')}</button></div>`}
function spAddStep(){$('#steprows').insertAdjacentHTML('beforeend',stepRow({}))}
async function uploadImage(file){const fd=new FormData();fd.append('photo',file);const j=await api('/specialist/upload',{method:'POST',body:fd});return j.url}
async function spCoverPhoto(inp){if(!inp.files[0])return;try{const url=await uploadImage(inp.files[0]);$('#d_photo').value=url;$('#dishcover').style.backgroundImage='url('+url+')';const b=$('#dishcover .cover-btn');if(b)b.innerHTML=icon('camera')+' Изменить фото'}catch(e){toast(e.message,'err')}}
async function spStepPhoto(inp){if(!inp.files[0])return;try{const url=await uploadImage(inp.files[0]);const row=inp.closest('.step-row');row.querySelector('[data-sphoto]').value=url;row.querySelector('.step-photo').style.backgroundImage='url('+url+')';const cam=row.querySelector('.step-cam');if(cam)cam.innerHTML=''}catch(e){toast(e.message,'err')}}
async function spSaveDish(e,id){e.preventDefault();const ings=[...document.querySelectorAll('.ingrow')].map(r=>({ingredient_id:+r.querySelector('[data-ing]').value,grams:+r.querySelector('[data-g]').value})).filter(x=>x.ingredient_id&&x.grams);if(!ings.length){toast('Добавьте хотя бы один ингредиент','err');return}const steps=[...document.querySelectorAll('.step-row')].map(r=>({text:r.querySelector('[data-step]').value.trim(),photo_url:r.querySelector('[data-sphoto]').value||null})).filter(s=>s.text||s.photo_url);const body={name:$('#d_n').value,cook_minutes:+$('#d_t').value,meal_types:[$('#d_m').value],photo_url:$('#d_photo').value||null,steps,instructions:steps.map(s=>s.text).filter(Boolean).join('\n'),ingredients:ings,tags:$('#d_tags').value.split(',').map(s=>s.trim()).filter(Boolean)};try{await api(id?'/specialist/dishes/'+id:'/specialist/dishes',{method:id?'PATCH':'POST',body:JSON.stringify(body)});closeModal();spDishes()}catch(x){toast(x.message,'err')}}
async function spDeleteDish(id){if(!confirm('Удалить блюдо?'))return;await api('/specialist/dishes/'+id,{method:'DELETE'});closeModal();spDishes()}
async function spIngredients(){const j=await api('/specialist/ingredients');A.ingredients=j.ingredients;go(spShell(`${navBar('Продукты','spBackToMore()',`<button class="nb-act" aria-label="Новый продукт" onclick="spIngEditor()">${icon('plus')}</button>`)}${dishSeg('ing')}<div class="searchbox full" style="margin-bottom:14px">${icon('search')}<input placeholder="Поиск ингредиента…" oninput="spRenderIng(this.value)"></div><div id="inglist" class="ing-list"></div>`,'dishes'));spRenderIng('')}
function spRenderIng(q){q=(q||'').toLowerCase();const ds=(A.ingredients||[]).filter(d=>!q||(d.name||'').toLowerCase().includes(q));const el=$('#inglist');if(!el)return;el.innerHTML=ds.slice(0,200).map(i=>`<div class="ing-row"><div class="grow"><strong>${esc(i.name)}</strong><span class="muted">${esc(i.category||'Прочее')}</span></div><div class="ing-macros num">${R(i.kcal)} ккал · Б ${R(i.protein)} · Ж ${R(i.fat)} · У ${R(i.carbs)}</div></div>`).join('')||'<div class="empty small">Ничего не найдено</div>';stagger(el)}
function spIngEditor(){showModal(`<div class="sheet-head"><div><div class="eyebrow">Новый ингредиент</div><h2>Добавить ингредиент</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><form onsubmit="spSaveIng(event)" class="formgrid"><label class="full">Название<input id="i_n" required></label><label>Категория<input id="i_c" placeholder="Белок"></label><label>Ккал / 100 г<input id="i_k" type="number" value="0"></label><label>Белки<input id="i_p" type="number" value="0"></label><label>Жиры<input id="i_f" type="number" value="0"></label><label>Углеводы<input id="i_cb" type="number" value="0"></label><label>Клетчатка<input id="i_fi" type="number" value="0"></label><label>Коэф. варки<input id="i_r" type="number" step="0.1" value="1"></label><button class="primary wide full">Создать</button></form>`)}
async function spSaveIng(e){e.preventDefault();try{await api('/specialist/ingredients',{method:'POST',body:JSON.stringify({name:$('#i_n').value,category:$('#i_c').value,kcal:+$('#i_k').value,protein:+$('#i_p').value,fat:+$('#i_f').value,carbs:+$('#i_cb').value,fiber:+$('#i_fi').value,cooked_ratio:+$('#i_r').value||1})});closeModal();spIngredients()}catch(x){toast(x.message,'err')}}
function plural(n,f){n=Math.abs(n)%100;const n1=n%10;if(n>10&&n<20)return f[2];if(n1>1&&n1<5)return f[1];if(n1===1)return f[0];return f[2]}
/* Дни меню человек держит в голове датами, а не порядковыми номерами:
   «день 3» ничего не говорит, «среда, 9 сентября» — говорит всё. */
const WD_SHORT=['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
const WD_FULL=['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'];
function menuDate(start,day){return addDays(start,day-1)}
function dayTitle(start,day,full){const iso=menuDate(start,day);if(!iso)return 'День '+day;const d=new Date(iso+'T00:00:00');
  const name=(full?WD_FULL:WD_SHORT)[d.getDay()];
  const md=d.toLocaleDateString('ru-RU',{day:'numeric',month:full?'long':'short'});
  return name+', '+md}
/* Шапка дня: крупно число с месяцем, под ним день недели — «Воскресенье,
   6 сентября» в один h1 не влезает и переносится на две строки. */
function dayHeadTitle(start,day){const iso=menuDate(start,day);if(!iso)return 'День '+day;
  return new Date(iso+'T00:00:00').toLocaleDateString('ru-RU',{day:'numeric',month:'long'})}
function dayHeadSub(start,day,fallback){const iso=menuDate(start,day);if(!iso)return fallback||'';
  return WD_FULL[new Date(iso+'T00:00:00').getDay()]+(isToday(iso)?' · сегодня':'')}
/* menuDate отдаёт ISO-строку, поэтому день недели считаем от неё */
const dowShort=iso=>iso?WD_SHORT[new Date(iso+'T00:00:00').getDay()]:'';
const dayNum=iso=>iso?new Date(iso+'T00:00:00').getDate():'';
function isToday(iso){const n=new Date();const pad=x=>String(x).padStart(2,'0');
  return iso===n.getFullYear()+'-'+pad(n.getMonth()+1)+'-'+pad(n.getDate())}
function addDays(dateStr,n){if(!dateStr)return '';const d=new Date(dateStr+'T00:00:00');if(isNaN(d))return '';d.setDate(d.getDate()+n);return d.toISOString().slice(0,10)}
const MON_RU=['янв','фев','мар','апр','мая','июн','июл','авг','сен','окт','ноя','дек'];
function fmtD(dateStr){if(!dateStr)return '';const d=new Date(dateStr+'T00:00:00');if(isNaN(d))return esc(dateStr);return d.getDate()+' '+MON_RU[d.getMonth()]}
function spGoWeek(w){const weeks=Math.ceil((A.menu.days_count||7)/7);w=Math.min(weeks,Math.max(1,w));A.day=(w-1)*7+1;spRenderMenu()}
async function spTemplates(){const j=await api('/specialist/templates');A.templates=j.templates;const t=j.templates;go(spShell(`${navBar('Шаблоны','spBackToMore()')}<div class="tmpl-list">${t.length?t.map(x=>{const d=+x.days_count||0,it=+x.items_count||0;return `<div class="tmpl card"><div class="tmpl-ic">${icon('layers')}</div><div class="grow"><strong>${esc(x.name)}</strong><div class="tmpl-meta"><span>${d} ${plural(d,['день','дня','дней'])}</span><i>·</i><span>${it} ${plural(it,['блюдо','блюда','блюд'])}</span><i>·</i><span class="muted">${esc((x.created_at||'').slice(0,10))}</span></div></div><div class="tmpl-acts"><button class="primary green sm" onclick="spApplyTemplate(${x.id})">Применить</button><button class="iconbtn danger" title="Удалить" onclick="spDeleteTemplate(${x.id})">${icon('trash')}</button></div></div>`}).join(''):`<div class="empty"><div class="orb">${icon('layers')}</div><h3>Пока нет шаблонов</h3><p>Сохраните любое меню как шаблон: карточка клиента → «Меню» → «…» → «Сохранить как шаблон». Потом сможете применять его в новых меню.</p></div>`}</div>`,'templates'))}
async function spApplyTemplate(tid){const t=(A.templates||[]).find(x=>x.id===tid);let cs=A.clientsCache;if(!cs){cs=(await api('/specialist/clients')).clients;A.clientsCache=cs}showModal(`<div class="sheet-head"><div><div class="eyebrow">Шаблон${t?' · '+esc(t.name):''}</div><h2>Кому применить</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><p class="muted" style="margin:-4px 0 12px">Создаст новое меню-черновик для выбранного клиента.</p><div class="picker-list">${cs.length?cs.map(c=>`<button class="picker-row" onclick="spApplyTemplateTo(${tid},${c.id})">${av(c.name,'',c.avatar_url)}<div class="grow"><strong>${esc(c.name)}</strong><span class="muted">${esc(c.goal||'Цель не задана')}</span></div>${icon('chevr')}</button>`).join(''):'<div class="empty small">Нет клиентов</div>'}</div>`)}
async function spApplyTemplateTo(tid,cid){try{const r=await api('/specialist/templates/'+tid+'/apply',{method:'POST',body:JSON.stringify({client_id:cid})});closeModal();spClient(cid,'menu')}catch(e){toast(e.message,'err')}}
async function spDeleteTemplate(tid){if(!confirm('Удалить шаблон? Это не затронет уже созданные меню.'))return;await api('/specialist/templates/'+tid,{method:'DELETE'});spTemplates()}
async function spAnalytics(){const d=await api('/specialist/dashboard');const cs=(await api('/specialist/clients')).clients;const goals={};cs.forEach(c=>{const g=c.goal||'Не задана';goals[g]=(goals[g]||0)+1});
const N=cs.length||1;const active=cs.filter(c=>c.last_activity&&(Date.now()-new Date(c.last_activity.replace(' ','T')+'Z'))<6048e5).length;
const bands=[['Отлично · ≥80%','g',cs.filter(c=>c.compliance!=null&&c.compliance>=80).length],['Средне · 55–79%','a',cs.filter(c=>c.compliance!=null&&c.compliance>=55&&c.compliance<80).length],['Низкая · <55%','r',cs.filter(c=>c.compliance!=null&&c.compliance<55).length],['Нет данных','mut',cs.filter(c=>c.compliance==null).length]];
go(spShell(`${navBar('Аналитика','spBackToMore()')}
<div class="stat-grid"><div class="stat card"><div class="stat-ic good">${icon('users')}</div><div><b class="num">${cs.length}</b><span>Всего клиентов</span></div></div><div class="stat card"><div class="stat-ic info">${icon('menu')}</div><div><b class="num">${d.published_menus}</b><span>Опубликовано меню</span></div></div><div class="stat card"><div class="ring-wrap">${ring(d.avg_adherence??0,52,d.avg_adherence==null?'—':d.avg_adherence+'%')}</div><div><b class="num">${d.avg_adherence==null?'—':d.avg_adherence+'%'}</b><span>Ср. приверженность</span></div></div><div class="stat card"><div class="stat-ic good">${icon('trend')}</div><div><b class="num">${d.avg_weight_delta==null?'—':(d.avg_weight_delta>0?'+':'')+kg(d.avg_weight_delta)+' кг'}</b><span>Ср. динамика веса</span></div></div></div>
<div class="an-grid">
<div class="card pad"><div class="an-head"><h3>Приверженность клиентов</h3></div><div class="an-stack">${bands.map(([l,c2,n])=>`<div class="an-seg ${c2}" style="flex:${n||0.0001}" title="${l}: ${n}"></div>`).join('')}</div><div class="an-legend">${bands.map(([l,c2,n])=>`<div class="an-leg"><span class="an-dot ${c2}"></span>${esc(l)}<b>${n}</b></div>`).join('')}</div></div>
<div class="card pad"><div class="an-head"><h3>Активность за неделю</h3></div><div class="an-ring">${ring(Math.round(active/N*100),96,active+' / '+cs.length)}</div><p class="muted small" style="text-align:center;margin-top:8px">${active} из ${cs.length} заходили за 7 дней</p></div>
</div>
<div class="panel-title"><h2>Клиенты по целям</h2></div><div class="sec-pad"><div class="card pad">${Object.entries(goals).sort((a,b)=>b[1]-a[1]).map(([g,n])=>`<div class="goalbar"><span>${esc(g)}</span><div class="gb-track"><i style="width:${cs.length?Math.round(n/cs.length*100):0}%"></i></div><b class="num">${n}</b></div>`).join('')||'<div class="muted small">Пока нет клиентов</div>'}</div></div>`,'analytics'))}

/* ---------- modal / sheet ---------- */

async function spPublishCurrent(){if(!A.menu){toast('Сначала откройте вкладку «Меню».','err');return}await api('/specialist/menus/'+A.menu.id+'/publish',{method:'POST'});const mp=await api('/specialist/menus/'+A.menu.id);A.menu=mp.menu;toast('Меню опубликовано и отправлено клиенту ✓','ok')}
function spMenuTools(){if(!A.menu){spClient(A.client.id,'menu');return}showModal(`<div class="sheet-head"><div><div class="eyebrow">Меню</div><h2>Действия</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="action-list"><button onclick="spDuplicate()">Дублировать меню на неделю ${icon('chevr')}</button><button onclick="spMakeTemplate()">Сохранить как шаблон ${icon('chevr')}</button></div>`)}
async function spDuplicate(){await api('/specialist/menus/'+A.menu.id+'/duplicate',{method:'POST',body:JSON.stringify({start_date:new Date(Date.now()+7*864e5).toISOString().slice(0,10)})});closeModal();toast('Копия создана','ok')}
async function spMakeTemplate(){const n=prompt('Название шаблона','Сбалансированная неделя');if(!n)return;await api('/specialist/templates',{method:'POST',body:JSON.stringify({name:n,source_menu_id:A.menu.id})});closeModal();toast('Шаблон сохранён','ok')}
function spCopyDay(){showModal(`<div class="sheet-head"><div><div class="eyebrow">Копирование</div><h2>День ${A.day} →</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="daygrid">${Array.from({length:A.menu.days_count},(_,i)=>`<button class="day ${i+1===A.day?'active':''}" ${i+1===A.day?'disabled':''} onclick="spDoCopy(${i+1})"><small>ДЕНЬ</small><b>${i+1}</b></button>`).join('')}</div>`)}
async function spDoCopy(to){await api('/specialist/menus/'+A.menu.id+'/copy-day',{method:'POST',body:JSON.stringify({from_day:A.day,to_day:to})});closeModal();const mp=await api('/specialist/menus/'+A.menu.id);A.items=mp.items;spRenderMenu()}

async function spTabProfile(){const j=await api('/specialist/clients/'+A.client.id+'/profile');const c=j.client,p=j.preferences||{};const arr=v=>{try{return JSON.parse(v||'[]')||[]}catch{return[]}};
const likes=arr(p.likes),dis=arr(p.dislikes),exc=arr(p.excluded);const chipsOf=(a,cls)=>a.length?a.map(x=>`<span class="pref-chip ${cls}">${esc(x)}</span>`).join(''):'<span class="muted small">не указано</span>';
$('#tabbody').innerHTML=`<button class="backlink sm" onclick="spClient(A.client.id,'overview')">${icon('back')} К обзору</button><div class="prof-grid"><div class="card pad span2"><h3>Целевые показатели</h3><div class="targets">${[['Ккал',c.target_kcal,''],['Белки',c.target_protein,'г'],['Жиры',c.target_fat,'г'],['Углеводы',c.target_carbs,'г']].map(([l,v,u])=>`<div class="tgt"><b class="num">${v||'—'}${u&&v?'<i>'+u+'</i>':''}</b><span>${l}</span></div>`).join('')}</div></div>
<div class="card pad span2 pref-cards"><h3>Предпочтения в питании</h3><div class="pref-grid"><div class="pref-col"><div class="pref-h like">${icon('check')} Любит</div><div class="pref-list">${chipsOf(likes,'like')}</div></div><div class="pref-col"><div class="pref-h dislike">${icon('x')} Не любит</div><div class="pref-list">${chipsOf(dis,'dislike')}</div></div><div class="pref-col"><div class="pref-h excl">${icon('bell')} Ограничения</div><div class="pref-list">${chipsOf(exc,'excl')}</div></div></div></div>
<form class="card pad" onsubmit="spSaveProfile(event)"><h3>Анкета клиента</h3><div class="formgrid"><label class="full">Цель<input id="pf_goal" value="${esc(c.goal||'')}"></label><label>Пол<select id="pf_sex"><option value="">—</option><option value="f" ${c.sex==='f'?'selected':''}>Женский</option><option value="m" ${c.sex==='m'?'selected':''}>Мужской</option></select></label><label>Возраст<input id="pf_age" type="number" min="10" max="100" value="${c.birth_year?(new Date().getFullYear()-c.birth_year):''}"></label><label>Рост, см<input id="pf_h" type="number" value="${c.height_cm||''}"></label><label>Вес, кг<input id="pf_w" type="number" step="0.1" value="${c.weight_kg||''}"></label><label>Активность<input id="pf_act" value="${esc(c.activity_level||'')}"></label><label>Ккал<input id="pf_k" type="number" value="${c.target_kcal||''}"></label><label>Белки<input id="pf_p" type="number" value="${c.target_protein||''}"></label><label>Жиры<input id="pf_f" type="number" value="${c.target_fat||''}"></label><label>Углеводы<input id="pf_c" type="number" value="${c.target_carbs||''}"></label></div><button class="primary wide">Сохранить анкету</button></form>
<form class="card pad" onsubmit="spSavePrefs(event)"><h3>Предпочтения</h3><label>Любит (через запятую)<input id="pr_l" value="${esc(arr(p.likes).join(', '))}"></label><label>Не любит<input id="pr_d" value="${esc(arr(p.dislikes).join(', '))}"></label><label>Исключения (аллергии и т.п.)<input id="pr_e" value="${esc(arr(p.excluded).join(', '))}"></label><label class="switch"><input id="pr_a" type="checkbox" ${p.allowed_replacements?'checked':''}><span>Разрешить самостоятельные замены блюд</span></label><button class="primary wide">Сохранить предпочтения</button></form></div>`}
async function spSaveProfile(e){e.preventDefault();await api('/specialist/clients/'+A.client.id,{method:'PATCH',body:JSON.stringify({goal:$('#pf_goal').value,sex:$('#pf_sex').value,birth_year:(+$('#pf_age').value?new Date().getFullYear()-(+$('#pf_age').value):null),height_cm:+$('#pf_h').value||null,weight_kg:+$('#pf_w').value||null,activity_level:$('#pf_act').value,target_kcal:+$('#pf_k').value||null,target_protein:+$('#pf_p').value||null,target_fat:+$('#pf_f').value||null,target_carbs:+$('#pf_c').value||null})});const c=await api('/specialist/clients/'+A.client.id);A.client=c.client;toast('Анкета сохранена ✓','ok')}
async function spSavePrefs(e){e.preventDefault();const split=v=>v.split(',').map(s=>s.trim()).filter(Boolean);await api('/specialist/clients/'+A.client.id+'/preferences',{method:'PATCH',body:JSON.stringify({likes:split($('#pr_l').value),dislikes:split($('#pr_d').value),excluded:split($('#pr_e').value),allowed_replacements:$('#pr_a').checked?1:0})});toast('Предпочтения сохранены ✓','ok')}

async function spTabProgress(){const j=await api('/specialist/clients/'+A.client.id+'/profile');const pr=await api('/specialist/clients/'+A.client.id+'/progress');const ws=pr.weights;const last=ws.at(-1)?.weight_kg,first=ws[0]?.weight_kg;const delta=last&&first?last-first:null;
$('#tabbody').innerHTML=`<div class="prog-grid"><div class="card pad"><div class="section-head"><h3>Вес</h3><span class="delta ${delta<0?'good':''}">${delta==null?'':(delta>0?'+':'')+kg(delta)+' кг'}</span></div>${weightChart(ws)}<div class="hist">${ws.slice().reverse().slice(0,6).map(w=>`<div class="hrow"><small>${esc(w.measured_on)}</small><b class="num">${kg(w.weight_kg)} кг</b></div>`).join('')||'<div class="muted small">Нет измерений</div>'}</div></div>
<div class="card pad"><h3>Замеры</h3><div class="hist">${(j.measurements||[]).slice(0,8).map(mz=>`<div class="hrow"><small>${esc(mz.measured_on)}</small><b class="num">Талия ${mz.waist_cm||'—'} · Бёдра ${mz.hips_cm||'—'} · Грудь ${mz.chest_cm||'—'}</b></div>`).join('')||'<div class="muted small">Пока нет замеров</div>'}</div><h3 style="margin-top:18px">Фото прогресса</h3><div class="photo-grid">${(j.photos||[]).map(p=>`<img src="${esc(p.photo_url)}" alt="">`).join('')||'<div class="muted small">Фото пока не добавлены</div>'}</div></div></div>`}

async function spSendChat(e){
  e.preventDefault();
  const el=$('#ci'),v=el.value.trim();if(!v)return;
  el.value='';
  try{
    const r=await api('/specialist/messages',{method:'POST',body:JSON.stringify({client_id:A.client.id,body:v})});
    if(r&&r.message)chatAppend([r.message]);
  }catch(err){el.value=v;toast(err.message||'Не отправилось','err')}
}

async function spTabActivity(){let wr={};try{wr=await api('/specialist/weekly-report?client_id='+A.client.id)}catch(e){}let notes={notes:[]};try{notes=await api('/specialist/clients/'+A.client.id+'/notes')}catch(e){}let fb={feedback:[]};try{fb=await api('/specialist/clients/'+A.client.id+'/feedback')}catch(e){}
let fl={days:[]};try{fl=await api('/specialist/clients/'+A.client.id+'/food-log')}catch(e){}
const feed=[];(notes.notes||[]).forEach(n=>feed.push({t:n.created_at,ic:'edit',title:'Заметка специалиста',text:n.body}));(fb.feedback||[]).forEach(f=>feed.push({t:f.created_at,ic:'x',title:'Пропуск: '+MEAL[f.meal_type]+' · '+f.dish_name,text:f.reason||'без причины'}));if(wr.checkin)feed.push({t:wr.checkin.created_at||wr.period?.to,ic:'check',title:'Weekly check-in',text:'Лёгкость '+(wr.checkin.ease_score||'—')+'/5, самочувствие '+(wr.checkin.wellbeing_score??'—')});feed.sort((a,b)=>String(b.t).localeCompare(String(a.t)));
$('#tabbody').innerHTML=`<button class="backlink sm" onclick="spClient(A.client.id,'overview')">${icon('back')} К обзору</button><div class="prog-grid"><div class="card pad"><h3>Сводка недели</h3><div class="stat-grid two"><div class="stat-in"><b class="num">${wr.adherence??'—'}%</b><span>Приверженность</span></div><div class="stat-in"><b class="num">${wr.weight_delta==null?'—':(wr.weight_delta>0?'+':'')+kg(wr.weight_delta)+' кг'}</b><span>Вес за неделю</span></div><div class="stat-in"><b class="num">${wr.avg_kcal??'—'}</b><span>Ср. ккал меню</span></div><div class="stat-in"><b class="num">${wr.eaten??0}/${wr.logged??0}</b><span>Отмечено приёмов</span></div></div>
<form class="note-add" onsubmit="spAddNote(event)"><input id="note" placeholder="Добавить заметку о клиенте…"><button class="primary send">${icon('plus')}</button></form></div>
<div class="card pad"><h3>Лента активности</h3><div class="feed">${feed.length?feed.map(f=>`<div class="feed-row"><span class="feed-ic">${icon(f.ic)}</span><div><strong>${esc(f.title)}</strong><span>${esc(f.text)}</span><small>${esc((f.t||'').slice(0,16).replace('T',' '))}</small></div></div>`).join(''):'<div class="muted small">Пока нет событий</div>'}</div></div>
${spFoodLog(fl)}</div>`}

/* Съеденное мимо меню — специалисту. Без этого он смотрит на
   «съедено 30%» и строит догадки, почему вес стоит: половина
   съеденного просто не попадала ему на глаза. */
function spFoodLog(fl){
  const days=(fl&&fl.days)||[];
  if(!days.length)return `<div class="card pad"><h3>Ел не по меню</h3>
    <p class="muted small">За две недели таких записей нет.</p></div>`;
  return `<div class="card pad"><h3>Ел не по меню</h3>
    <p class="muted small" style="margin:-4px 0 12px">За две недели. Это съеденное сверх меню или вместо него — в соблюдение меню не входит, но в калории дня входит.</p>
    <div class="feed">${days.map(d=>`<div class="feed-row">
      <span class="feed-ic">${icon('bowl')}</span>
      <div><strong>${esc(hDay(d.date))} · ${R(d.totals.kcal)} ккал</strong>
        <span>${d.entries.map(e=>esc(e.meal_title)+': '+e.items.map(i=>esc(i.name)+' '+R(i.grams)+' г').join(', ')).join(' · ')}</span>
        <small>Б ${d.totals.protein} · Ж ${d.totals.fat} · У ${d.totals.carbs}</small></div>
    </div>`).join('')}</div></div>`;
}
async function spAddNote(e){e.preventDefault();const v=$('#note').value.trim();if(!v)return;await api('/specialist/clients/'+A.client.id+'/notes',{method:'POST',body:JSON.stringify({body:v})});spTabActivity()}

async function spChatList(){const j=await api('/specialist/clients');A.clientsCache=j.clients.slice().sort((a,b)=>(b.unread?1:0)-(a.unread?1:0)||String(b.last_msg_at||'').localeCompare(String(a.last_msg_at||''))||String(a.name).localeCompare(String(b.name)));const total=unreadOf(A.clientsCache);A.unread=total;go(spShell(`<div class="msgr" id="msgr"><aside class="msgr-list"><div class="msgr-lhead"><h1>Сообщения</h1><p class="muted small" style="margin:-2px 0 12px">${total?total+' непрочитанных':'Переписки с клиентами'}</p><div class="searchbox"><span>${icon('search')}</span><input id="chq" placeholder="Поиск диалога…" oninput="spFilterInbox(this.value)"></div></div><div id="inbox" class="inbox"></div></aside><section class="msgr-thread" id="msgrThread"><div class="msgr-empty">${icon('chat')}<p>Выберите диалог,<br>чтобы начать переписку</p></div></section></div>`,'chat'));spRenderInbox('');const first=(A.clientsCache||[])[0];if(first&&window.innerWidth>860)spOpenThread(first.id)}
function spFilterInbox(v){spRenderInbox(v)}
function spRenderInbox(q){q=(q||'').toLowerCase();const cs=(A.clientsCache||[]).filter(c=>!q||(c.name||'').toLowerCase().includes(q));const el=$('#inbox');if(!el)return;el.innerHTML=cs.map(c=>`<button class="inbox-row ${A._openThread===c.id?'active':''}" onclick="spOpenThread(${c.id})">${av(c.name,'',c.avatar_url)}<div class="grow"><div class="inbox-top"><strong>${esc(c.name)}</strong><small>${c.last_msg_at?timeShort(c.last_msg_at):''}</small></div><div class="inbox-prev ${c.unread?'unread-prev':''}">${c.last_msg?esc(c.last_msg):'<i>Начните переписку</i>'}</div></div>${c.unread?`<b class="unread">${c.unread}</b>`:''}</button>`).join('')||`<div class="empty small">Никого не найдено</div>`}
/* Как и у клиента: сообщение встаёт на место, а не перезагружает
   диалог. Список слева обновляем точечно — там меняется одна строка. */
async function spSendThread(e,id){
  e.preventDefault();
  const el=$('#ci'),v=el.value.trim();if(!v)return;
  el.value='';
  let r=null;
  try{ r=await api('/specialist/messages',{method:'POST',body:JSON.stringify({client_id:id,body:v})}) }
  catch(err){ el.value=v;toast(err.message||'Не отправилось','err');return }
  if(r&&r.message)chatAppend([r.message]);
  const c=(A.clientsCache||[]).find(x=>x.id===id);
  if(c){c.last_msg=v;c.last_msg_at=new Date().toISOString();c.unread=0;spRenderInbox($('#chq')?.value||'')}
}
function spBackToList(){A._openThread=null;$('#msgr')?.classList.remove('show-thread');spRenderInbox($('#chq')?.value||'')}
async function spThreadAttach(inp,id){if(!inp.files||!inp.files[0])return;const f=inp.files[0];inp.value='';try{const url=await uploadImage(f);await api('/specialist/messages',{method:'POST',body:JSON.stringify({client_id:id,attachment_url:url})});const c=(A.clientsCache||[]).find(x=>x.id===id);if(c){c.last_msg='📎 Вложение';c.last_msg_at=new Date().toISOString()}spOpenThread(id)}catch(e){toast(e.message||'Не удалось загрузить файл','err')}}
async function spLeadRead(id){await api('/specialist/leads/'+id+'/read',{method:'POST'});spHome()}
function dishSeg(a){return `<div class="seg-tabs">${[['dishes','Блюда','spDishes()'],['ing','Ингредиенты','spIngredients()']].map(([k,l,fn])=>`<button class="seg-tab ${a===k?'active':''}" onclick="${fn}">${l}</button>`).join('')}</div>`}
async function spDishes(){const j=await api('/specialist/dishes');A.dishes=j.dishes;if(!A.dishSource)A.dishSource='all';if(!A.dishMeal)A.dishMeal='all';A.dishQ='';
go(spShell(`${navBar('База блюд','spBackToMore()',`<button class="nb-act" aria-label="Новое блюдо" onclick="spDishEditor()">${icon('plus')}</button>`)}${dishSeg('dishes')}<div class="searchbox full" style="margin-bottom:12px">${icon('search')}<input value="${esc(A.dishQ||'')}" placeholder="Поиск блюд…" oninput="A.dishQ=this.value;spRenderDishPage()"></div>
<div class="dish-filters">
  <div class="seg-mini" id="dsrc">${[['all','Все'],['public','Общая база'],['mine','Мои']].map(([k,l])=>`<button class="segm ${A.dishSource===k?'active':''}" data-k="${k}" onclick="A.dishSource='${k}';spRenderDishPage()">${l}</button>`).join('')}</div>
  <div class="chip-row" id="dmeal">${[['all','Все'],['breakfast','Завтрак'],['lunch','Обед'],['dinner','Ужин'],['snack1','Перекус']].map(([k,l])=>`<button class="chip ${A.dishMeal===k?'active':''}" data-k="${k}" onclick="A.dishMeal='${k}';spRenderDishPage()">${l}</button>`).join('')}</div>
</div>
<div id="dishcount" class="muted small"></div><div id="dishpage" class="dish-page"></div>`,'dishes'));spRenderDishPage()}
function spFilterDishPage(v){A.dishQ=v;spRenderDishPage()}
function spRenderDishPage(){const q=(A.dishQ||'').toLowerCase();let ds=(A.dishes||[]);
if(A.dishSource==='public')ds=ds.filter(d=>+d.is_public===1);else if(A.dishSource==='mine')ds=ds.filter(d=>+d.is_public===0);
if(A.dishMeal&&A.dishMeal!=='all')ds=ds.filter(d=>{try{return (JSON.parse(d.meal_types||'[]')||[]).includes(A.dishMeal)}catch{return false}});
if(q)ds=ds.filter(d=>(d.name||'').toLowerCase().includes(q));
document.querySelectorAll('#dsrc .segm').forEach(b=>b.classList.toggle('active',b.dataset.k===A.dishSource));
document.querySelectorAll('#dmeal .chip').forEach(b=>b.classList.toggle('active',b.dataset.k===A.dishMeal));
if($('#dishcount'))$('#dishcount').textContent=`${ds.length} ${plural(ds.length,['блюдо','блюда','блюд'])}`;

/* Каталог в полсотни блюд одним списком листать бессмысленно, поэтому,
   когда приём не выбран, раскладываем по приёмам с подзаголовками —
   как секции в приложении. Блюдо попадает в раздел первого своего
   приёма, иначе оно двоилось бы. */
const tile=d=>`<button class="dish-tile card" onclick="spDishRecipe(${d.id})"><span class="tile-photo" style="background-image:url(${esc(dishThumb(d))})">${+d.is_public===0?'<i class="tile-badge">Моё</i>':''}</span><h3>${esc(d.name)}</h3><div class="muted small num">${R(d.kcal_100)} ккал/100 г</div><div class="mm num">Б ${R(d.protein_100)} · Ж ${R(d.fat_100)} · У ${R(d.carbs_100)}</div></button>`;
const mealsOf=d=>{try{return JSON.parse(d.meal_types||'[]')||[]}catch{return []}};
const NO_MEAL='Без приёма';
ds=ds.slice().sort((a,b)=>(a.name||'').localeCompare(b.name||'','ru',{numeric:true}));
let html;
if(!ds.length)html='<div class="empty small">Ничего не найдено — измените фильтры</div>';
else if(A.dishMeal&&A.dishMeal!=='all')html=`<div class="dish-grid">${ds.map(tile).join('')}</div>`;
else{
  const order=['breakfast','lunch','dinner','snack1'],by={};
  ds.forEach(d=>{const m=mealsOf(d);const t=m.length?(MEAL[m[0]]||NO_MEAL):NO_MEAL;(by[t]=by[t]||[]).push(d)});
  const titles=[...order.map(k=>MEAL[k]),NO_MEAL].filter((t,i,a)=>a.indexOf(t)===i&&by[t]);
  html=titles.map(t=>`<div class="dish-sect"><h2 class="dish-sect-h">${esc(t)}<span>${by[t].length}</span></h2><div class="dish-grid">${by[t].map(tile).join('')}</div></div>`).join('');
}
$('#dishpage').innerHTML=html;stagger($('#dishpage'))}
async function spProfile(){const j=await api('/specialist/profile');const p=j.profile||{};go(spShell(`${navBar('Настройки','spBackToMore()',`<button class="nb-act text" onclick="spSaveSettings()">Сохранить</button>`)}<div class="prof-grid"><div class="card pad prof-card"><label class="avatar-edit">${av(A.user?.name||'N','huge',A.user?.avatar_url)}<input type="file" accept="image/*" hidden onchange="spUploadAvatar(this)"><span class="cam">${icon('camera')}</span></label><div><h2>${esc(A.user?.name||'')}</h2><p class="muted">${esc(A.user?.email||'')}</p><span class="role-chip">${PROF[profOf()]}</span>${A.user?.avatar_url?`<button class="textbtn danger-text" onclick="spDeleteAvatar()">Удалить фото</button>`:`<span class="muted small">Загрузите фото профиля</span>`}</div></div>${foldCard('f_main','Основное',`<form onsubmit="event.preventDefault();spSaveSettings()"><div class="field-label">Специализация</div><div class="rolepick" id="s_role">${[['nutritionist','Нутрициолог'],['trainer','Тренер'],['coach','Коуч']].map(([k,l])=>`<button type="button" class="role-opt ${profOf()===k?'active':''}" data-r="${k}" onclick="pickSettingsRole('${k}')">${l}</button>`).join('')}</div><label>Имя<input id="s_n" value="${esc(p.name||'')}"></label><label>Телефон<input id="s_p" value="${esc(p.phone||'')}"></label><label>О себе<textarea id="s_b">${esc(p.bio||'')}</textarea></label></form>`,esc([p.name||A.user?.name||'',PROF[profOf()]].filter(Boolean).join(' · ')))}${foldCard('f_card','Карточка в каталоге',`<form onsubmit="event.preventDefault();spSaveSettings()"><p class="muted small" style="margin:0 0 12px">Как вас увидят клиенты при поиске специалиста.</p><div class="formgrid"><label>Опыт, лет<input id="s_exp" type="number" value="${p.experience_years??''}" placeholder="5"></label><label>Город<input id="s_city2" value="${esc(p.city||'')}" placeholder="Москва"></label></div>
<p class="muted small" style="margin:2px 0 12px">Цену в каталоге считаем по вашим услугам — по самой дешёвой из активных. Меняется в разделе <button type="button" class="linkbtn" onclick="spServices()">Мои услуги</button>.</p><label>Образование<input id="s_edu" value="${esc(p.education||'')}" placeholder="ВУЗ, курсы, сертификаты"></label><label>Специализации <span class="muted small">(через запятую)</span><input id="s_spec" value="${esc(p.specializations||'')}" placeholder="Снижение веса, ЖКТ, спортпит"></label><label>В чём ваше преимущество<textarea id="s_adv" placeholder="Коротко: чем вы полезнее других">${esc(p.advantages||'')}</textarea></label><label class="switch"><input id="s_pub" type="checkbox" ${p.is_public?'checked':''}><span>Показывать в каталоге ${catalogWord()}</span></label><p class="muted small" style="margin:8px 0 0">Карточка появится в каталоге после верификации — переключатель без неё ничего не показывает.</p></form>`,esc([p.city||'',p.experience_years?p.experience_years+' '+plural(p.experience_years,['год','года','лет'])+' опыта':''].filter(Boolean).join(' · ')||'не заполнена'))}${verifyCard()}${rewardsCard()}${themeCard()}<div class="card pad prof-more"><h3>Ещё</h3><button class="row-btn" type="button" onclick="pushSettings()">${icon('bell')}<span>Уведомления и тихие часы</span>${icon('chevr')}</button><button class="row-btn danger-row" type="button" onclick="logout()">${icon('lock')}<span>Выйти</span>${icon('chevr')}</button><button class="row-btn danger-row" type="button" onclick="deleteAccount(A.type==='specialist'?'specialist':'client')">${icon('trash')}<span>Удалить аккаунт</span>${icon('chevr')}</button></div></div>`,'settings'));spPaintVerify();spPaintRewards()}
async function spSaveSettings(){const prof=A._settingsRole||profOf();const g=id=>$(id)?$(id).value:'';await api('/specialist/profile',{method:'PATCH',body:JSON.stringify({name:$('#s_n').value,phone:$('#s_p').value,city:g('#s_city2'),bio:$('#s_b').value,is_public:$('#s_pub').checked?1:0,profession:prof,experience_years:g('#s_exp')?+g('#s_exp'):null,education:g('#s_edu'),specializations:g('#s_spec'),advantages:g('#s_adv')})});if(A.user)A.user.profession=prof;A._settingsRole=null;toast('Сохранено ✓','ok');spProfile()}
function pickSettingsRole(r){A._settingsRole=r;document.querySelectorAll('#s_role .role-opt').forEach(b=>b.classList.toggle('active',b.dataset.r===r))}
/* Уведомления специалиста приходят из двух источников: события у клиентов
   и то, что касается его самого — верификация, отзывы, заявки. Открытие
   списка гасит колокольчик: до этого он не гас никогда. */
/* Очистка ленты. Уведомления о клиентах принадлежат клиентам — сервер
   их не удаляет, а запоминает время очистки и перестаёт показывать
   специалисту всё, что было раньше. Свои уведомления удаляются. */
async function spClearNotices(){
  if(!confirm('Очистить уведомления? Список событий станет пустым. Сами сообщения и звонки останутся на своих местах.'))return;
  try{await api('/specialist/notifications',{method:'DELETE'});closeModal();toast('Уведомления очищены');spHome()}
  catch(e){toast(e.message||'Не удалось очистить','err')}
}
/* Сколько уведомлений не прочитано.
 *
 * Раньше на колокольчике стояло что угодно, только не это: на «Главной»
 * — число сообщений без ответа, в «Клиентах» — число клиентов,
 * требующих внимания. Значок ведёт в «Уведомления», и считать он должен
 * уведомления: очищенный список с единицей на колокольчике читается как
 * поломка, и справедливо.
 *
 * Считаем после отрисовки шапки, а не до: экран не должен ждать ещё
 * одного запроса, чтобы показаться. */
async function spPaintNotices(){
  const host=document.querySelector('.head-icons .icon-circle[aria-label="Уведомления"]');
  if(!host)return;
  let n=0;
  try{ n=((await api('/specialist/notifications')).notifications||[]).filter(x=>!x.read_at).length }
  catch(e){ return }
  const old=host.querySelector('.cbadge,.badge-dot'); if(old)old.remove();
  if(n>0)host.insertAdjacentHTML('beforeend','<i class="cbadge">'+n+'</i>');
}

async function spNotifications(){
  const j=await api('/specialist/notifications');
  const rows=(j.notifications||[]).slice(0,30);
  const ic={verification:'shield',review:'star',lead:'gift'};
  showModal(`<div class="sheet-head"><div><div class="eyebrow">Уведомления</div><h2>Последние события</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <div class="feed">${rows.map(n=>`<div class="feed-row ${n.read_at?'':'unread'}">
    <span class="feed-ic">${icon(ic[n.type]||'bell')}</span>
    <div><strong>${esc(n.title)}</strong>
      <span>${[esc(n.client_name||''),esc(n.body||'')].filter(Boolean).join(': ')}</span>
      <small>${esc((n.created_at||'').slice(0,16))}</small></div></div>`).join('')
    ||'<div class="muted small">Пока пусто</div>'}</div>
  ${rows.length?`<button class="textbtn wide notices-clear" onclick="spClearNotices()">${icon('trash')} Очистить список</button>`:''}`);
  try{await api('/specialist/notifications/read',{method:'POST'})}catch(e){}
}

/* ======================================================================
   CLIENT PWA
   ====================================================================== */
function clShell(body,active){
setTimeout(paintAside,0);
return `<div class="client-shell shell-${active}"><nav class="client-nav pillnav"><button class="pill-item ${active==='home'?'active':''}" onclick="clToday()">${icon('home')}<span>Сегодня</span></button><button class="pill-item ${active==='cal'?'active':''}" onclick="clWeek()">${icon('cal')}<span>Неделя</span></button><button class="pill-item ${active==='chat'?'active':''}" onclick="clChat()">${icon('chat')}<span>Чат</span></button><button class="pill-item ${['more','trend','user'].includes(active)?'active':''}" onclick="clMore()">${icon('kebab')}<span>Ещё</span></button></nav><main class="client-main">${body}</main><aside class="client-aside" id="claside">${A.gam?clAsideInner(A.gam):'<div class="aside-skel"></div>'}</aside></div>`}
async function ensureGam(force){if(force||!A.gam){try{A.gam=await api('/client/gamification')}catch(e){A.gam=A.gam||null}}return A.gam}
async function paintAside(){const el=document.getElementById('claside');if(!el)return;const g=await ensureGam();if(el&&g)el.innerHTML=clAsideInner(g)}
function clAsideInner(g){const u=A.user||{};const span=Math.max(1,g.level_next-g.level_base);const p=Math.max(0,Math.min(100,Math.round((g.earned-g.level_base)/span*100)));return `<div class="aside-card"><div class="aside-top">${av(u.name,'huge',u.avatar_url)}<div><strong>${esc(u.name||'')}</strong><span class="muted">${esc(u.goal||'')}</span></div></div>
<div class="level-row"><span class="lvl-badge">Ур. ${g.level}</span><b>${esc(g.level_title)}</b></div>
<div class="lvl-track"><i style="width:${p}%"></i></div><div class="lvl-meta muted">${g.earned} / ${g.level_next} XP до ур. ${g.level+1}</div>
<div class="aside-stats"><div class="asr"><div class="asr-ic flame">${icon('flame')}</div><div><b>${g.streak}</b><span>${plural(g.streak,['день','дня','дней'])} подряд</span></div></div><div class="asr"><div class="asr-ic coin">${icon('coin')}</div><div><b>${g.balance}</b><span>баллов</span></div></div></div>
<div class="aside-ach">${g.achievements.map(a=>`<span class="ach-mini ${a.unlocked?'on':''}" title="${esc(a.label)} — ${esc(a.hint)}">${icon(a.unlocked?a.icon:'lock')}</span>`).join('')}</div>
<button class="primary green wide" onclick="clRewards()">${icon('gift')} Награды и баллы</button></div>`}
function clHead(title,sub,back){
  /* Как в приложении: крупный заголовок остаётся у корневых экранов
     («Сегодня», «Неделя», «Чат»), а всё, что открывается поверх них,
     получает NavBar — заголовок по центру и возврат слева. */
  if(back)return navBar(title,back)+(sub?`<p class="nb-sub muted">${esc(sub)}</p>`:'');
  return `<div class="c-head"><div><h1>${esc(title)}</h1>${sub?`<p class="muted">${esc(sub)}</p>`:''}</div></div>`}

async function clToday(){const j=await api('/client/today');
/* Пока меню нет, экран должен объяснять, чего ждать. Ждать нечего, если
   специалист не выбран: меню составляет он, и первый шаг — каталог.
   Раньше здесь в обоих случаях стояло «Меню готовится», и человек без
   специалиста ждал того, что никогда не появится. */
/* Без меню экран остаётся тем же дневником: пять приёмов пищи, просто
   без назначенного специалистом. Раньше здесь был тупик «Меню
   готовится», и человек ждал того, чего может и не быть. */
if(!j.menu){
  const has=!!(A.user&&A.user.specialist_id);
  return go(clShell(`<div class="c-top"><div><div class="eyebrow">${new Date().toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long'})}</div><h1>Сегодня</h1></div></div>
  ${pushNudge()}${specCta()}
  <div class="card quiet pad day-hint">
    ${has?`<p class="muted small">Меню от специалиста пока не назначено. Отмечайте, что едите — ему это пригодится.</p>`
         :`<p class="muted small">Ведите дневник питания уже сейчас. Специалист составит меню под ваши цели, когда вы его выберете.</p>`}
  </div>
  ${MEAL_ORDER.map(mt=>dayMeal(j,mt)).join('')}`,'home'));
}
await ensureGam();const g=A.gam;
const tk=A.user?.target_kcal||j.menu.target_kcal||1800;const pct=j.totals.kcal/tk*100;const tg={protein:A.user?.target_protein||110,fat:A.user?.target_fat||60,carbs:A.user?.target_carbs||190};
const _eaten=R(j.totals.kcal),_rem=tk-_eaten;
go(clShell(`<div class="c-top"><div><div class="eyebrow">${new Date().toLocaleDateString('ru-RU',{weekday:'long',day:'numeric',month:'long'})}</div><h1>Сегодня</h1></div></div>
${pushNudge()}${specCta()}
${clCalStrip()}
${daySummary(j,tk,tg,_eaten,_rem,pct)}
${MEAL_ORDER.map(mt=>dayMeal(j,mt)).join('')}`,'home'))}

/* ==========================================================================
   ОДИН ПРИЁМ ПИЩИ

   День — это дневник, а не два списка. В одной секции стоит и то, что
   назначил специалист, и то, что человек съел на самом деле: он не
   обязан помнить, откуда какая строка взялась. Раньше съеденное мимо
   меню жило отдельным блоком внизу и кнопкой «Съел своё» — это была
   наша внутренняя граница, вынесенная человеку на экран.
   ========================================================================== */
function dayMeal(j,mt){
  const planned=(j.items||[]).filter(x=>x.meal_type===mt);
  const eaten=(j.food||[]).filter(e=>e.meal===mt);
  const planK=planned.reduce((s,x)=>s+(x.nutrition?.kcal||0),0);
  const doneK=planned.filter(x=>x.log_status==='eaten').reduce((s,x)=>s+(x.nutrition?.kcal||0),0)
             +eaten.reduce((s,e)=>s+e.totals.kcal,0);
  /* Показываем «съедено из назначенного», когда есть план, и просто
     съеденное, когда плана нет: «0 из 0 ккал» — не число, а шум. */
  const head=planK?`${R(doneK)} из ${R(planK)} ккал`:(doneK?`${R(doneK)} ккал`:'');
  const rows=planned.map(mealRow).join('')
    +eaten.map(e=>e.items.map(i=>`<div class="day-own">
        <div class="grow"><strong>${esc(i.name)}</strong><small>${R(i.grams)} г · ${R(i.kcal)} ккал</small></div>
        <button class="icon-circle sm" title="Убрать" onclick="foodDropItem(${e.id},${e.items.length})">${icon('x')}</button>
      </div>`).join('')).join('');
  return `<div class="meal-sec"><div class="meal-head"><b>${MEAL[mt]}</b>
      <small>${timeFor(mt)}${head?' · '+head:''}</small></div>
    <div class="meal-group">${rows}
      <button class="day-add" onclick="clFoodSheet('${mt}')">${icon('plus')}<span>Добавить еду</span></button>
    </div></div>`;
}


/* ==========================================================================
   ДНЕВНИК ПРОДУКТОВ

   Человек не всегда ест блюдо. Иногда это свёкла и греческий йогурт —
   набор продуктов, которого в меню нет и быть не могло. Раньше отметить
   такое было негде, и съеденное просто не попадало в итог дня.

   Запись независима от меню: день, приём пищи, список продуктов с
   граммовкой. Меню она не трогает — соблюдение меню и съеденные калории
   разные вопросы, и смешивать их нельзя.
   ========================================================================== */
/* Те же пять слотов, что у меню: день один, и назначенное со съеденным
   должны попадать в одну и ту же секцию. */
const FOOD_MEALS=[['breakfast','Завтрак'],['snack1','Перекус'],['lunch','Обед'],
  ['snack2','Перекус'],['dinner','Ужин']];
/* Черновик записи живёт до сохранения: человек ищет продукт, ошибается,
   возвращается — и добавленное не должно пропадать. */
const FOOD={meal:'snack2',items:[],busy:false,q:'',found:[],date:null,step2:false};

function foodMealTitle(m){return (FOOD_MEALS.find(x=>x[0]===m)||[,'Перекус'])[1]}
function foodMealTime(m){return timeFor(m)}
function foodKcal(items){return items.reduce((s,x)=>s+x.kcal,0)}

/* Сколько весит одна штука или порция — чтобы не набирать «60» руками. */
function foodStep(f){
  if(f.unit==='pc'&&f.piece_g)return {g:f.piece_g,label:'1 шт.'};
  if(f.per_serving_g)return {g:f.per_serving_g,label:'порция'};
  return null;
}
function foodMacros(f,g){
  const k=g/100;
  return {kcal:Math.round(f.kcal*k*10)/10,protein:Math.round(f.protein*k*10)/10,
    fat:Math.round(f.fat*k*10)/10,carbs:Math.round(f.carbs*k*10)/10};
}

/* ---------- Лист «Съел своё» ---------- */
/* Лист открывается из нужной секции, поэтому приём пищи уже выбран —
   человек нажал «Добавить еду» под «Обедом», а не вообще. */
function clFoodSheet(meal,date){
  FOOD.meal=meal||'snack2';FOOD.items=[];FOOD.q='';FOOD.found=[];FOOD.date=date||null;FOOD.step2=false;
  showSheet(`<div class="sheet-head"><div><div class="eyebrow" id="food_eyebrow"></div><h2>Добавить еду</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <div id="food_search_wrap" class="food-searchrow">
    <input id="food_q" placeholder="Найти продукт" autocomplete="off"
      oninput="foodSearch(this.value)">
    <button class="food-scan" title="Сканировать штрихкод" aria-label="Сканировать штрихкод"
      onclick="foodScan()">${icon('camera')}</button></div>
  <div id="food_found" class="food-found"></div>
  <div id="food_cart" class="food-cart"></div>
  <div id="food_err"></div>
  <button class="primary green wide" id="food_save" onclick="foodSave()" hidden>Сохранить</button>`);
  foodPaintMeal();foodPaintCart();foodSearch('');
}
/* Приём пищи выбран раньше — нажатием «Добавить еду» в нужной секции
   дня, и назван в шапке листа над заголовком. Ряд кнопок с теми же
   пятью приёмами повторял этот выбор: занимал место, ездил под пальцем
   и ничего не добавлял. Осталась подпись. */
function foodPaintMeal(){
  const eb=$('#food_eyebrow');
  if(eb)eb.textContent=foodMealTitle(FOOD.meal)+' · '+timeFor(FOOD.meal);
}

/* Ищем с задержкой: буква за буквой запрос на каждый символ — это
   и лишняя нагрузка, и мигающий список под пальцем. */
let _foodT=null;
function foodSearch(q){
  FOOD.q=q;
  clearTimeout(_foodT);
  _foodT=setTimeout(async()=>{
    try{
      const j=await api('/client/foods?limit=30&q='+encodeURIComponent(q.trim()));
      FOOD.found=j.foods||[];
    }catch(e){FOOD.found=[]}
    foodPaintFound();
  },q.trim()?220:0);
}
function foodPaintFound(){
  const el=$('#food_found');if(!el)return;
  if(!FOOD.found.length){
    el.innerHTML=FOOD.q.trim()
      ? `<div class="food-none"><p class="muted small">Такого продукта нет в справочнике.</p>
         <button class="secondary" onclick="foodOwnForm()">Добавить свой продукт</button></div>`
      : '<p class="muted small">Начните вводить название.</p>';
    return;
  }
  el.innerHTML=FOOD.found.map((f,i)=>`<button class="food-row" onclick="foodPick(${i})">
    <div class="grow"><strong>${esc(f.name)}</strong>
      <small>${R(f.kcal)} ккал · Б ${f.protein} Ж ${f.fat} У ${f.carbs} / 100 г</small></div>
    ${icon('plus')}</button>`).join('');
}

/* Граммовку спрашиваем сразу: продукт без веса в дневнике бесполезен.
   Шаг рисуем внутри того же листа, а не вторым окном поверх: лист и
   модальное окно — один и тот же узел, и второе окно сносило первое
   вместе с уже набранной корзиной. */
function foodPick(i){
  const f=FOOD.found[i],box=$('#food_found');
  if(!f||!box)return;
  const step=foodStep(f);
  const def=step?R(step.g):100;
  foodStep2(true);
  box.innerHTML=`<div class="food-gram">
    <button class="textbtn" onclick="foodBack()">${icon('chevl')} К поиску</button>
    <div class="food-gram-name"><strong>${esc(f.name)}</strong>
      <small>${R(f.kcal)} ккал · Б ${f.protein} Ж ${f.fat} У ${f.carbs} / 100 г</small></div>
    <label>Сколько, граммов<input id="food_g" type="number" inputmode="numeric" min="1" max="5000"
      value="${def}" oninput="foodPreview(${i})"></label>
    <div class="chip-row">${step
      ? [1,2,3].map(n=>`<button class="chip" onclick="foodSetG(${R(step.g*n)},${i})">${n} × ${esc(step.label)}</button>`).join('')
      : [50,100,150,200].map(n=>`<button class="chip" onclick="foodSetG(${n},${i})">${n} г</button>`).join('')}</div>
    <div class="food-prev" id="food_prev"></div>
    <button class="primary green wide" onclick="foodAdd(${i})">Добавить</button></div>`;
  foodPreview(i);
}
function foodSetG(g,i){const el=$('#food_g');if(el)el.value=g;foodPreview(i)}
/* Возврат к поиску: список уже в памяти, второй раз на сервер не ходим. */
function foodBack(){ foodScanStop(); foodStep2(false); foodPaintFound(); foodSaveVis(); }
/* Второй шаг листа: поиск и «Сохранить» прячем, чтобы на экране была
   ровно одна кнопка, заканчивающая начатое. */
function foodStep2(on){
  FOOD.step2=!!on;
  const sw=$('#food_search_wrap');if(sw)sw.hidden=FOOD.step2;
  foodSaveVis();
}
/* «Сохранить» показываем, только когда есть что сохранять и мы на первом
   шаге. Раньше кнопка стояла всегда, просто погашенная, — а она липкая,
   и полупрозрачная плашка лежала поверх списка продуктов. */
function foodSaveVis(){
  const sv=$('#food_save');if(!sv)return;
  sv.hidden=FOOD.step2||!FOOD.items.length;
}
function foodPreview(i){
  const f=FOOD.found[i],el=$('#food_prev');if(!f||!el)return;
  const g=Math.max(0,+($('#food_g')?.value||0));
  const m=foodMacros(f,g);
  el.innerHTML=`<b class="num">${R(m.kcal)} ккал</b>
    <span class="muted small">Б ${m.protein} · Ж ${m.fat} · У ${m.carbs}</span>`;
}
function foodAdd(i){
  const f=FOOD.found[i];if(!f)return;
  const g=Math.round(+($('#food_g')?.value||0));
  if(!(g>0&&g<=5000)){toast('Вес — от 1 до 5000 г','err');return}
  FOOD.items.push(Object.assign({ingredient_id:f.id,name:f.name,grams:g},foodMacros(f,g)));
  foodBack();
  foodPaintCart();
  toast(f.name+' · '+R(g)+' г','ok');
}
function foodDrop(i){FOOD.items.splice(i,1);foodPaintCart()}
function foodPaintCart(){
  const el=$('#food_cart');if(!el)return;
  if(!FOOD.items.length){el.innerHTML='';foodSaveVis();return}
  const k=foodKcal(FOOD.items);
  el.innerHTML=`<div class="sect">Съедено</div>
    <div class="food-list">${FOOD.items.map((x,i)=>`<div class="food-item">
      <div class="grow"><strong>${esc(x.name)}</strong><small>${R(x.grams)} г · ${R(x.kcal)} ккал</small></div>
      <button class="icon-circle sm" title="Убрать" onclick="foodDrop(${i})">${icon('x')}</button></div>`).join('')}</div>
    <div class="food-total"><span>Итого</span><b class="num">${R(k)} ккал</b></div>`;
  foodSaveVis();
}
async function foodSave(){
  if(!FOOD.items.length||FOOD.busy)return;
  FOOD.busy=true;
  const btn=$('#food_save');if(btn)btn.disabled=true;
  try{
    await api('/client/food-log',{method:'POST',body:JSON.stringify({
      meal:FOOD.meal,eaten_on:FOOD.date||undefined,
      items:FOOD.items.map(x=>({ingredient_id:x.ingredient_id,grams:x.grams}))})});
    closeModal();toast('Записано ✓','ok');
    clToday();
  }catch(e){
    const el=$('#food_err');if(el)el.innerHTML=`<div class="error">${esc(e.message)}</div>`;
    if(btn)btn.disabled=false;
  }finally{FOOD.busy=false}
}

/* ---------- Штрихкод ----------
   Переписывать с этикетки четыре числа — верный способ бросить дневник
   на третий день. Штрихкод снимает эту работу: нашли товар — КБЖУ уже
   заполнено.

   Читаем двумя путями. Где есть браузерный BarcodeDetector (Chrome,
   Android) — им: он быстрый и ничего не весит. Где его нет — а на
   iPhone его нет ни у кого, потому что все тамошние браузеры работают
   на WebKit, — подгружаем распознаватель из поставки. Грузим лениво,
   только по нажатию: 97 КБ по сети не должны платить те, кто сканером
   не пользуется.

   Ручной ввод цифр остаётся всегда: камера может быть занята, запрещена
   или просто не видеть полоски в темноте. */
function foodScanNative(){return typeof window.BarcodeDetector==='function'}

let _zxing=null;
function zxingLoad(){
  if(_zxing)return _zxing;
  _zxing=new Promise((res,rej)=>{
    if(window.ZXing)return res(window.ZXing);
    const s=document.createElement('script');
    s.src='/app/vendor/zxing.min.js';
    s.onload=()=>window.ZXing?res(window.ZXing):rej(new Error('Распознаватель не загрузился'));
    s.onerror=()=>rej(new Error('Распознаватель не загрузился'));
    document.head.appendChild(s);
  });
  return _zxing;
}

function foodScan(){
  const box=$('#food_found');if(!box)return;
  foodStep2(true);
  box.innerHTML=`<div class="food-gram">
    <button class="textbtn" onclick="foodScanStop();foodBack()">${icon('chevl')} К поиску</button>
    <div class="scan-box"><video id="scan_v" playsinline muted></video><i></i></div>
    <p class="muted small" id="scan_msg">Наведите камеру на штрихкод</p>
    <label>Штрихкод<input id="scan_code" inputmode="numeric" autocomplete="off"
      placeholder="4680019620015" oninput="foodScanTyped(this.value)"></label>
    <div id="scan_err"></div>
    <button class="primary green wide" onclick="foodScanLookup($('#scan_code').value)">Найти товар</button></div>`;
  foodScanStart();
}

let _scanStream=null,_scanTimer=null,_scanLast='';
async function foodScanStart(){
  const v=$('#scan_v');if(!v)return;
  try{
    _scanStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}}});
    v.srcObject=_scanStream;await v.play();
  }catch(e){
    const m=$('#scan_msg');
    if(m)m.textContent='Камера недоступна. Введите цифры штрихкода руками.';
    return;
  }
  /* Кадр отдаём распознавателю: своему, если браузер умеет, иначе —
     тому, что лежит в поставке. */
  let read;
  if(foodScanNative()){
    const det=new window.BarcodeDetector({formats:['ean_13','ean_8','upc_a','upc_e']});
    read=async()=>{const c=await det.detect(v);return c.length?String(c[0].rawValue||''):''};
  }else{
    const msg=$('#scan_msg');if(msg)msg.textContent='Готовим распознаватель…';
    let Z;
    try{ Z=await zxingLoad() }
    catch(e){
      if(msg)msg.textContent='Распознаватель не загрузился. Введите цифры штрихкода руками.';
      return;
    }
    if(msg)msg.textContent='Наведите камеру на штрихкод';
    const hints=new Map();
    hints.set(Z.DecodeHintType.POSSIBLE_FORMATS,
      [Z.BarcodeFormat.EAN_13,Z.BarcodeFormat.EAN_8,Z.BarcodeFormat.UPC_A,Z.BarcodeFormat.UPC_E]);
    /* TRY_HARDER заметно медленнее, а полоски на пачке и так крупные. */
    const reader=new Z.MultiFormatReader();
    reader.setHints(hints);
    const cv=document.createElement('canvas');
    read=async()=>{
      const w=v.videoWidth,h=v.videoHeight;
      if(!w||!h)return '';
      cv.width=w;cv.height=h;
      cv.getContext('2d',{willReadFrequently:true}).drawImage(v,0,0,w,h);
      try{ return String(zxingDecodeCanvas(Z,reader,cv)||'') }catch(e){ return '' }
    };
  }
  _scanTimer=setInterval(async()=>{
    if(!document.getElementById('scan_v'))return foodScanStop();
    try{
      const raw=String(await read()||'').replace(/\D+/g,'');
      /* Камера отдаёт один и тот же код десятки раз в секунду, пока
         пачка в кадре. Запрос шлём один. */
      if(!raw||raw===_scanLast)return;
      _scanLast=raw;
      const inp=$('#scan_code');if(inp)inp.value=raw;
      foodScanStop();
      foodScanLookup(raw);
    }catch(e){}
  },foodScanNative()?400:600);
}

/* Разбор одного кадра распознавателем из поставки. Вынесено отдельно,
   чтобы было что проверить машинно: кодируем штрихкод, рисуем, читаем
   обратно и сверяем — без камеры и без телефона. */
function zxingDecodeCanvas(Z,reader,cv){
  const src=new Z.HTMLCanvasElementLuminanceSource(cv);
  const bmp=new Z.BinaryBitmap(new Z.HybridBinarizer(src));
  try{ return reader.decode(bmp).getText() }
  finally{ reader.reset&&reader.reset() }
}
function foodScanStop(){
  if(_scanTimer){clearInterval(_scanTimer);_scanTimer=null}
  if(_scanStream){_scanStream.getTracks().forEach(t=>t.stop());_scanStream=null}
}
function foodScanTyped(v){_scanLast=''}
async function foodScanLookup(code){
  const c=String(code||'').replace(/\D+/g,'');
  const err=$('#scan_err');
  if(c.length<8){if(err)err.innerHTML='<div class="error">В штрихкоде 8 или 13 цифр.</div>';return}
  if(err)err.innerHTML='<p class="muted small">Ищем товар…</p>';
  try{
    const j=await api('/client/foods/barcode/'+c);
    foodScanStop();
    FOOD.found=[j.food];
    /* Показываем, что нашли, сразу шагом граммовки: штрихкод мог
       прочитаться с соседней пачки, и название это покажет. */
    foodPick(0);
    toast(j.food.name,'ok');
  }catch(x){
    if(err)err.innerHTML=`<div class="error">${esc(x.message)}</div>
      <button class="secondary" onclick="foodScanStop();foodOwnForm()">Завести продукт руками</button>`;
  }
}

/* Своего продукта нет в справочнике — заводим по упаковке. Тоже шагом
   внутри листа: набранная корзина должна пережить эту отлучку. */
function foodOwnForm(){
  const box=$('#food_found');if(!box)return;
  foodStep2(true);
  box.innerHTML=`<div class="food-gram">
  <button class="textbtn" onclick="foodBack()">${icon('chevl')} К поиску</button>
  <div class="food-gram-name"><strong>Свой продукт</strong>
    <small>Значения указывайте на 100 г — так они написаны на этикетке</small></div>
  <form onsubmit="foodOwnSave(event)">
    <label>Название<input id="fo_n" required maxlength="120" value="${esc(FOOD.q.trim())}"></label>
    <div class="formgrid">
      <label>Ккал<input id="fo_k" type="number" inputmode="decimal" min="0" max="950" required></label>
      <label>Белки, г<input id="fo_p" type="number" inputmode="decimal" min="0" max="100" required></label>
      <label>Жиры, г<input id="fo_f" type="number" inputmode="decimal" min="0" max="100" required></label>
      <label>Углеводы, г<input id="fo_c" type="number" inputmode="decimal" min="0" max="100" required></label>
    </div>
    <button class="primary green wide">Добавить в справочник</button></form><div id="fo_err"></div></div>`;
}
async function foodOwnSave(e){
  e.preventDefault();
  try{
    const j=await api('/client/foods',{method:'POST',body:JSON.stringify({
      name:$('#fo_n').value,kcal:+$('#fo_k').value,protein:+$('#fo_p').value,
      fat:+$('#fo_f').value,carbs:+$('#fo_c').value})});
    FOOD.found=[j.food];
    /* Сразу спрашиваем граммовку: продукт заводили не ради справочника,
       а чтобы отметить съеденное. */
    foodPick(0);
    toast('Продукт добавлен ✓','ok');
  }catch(x){const el=$('#fo_err');if(el)el.innerHTML=`<div class="error">${esc(x.message)}</div>`}
}

/* Убрать съеденное. Запись может состоять из нескольких продуктов —
   если он в ней последний, уходит вся запись; иначе предупреждаем, что
   уйдут все: правка отдельной строки внутри записи потребовала бы
   отдельного экрана ради редкого случая. */
function foodDropItem(entryId,count){
  const msg=count>1
    ? 'В этой записи '+count+' '+plural(count,['продукт','продукта','продуктов'])+'. Убрать её целиком?'
    : 'Убрать эту запись?';
  if(!confirm(msg))return;
  api('/client/food-log/'+entryId,{method:'DELETE'}).then(clToday).catch(e=>toast(e.message,'err'));
}

/* ==========================================================================
   СВОДКА ДНЯ.

   Человек открывает приложение, чтобы посмотреть, что сегодня есть, — а
   не чтобы изучать отчётность. Раньше пять карточек с цифрами занимали
   весь первый экран, и еда начиналась ниже сгиба. Теперь сводка свёрнута
   в одну строку: остаток калорий и три полосы БЖУ. Кому нужны подробности
   — разворачивает, и они те же, что были. Состояние помним: тот, кто
   считает граммы, не должен раскрывать её каждый день заново.
   ========================================================================== */
function daySummary(j,tk,tg,eaten,rem,pct){
  const open=(()=>{try{return localStorage.nm_daysum==='1'}catch(e){return false}})();
  /* У полосы нужна подложка: при нуле съеденного заполнение имеет нулевую
     ширину, и без дорожки строка выглядела бы пустой — «Б Ж У» без всего. */
  const mini=(l,c,t,col)=>{const f=t?Math.min(1,c/t):0;
    return `<span class="dsm" title="${l}: ${R(c)} из ${R(t)||'—'} г"><u><i style="background:${col};transform:scaleX(${f})"></i></u><b>${l}</b></span>`};
  return `<details class="day-sum card lead" ${open?'open':''} ontoggle="try{localStorage.nm_daysum=this.open?'1':'0'}catch(e){}">
    <summary class="ds-bar">
      <div class="ds-num num ${rem<0?'over':''}">
        <b>${rem>=0?rem:(-rem)}</b><span>ккал ${rem>=0?'осталось':'перебор'}</span>
      </div>
      <div class="ds-macro">
        ${mini('Б',j.totals.protein,tg.protein,'var(--mp)')}
        ${mini('Ж',j.totals.fat,tg.fat,'var(--mf)')}
        ${mini('У',j.totals.carbs,tg.carbs,'var(--mc)')}
      </div>
      <span class="ds-chev">${icon('chevr')}</span>
    </summary>
    <div class="wgrid">
      <div class="kcal-card">
        <div class="kc-lbl">Калории</div>
        <div class="kc-line">
          <div class="kc-left num"><b>${eaten}</b><span>ккал / ${tk}</span></div>
          <div class="kc-right num ${rem<0?'over':''}"><b>${rem>=0?rem:(-rem)}</b><span>${rem>=0?'осталось':'перебор'}</span></div>
        </div>
        <div class="kc-bar"><i style="transform:scaleX(${Math.min(1,pct/100)})"></i></div>
        ${j.plan_totals?`<div class="kc-plan muted">По плану на день ${R(j.plan_totals.kcal)} ккал${eaten<R(j.plan_totals.kcal)?` · осталось съесть ${R(j.plan_totals.kcal)-eaten}`:''}</div>`:''}
      </div>
      <div class="macro-card">${macroCols(j.totals,tg)}</div>
      ${weightTile(j.weight)}
      ${eatenTile(j.items)}
      ${waterTile(j.water)}
    </div>
  </details>`;
}
function wtBar(cur,target,col){const f=target?Math.min(1,cur/target):0;return `<span class="wt-track"><i style="transform:scaleX(${f});background:${col}"></i></span>`}
function macroCols(cur,tg){
  const rows=[['Белки',cur.protein,tg.protein,macroCol(cur.protein,tg.protein)],['Жиры',cur.fat,tg.fat,macroCol(cur.fat,tg.fat)],['Углеводы',cur.carbs,tg.carbs,macroCol(cur.carbs,tg.carbs)]];
  return rows.map(([l,c,t,col])=>{const f=t?Math.min(1,c/t):0;return `<div class="mc-col">
    <div class="mc-name"><i style="background:${col}"></i>${l}</div>
    <div class="mc-val num"><b>${R(c)}</b><span>г / ${R(t)||'—'}</span></div>
    <span class="mc-track"><i style="transform:scaleX(${f});background:${col}"></i></span></div>`}).join('');
}
function macroRows(cur,tg){
  const rows=[['Белки',cur.protein,tg.protein,macroCol(cur.protein,tg.protein)],['Жиры',cur.fat,tg.fat,macroCol(cur.fat,tg.fat)],['Углеводы',cur.carbs,tg.carbs,macroCol(cur.carbs,tg.carbs)]];
  return rows.map(([l,c,t,col])=>{const f=t?Math.min(1,c/t):0;return `<div class="mw-row">
    <span class="mw-name">${l}</span>
    <span class="mw-track"><i style="transform:scaleX(${f});background:${col}"></i></span>
    <span class="mw-val num"><b>${R(c)}</b><em>/ ${R(t)||'—'} г</em></span></div>`}).join('');
}
function macroTiles(cur,tg){const rows=[['Белки',cur.protein,tg.protein,macroCol(cur.protein,tg.protein),''],['Жиры',cur.fat,tg.fat,macroCol(cur.fat,tg.fat),''],['Углеводы',cur.carbs,tg.carbs,macroCol(cur.carbs,tg.carbs),'full']];return rows.map(([l,c,t,col,cls])=>`<div class="wtile ${cls}"><div class="wt-lbl">${l}</div><div class="wt-big num">${R(c)} <small>/ ${R(t)||'—'} г</small></div>${wtBar(c,t,col)}</div>`).join('')}
/* Вода на «Сегодня»: в приложении она здесь же, и данные уже приходят
   вместе с днём — отдельный запрос ради одной плитки не нужен. */
function waterTile(w){
  const ml=+(w?.ml||0), goal=+(w?.goal_ml||2000), f=goal?Math.min(1,ml/goal):0;
  return `<div class="wtile wide water" onclick="clWater()" role="button" tabindex="0">
    <div class="wt-body">
      <div class="wt-lbl">Вода</div>
      <div class="wt-big num">${ml} <small>из ${goal} мл</small></div>
      <span class="wt-track"><i style="transform:scaleX(${f});background:var(--mc)"></i></span>
    </div>
    <button class="water-add" onclick="event.stopPropagation();clAddWater(250)" aria-label="Добавить 250 мл">${icon('plus')}</button>
  </div>`}
async function clAddWater(ml){try{await api('/client/water',{method:'POST',body:JSON.stringify({ml})});clToday()}catch(e){toast(e.message,'err')}}

/* ==========================================================================
   ВОДА: СИЛУЭТ, НАПОЛНЯЮЩИЙСЯ ВОДОЙ
   В приложении это отдельный экран: фигура человека служит маской, и
   вода внутри неё обрезается точно по краю, а верхняя кромка — бегущая
   волна, а не прямая полоса. Прямая читается как заливка, волна — как
   жидкость. Здесь то же самое, только средствами SVG в браузере.
   ========================================================================== */
const WATER={anim:null};
function waterFigure(fill,sex){
  /* Ширину считаем из высоты по настоящим пропорциям рисунка: у женской
     фигуры 409x1283, у мужской 483x1281. Раньше тут стояла фиксированная
     рамка 150x340 и preserveAspectRatio="none" — она растягивала силуэт
     поперёк, и фигура выглядела сплющенной. */
  const RATIO=(sex==='m')?483/1281:409/1283;
  const H=340,W=Math.round(H*RATIO);
  const v=Math.max(0,Math.min(1,fill));
  const top=H-v*H;
  const a=(v>0.02&&v<0.98)?H*0.021:0;
  const len=W*2,q=len/4;
  const d=`M0 ${top} q${q/2} ${-a} ${q} 0 t${q} 0 t${q} 0 t${q} 0 t${q} 0 t${q} 0`
        +` L${len*1.5} ${H} L0 ${H} Z`;
  const src='/app/assets/body-'+(sex==='m'?'m':'f')+'.png';
  return `<svg class="water-fig" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" aria-hidden="true">
    <defs><mask id="wbody" maskUnits="userSpaceOnUse" x="0" y="0" width="${W}" height="${H}">
      <image href="${src}" x="0" y="0" width="${W}" height="${H}"/>
    </mask></defs>
    <rect x="0" y="0" width="${W}" height="${H}" fill="var(--water-base)" mask="url(#wbody)"/>
    <g mask="url(#wbody)"><path class="water-wave" d="${d}" fill="var(--water-fill)"/></g>
  </svg>`;
}
async function clWater(){
  let j;
  try{ j=await api('/client/today') }catch(e){ toast(e.message,'err'); return }
  const w=j.water||{},ml=+(w.ml||0),goal=+(w.goal_ml||2000);
  const f=goal?Math.min(1,ml/goal):0;
  const sex=(A.user&&A.user.sex)||'f';
  const left=Math.max(0,goal-ml);
  go(clShell(`${navBar('Вода',"clToday()")}
  <div class="water-screen">
    <div class="water-stage">${waterFigure(f,sex)}</div>
    <div class="water-num"><b class="num">${ml}</b><span>из ${goal} мл</span></div>
    <div class="water-left muted">${left?('Осталось '+left+' мл'):'Норма на сегодня выполнена ✓'}</div>
    <div class="water-btns">
      ${[100,250,500].map(v=>`<button class="water-btn" onclick="clWaterAdd(${v})">+${v}<small>мл</small></button>`).join('')}
    </div>
    <button class="textbtn water-undo" onclick="clWaterAdd(-250)">Убрать 250 мл</button>
  </div>`,'home'));
}
async function clWaterAdd(ml){
  try{
    await api('/client/water',{method:'POST',body:JSON.stringify({ml})});
    haptic();
    clWater();
  }catch(e){toast(e.message,'err')}
}
/* --- Отклик на нажатие ---
   На iPhone в браузере вибрации нет и взяться ей неоткуда: Vibration API
   там не поддерживается, и navigator.vibrate работает только на
   Android. Внутри Telegram отклик даёт сам мессенджер — и это
   единственный способ получить его на iPhone, не выпуская приложение.

   Виды разделены не ради разнообразия: подтверждение и отказ должны
   ощущаться по-разному, иначе палец перестаёт их различать и отклик
   превращается в шум. */
function haptic(kind){
  try{
    if(window.TG_MINIAPP&&typeof tgHaptic==='function'){ tgHaptic(kind||'tap'); return }
    if(!navigator.vibrate)return;
    navigator.vibrate(kind==='err'?[12,60,12]:kind==='ok'?[10,40,10]:8);
  }catch(e){}
}

/* Отклик на каждое нажатие — один обработчик на всё приложение.
   Расставлять его по кнопкам нельзя: их сотни, и забытая кнопка
   ощущается сломанной, хотя работает. Ловим на pointerdown, а не на
   click: отклик должен прийти в момент касания, иначе он опаздывает за
   собственной анимацией нажатия и читается как задержка.

   Прокрутку не трогаем: отклик на каждое движение пальца по списку —
   это вибрирующий телефон в кармане, а не обратная связь. */
(function(){
  const TAPPABLE='button,a[href],.pill-item,.ptab,.tag-chip,.ad-btn,.chip,'
    +'.tap-area,[onclick],label,input[type=checkbox],input[type=radio],select';
  let last=0;
  addEventListener('pointerdown',e=>{
    if(e.pointerType==='mouse')return;          /* мышь ничего не чувствует */
    const t=e.target;
    if(!t||!t.closest)return;
    if(!t.closest(TAPPABLE))return;
    /* Ползунок граммовки и прокрутка дают десятки событий подряд —
       из них отклик заслуживает только первое. */
    const now=Date.now();
    if(now-last<60)return;
    last=now;
    haptic('tap');
  },{passive:true,capture:true});
})();

/* Цифра, которую надо расшифровывать, работает хуже фразы. «−2,4 кг за
   период» не отвечает на вопрос, ради которого человек сюда смотрит:
   идёт ли он туда, куда хотел. Ответ зависит от цели — при снижении
   минус это хорошо, при наборе наоборот. */
function weightWord(d,goal){
  const g=String(goal||'').toLowerCase();
  const dec=v=>String(v).replace('.',',');
  if(!d)return 'первая запись';
  const down=d<0, abs=dec(Math.abs(d));
  const wantDown=/сниж|похуд/.test(g), wantUp=/набор|масс/.test(g);
  const num=(down?'−':'+')+abs+' кг';
  if(wantDown)return num+(down?' — идёте к цели':' — пока в другую сторону');
  if(wantUp)  return num+(down?' — пока в другую сторону':' — идёте к цели');
  return num+' за период';
}
function weightTile(w){if(!w)return `<button class="wtile tap" onclick="clAddWeight()"><div class="wt-lbl">Вес</div><div class="wt-big num">—</div><div class="wt-foot">Записать вес</div></button>`;const dec=v=>String(v).replace('.',',');return `<button class="wtile tap" onclick="clAddWeight()"><div class="wt-lbl">Вес</div><div class="wt-big num">${dec(w.last)} <small>кг</small></div><div class="wt-foot">${esc(weightWord(w.delta,A.user&&A.user.goal))}</div></button>`}
function eatenTile(items){const t=items.length,e=items.filter(x=>x.log_status==='eaten').length;return `<div class="wtile"><div class="wt-lbl">Отмечено</div><div class="wt-big num">${e} <small>/ ${t}</small></div>${wtBar(e,t,'var(--mp)')}</div>`}
function mealRow(x){const done=x.log_status==='eaten',skip=x.log_status==='skipped';return `<div class="meal-row food ${done?'done':''} ${skip?'skip':''}" onclick="clDish(${x.id})"><span class="mr-photo" style="background-image:url(${esc(dishThumb(x))})"></span><div class="mr-body"><strong>${esc(x.dish_name)}</strong><small class="num">${R(x.portion_g)} г · ${R(x.nutrition.kcal)} ккал</small></div><button class="mr-chk ${done?'done':''}" title="${done?'Съедено':'Отметить съеденным'}" onclick="event.stopPropagation();clToggleEat(${x.id},${done?1:0},this)">${icon('check')}</button></div>`}
function clDishRow(x){const done=x.log_status==='eaten',skip=x.log_status==='skipped';return `<div class="c-dish card ${done?'done':''} ${skip?'skip':''}" onclick="clDish(${x.id})"><span class="thumb" style="background-image:url(${esc(dishThumb(x))})"></span><div class="grow"><strong>${esc(x.dish_name)}</strong><small class="num">${R(x.portion_g)} г · ${R(x.nutrition.kcal)} ккал</small></div><button class="chk ${done?'done':''}" title="${done?'Съедено':'Отметить съеденным'}" onclick="event.stopPropagation();clToggleEat(${x.id},${done?1:0},this)">${icon('check')}</button></div>`}
async function clToggleEat(id,done,el){const st=done?'planned':'eaten';if(el){el.classList.toggle('done',!done);const _r=el.closest('.meal-row');if(_r)_r.classList.toggle('done',!done)}try{await api('/client/meals/'+id+'/log',{method:'POST',body:JSON.stringify({status:st})});A.gam=null;if(!done)pointsPop('+10');clToday()}catch(e){toast(e.message,'err')}}
function pointsPop(text){const el=document.createElement('div');el.className='points-pop';el.textContent=text;document.body.appendChild(el);setTimeout(()=>el.remove(),1100)}
function clTasksCard(g){const doneN=g.tasks.filter(t=>t.done).length;return `<div class="tasks-card card"><div class="tasks-head"><div class="th-left"><span class="streak-chip">${icon('flame')} ${g.streak}</span><b>Задания дня</b></div><span class="muted small">${doneN}/${g.tasks.length}</span></div>${g.tasks.map(t=>`<div class="task-row ${t.done?'done':''}"><span class="task-check">${t.done?icon('check'):''}</span><span class="grow">${esc(t.label)}</span>${t.progress?`<span class="muted small num">${esc(t.progress)}</span>`:''}<b class="task-rw">+${t.reward}</b></div>`).join('')}<button class="tasks-cta" onclick="clRewards()"><span>${icon('coin')} ${g.balance} баллов · ур. ${g.level}</span>${icon('chevr')}</button></div>`}
async function clRewards(){const g=await ensureGam(true);const span=Math.max(1,g.level_next-g.level_base);const p=Math.max(0,Math.min(100,Math.round((g.earned-g.level_base)/span*100)));go(clShell(`${clHead('Награды и баллы','',"clProfile()")}
<div class="rw-hero card"><div class="rw-hero-top"><div><div class="rw-balance"><span class="num">${g.balance}</span> баллов</div><div class="muted">Ур. ${g.level} · ${esc(g.level_title)} · 🔥 ${g.streak} ${plural(g.streak,['день','дня','дней'])}</div></div><div class="rw-coin">${icon('coin')}</div></div><div class="lvl-track light"><i style="width:${p}%"></i></div><div class="lvl-meta">${g.earned} / ${g.level_next} XP до следующего уровня</div></div>
<div class="c-sect">Задания дня</div><div class="card pad">${g.tasks.map(t=>`<div class="task-row ${t.done?'done':''}"><span class="task-check">${t.done?icon('check'):''}</span><span class="grow">${esc(t.label)}</span>${t.progress?`<span class="muted small num">${esc(t.progress)}</span>`:''}<b class="task-rw">+${t.reward}</b></div>`).join('')}</div>
<div class="c-sect">Задания специалиста</div>${(g.personal_tasks||[]).length?`<div class="card pad task-list">${g.personal_tasks.map(t=>`
  <div class="ptask ${t.status==='done'?'done':''}">
    <span class="task-check">${t.status==='done'?icon('check'):(t.kind==='photo'?icon('camera'):'')}</span>
    <div class="grow"><strong>${esc(t.title)}</strong>
      ${t.note?`<span class="muted small">${esc(t.note)}</span>`:''}
      ${t.due_on&&t.status!=='done'?`<span class="muted small">до ${esc(hDay(t.due_on))}</span>`:''}
      ${t.comment?`<span class="muted small">Ваш ответ: ${esc(t.comment)}</span>`:''}</div>
    ${t.photo_url?`<img class="ptask-photo" src="${esc(t.photo_url)}" alt="">`:''}
    ${t.status==='done'
      ?`<span class="task-pts done">+${t.points}</span>`
      :`<button class="primary green sm" onclick="clTaskDone(${t.id},${t.kind==='photo'?1:0})">${t.kind==='photo'?'Отчёт':'Готово'}</button>`}
  </div>`).join('')}</div>`:'<div class="card pad"><p class="muted small">Личных заданий пока нет.</p></div>'}
<div class="c-sect">Достижения</div><div class="ach-grid">${g.achievements.map(a=>`<div class="ach-cell ${a.unlocked?'on':''}"><div class="ach-ic">${icon(a.unlocked?a.icon:'lock')}</div><b>${esc(a.label)}</b><span class="muted">${esc(a.hint)}</span></div>`).join('')}</div>
<div class="c-sect">Обменять баллы</div>${g.rewards.length?`<div class="rewards-list">${g.rewards.map(r=>{const ok=g.balance>=r.cost;return `<div class="reward-row card ${ok?'':'locked'}"><div class="rw-ic">${icon('gift')}</div><div class="grow"><strong>${esc(r.label)}</strong><span class="muted small">${esc(r.note||'')}</span></div><button class="primary green sm" ${ok?'':'disabled'} onclick="clRedeem(${r.id},'${esc(r.label).replace(/'/g,"\\'")}')">${r.cost} б.</button></div>`}).join('')}</div>`:'<div class="card pad"><p class="muted small">Специалист пока не назначил, на что можно обменять баллы.</p></div>'}
${g.redemptions.length?`<div class="c-sect">Мои коды</div><div class="card pad">${g.redemptions.map(r=>`<div class="promo-row"><div><b>${esc(r.title||'Привилегия')}</b></div><code class="promo-code">${esc(r.code)}</code></div>`).join('')}</div>`:''}
<p class="rw-foot muted">Баллы начисляются за отмеченные приёмы пищи (+10), идеальные дни без пропусков (+25), записи веса (+15) и выполненные задания специалиста. Код обмена назовите специалисту — он и выдаёт привилегию.</p>`,'user'))}
/* Задание с фотоотчётом без снимка не закрывается: специалист хочет
   увидеть результат, а не галочку. */
function clTaskDone(id,needPhoto){
  showSheet(`<div class="sheet-head"><h2>Закрыть задание</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="clSendTask(event,${id},${needPhoto})">
    ${needPhoto?`<label>Фотоотчёт<input id="tk_f" type="file" accept="image/*" required></label>`:''}
    <label>Комментарий${needPhoto?' (необязательно)':''}<textarea id="tk_c" rows="3" placeholder="Как прошло"></textarea></label>
    <button class="primary green wide">Отправить</button>
  </form>`);
}
async function clSendTask(e,id,needPhoto){e.preventDefault();
  try{
    const fd=new FormData();
    fd.append('comment',$('#tk_c').value||'');
    if(needPhoto){
      const f=$('#tk_f').files[0];
      if(!f){toast('Приложите фото','err');return}
      fd.append('photo',f);
    }
    await api('/client/tasks/'+id+'/done',{method:'POST',body:fd});
    A.gam=null;closeModal();clRewards();
  }catch(x){toast(x.message,'err')}
}
async function clRedeem(id,label){
  if(!confirm('Обменять баллы на «'+label+'»?'))return;
  try{
    const j=await api('/client/redeem',{method:'POST',body:JSON.stringify({reward_id:id})});
    A.gam=null;
    toast('Готово. Код обмена: '+j.code+'\nНазовите его специалисту — привилегию выдаёт он.','ok');
    clRewards();
  }catch(e){toast(e.message,'err')}
}
async function clDish(id){
  /* Отдельный экран, а не шторка снизу — как Dish.tsx в приложении:
     «назад» в шапке, приём надзаголовком, квадратное фото, карточка
     порции, состав и рецепт списками, действия внизу. */
  const j=await api('/client/menu-items/'+id);const x=j.item;
  const done=x.log_status==='eaten';const n=x.nutrition;
  const photo=dishPhoto(x);
  go(clShell(`${navBar('',"clToday()")}
<div class="eyebrow">${esc(MEAL[x.meal_type]||'Блюдо')}</div>
<h1 class="dish-title">${esc(x.dish_name)}</h1>
${photo?`<div class="dish-hero" style="background-image:url(${esc(photo)})"></div>`:''}
<div class="card dish-portion"><div class="eyebrow">Порция</div>
  <div class="dp-row"><b class="num">${R(x.portion_g)}</b><span class="muted">г</span></div>
  <div class="dp-row second"><b>${R(n.kcal)}</b><span class="muted">ккал · Б ${R(n.protein)} · Ж ${R(n.fat)} · У ${R(n.carbs)} г</span></div>
</div>
${x.ingredients&&x.ingredients.length?`<h3 class="dish-sect">Состав</h3><div class="card flat"><ul class="complist">${x.ingredients.map(i=>`<li><span>${esc(i.ingredient_name)}</span><b class="num">${R(i.grams)} г</b></li>`).join('')}</ul></div>`:''}
${x.instructions?`<h3 class="dish-sect">Рецепт</h3><div class="card"><p class="dish-recipe">${esc(x.instructions)}</p></div>`:''}
<div class="dish-actions">
  <button class="primary wide" onclick="clLog(${id},'${done?'planned':'eaten'}')">${done?'Отмечено':'Я съел(а)'}</button>
  <button class="secondary wide" onclick="clReplace(${id})">Заменить блюдо</button>
  <button class="ghost wide" onclick="clSkip(${id})">Пропустить</button>
</div>`,'home'))}

async function clLog(id,st){await api('/client/meals/'+id+'/log',{method:'POST',body:JSON.stringify({status:st})});A.gam=null;closeModal();clToday()}
function clSkip(id){showSheet(`<div class="sheet-head"><h2>Почему пропуск?</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="reason-list">${['Не было времени','Не было продуктов','Не хотелось','Ел(а) другое','Другое'].map(r=>`<button class="reason" onclick="clDoSkip(${id},'${r}')">${r}</button>`).join('')}</div>`)}
async function clDoSkip(id,reason){await api('/client/meals/'+id+'/log',{method:'POST',body:JSON.stringify({status:'skipped',reason})});A.gam=null;closeModal();clToday()}
/* Насколько замена отличается от того, что стояло в плане. Клиенту
   важно не абсолютное число, а «съем ли я больше», поэтому со знаком. */
const replDiff=n=>n>0?'+'+n:(n<0?'\u2212'+Math.abs(n):'0');
/* Зелёным — то, что совпало, жёлтым — где расхождение заметное. Красить
   всю строку одним цветом нельзя: «калории те же» при белке −14 г
   читалось бы как «всё совпало», а это неправда. */
const replTag=(n,lim,txt)=>`<b class="${Math.abs(n)<=lim?'same':'off'}">${txt}</b>`;
async function clReplace(id){const j=await api('/client/menu-items/'+id+'/replacements');const ds=j.dishes||[];if(!ds.length){toast('Подходящих замен для этого блюда не нашлось.','err');return}const hint=j.source==='specialist'?'Замены, которые разрешил специалист':'Подобрали блюда с близкими КБЖУ';showSheet(`<div class="sheet-head"><div><h2>Заменить блюдо</h2><p class="muted">${hint}</p></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="repl-list">${ds.map((d,i)=>`<label class="repl"><span class="thumb" style="background-image:url(${esc(dishThumb(d))})"></span><div class="grow"><strong>${esc(d.name)}</strong><small class="num">${d.portion_g} г · ${d.kcal} ккал · Б ${d.protein} · Ж ${d.fat} · У ${d.carbs}</small><small class="num repl-diff">${replTag(d.kcal_diff,15,Math.abs(d.kcal_diff)<=15?'калории те же':replDiff(d.kcal_diff)+' ккал')} · Б ${replTag(d.protein_diff,9,replDiff(d.protein_diff))} · Ж ${replTag(d.fat_diff,9,replDiff(d.fat_diff))} · У ${replTag(d.carbs_diff,14,replDiff(d.carbs_diff))}</small></div><input type="radio" name="repl" value="${d.id}" ${i===0?'checked':''}></label>`).join('')}</div><button class="primary wide" onclick="clDoReplace(${id})">Заменить блюдо</button>`)}
async function clDoReplace(id){const sel=document.querySelector('input[name=repl]:checked');if(!sel)return;await api('/client/menu-items/'+id+'/replace',{method:'POST',body:JSON.stringify({dish_id:+sel.value})});closeModal();clToday()}

async function clWeek(day){
  /* Как Week.tsx в приложении: полоса дней сверху, содержимое выбранного
     дня — тут же. Раньше день открывался отдельным экраном, и чтобы
     сравнить два дня, приходилось ходить туда-обратно. */
  const j=await api('/client/week');if(!j.menu)return clToday();A._week=j;
  const days=j.menu.days_count;
  let d=day;
  if(!d){for(let n=1;n<=days;n++)if(isToday(menuDate(j.menu.start_date,n))){d=n;break}}
  d=Math.min(days,Math.max(1,d||1));
  const tk=A.user?.target_kcal||j.menu.target_kcal||1800;
  const items=j.items.filter(x=>+x.day_number===d);
  const tot=j.days[d]||{kcal:0,protein:0,fat:0,carbs:0};
  const pct=tk?R(tot.kcal/tk*100):0;
  const tg={protein:A.user?.target_protein||110,fat:A.user?.target_fat||60,carbs:A.user?.target_carbs||190};
  const strip=Array.from({length:days},(_,n)=>{const num=n+1;const dt=menuDate(j.menu.start_date,num);
    const on=num===d,now=isToday(dt);
    return `<button class="wd${on?' on':''}${now&&!on?' now':''}" onclick="clWeek(${num})"><small>${dowShort(dt)}</small><b>${dayNum(dt)}</b></button>`}).join('');
  go(clShell(`<div class="eyebrow">${esc(j.menu.title||'Меню')}</div><h1 class="week-title">Неделя</h1>
<div class="wd-strip">${strip}</div>
<div class="wd-head"><h3>${esc(dayTitle(j.menu.start_date,d))}</h3>${isToday(menuDate(j.menu.start_date,d))?'<span class="muted">сегодня</span>':''}</div>
<div class="wgrid"><div class="wtile wide">${ring(pct,96,R(pct)+'%')}<div class="wt-body"><div class="wt-lbl">Калории за день</div><div class="wt-big num">${R(tot.kcal)} <small>/ ${tk}</small></div><div class="wt-foot">${items.length} ${plural(items.length,['блюдо','блюда','блюд'])} в плане</div></div></div>${macroTiles(tot,tg)}</div>
${MEAL_ORDER.map(mt=>{const arr=items.filter(x=>x.meal_type===mt);if(!arr.length)return '';const mk=arr.reduce((s,x)=>s+(x.nutrition?.kcal||0),0);return `<div class="meal-sec"><div class="meal-head"><b>${MEAL[mt]}</b><small>${timeFor(mt)} · ${R(mk)} ккал</small></div><div class="meal-group">${arr.map(x=>`<div class="meal-row" onclick="clDish(${x.id})"><span class="mr-thumb" style="background-image:url(${esc(dishThumb(x))})"></span><div class="mr-body"><strong>${esc(x.dish_name)}</strong><small class="num">${R(x.portion_g)} г · ${R(x.nutrition.kcal)} ккал</small></div>${icon('chevr')}</div>`).join('')}</div></div>`}).join('')||`<div class="empty"><div class="orb">${icon('bowl')}</div><h3>На этот день блюд ещё нет</h3></div>`}
<button class="shop-cta" onclick="clShopping()"><span class="shop-ic">${icon('cart')}</span><div class="grow"><strong>Список покупок</strong><small>Всё, что нужно купить на меню</small></div>${icon('chevr')}</button>`,'cal'))}
function clDayView(d){return clWeek(d)}

function clAddWeight(){showSheet(`<div class="sheet-head"><h2>Добавить вес</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><form onsubmit="clSaveWeight(event)"><label>Вес, кг<input id="wv" type="number" step="0.1" required></label><button class="primary wide">Сохранить</button></form>`)}
async function clSaveWeight(e){e.preventDefault();await api('/client/weight',{method:'POST',body:JSON.stringify({weight_kg:+$('#wv').value})});closeModal();A.ptab='weight';clProgress()}
function clAddMeasure(){showSheet(`<div class="sheet-head"><h2>Добавить замеры</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><form onsubmit="clSaveMeasure(event)" class="formgrid"><label>Талия, см<input id="mw" type="number"></label><label>Бёдра, см<input id="mh" type="number"></label><label>Грудь, см<input id="mc" type="number"></label><button class="primary wide full">Сохранить</button></form>`)}
async function clSaveMeasure(e){e.preventDefault();await api('/client/measurements',{method:'POST',body:JSON.stringify({waist_cm:+$('#mw').value||null,hips_cm:+$('#mh').value||null,chest_cm:+$('#mc').value||null})});closeModal();A.ptab='measure';clProgress()}
async function clUploadPhoto(inp){if(!inp.files[0])return;const fd=new FormData();fd.append('photo',inp.files[0]);try{await api('/client/progress/photo',{method:'POST',body:fd});A.ptab='photo';clProgress()}catch(e){toast(e.message,'err')}}

/* Своё сообщение показываем сразу и на месте. Прежде здесь стоял
   вызов clChat() — полная перерисовка экрана: переписка прыгала
   наверх, а поле ввода теряло фокус и клавиатура закрывалась. */
async function clSend(e){
  e.preventDefault();
  const el=$('#ci'),v=el.value.trim();if(!v)return;
  el.value='';
  try{
    const r=await api('/client/messages',{method:'POST',body:JSON.stringify({body:v})});
    if(r&&r.message)chatAppend([r.message]);
  }catch(err){el.value=v;toast(err.message||'Не отправилось','err')}
}
async function clAttach(inp){if(!inp.files||!inp.files[0])return;const f=inp.files[0];inp.value='';try{const fd=new FormData();fd.append('file',f);const j=await api('/client/attachment',{method:'POST',body:fd});await api('/client/messages',{method:'POST',body:JSON.stringify({attachment_url:j.url})});clChat()}catch(e){toast(e.message||'Не удалось загрузить файл','err')}}

async function clProfile(){const u=A.user;const pj=await api('/client/preferences').catch(()=>({preferences:{}}));const p=pj.preferences||{};const arr=v=>{try{return JSON.parse(v||'[]')||[]}catch{return[]}};const age=u.birth_year?new Date().getFullYear()-u.birth_year:null;
go(clShell(`${clHead('Профиль',u.name,"clBackToMore()")}
<div class="cl-avatar"><label class="avatar-edit">${av(u.name,'huge',u.avatar_url)}<input type="file" accept="image/*" hidden onchange="clUploadAvatar(this)"><span class="cam">${icon('camera')}</span></label>${u.avatar_url?`<button class="textbtn danger-text" onclick="clDeleteAvatar()">Удалить фото</button>`:`<span class="muted small">Добавьте фото профиля</span>`}</div>
${foldCard('f_me','Мои данные',`<div class="prof-summary"><div class="ps-row"><span>Цель</span><b>${esc(u.goal||'—')}</b></div><div class="ps-row"><span>Текущий вес</span><b class="num">${kg(u.weight_kg)} кг</b></div><div class="ps-row"><span>Рост</span><b class="num">${u.height_cm||'—'} см</b></div><div class="ps-row"><span>Возраст</span><b class="num">${age||'—'}</b></div><div class="ps-row"><span>Уровень активности</span><b>${esc(u.activity_level||'—')}</b></div></div>`,esc([u.goal||'',u.weight_kg?kg(u.weight_kg)+' кг':''].filter(Boolean).join(' · ')||'не заполнены'))}
${foldCard('f_prefs','Предпочтения',`<form onsubmit="clSavePrefs(event)"><label>Люблю<input id="cl_l" value="${esc(arr(p.likes).join(', '))}"></label><label>Не люблю<input id="cl_d" value="${esc(arr(p.dislikes).join(', '))}"></label><label>Исключения<input id="cl_e" value="${esc(arr(p.excluded).join(', '))}"></label><button class="primary wide">Сохранить</button></form>`,(()=>{const n=arr(p.likes).length+arr(p.dislikes).length+arr(p.excluded).length;return n?n+' '+plural(n,['пункт','пункта','пунктов']):'не заполнены'})())}
${themeCard()}<div class="card pad"><h3>Ещё</h3><button class="row-btn" onclick="clRewards()">${icon('gift')}<span>Награды и баллы</span>${icon('chevr')}</button><button class="row-btn" onclick="clHealth()">${icon('heart')}<span>Моё здоровье</span>${icon('chevr')}</button><button class="row-btn" onclick="pushSettings()">${icon('bell')}<span>Уведомления и тихие часы</span>${icon('chevr')}</button><button class="row-btn" onclick="clCheckin()">${icon('check')}<span>Еженедельный check-in</span>${icon('chevr')}</button><button class="row-btn" onclick="logout()">${icon('user')}<span>Выйти</span>${icon('chevr')}</button><button class="row-btn danger-row" onclick="deleteAccount('client')">${icon('trash')}<span>Удалить аккаунт</span>${icon('chevr')}</button></div>`,'user'))}
async function clSavePrefs(e){e.preventDefault();const split=v=>v.split(',').map(s=>s.trim()).filter(Boolean);await api('/client/preferences',{method:'PATCH',body:JSON.stringify({likes:split($('#cl_l').value),dislikes:split($('#cl_d').value),excluded:split($('#cl_e').value)})});toast('Сохранено ✓','ok')}
function clCheckin(){showSheet(`<div class="sheet-head"><h2>Как прошла неделя?</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><form onsubmit="clSubmitCheckin(event)"><label>Легко ли соблюдать меню?<select id="ck_e"><option value="1">Очень сложно</option><option value="2">Сложно</option><option value="3" selected>Нормально</option><option value="4">Легко</option><option value="5">Очень легко</option></select></label><label>Самочувствие (1–10)<input id="ck_w" type="number" min="1" max="10"></label><label>Что было сложным<textarea id="ck_d"></textarea></label><button class="primary wide">Отправить специалисту</button></form>`)}
async function clSubmitCheckin(e){e.preventDefault();await api('/client/checkin',{method:'POST',body:JSON.stringify({ease_score:+$('#ck_e').value,wellbeing_score:$('#ck_w').value?+$('#ck_w').value:null,difficulties:$('#ck_d').value?[$('#ck_d').value]:[],comment:$('#ck_d').value})});closeModal();toast('Отчёт отправлен ✓','ok')}

async function spUploadAvatar(inp){if(!inp.files[0])return;const fd=new FormData();fd.append('photo',inp.files[0]);try{const j=await api('/specialist/avatar',{method:'POST',body:fd});A.user.avatar_url=j.avatar_url;spProfile()}catch(e){toast(e.message,'err')}}
async function clUploadAvatar(inp){if(!inp.files[0])return;const fd=new FormData();fd.append('photo',inp.files[0]);try{const j=await api('/client/avatar',{method:'POST',body:fd});A.user.avatar_url=j.avatar_url;clProfile()}catch(e){toast(e.message,'err')}}
async function spDeleteAvatar(){if(!confirm('Удалить фото профиля?'))return;await api('/specialist/avatar',{method:'DELETE'});A.user.avatar_url=null;spProfile()}
async function clDeleteAvatar(){if(!confirm('Удалить фото профиля?'))return;await api('/client/avatar',{method:'DELETE'});A.user.avatar_url=null;clProfile()}

/* ---------- modal / sheet ---------- */
function showModal(content){closeModal();const m=document.createElement('div');m.className='modal';m.id='modal';m.innerHTML=`<div class="sheet">${content}</div>`;m.addEventListener('click',e=>{if(e.target===m)closeModal()});document.body.appendChild(m)}
function showSheet(content){closeModal();const m=document.createElement('div');m.className='modal sheet-mode';m.id='modal';m.innerHTML=`<div class="sheet">${content}</div>`;m.addEventListener('click',e=>{if(e.target===m)closeModal()});document.body.appendChild(m)}
/* Закрыли лист — гасим камеру. Забытый поток держит индикатор записи
   и жрёт батарею: на телефоне это замечают сразу. */
function closeModal(){const m=$('#modal');if(m)m.remove();if(typeof foodScanStop==='function')foodScanStop()}

pickupOauthReturn();
/* Внутри Telegram страницу открывает WebView, где сервис-воркер или не
   заводится вовсе, или держит свой кэш и перестаёт отдавать правки.
   Второе хуже: приложение выглядит рабочим, но живёт прошлой версией.
   Поэтому в Telegram его не регистрируем — там и офлайна нет.

   Первый route() здесь пропускаем, когда страницу открыли из Telegram:
   tg.js ещё не успел войти, и человек увидел бы форму входа на миг
   раньше, чем свой экран. Его вызывает tg.js, когда разберётся. */
/* Признак ставит сама страница — до загрузки app.js. По window.Telegram
   судить нельзя: скрипт мессенджера грузится после нас, и к этому
   моменту и первый route(), и регистрация воркера уже отработали бы. */
if(!window.TG_MAYBE)route();
if(!window.TG_MAYBE&&'serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});

/* -------- Web Push -------- */
/* Ключ, под которым заведена подписка, лежит в её настройках сырыми
   байтами — приводим к тому же виду, в каком ключ приходит с сервера. */
function pushKeyMatches(sub,serverKey){
  try{
    const raw=sub.options&&sub.options.applicationServerKey;
    if(!raw||!serverKey)return false;
    const b=new Uint8Array(raw);
    let str='';for(let i=0;i<b.length;i++)str+=String.fromCharCode(b[i]);
    const mine=btoa(str).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
    return mine===String(serverKey).replace(/=+$/,'');
  }catch(e){return false}
}
function base64ToBytes(b){const pad='='.repeat((4-b.length%4)%4),s=(b+pad).replace(/-/g,'+').replace(/_/g,'/');const raw=atob(s);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)))}
/* ---------- Напоминание включить уведомления ----------
   Без них человек не узнает ни о меню, ни о сообщении, ни о звонке —
   а включить их можно только его собственным нажатием: браузер не
   спрашивает разрешение сам. Полоска висит на каждом экране, пока
   уведомления не включены, и исчезает сразу после.

   Отказ уважаем: «Не сейчас» прячет полоску на неделю, а не навсегда —
   иначе человек, случайно закрывший её в первый день, больше никогда
   о ней не вспомнит. Если браузер уведомления запретил насовсем,
   зовём не включать, а снять запрет: кнопка там бессильна. */
const NUDGE_KEY='nm_push_nudge_until';
function pushNudgeHidden(){
  try{ return Date.now()<+(localStorage.getItem(NUDGE_KEY)||0) }catch(e){ return false }
}
function pushNudgeNeeded(){
  if(!('Notification'in window)||!('serviceWorker'in navigator))return false;
  if(Notification.permission==='granted')return false;
  return !pushNudgeHidden();
}
function pushNudge(){
  if(!pushNudgeNeeded())return '';
  const denied=Notification.permission==='denied';
  return `<div class="push-nudge" id="pushNudge">
    <span class="pn-ic">${icon('bell')}</span>
    <div class="grow">
      <strong>${denied?'Уведомления запрещены':'Включите уведомления'}</strong>
      <span>${denied
        ? 'Снимите запрет в настройках сайта — иначе сообщения и звонки пройдут мимо.'
        : 'Иначе вы не узнаете о новом меню, сообщении и звонке.'}</span>
    </div>
    ${denied?'':`<button class="primary sm" onclick="pushNudgeOn()">Включить</button>`}
    <button class="pn-close" aria-label="Не сейчас" onclick="pushNudgeLater()">${icon('x')}</button>
  </div>`;
}
async function pushNudgeOn(){
  await enablePush();
  /* Разрешение выдано — полоска больше не нужна ни на одном экране. */
  if(Notification.permission==='granted')pushNudgeRemove();
}
function pushNudgeLater(){
  try{ localStorage.setItem(NUDGE_KEY,String(Date.now()+7*24*3600*1000)) }catch(e){}
  pushNudgeRemove();
}
function pushNudgeRemove(){
  const el=$('#pushNudge');
  if(el)el.remove();
}

async function enablePush(){if(!('serviceWorker'in navigator)||!('PushManager'in window)||!('Notification'in window)){toast('Push не поддерживается этим браузером.','err');return}try{const perm=await Notification.requestPermission();if(perm!=='granted'){toast('Разрешение не выдано.','err');return}const cfg=await api('/public/config');if(!cfg.vapid_public_key){toast('Push пока не настроен на сервере.','err');return}const reg=await navigator.serviceWorker.ready;let sub=await reg.pushManager.getSubscription();
/* Подписка на устройстве переживает смену ключа на сервере, и старую
   службы доставки отвергают кодом 403: она подписана под прежний
   ключ. Сверяем и, если ключ другой, заводим подписку заново. */
if(sub&&!pushKeyMatches(sub,cfg.vapid_public_key)){try{await sub.unsubscribe()}catch(e){}sub=null}
if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:base64ToBytes(cfg.vapid_public_key)});await api('/push/subscribe',{method:'POST',body:JSON.stringify({endpoint:sub.endpoint,keys:{p256dh:sub.toJSON().keys.p256dh,auth:sub.toJSON().keys.auth},device:/iPhone|iPad|iPod/i.test(navigator.userAgent)?'ios':/Android/i.test(navigator.userAgent)?'android':'web'})});toast('Уведомления включены ✓','ok')}catch(e){toast(e.message||'Не удалось включить уведомления','err')}}
/* Проверка доставки. «Включил, а не приходит» бывает по пяти разным
   причинам, и снаружи они выглядят одинаково: нет разрешения, нет
   подписки, на сервере нет ключей или библиотеки, подписка протухла.
   Кнопка спрашивает сервер и печатает, что именно не так. */
async function pushTest(){
  const el=$('#push_diag');
  if(el)el.innerHTML='<p class="muted small">Проверяем…</p>';
  try{
    const j=await api('/push/test',{method:'POST'});
    const rows=[];
    const perm=('Notification'in window)?Notification.permission:'нет';
    rows.push(['Разрешение браузера',perm==='granted'?'выдано':perm==='denied'?'запрещено — снимите запрет в настройках сайта':'не запрошено',perm==='granted']);
    rows.push(['Подписка этого устройства',(j.web||0)+(j.expo||0)?'есть':'нет — нажмите «Включить уведомления»',!!((j.web||0)+(j.expo||0))]);
    rows.push(['Шифрование на сервере',j.openssl===true?'openssl на месте':String(j.openssl||'нет openssl'),j.openssl===true]);
    rows.push(['Ключи VAPID',j.keys?'готовы':'создать не удалось',!!j.keys]);
    if(j.sent!==null&&j.sent!==undefined)
      rows.push(['Отправлено сейчас',String(j.sent),j.sent>0]);
    if(el)el.innerHTML=rows.map(([k,v,ok])=>
      `<div class="pd-row ${ok?'ok':'bad'}"><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('')
      +((j.errors&&j.errors.length)
        ? `<div class="pd-err">${j.errors.map(e=>esc(e)).join('<br>')}</div>` : '');
    if((j.sent||0)>0)toast('Проверочное отправлено — ждите уведомление','ok');
  }catch(e){ if(el)el.innerHTML=`<div class="pd-err">${esc(e.message||'Проверка не удалась')}</div>` }
}
async function disablePush(){try{const reg=await navigator.serviceWorker.ready;const sub=await reg.pushManager.getSubscription();if(sub){await api('/push/subscribe',{method:'DELETE',body:JSON.stringify({endpoint:sub.endpoint})});await sub.unsubscribe()}toast('Уведомления отключены','ok')}catch(e){toast(e.message,'err')}}
async function pushSettings(){const endpoint=A.type==='client'?'/client/push/preferences':'/specialist/push/preferences';try{const j=await api(endpoint);const p=j.preferences||{};showSheet(`<div class="sheet-head"><div><div class="eyebrow">Уведомления</div><h2>Настройки</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="push-status"><button class="primary wide" onclick="enablePush()">Включить уведомления</button><button class="secondary wide" onclick="disablePush()">Отключить</button>${A.type==='admin'?`<button class="secondary wide" onclick="pushTest()">Проверить доставку</button>`:''}<div id="push_diag" class="push-diag"></div></div><div class="formgrid push-prefs">${A.type==='client'?`<label><input id="pb" type="checkbox" ${p.breakfast?'checked':''}> Завтрак</label><label><input id="pl" type="checkbox" ${p.lunch?'checked':''}> Обед</label><label><input id="pd" type="checkbox" ${p.dinner?'checked':''}> Ужин</label><label><input id="pw" type="checkbox" ${p.weight?'checked':''}> Вес</label><label><input id="pm" type="checkbox" ${p.messages?'checked':''}> Сообщения</label><label><input id="pu" type="checkbox" ${p.menu_updates?'checked':''}> Изменения меню</label>`:`<label><input id="pm" type="checkbox" ${p.messages?'checked':''}> Сообщения</label><label><input id="plog" type="checkbox" ${p.meal_logs?'checked':''}> Отметки питания</label><label><input id="pin" type="checkbox" ${p.client_inactive?'checked':''}> Неактивные клиенты</label>`}<label>Не беспокоить с<input id="qs" type="time" value="${esc(p.quiet_start||'22:00')}"></label><label>до<input id="qe" type="time" value="${esc(p.quiet_end||'08:00')}"></label></div><button class="primary wide" onclick="savePush()">Сохранить</button>`)}catch(e){toast(e.message,'err')}}
async function savePush(){const endpoint=A.type==='client'?'/client/push/preferences':'/specialist/push/preferences';const b={quiet_start:$('#qs').value,quiet_end:$('#qe').value};if(A.type==='client')Object.assign(b,{breakfast:$('#pb').checked?1:0,lunch:$('#pl').checked?1:0,dinner:$('#pd').checked?1:0,weight:$('#pw').checked?1:0,messages:$('#pm').checked?1:0,menu_updates:$('#pu').checked?1:0});else Object.assign(b,{messages:$('#pm').checked?1:0,meal_logs:$('#plog').checked?1:0,client_inactive:$('#pin').checked?1:0});await api(endpoint,{method:'PATCH',body:JSON.stringify(b)});closeModal()}

/* -------- Плавающее меню: FAB и «Ещё» -------- */
/* «Ещё» в приложении — полноценный экран с логотипом в шапке и списками,
   разбитыми на группы, а не шторка снизу. Строки идут во всю ширину:
   это список, а не набор карточек. */
function moreScreen(shell,groups,active){
  const rows=g=>g.rows.map(([ic,label,fn,cls])=>
    `<button class="lrow ${cls||''}" onclick="${fn}">${icon(ic)}<span class="grow">${esc(label)}</span>${cls==='danger'?'':icon('chevr')}</button>`).join('');
  const body=groups.map(g=>
    (g.title?`<div class="lhead">${esc(g.title)}</div>`:'')+`<div class="lgroup">${rows(g)}</div>`).join('');
  go(shell(`<div class="navbar navbar-logo">${logoSvg('nb-logo')}</div>${body}`,active));
}
function clMore(){
  /* Пока специалист не выбран, половина списка ведёт в пустоту: отзыв не
     о ком, услуги не у кого. Вместо них — вход в каталог: это и есть
     следующий шаг, а не ещё один пункт среди прочих. */
  const has=!!(A.user&&A.user.specialist_id);
  moreScreen(clShell,[
  {rows:[['user','Профиль','clProfile()'],
         ['weight','Прогресс и замеры','clProgress()'],
         ['heart','Моё здоровье','clHealth()'],
         ['cart','Список покупок','clShopping()']]},
  {title:'Специалист',rows: has
    ? [...(feat('payments')?[['tag','Услуги и цены','clServices()']]:[]),
       ['star','Отзыв о специалисте','clReview()']]
    /* Каталог выключен — пункта нет вовсе: вести в поиск, которого не
       будет, хуже, чем не показывать строку. Код от специалиста
       по-прежнему работает на экране входа. */
    : (feat('catalog')?[['users','Найти специалиста','clFindSpecialist()']]:[])},
  {title:'Мотивация и связь',rows:[
         ['gift','Награды и баллы','clRewards()'],
         ...(feat('feed')?[['heart','Лента','feedScreen()']]:[]),
         ['bell','Уведомления','pushSettings()'],
         ['edit','Отчёт за неделю','clCheckin()']]},
  {title:'Поддержка',rows:[
         ['spark','EQUA info','infoScreen()'],
         ['chat','Написать в поддержку','supportScreen()']]},
],'more')}
function spMore(){moreScreen(spShell,[
  {rows:[['bowl','База блюд','spDishes()'],
         ['layers','Шаблоны меню','spTemplates()'],
         ['tag','Продукты','spIngredients()'],
         ['trend','Аналитика','spAnalytics()']]},
  {title:'Практика',rows:[
         ['coin','Баланс','spBalance()'],
         ['gift','Мои услуги','spServices()'],
         ['user','Код для клиентов','spInviteCode()'],
         ['edit','Настройки','spProfile()']]},
  {title:'Поддержка',rows:[
         ['spark','EQUA info','infoScreen()'],
         ['chat','Написать в поддержку','supportScreen()'],
         ['exit','Выйти','logout()','danger']]},
],'more')}
function actSheet(title,sub,rows){showSheet(`<div class="sheet-grab"></div><div class="qa-head"><h2>${title}</h2>${sub?`<p class="muted small">${sub}</p>`:''}</div><div class="qa-list">${rows.map(r=>r==='sep'?`<div class="qa-sep"></div>`:`<button class="qa-row ${r[3]||''}" onclick="closeModal();${r[2]}"><span class="qa-ic ${r[4]||''}">${icon(r[0])}</span><span class="grow">${r[1]}</span>${r[3]==='danger'?'':icon('chevr')}</button>`).join('')}</div>`)}
function spQuickAdd(){actSheet('Создать','Быстрое действие',[['user','Добавить '+clientAcc(),'clientModal()','','good'],['bowl','Новое блюдо','spDishEditor()','','info'],['carrot','Новый ингредиент','spIngEditor()','','warm']])}
/* -------- Календарь-точки (неделя + раскрытие месяца) -------- */
function clCalStrip(){const g=A.gam;const week=(g&&g.week)||[];const now=new Date();const pad=n=>String(n).padStart(2,'0');const today=now.getFullYear()+'-'+pad(now.getMonth()+1)+'-'+pad(now.getDate());
 const days=week.map(d=>{const dt=new Date(d.date+'T00:00:00');const isT=d.date===today;const pc=d.pct==null?0:d.pct;const cls=d.logged?(pc>=80?'ok':'part'):'';return `<button class="cal-day ${isT?'sel':''}" type="button"><span class="cal-dow">${esc(d.label)}</span><span class="cal-dot ${cls}"><i>${dt.getDate()}</i></span></button>`}).join('');
 return `<div class="cal" id="cal"><button class="cal-toggle" type="button" onclick="clCalToggle()"><b>${now.toLocaleDateString('ru-RU',{month:'long',year:'numeric'})}</b>${icon('chevd')}</button><div class="cal-week">${days||'<span class="muted small">Неделя появится после первых отметок</span>'}</div><div class="cal-month">${clCalMonth(now)}</div></div>`}
function clCalMonth(now){const y=now.getFullYear(),m=now.getMonth();const startDow=(new Date(y,m,1).getDay()+6)%7;const dim=new Date(y,m+1,0).getDate();const wd=['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];const pad=n=>String(n).padStart(2,'0');const today=y+'-'+pad(m+1)+'-'+pad(now.getDate());const map={};((A.gam&&A.gam.week)||[]).forEach(d=>map[d.date]=d);
 let cells=wd.map(w=>`<span class="cm-wd">${w}</span>`).join('');for(let i=0;i<startDow;i++)cells+='<span class="cm-cell out"></span>';
 for(let dn=1;dn<=dim;dn++){const ds=y+'-'+pad(m+1)+'-'+pad(dn);const isT=ds===today;const info=map[ds];const cls=isT?'today':(info&&info.logged?(info.pct>=80?'ok':'part'):'');cells+=`<span class="cm-cell ${cls}">${dn}</span>`}
 return `<div class="cm-grid">${cells}</div>`}
function clCalToggle(){const c=document.getElementById('cal');if(c)c.classList.toggle('open')}

/* -------- iOS-ощущение: свайп вниз для закрытия нижних шторок -------- */
(function(){let sy=0,dragging=false,sheet=null;
 document.addEventListener('touchstart',e=>{const m=e.target.closest('.modal.sheet-mode');if(!m)return;const s=m.querySelector('.sheet');if(!s)return;const r=s.getBoundingClientRect();if(e.touches[0].clientY-r.top>96)return;sheet=s;sy=e.touches[0].clientY;dragging=true;s.style.transition='none'},{passive:true});
 document.addEventListener('touchmove',e=>{if(!dragging||!sheet)return;const dy=e.touches[0].clientY-sy;if(dy>0)sheet.style.transform='translateY('+dy+'px)'},{passive:true});
 document.addEventListener('touchend',e=>{if(!dragging||!sheet)return;const dy=e.changedTouches[0].clientY-sy;sheet.style.transition='transform .3s cubic-bezier(.2,.9,.2,1)';if(dy>120){sheet.style.transform='translateY(100%)';setTimeout(()=>closeModal(),260)}else{sheet.style.transform=''}dragging=false;sheet=null},{passive:true});
})();

/* -------- Регистрация: выбор роли + анкета клиента -------- */
function registerChoice(){A._regRole=null;
  go(authShell(`<h1 class="auth2-h1">Создать аккаунт</h1>
<p class="auth2-note">Кто вы?</p>
<div class="auth2-roles">
  <button type="button" class="auth2-role" onclick="regSpecForm()">${icon('grad')}<b>Я специалист</b><span>Нутрициолог, тренер или коуч — веду клиентов и составляю меню</span></button>
  <button type="button" class="auth2-role" onclick="registerClient()">${icon('bowl')}<b>Я клиент</b><span>Хочу вести питание, отмечать приёмы и следить за целями</span></button>
</div>`,"login()"))}
function regPick(group,val,el){A._reg[group]=val;el.parentElement.querySelectorAll('.role-opt').forEach(b=>b.classList.remove('active'));el.classList.add('active')}
async function regPickSpecialist(){let cs=[];try{cs=(await api('/catalog')).specialists||[]}catch(e){}showSheet(`<div class="sheet-head"><div><div class="eyebrow">Каталог</div><h2>Выберите специалиста</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><div class="picker-list"><button class="picker-row" onclick="regChooseSpec(0,'')">${av('?','')}<div class="grow"><strong>Пока без специалиста</strong><span class="muted">Выберу позже в каталоге</span></div>${icon('chevr')}</button>${cs.map(s=>`<button class="picker-row" onclick="regChooseSpec(${s.id},'${esc(String(s.name)).replace(/'/g,"\\'")}')">${av(s.name,'',s.avatar_url)}<div class="grow"><strong>${esc(s.name)}</strong><span class="muted">${esc(s.city||PROF[s.profession]||'Специалист')}</span></div>${icon('chevr')}</button>`).join('')||'<div class="empty small" style="padding:16px">Пока нет специалистов в каталоге</div>'}</div>`)}
async function doRegisterClient(e){e.preventDefault();const w=+$('#cr_w').value,h=+$('#cr_h').value,age=+$('#cr_age').value,sex=A._reg.sex,act=A._reg.activity,goal=A._reg.goal;const bmr=10*w+6.25*h-5*age+(sex==='m'?5:-161);const af={low:1.3,medium:1.5,high:1.7}[act]||1.5;let kcal=bmr*af;if(goal==='Снижение веса')kcal*=0.85;else if(goal==='Набор массы')kcal*=1.1;kcal=Math.max(1000,Math.round(kcal/10)*10);const protein=Math.round(1.8*w),fat=Math.round(0.9*w),carbs=Math.max(0,Math.round((kcal-protein*4-fat*9)/4));const dislikes=$('#cr_dis').value.split(',').map(s=>s.trim()).filter(Boolean);const answers={goal,sex,age,height_cm:h,weight_kg:w,activity_level:act,dislikes,target_kcal:kcal,target_protein:protein,target_fat:fat,target_carbs:carbs};try{const j=await api('/public/client-register',{method:'POST',body:JSON.stringify({name:$('#cr_name').value,email:$('#cr_email').value,password:$('#cr_pass').value,specialist_id:A._regSid||0,answers,source:signupSource()})});saveAuth(j);route()}catch(x){$('#cr_err').innerHTML=`<div class="error">${esc(x.message)}</div>`}}

/* -------- Анкета клиента: пошаговый мастер (в стиле MyFitnessPal) -------- */
function registerClient(){A._wiz={step:1,total:7,name:'',goal:'',sex:'',age:'',h:'',w:'',activity:'',dislikes:[],sid:0,specName:'',email:'',pass:''};wizRender()}
function wizOptions(field,opts){const W=A._wiz;return `<div class="wiz-opts">${opts.map(o=>`<button type="button" class="wiz-opt ${W[field]===o[0]?'on':''}" onclick="A._wiz['${field}']='${String(o[0]).replace(/'/g,"\\'")}';wizRender()"><div class="grow"><b>${o[1]}</b>${o[2]?`<small>${o[2]}</small>`:''}</div><span class="wiz-radio"></span></button>`).join('')}</div>`}
function wizToggleDislike(x){const d=A._wiz.dislikes,i=d.indexOf(x);if(i<0)d.push(x);else d.splice(i,1);wizRender()}
function wizBack(){if(A._wiz.step>1){A._wiz.step--;wizRender()}else registerChoice()}
function wizRender(){const W=A._wiz,s=W.step;let eyebrow='Анкета',title='',sub='',body='',nextLabel='Далее';
 if(s===1){eyebrow='Знакомство';title='Как к вам обращаться?';sub='Имя будем показывать в приложении.';body=`<input class="wiz-input" id="w_name" value="${esc(W.name)}" placeholder="Ваше имя" oninput="A._wiz.name=this.value" autofocus>`;}
 else if(s===2){eyebrow='Цель';title='С какой целью вы здесь?';sub='Выберите одну — под неё рассчитаем КБЖУ.';body=wizOptions('goal',[['Снижение веса','Похудеть'],['Поддержание','Поддерживать вес'],['Набор массы','Набрать вес'],['Набор мышечной массы','Набрать мышечную массу'],['Здоровье ЖКТ','Здоровье и ЖКТ']]);}
 else if(s===3){eyebrow='О вас';title='Немного о вас';sub='Нужно для точного расчёта нормы.';body=`<div class="wiz-seg">${[['f','Женский'],['m','Мужской']].map(([k,l])=>`<button type="button" class="wiz-segbtn ${W.sex===k?'on':''}" onclick="A._wiz.sex='${k}';wizRender()">${l}</button>`).join('')}</div><div class="wiz-fields"><label>Возраст<input type="number" inputmode="numeric" value="${esc(W.age)}" oninput="A._wiz.age=this.value"></label><label>Рост, см<input type="number" inputmode="numeric" value="${esc(W.h)}" oninput="A._wiz.h=this.value"></label><label>Вес, кг<input type="number" inputmode="decimal" step="0.1" value="${esc(W.w)}" oninput="A._wiz.w=this.value"></label></div>`;}
 else if(s===4){eyebrow='Активность';title='Насколько вы активны?';sub='В среднем за неделю.';body=wizOptions('activity',[['low','Низкая','Сидячий образ жизни, мало движения'],['medium','Средняя','Тренировки 2–3 раза в неделю'],['high','Высокая','Спорт почти каждый день']]);}
 else if(s===5){eyebrow='Предпочтения';title='Что вы не едите?';sub='Необязательно — можно пропустить.';body=`<div class="wiz-pills">${['Рыба','Мясо','Молочное','Глютен','Орехи','Грибы','Яйца','Мёд','Свинина','Лактоза'].map(x=>`<button type="button" class="wiz-pill ${W.dislikes.includes(x)?'on':''}" onclick="wizToggleDislike('${x}')">${x}</button>`).join('')}</div>`;}
 else if(s===6){eyebrow='Специалист';title='Выбрать специалиста?';sub='Он будет составлять вам меню. Можно выбрать позже.';body=`<button type="button" class="pick-spec" onclick="regPickSpecialist()">${icon('users')}<span>${W.sid?('Специалист: '+esc(W.specName)):'Пока без специалиста — выберу позже'}</span>${icon('chevr')}</button>`;}
 else{eyebrow='Аккаунт';title='Создайте аккаунт';sub='Чтобы сохранить прогресс и войти позже.';body=`<input class="wiz-input" type="email" placeholder="Email" value="${esc(W.email)}" oninput="A._wiz.email=this.value"><input class="wiz-input" type="password" placeholder="Пароль — от 8 символов, с цифрой" value="${esc(W.pass)}" oninput="A._wiz.pass=this.value"><div id="w_err"></div>`;nextLabel='Создать аккаунт';}
 const segs=Array.from({length:W.total},(_,i)=>`<i class="${i<s?'done':''}"></i>`).join('');
 go(`<div class="wiz"><div class="wiz-top"><button class="wiz-back" onclick="wizBack()">${icon('back')}</button><div class="wiz-eyebrow">${eyebrow}</div><button class="wiz-skip" onclick="login()">${icon('x')}</button></div><div class="wiz-prog">${segs}</div><div class="wiz-body"><h1>${title}</h1><p class="wiz-sub">${sub}</p>${body}</div><div class="wiz-foot"><button class="primary wide" onclick="wizNext()">${nextLabel}</button>${W.step===W.total?legalNote():''}</div></div>`);const f=$('#w_name');if(f)f.focus()}
function regChooseSpec(id,name){A._wiz.sid=id;A._wiz.specName=name;closeModal();wizRender()}
function wizNext(){const W=A._wiz,s=W.step,err=m=>{const e=$('#w_err');if(e)e.innerHTML=`<div class="error">${m}</div>`;else toast(m,'err')};
 if(s===1&&!W.name.trim())return err('Введите имя');
 if(s===2&&!W.goal)return err('Выберите цель');
 if(s===3){if(!W.sex)return err('Укажите пол');if(!(+W.age>0)||!(+W.h>0)||!(+W.w>0))return err('Заполните возраст, рост и вес')}
 if(s===4&&!W.activity)return err('Выберите уровень активности');
 if(s<W.total){W.step++;return wizRender()}
 // финал — регистрация
 const w=+W.w,h=+W.h,age=+W.age,sex=W.sex,act=W.activity,goal=W.goal;
 const em=String(W.email||'').trim();if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em))return err('Введите корректный email');
 if(!(W.pass&&W.pass.length>=8&&/\d/.test(W.pass)))return err('Пароль от 8 символов и с цифрой');
 const bmr=10*w+6.25*h-5*age+(sex==='m'?5:-161),af={low:1.3,medium:1.5,high:1.7}[act]||1.5;let kcal=bmr*af;if(goal==='Снижение веса')kcal*=0.85;else if(goal==='Набор массы'||goal==='Набор мышечной массы')kcal*=1.1;kcal=Math.max(1000,Math.round(kcal/10)*10);
 const protein=Math.round((goal==='Набор мышечной массы'?2:1.8)*w),fat=Math.round(0.9*w),carbs=Math.max(0,Math.round((kcal-protein*4-fat*9)/4));
 const answers={goal,sex,age,height_cm:h,weight_kg:w,activity_level:act,dislikes:W.dislikes,target_kcal:kcal,target_protein:protein,target_fat:fat,target_carbs:carbs};
 api('/public/client-register',{method:'POST',body:JSON.stringify({name:W.name.trim(),email:em,password:W.pass,specialist_id:W.sid||0,answers,source:signupSource()})}).then(j=>{saveAuth(j);route()}).catch(x=>err(esc(x.message)))}

/* ==========================================================================
   КАТАЛОГ СПЕЦИАЛИСТОВ

   Экран устроен как витрина, а не как список контактов. Сверху —
   сколько специалистов в каталоге и кто именно (заголовок меняется
   вместе с фильтром профессии), затем строка фильтров, затем карточки.

   Карточка отвечает на четыре вопроса, по которым человека и выбирают:
   кто это (фото, имя, проверен ли), когда он был в сети, что о нём
   говорят (рейтинг, отзывы, «очень хвалят») и что он делает и почём —
   услуги с ценой и длительностью прямо в карточке. Кнопка «Выбрать»
   стоит в самой карточке: если человек уже решил, лезть в профиль
   незачем. Нажатие на остальную часть карточки открывает профиль.
   ========================================================================== */
function specCta(){if(A.user&&A.user.specialist_id)return '';if(!feat('catalog'))return '';return `<button class="spec-cta" onclick="clFindSpecialist()"><span class="spec-ic">${icon('users')}</span><div class="grow"><strong>Выберите специалиста</strong><small>По коду, ссылке или из каталога</small></div>${icon('chevr')}</button>`}

/* Фильтры держим в памяти экрана, а не в запросе: каталог небольшой,
   отдаётся одним запросом, и перебирать его на месте быстрее, чем
   ходить на сервер на каждое нажатие. */
const CAT={prof:'',kind:'',city:'',fav:0,q:'',passport:0,minRate:0};

/* Избранное — у клиента в браузере. Это закладка «вернуться и
   подумать», а не связь со специалистом: держать её на сервере значит
   показывать специалисту, кто его рассматривал. */
function favIds(){try{const a=JSON.parse(localStorage.getItem('nm_fav_sp')||'[]');return Array.isArray(a)?a.map(Number):[]}catch(e){return[]}}
function favHas(id){return favIds().includes(+id)}
function favToggle(id,ev){
  if(ev){ev.stopPropagation();ev.preventDefault()}
  const a=favIds(),i=a.indexOf(+id);
  if(i<0)a.push(+id);else a.splice(i,1);
  localStorage.setItem('nm_fav_sp',JSON.stringify(a));
  if($('#cat_list'))clCatalogPaint();else if($('#spp_fav'))$('#spp_fav').classList.toggle('on',favHas(id));
}

/* «В сети сегодня в 11:05». Пола специалиста мы не знаем, поэтому
   безличная форма: «была»/«был» тут угадывать нельзя. */
function seenPhrase(ts){
  if(!ts)return '';
  const t=Date.parse(String(ts).replace(' ','T')+'Z');if(isNaN(t))return '';
  const d=new Date(t),n=new Date(),s=Math.max(0,(n-t)/1000);
  if(s<300)return 'В сети только что';
  const hhmm=d.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});
  if(d.toDateString()===n.toDateString())return 'В сети сегодня в '+hhmm;
  const y=new Date(n);y.setDate(y.getDate()-1);
  if(d.toDateString()===y.toDateString())return 'В сети вчера в '+hhmm;
  if(s<7*86400){const k=Math.floor(s/86400);return 'В сети '+k+' '+plural(k,['день','дня','дней'])+' назад'}
  return 'В сети '+d.toLocaleDateString('ru-RU',{day:'numeric',month:'long'});
}

/* Мера услуги: у разовой — сколько длится, у подписки — за какой срок.
   Без неё цены не сравнить: 3000 ₽ за час и 3000 ₽ за месяц — разное. */
function svcUnit(s){
  if(s.kind==='subscription'){
    const p=+s.period_days||30;
    return p<=7?'неделя':p>=28?'месяц':p+' '+plural(p,['день','дня','дней']);
  }
  return s.duration_min?(+s.duration_min)+' мин.':'разово';
}
function svcShort(s){
  return `<div class="sp-svc"><span class="sp-svc-t">${esc(s.title)}</span>
    <span class="sp-svc-p"><b class="num">${rub(s.price_kop)}</b><i>${esc(svcUnit(s))}</i></span></div>`;
}
function specRate(r){const v=+r||0;return v?v.toFixed(1).replace('.',','):'—'}
function specStars(r){return `<span class="sp-rate">${icon('star')}<b class="num">${specRate(r)}</b></span>`}

function specCard(s){
  const revs=+s.reviews_count||0, rate=+s.rating||0;
  /* «Рекомендуют» — не украшение, а порог: высокая оценка при
     единственном отзыве ничего не значит, поэтому нужны и оценка, и
     число отзывов. */
  const praised=rate>=4.8&&revs>=3;
  const svcs=(s.services||[]);
  const more=Math.max(0,(+s.services_count||svcs.length)-svcs.length);
  const fav=favHas(s.id);
  return `<article class="sp-card">
    <button class="sp-bm ${fav?'on':''}" aria-label="${fav?'Убрать из избранного':'Добавить в избранное'}"
      title="${fav?'Убрать из избранного':'Добавить в избранное'}" onclick="favToggle(${s.id},event)">${icon('heart')}</button>
    <button class="sp-main" onclick="clSpecProfile(${s.id})">
      <div class="sp-top">
        ${av(s.name,'lg',s.avatar_url)}
        <div class="grow">
          <div class="sp-name"><strong>${esc(s.name)}</strong>${s.verified?`<span class="sp-check" title="Документы проверены">${icon('check')}</span>`:''}</div>
          <div class="sp-seen">${esc(seenPhrase(s.last_seen_at)||(PROF[s.profession]||'Специалист'))}</div>
          <div class="sp-pills">
            <span class="sp-pill sp-rate">${icon('star')}<b class="num">${specRate(s.rating)}</b></span>
            <span class="sp-pill"><b class="num">${revs}</b> ${plural(revs,['отзыв','отзыва','отзывов'])}</span>
            ${s.identity_verified?`<span class="sp-pill sp-id">${icon('shield')}Паспорт</span>`:''}
          </div>
          ${praised?`<div class="sp-praise">${icon('star')}Рекомендуют</div>`:''}
        </div>
      </div>
      ${svcs.length?`<div class="sp-svcs">${svcs.map(svcShort).join('')}${
        more?`<div class="sp-more">Ещё ${more} ${plural(more,['услуга','услуги','услуг'])}</div>`:''}</div>`:''}
      <div class="sp-foot"><span class="sp-remote">${icon('device')}Работает дистанционно</span>${s.city?`<span class="muted small">${esc(s.city)}</span>`:''}</div>
    </button>
    <button class="sp-cta" onclick="clConnectTo(${s.id})">Выбрать специалиста</button>
  </article>`;
}

function catalogTitle(){
  const p=CAT.prof;
  if(p==='trainer')return 'Тренеры';
  if(p==='coach')return 'Коучи';
  if(p==='nutritionist')return 'Нутрициологи';
  return 'Специалисты';
}
function catalogNoun(n){
  const p=CAT.prof;
  if(p==='trainer')return plural(n,['тренер','тренера','тренеров']);
  if(p==='coach')return plural(n,['коуч','коуча','коучей']);
  if(p==='nutritionist')return plural(n,['нутрициолог','нутрициолога','нутрициологов']);
  return plural(n,['специалист','специалиста','специалистов']);
}

async function clFindSpecialist(){
  let cs=[];try{cs=(await api('/catalog')).specialists||[]}catch(e){}
  A._catalog=cs;
  /* Ввод кода — тихой строкой под фильтрами, а не плавающей кнопкой.
     Плавающая кнопка постоянно накрывала полосу карточек: у Профи там
     главное действие страницы, а у нас код нужен меньшинству — те, кто
     пришёл с кодом, смотрят верх экрана, а не листают каталог. */
  go(clShell(`<div class="cat">
    <div class="cat-head"><div class="cat-count" id="cat_count"></div><h1 class="cat-h1" id="cat_h1">${esc(catalogTitle())}</h1></div>
    <div class="cat-filters" id="cat_filters"></div>
    <button class="cat-code" onclick="clCodeSheet()">${icon('tag')}
      <span>У меня есть код от специалиста</span>${icon('chevr')}</button>
    <div id="cat_list"></div>
  </div>`,'more'));
  clCatalogPaint();
}

/* Отбор идёт по тем же полям, что показаны в карточке: человек
   фильтрует то, что видит. */
function catalogRows(){
  const fav=favIds();
  return (A._catalog||[]).filter(s=>{
    if(CAT.prof&&(s.profession||'nutritionist')!==CAT.prof)return false;
    if(CAT.passport&&!s.identity_verified)return false;
    if(CAT.minRate&&(+s.rating||0)<CAT.minRate)return false;
    if(CAT.fav&&!fav.includes(+s.id))return false;
    if(CAT.city&&(s.city||'')!==CAT.city)return false;
    if(CAT.kind&&!(s.services||[]).some(v=>CAT.kind==='subscription'?v.kind==='subscription':v.kind!=='subscription'))return false;
    if(CAT.q){
      const q=CAT.q.toLowerCase();
      const hay=[s.name,s.city,s.bio,s.specializations].concat((s.services||[]).map(v=>v.title)).join(' ').toLowerCase();
      if(!hay.includes(q))return false;
    }
    return true;
  });
}
function catCities(){
  const m=new Set();(A._catalog||[]).forEach(s=>{if(s.city)m.add(s.city)});
  return [...m].sort((a,b)=>a.localeCompare(b,'ru'));
}
function catChip(label,active,onclick,extra){
  return `<button class="cat-f ${active?'on':''}" onclick="${onclick}">${extra||''}<span>${esc(label)}</span>${icon('chevd')}</button>`;
}
function clCatalogPaint(){
  const rows=catalogRows(),cnt=$('#cat_count'),h1=$('#cat_h1'),f=$('#cat_filters'),list=$('#cat_list');
  if(!list)return;
  if(cnt)cnt.textContent=rows.length+' '+catalogNoun(rows.length);
  if(h1)h1.textContent=catalogTitle();
  const on=CAT.passport||CAT.minRate||CAT.q;
  if(f)f.innerHTML=
    `<button class="cat-f cat-f-main ${on?'on':''}" onclick="clCatFilters()">${icon('filter')}<span>Фильтры</span>${on?'<i class="cat-dot"></i>':''}</button>`
    +catChip(CAT.kind==='subscription'?'Подписка':CAT.kind==='one_time'?'Разовая':'Уточнить услугу',!!CAT.kind,'clCatKind()')
    +catChip(CAT.city||'Где нужна',!!CAT.city,'clCatCity()')
    +`<button class="cat-f ${CAT.fav?'on':''}" onclick="CAT.fav=CAT.fav?0:1;clCatalogPaint()">${icon('heart')}<span>Избранные</span></button>`;
  list.innerHTML=rows.length
    ? `<div class="sp-list">${rows.map(specCard).join('')}</div>`
    : ((A._catalog||[]).length
      ? `<div class="empty"><div class="orb">${icon('search')}</div><h3>Никого не нашлось</h3><p class="muted">Смягчите фильтры — например, уберите ограничение по рейтингу.</p><button class="secondary" onclick="clCatReset()">Сбросить фильтры</button></div>`
      : `<div class="empty"><div class="orb">${icon('users')}</div><h3>В каталоге пока пусто</h3><p class="muted">Подключитесь по коду от вашего специалиста.</p><button class="secondary" onclick="clCodeSheet()">Ввести код</button></div>`);
}
function clCatReset(){Object.assign(CAT,{prof:'',kind:'',city:'',fav:0,q:'',passport:0,minRate:0});closeModal();clCatalogPaint()}
function clCatKind(){
  const pick=v=>`clCatSet('kind','${v}')`;
  showSheet(`<div class="sheet-head"><h2>Какая услуга нужна</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <div class="opt-list">
    <button class="opt ${CAT.kind===''?'on':''}" onclick="${pick('')}">Любая${CAT.kind===''?icon('check'):''}</button>
    <button class="opt ${CAT.kind==='subscription'?'on':''}" onclick="${pick('subscription')}">Ведение по подписке${CAT.kind==='subscription'?icon('check'):''}</button>
    <button class="opt ${CAT.kind==='one_time'?'on':''}" onclick="${pick('one_time')}">Разовая консультация${CAT.kind==='one_time'?icon('check'):''}</button>
  </div>`);
}
function clCatCity(){
  const cities=catCities();
  showSheet(`<div class="sheet-head"><h2>Где нужна</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <p class="muted small" style="margin:-4px 0 10px">Все специалисты работают дистанционно. Город — если хотите земляка и один часовой пояс.</p>
  <div class="opt-list">
    <button class="opt ${CAT.city===''?'on':''}" onclick="clCatSet('city','')">Любой город${CAT.city===''?icon('check'):''}</button>
    ${cities.map((c,i)=>`<button class="opt ${CAT.city===c?'on':''}" onclick="clCatCityPick(${i})">${esc(c)}${CAT.city===c?icon('check'):''}</button>`).join('')}
  </div>`);
}
function clCatSet(k,v){CAT[k]=v;closeModal();clCatalogPaint()}
/* Город берём по номеру в списке, а не подставляем строкой в onclick:
   апостроф в названии («Ростов-на-Дону» ещё ладно, а вот «О'Брайен»)
   рвал бы вызов. То же и с документами ниже. */
function clCatCityPick(i){clCatSet('city',catCities()[i]||'')}
function clCatFilters(){
  showSheet(`<div class="sheet-head"><h2>Фильтры</h2><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <label>Имя, город или специализация<input id="cf_q" value="${esc(CAT.q)}" placeholder="Например, спортивное питание"></label>
  <div class="sect">Кто нужен</div>
  <div class="chip-row">${[['','Все'],['nutritionist','Нутрициолог'],['trainer','Тренер'],['coach','Коуч']]
    .map(([v,t])=>`<button class="chip ${CAT.prof===v?'active':''}" onclick="CAT.prof='${v}';clCatFilters()">${t}</button>`).join('')}</div>
  <div class="sect">Рейтинг не ниже</div>
  <div class="chip-row">${[[0,'Любой'],[4,'4,0'],[4.5,'4,5'],[4.8,'4,8']]
    .map(([v,t])=>`<button class="chip ${CAT.minRate===v?'active':''}" onclick="CAT.minRate=${v};clCatFilters()">${t}</button>`).join('')}</div>
  <label class="checkrow"><input type="checkbox" id="cf_p" ${CAT.passport?'checked':''}> Только с проверенным паспортом</label>
  <div class="cat-acts"><button class="secondary" onclick="clCatReset()">Сбросить</button>
    <button class="primary" onclick="clCatApply()">Показать</button></div>`);
}
function clCatApply(){
  CAT.q=($('#cf_q')?.value||'').trim();
  CAT.passport=$('#cf_p')?.checked?1:0;
  closeModal();clCatalogPaint();
}
function clCodeSheet(){
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Приглашение</div><h2>У меня есть код</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <p class="muted small" style="margin:-4px 0 12px">Специалист может дать вам код или ссылку-приглашение.</p>
  <form class="code-form" onsubmit="clConnectCode(event)"><input id="jc" placeholder="240A14" maxlength="12" autocapitalize="characters"><button class="primary">Подключиться</button></form><div id="jc_err"></div>`);
}

/* ==========================================================================
   ПРОФИЛЬ СПЕЦИАЛИСТА

   Порядок блоков — по тому, в каком порядке человек принимает решение:
   кто это и в сети ли → чем подтверждён → о себе → действие → как
   работает → услуги и цены → образование и опыт → документы → отзывы.
   Кнопки действия стоят сразу под рассказом о себе, а не в конце
   длинной страницы: внизу они к тому же прятались под панелью вкладок.
   ========================================================================== */
function eduLines(v){return String(v||'').split(/\r?\n|;/).map(x=>x.trim()).filter(Boolean)}
async function clSpecProfile(id){
  const s=(A._catalog||[]).find(x=>+x.id===+id);
  if(!s)return clFindSpecialist();
  let full=s;
  try{ if(s.slug) full={...s,...((await api('/public/specialists/'+s.slug)).specialist||{})} }catch(e){}
  A._spec=full;
  const rate=+full.rating||0, revs=+full.reviews_count||0;
  const exp=+full.experience_years||0;
  const here=full.joined_at?Math.max(0,new Date().getFullYear()-new Date(String(full.joined_at).slice(0,4)).getFullYear()):null;
  const tiles=[
    full.identity_verified?['shield','Паспорт','проверен']:['check','Документы',full.verified?'проверены':'нет'],
    ['star','Рейтинг',specRate(full.rating)],
    ['chat','Отзывы',String(revs)],
  ];
  const docs=full.documents||[];
  const revList=full.reviews||[];
  const edu=eduLines(full.education);
  const fav=favHas(full.id);
  go(clShell(`${navBar('Специалист','clFindSpecialist()')}
  <div class="spp">
    <div class="spp-head">
      <button id="spp_fav" class="spp-bm ${fav?'on':''}" aria-label="В избранное" title="В избранное" onclick="favToggle(${full.id},event)">${icon('heart')}</button>
      ${av(full.name,'huge',full.avatar_url)}
      <div class="spp-name"><h2>${esc(full.name)}</h2>${full.verified?`<span class="sp-check" title="Документы проверены">${icon('check')}</span>`:''}</div>
      <p class="spp-seen">${esc(seenPhrase(full.last_seen_at)||(PROF[full.profession]||'Специалист'))}</p>
    </div>

    <div class="spp-tiles">${tiles.map(([ic,t,v])=>`<div class="spp-tile">
      <span class="spp-ic">${icon(ic)}</span><b>${esc(v)}</b><small>${esc(t)}</small></div>`).join('')}</div>

    ${full.bio?`<div class="spp-bio-wrap"><p class="spp-bio" id="spp_bio">${esc(bioShort(full.bio))}</p>
      ${full.bio.length>BIO_CUT?`<button class="textbtn" id="spp_bio_more" onclick="sppBioMore()">Ещё</button>`:''}</div>`:''}

    <div class="spp-acts">
      <button class="primary green" onclick="clConnectTo(${full.id})">${icon('check')} Выбрать</button>
      <button class="secondary" onclick="clLeadForm(${full.id})">Оставить заявку</button>
    </div>

    <div class="spp-remote"><span class="spp-ic">${icon('device')}</span>
      <div><strong>Работает дистанционно</strong>
      <small>Меню, чат и созвоны — в приложении. ${full.city?'Часовой пояс — '+esc(full.city)+'.':'Часовой пояс уточните в переписке.'}</small></div></div>

    ${(full.services||[]).length?`<div class="meal-sec"><div class="meal-head"><b>Услуги и цены</b></div>
      <div class="spp-svcs">${full.services.map(x=>`<div class="spp-svc">
        <div class="grow"><strong>${esc(x.title)}</strong>
          ${x.description?`<p class="muted small">${esc(x.description)}</p>`:''}
          <small>${esc(svcUnit(x))}</small></div>
        <b class="spp-price num">${rub(x.price_kop)}</b></div>`).join('')}</div></div>`:''}

    ${edu.length?`<div class="meal-sec"><div class="meal-head"><b>Образование</b></div>
      <div class="spp-edu">
        <div class="spp-edu-row"><span class="spp-ic">${icon('grad')}</span><span>${esc(edu[0])}</span></div>
        ${edu.length>1?`<div id="spp_edu_rest" hidden>${edu.slice(1).map(x=>`<div class="spp-edu-row"><span class="spp-ic">${icon('grad')}</span><span>${esc(x)}</span></div>`).join('')}</div>
        <button class="textbtn" id="spp_edu_btn" onclick="sppEduMore(${edu.length-1})">Ещё ${edu.length-1} ${plural(edu.length-1,['запись','записи','записей'])} об образовании</button>`:''}
      </div></div>`:''}

    ${exp?`<div class="meal-sec"><div class="meal-head"><b>${exp} ${plural(exp,['год','года','лет'])} опыта</b></div>
      <div class="spp-exp">${here!==null?`<div class="spp-edu-row"><span class="spp-ic">${icon('spark')}</span><span>Из них ${here||'меньше'} ${here?plural(here,['год','года','лет']):'года'} на EQUA</span></div>`:''}
      ${full.specializations?`<div class="spp-edu-row"><span class="spp-ic">${icon('target')}</span><span>${esc(full.specializations)}</span></div>`:''}
      ${full.active_clients?`<div class="spp-edu-row"><span class="spp-ic">${icon('users')}</span><span>Сейчас ведёт ${full.active_clients} ${plural(full.active_clients,['клиента','клиентов','клиентов'])}</span></div>`:''}</div></div>`:''}

    ${docs.length?`<div class="meal-sec"><div class="meal-head"><b>Документы</b><small>${docs.length}</small></div>
      <div class="spp-docs">${docs.map((d,di)=>d.scan_url
        ? `<button class="spp-doc" onclick="sppDoc(${di})">
             <img src="${esc(d.scan_url)}" alt="${esc(d.title)}" loading="lazy">
             <span>${esc(DOC_KINDS[d.kind]||'Документ')}</span></button>`
        : `<div class="spp-doc spp-doc-flat"><span class="spp-doc-ph">${icon('grad')}<b>${esc(d.title)}</b></span>
             <span>${esc([DOC_KINDS[d.kind]||'',d.issued_on?String(d.issued_on).slice(0,4):''].filter(Boolean).join(' · '))}</span></div>`).join('')}</div></div>`:''}

    ${revs||revList.length?`<div class="meal-sec"><div class="meal-head"><b>Рейтинг ${specRate(full.rating)}</b><small>${revs} ${plural(revs,['отзыв','отзыва','отзывов'])}</small></div>
      ${revList.length?`<div class="spp-revs">${revList.slice(0,10).map(r=>`<div class="spp-rev">
        <div class="spp-rev-top"><strong>${esc(r.author||'Клиент')}</strong>${specStars(r.rating)}</div>
        ${r.body?`<p class="muted">${esc(r.body)}</p>`:''}</div>`).join('')}</div>`
      :`<p class="muted small">Отзывы появятся, когда клиенты завершат работу.</p>`}</div>`:''}
  </div>`,'more'));
}
function sppDoc(i){const d=((A._spec||{}).documents||[])[i];if(d&&d.scan_url)showViewer(d.scan_url,d.title)}
/* Рассказ о себе укорачиваем текстом, а не обрезкой по высоте: обрезка
   по высоте прячет строку так, что её не выделить и не прочесть с
   экранного диктора, и проверка вёрстки справедливо считает это
   срезанным содержимым. Режем по последнему пробелу — не по букве. */
const BIO_CUT=260;
function bioShort(t){
  t=String(t||'');
  if(t.length<=BIO_CUT)return t;
  const cut=t.slice(0,BIO_CUT), i=cut.lastIndexOf(' ');
  return (i>160?cut.slice(0,i):cut).replace(/[\s,;:—-]+$/,'')+'…';
}
function sppBioMore(){
  const el=$('#spp_bio'),b=$('#spp_bio_more'),full=(A._spec||{}).bio||'';
  if(!el)return;
  const open=el.dataset.open==='1';
  el.textContent=open?bioShort(full):full;
  el.dataset.open=open?'':'1';
  if(b)b.textContent=open?'Ещё':'Свернуть';
}
function sppEduMore(n){const r=$('#spp_edu_rest'),b=$('#spp_edu_btn');if(!r)return;r.hidden=!r.hidden;if(b)b.textContent=r.hidden?('Ещё '+n+' '+plural(n,['запись','записи','записей'])+' об образовании'):'Свернуть'}

/* Заявка — для тех, кто не готов выбирать сразу: специалист увидит
   контакт у себя в «Заявках» и напишет первым. */
function clLeadForm(id){
  const u=A.user||{};
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Заявка</div><h2>Оставить контакт</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <p class="muted small" style="margin:-4px 0 12px">Специалист получит заявку и свяжется с вами. Подключение при этом не происходит.</p>
  <form onsubmit="clLeadSend(event,${id})">
    <label>Как к вам обращаться<input id="ld_n" value="${esc(u.name||'')}" required></label>
    <label>Телефон или почта<input id="ld_c" value="${esc(u.email||'')}" required></label>
    <label>Что хотите решить<textarea id="ld_m" rows="3" placeholder="Например: снизить вес, разобраться с питанием при гастрите"></textarea></label>
    <button class="primary wide">Отправить заявку</button></form><div id="ld_err"></div>`);
}
async function clLeadSend(e,id){
  e.preventDefault();
  try{
    await api('/catalog/'+id+'/lead',{method:'POST',body:JSON.stringify({
      name:$('#ld_n').value,contact:$('#ld_c').value,message:$('#ld_m').value})});
    closeModal();toast('Заявка отправлена ✓','ok');
  }catch(x){$('#ld_err').innerHTML=`<div class="error">${esc(x.message)}</div>`}
}

async function clConnectCode(e){e.preventDefault();const c=($('#jc').value||'').trim();try{const j=await api('/client/connect-code',{method:'POST',body:JSON.stringify({code:c})});if(A.user)A.user.specialist_id=j.specialist.id;clearJoinCode();afterConnect()}catch(x){$('#jc_err').innerHTML=`<div class="error">${esc(x.message)}</div>`}}
async function clConnectTo(id){const n=((A._catalog||[]).find(x=>+x.id===+id)||A._spec||{}).name||'специалисту';
  if(!confirm('Подключиться к специалисту «'+n+'»?'))return;try{await api('/client/connect',{method:'POST',body:JSON.stringify({specialist_id:id})});if(A.user)A.user.specialist_id=id;clearJoinCode();afterConnect()}catch(x){toast(x.message,'err')}}

/* Сразу после выбора специалиста показываем его услуги: это следующий
   шаг в разговоре, а не отдельная тема из меню «Ещё». Если услуг нет —
   ведём на главную, пустой прайс никому не нужен. */
async function afterConnect(){
  toast('Специалист выбран ✓','ok');
  try{
    const j=await api('/client/services');
    if((j.services||[]).length)return clServices();
  }catch(e){}
  clToday();
}
function joinCodeFromUrl(){try{const c=(new URLSearchParams(location.search).get('join')||'').trim();if(c){localStorage.nm_join=c;return c}return localStorage.nm_join||''}catch(e){return''}}
function clearJoinCode(){try{localStorage.removeItem('nm_join');history.replaceState({},'',location.pathname)}catch(e){}}
async function spInviteCode(){let j={};try{j=await api('/specialist/invite-code')}catch(e){}
 showSheet(`<div class="sheet-head"><div><div class="eyebrow">Приглашение</div><h2>Код для клиентов</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div><p class="lead">Дайте клиенту код или ссылку — он подключится к вам сразу после регистрации.</p><div class="join-code">${esc(j.code||'—')}</div><div class="invitebox">${esc(j.url||'')}</div><button class="primary wide" onclick="navigator.clipboard&&navigator.clipboard.writeText('${esc(j.url||'')}');this.textContent='Скопировано ✓'">Скопировать ссылку</button>`)}
/* ============================================================
   Клиент · Прогресс — язык «Сегодня»: плитки, график в карточке,
   история сгруппированным списком. Переопределяет ранние версии.
   ============================================================ */
const dmy=s=>{if(!s)return '—';const p=String(s).slice(0,10).split('-');return p.length===3?`${p[2]}.${p[1]}`:s};
function weightChart(ws){
  if(!ws||ws.length<2)return `<div class="chart-empty">${ws&&ws.length?'Добавьте ещё одно измерение — и здесь появится график':'Пока нет измерений веса'}</div>`;
  const v=ws.map(w=>+w.weight_kg),mn=Math.min(...v),mx=Math.max(...v),pad=(mx-mn)*0.3||1,lo=mn-pad,hi=mx+pad;
  const W=320,H=150,PX=30,PY=26,n=ws.length;
  const X=i=>PX+i*(W-2*PX)/(n-1),Y=val=>PY+(hi-val)/(hi-lo)*(H-2*PY);
  const pts=ws.map((w,i)=>`${X(i).toFixed(1)},${Y(+w.weight_kg).toFixed(1)}`).join(' ');
  const area=`${PX},${H-PY+14} ${pts} ${(W-PX)},${H-PY+14}`;
  const dots=ws.map((w,i)=>(i===0||i===n-1)?`<circle cx="${X(i).toFixed(1)}" cy="${Y(+w.weight_kg).toFixed(1)}" r="${i===n-1?4:3}" fill="var(--mp)" stroke="none"/>`:'').join('');
  const lbl=`<text x="${X(n-1).toFixed(1)}" y="${(Y(v[n-1])-12).toFixed(1)}" class="cv" text-anchor="end">${kg(v[n-1])}</text>`;
  const step=(hi-lo)/3;
  const axis=[0,1,2,3].map(i=>{const val=lo+step*i;const y=Y(val).toFixed(1);
    return `<text x="6" y="${(+y+3).toFixed(1)}" class="cd" text-anchor="start">${Math.round(val)}</text>`}).join('');
  const dts=[0,n-1].map(i=>`<text x="${X(i).toFixed(1)}" y="${H-8}" class="cd" text-anchor="${i?'end':'start'}">${dmy(ws[i].measured_on)}</text>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" class="wchart">
    <defs><linearGradient id="wgrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="var(--mp)" stop-opacity=".13"/><stop offset="100%" stop-color="var(--mp)" stop-opacity="0"/>
    </linearGradient></defs>
    <polygon points="${area}" fill="url(#wgrad)"/>
    ${axis}
    <polyline class="wline" pathLength="1" points="${pts}" fill="none" stroke="var(--mp)" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/>
    ${dots}${lbl}${dts}</svg>`;
}
async function clProgress(){
  const j=await api('/client/progress');A.progressData=j;
  const ws=j.weights||[];
  const last=ws.length?+ws[ws.length-1].weight_kg:null, first=ws.length?+ws[0].weight_kg:null;
  const delta=(last!=null&&first!=null&&ws.length>1)?last-first:null;
  A.ptab=A.ptab||'weight';
  const tabs=[['weight','Вес'],['measure','Замеры'],['photo','Фото']];
  let body='';
  if(A.ptab==='weight'){
    body=`<div class="wgrid">
      <div class="wtile wide"><div class="wt-body"><div class="wt-lbl">Текущий вес</div>
        <div class="wt-big num">${kg(last)} <small>кг</small></div>
        ${delta==null?`<div class="wt-foot">Добавьте ещё одно измерение, чтобы увидеть динамику</div>`
          :`<div class="wt-pill ${delta>0?'up':'down'} num">${delta>0?'+':'−'}${kg(Math.abs(delta))} кг за период</div>`}
      </div></div>
      <div class="wtile"><div class="wt-lbl">Старт</div><div class="wt-big num">${kg(first)} <small>кг</small></div>
        <div class="wt-foot">${ws.length?dmy(ws[0].measured_on):'нет данных'}</div></div>
      <div class="wtile"><div class="wt-lbl">Измерений</div><div class="wt-big num">${ws.length}</div>
        <div class="wt-foot">${ws.length?('последнее '+dmy(ws[ws.length-1].measured_on)):'ещё не было'}</div></div>
    </div>
    <div class="chart-card">${weightChart(ws)}</div>
    ${ws.length?`<div class="meal-sec"><div class="meal-head"><b>История</b><small>${ws.length} ${plural(ws.length,['запись','записи','записей'])}</small></div>
      <div class="meal-group">${ws.slice().reverse().slice(0,10).map((w,i,arr)=>{
        const prev=arr[i+1],d=prev?(+w.weight_kg-+prev.weight_kg):null;
        return `<div class="hist-row"><span class="hr-date">${dmy(w.measured_on)}</span><b class="num">${kg(w.weight_kg)} кг</b>${
          d==null||Math.abs(d)<0.05?'<span class="hr-d"></span>':`<span class="hr-d ${d>0?'up':'down'} num">${d>0?'+':'−'}${kg(Math.abs(d))}</span>`}</div>`}).join('')}</div></div>`:''}
    <button class="btn-wide" onclick="clAddWeight()">${icon('plus')} Записать вес</button>`;
  }
  if(A.ptab==='measure'){
    const ms=(j.measurements||[]).slice().reverse();
    body=`${ms.length?`<div class="meal-sec"><div class="meal-head"><b>Замеры</b><small>${ms.length} ${plural(ms.length,['запись','записи','записей'])}</small></div>
      <div class="meal-group">${ms.map(m=>`<div class="hist-row"><span class="hr-date">${dmy(m.measured_on)}</span><b class="num">Т ${m.waist_cm||'—'} · Б ${m.hips_cm||'—'} · Г ${m.chest_cm||'—'}</b><span class="hr-d"></span></div>`).join('')}</div></div>`
      :`<div class="empty"><div class="orb">${icon('chart')}</div><h3>Замеров пока нет</h3><p class="muted">Талия, бёдра и грудь показывают прогресс там, где вес стоит на месте.</p></div>`}
    <button class="btn-wide" onclick="clAddMeasure()">${icon('plus')} Добавить замеры</button>`;
  }
  if(A.ptab==='photo'){
    const ph=j.photos||[];
    body=`${ph.length?`<div class="photo-grid">${ph.map(p=>`<img src="${esc(p.photo_url)}" alt="Фото прогресса от ${esc(p.measured_on||'')}">`).join('')}</div>`
      :`<div class="empty"><div class="orb">${icon('camera')}</div><h3>Фото пока нет</h3><p class="muted">Снимок раз в две недели с одного ракурса — самый честный показатель.</p></div>`}
    <label class="btn-wide"><input type="file" accept="image/*" hidden onchange="clUploadPhoto(this)">${icon('camera')} Добавить фото</label>`;
  }
  go(clShell(`${clHead('Прогресс','',"clBackToMore()")}<div class="ptabs">${tabs.map(([k,l])=>`<button class="ptab ${A.ptab===k?'on':''}" onclick="A.ptab='${k}';clProgress()">${l}</button>`).join('')}</div>${body}`,'trend'));
}

/* ============================================================
   ПАНЕЛЬ ВЛАДЕЛЬЦА (роль admin). Доступна только по учётке владельца.
   ============================================================ */
/* Метку источника (?from=…, ?utm_source=…) запоминаем при первом заходе:
   регистрация случается позже, часто через несколько страниц, и к тому
   времени адрес уже другой. */
(function keepSource(){
  try{
    const q=new URLSearchParams(location.search);
    const v=(q.get('from')||q.get('utm_source')||'').trim();
    if(v&&!localStorage.getItem('nm_source'))localStorage.setItem('nm_source',v.slice(0,60));
  }catch(e){}
})();
function signupSource(){ try{ return localStorage.getItem('nm_source')||'' }catch(e){ return '' } }

/* Что сервис разрешил показывать. Спрашиваем один раз при запуске:
   выключенная возможность не должна исчезать у человека на полпути, и
   лишний запрос на каждом экране заметен на слабой связи.
   Сервер молчит — ничего не прячем: плохая связь не повод убирать
   половину приложения. */
async function loadAppConfig(){
  try{ A.cfg=await api('/public/config') }catch(e){ A.cfg=A.cfg||{features:{}} }
}
function feat(key){ const f=(A.cfg&&A.cfg.features)||{}; return f[key]!==false }

async function route(){if(A._resetToken)return resetForm(A._resetToken);
 /* В Telegram пароля нет: личность подтверждает подпись мессенджера.
    Не вышло — падаем на обычный вход, он никуда не делся. */
 if(!A.token&&window.TG_MAYBE&&typeof tgSignIn==='function'&&!A._tgTried){
   A._tgTried=true;
   await tgSignIn();
 }
 if(!A.token)return login();
 if(!A.cfg)await loadAppConfig();
 try{const j=await api('/me');A.user=j.user;A.type=j.user_type;
  /* Права сотрудника панели: по ним прячем разделы. Решает всё равно
     сервер — интерфейс просто не показывает закрытые двери. */
  A.rights=j.rights||null; A.role=j.role||null; A.roles=j.roles||null;
 if(A.type==='admin')return adOverview();
 if(A.type==='client'&&!A.user.specialist_id){const code=joinCodeFromUrl();if(code){try{const r=await api('/client/connect-code',{method:'POST',body:JSON.stringify({code})});A.user.specialist_id=r.specialist.id;clearJoinCode()}catch(e){}}}
 a2hsMaybe();
 if(A.type==='client'){
   /* Пришёл по ссылке от специалиста — говорим об этом сразу: человек
      нажал ссылку в переписке и должен увидеть, что попал к тому, к
      кому шёл, а не просто «в приложение». */
   if(A._tgLinked){ const n=A._tgLinked.name; A._tgLinked=null;
     setTimeout(()=>toast('Вы у специалиста: '+n,'ok'),400) }
   return clToday();
 }
 spHome()}catch(e){logout()}}

/* Разделы панели владельца.
   Раньше их было четыре, а всё остальное — рассылка, лента, деньги,
   EQUA info, push, подписки, каталог, копии базы, пароль — лежало общей
   кучей внутри «Ещё» на два экрана прокрутки. Найти там что-то можно
   было только перечитав страницу целиком. Теперь у каждого занятия свой
   раздел, и место любой задачи видно по меню.

   На компьютере в боковой колонке помещаются все семь. На телефоне в
   нижнюю панель влезает пять, поэтому три последних уходят под «Ещё» —
   но это уже не свалка, а короткое оглавление из трёх ссылок. Кнопки
   рисуем все, а лишние прячет CSS: так один и тот же экран открывается
   с телефона и с компьютера без разных сборок разметки. */
const AD_SECTIONS = {
  /* ключ: [значок, подпись, вызов, только-широкий] */
  home:    ['home',  'Сводка',    'adOverview()', false],
  users:   ['users', 'Люди',      'adPeople()',   false],
  content: ['bowl',  'Контент',   'adContent()',  false],
  chat:    ['chat',  'Поддержка', 'adSupport()',  false],
  coin:    ['coin',  'Деньги',    'adFinance()',  true ],
  send:    ['send',  'Рассылки',  'adMailing()',  true ],
  cog:     ['cog',   'Система',   'adSystem()',   true ],
};
/* Разделы, которые на телефоне живут под «Ещё». */
const AD_DEEP = ['coin','send','cog'];

/* Раздел панели → название права, которым он закрыт. */
const AD_RIGHT={home:'overview',users:'people',content:'content',
  chat:'support',coin:'money',send:'mailing',cog:'system'};
/* Виден ли раздел этому сотруднику. Владельцу видно всё. */
function adCan(key){
  const r=A.rights; if(!r)return true;
  return (r[AD_RIGHT[key]]||0)>0;
}
function adShell(body,active){
  /* Поддержка стоит в навигации, а не на втором уровне: обращение ждёт
     ответа, и туда надо заглядывать каждый день. Счётчик непрочитанных —
     по той же причине. */
  const un=A.adSupportOpen||0;
  const deep=AD_DEEP.includes(active);
  const btn=(key)=>{
    const [ic,label,fn,wide]=AD_SECTIONS[key];
    const on=active===key;
    const badge=key==='chat'?un:0;
    return `<button class="pill-item ${on?'active':''} ${wide?'nav-wide':''}" onclick="${fn}">`
      +`${icon(ic)}<span>${label}</span>`
      +`${badge?`<i class="nav-badge num">${badge>99?'99+':badge}</i>`:''}</button>`;
  };
  const more=`<button class="pill-item nav-narrow ${deep?'active':''}" onclick="adMore()">`
    +`${icon('kebab')}<span>Ещё</span></button>`;
  const keys=Object.keys(AD_SECTIONS).filter(adCan);
  const deepShown=AD_DEEP.filter(adCan);
  return `<div class="client-shell admin-shell"><nav class="client-nav pillnav admin-nav">${
    keys.map(btn).join('')+(deepShown.length?more:'')
  }</nav><main class="client-main"><div class="client-body">${body}</div></main></div>`;
}
function adHead(title,sub){
  /* Подпись говорит, под какой ролью человек работает: у помощника
     половина разделов закрыта, и знать почему он должен сразу. */
  const role=(A.roles&&A.role&&A.roles[A.role])||'Владелец';
  return `<div class="c-head"><div><div class="eyebrow">Панель · ${esc(role)}</div><h1>${esc(title)}</h1>${sub?`<p class="muted">${esc(sub)}</p>`:''}</div></div>`}
function adWarn(on){return on?`<button class="ad-warn" onclick="adPassword()"><span class="ad-warn-ic">${icon('lock')}</span><div class="grow"><strong>Смените пароль владельца</strong><small>Сейчас стоит пароль из настроек по умолчанию — его знает каждый, у кого есть архив.</small></div>${icon('chevr')}</button>`:''}

function adBars(series){
  if(!series||!series.length)return '';
  /* Пустое окно рисовалось голым пунктиром с двумя датами по краям — это
     читалось как сломанный график, а не как «никто не регистрировался». */
  const sum=series.reduce((a,d)=>a+(+d.clients||0)+(+d.specialists||0),0);
  if(!sum)return `<div class="chart-card"><p class="muted small" style="margin:0;padding:22px 0;text-align:center">За 30 дней никто не регистрировался</p></div>`;
  const mx=Math.max(1,...series.map(d=>d.clients+d.specialists));
  const W=320,H=110,n=series.length,bw=(W-4)/n;
  const bars=series.map((d,i)=>{
    const x=2+i*bw,tot=d.clients+d.specialists;
    if(!tot)return `<rect x="${(x+bw*0.18).toFixed(1)}" y="${H-11}" width="${(bw*0.64).toFixed(1)}" height="2" rx="1" fill="var(--line)"/>`;
    const hC=(H-22)*d.clients/mx,hS=(H-22)*d.specialists/mx;
    return `<rect x="${(x+bw*0.18).toFixed(1)}" y="${(H-11-hC).toFixed(1)}" width="${(bw*0.64).toFixed(1)}" height="${hC.toFixed(1)}" rx="2" fill="var(--mp)"/>`
      +(hS?`<rect x="${(x+bw*0.18).toFixed(1)}" y="${(H-11-hC-hS-1).toFixed(1)}" width="${(bw*0.64).toFixed(1)}" height="${hS.toFixed(1)}" rx="2" fill="var(--ink)"/>`:'');
  }).join('');
  return `<div class="chart-card"><svg viewBox="0 0 ${W} ${H}" class="adchart" preserveAspectRatio="none">${bars}
    <text x="2" y="${H-1}" class="cd">${dmy(series[0].date)}</text>
    <text x="${W-2}" y="${H-1}" class="cd" text-anchor="end">${dmy(series[n-1].date)}</text></svg>
    <div class="ad-bleg"><span><i style="background:var(--mp)"></i>Клиенты</span><span><i style="background:var(--ink)"></i>Специалисты</span></div></div>`;
}

/* --- Люди: рабочий список ---
   Владелец приходит сюда с вопросом про конкретного человека, а не
   посмотреть на всех сразу. Поэтому поиск по имени и почте, фильтр по
   состоянию и страницы. Раньше специалисты грузились все разом, клиенты
   обрезались на двухстах молча, а единственным действием была кнопка
   «Блок» — кого именно блокируешь, приходилось выяснять в базе. */
/* Поиск в панели сравнивает так же, как сервер: без регистра и с «ё»,
   приравненной к «е». Иначе «Алёна» не ищется по «алена». */
function foldRu(v){ return String(v||'').toLowerCase().replace(/ё/g,'е').trim() }
const AD_PEOPLE_STATUS=[['','Все'],['active','Активные'],['blocked','Заблокированные']];

async function adPeople(tab){
  A.adTab=tab||A.adTab||'spec';
  A.adQ=A.adQ||''; A.adStatus=A.adStatus||''; A.adPage=1;
  const tabs=[['spec','Специалисты'],['cli','Клиенты'],['ver','Верификация']];
  /* Готовые выборки, за которыми приходят чаще всего. Раньше такие
     вопросы решались глазами по всему списку. */
  const segs=[['','Все'],['no_specialist','Без специалиста'],
              ['silent','Молчат 14 дней'],['menu_no_log','Меню есть, отметок нет']];
  if(A.adTab==='ver'){
    go(adShell(`${adHead('Люди','Специалисты и клиенты сервиса')}
      <div class="ptabs">${tabs.map(([k,l])=>`<button class="ptab ${A.adTab===k?'on':''}" onclick="adPeople('${k}')">${l}</button>`).join('')}</div>
      ${await adVerifyBody()}`,'users'));
    return;
  }
  /* Панель инструментов в одну строку: вкладки слева, поиск и фильтр
     справа. На телефоне они складываются друг под друга, на компьютере
     стоят в ряд — это разница между списком и рабочим экраном. */
  go(adShell(`${adHead('Люди','Специалисты и клиенты сервиса')}
    <div class="ad-toolbar">
      <div class="ptabs">${tabs.map(([k,l])=>`<button class="ptab ${A.adTab===k?'on':''}" onclick="adPeople('${k}')">${l}</button>`).join('')}</div>
      <div class="ad-tools">
        <div class="searchbox">${icon('search')}<input id="adpq"
          placeholder="Имя или почта" value="${esc(A.adQ)}" oninput="adPeopleSearch(this.value)"></div>
        <div class="ptabs sub">${(A.adTab==='cli'?segs:AD_PEOPLE_STATUS).map(([k,l])=>
          `<button class="ptab ${(A.adTab==='cli'?(A.adSeg||''):A.adStatus)===k?'on':''}"
            onclick="${A.adTab==='cli'?`adPeopleSeg('${k}')`:`adPeopleStatus('${k}')`}">${l}</button>`).join('')}</div>
        <button class="ad-btn" onclick="adExport()" title="Выгрузить в таблицу">${icon('doc')} CSV</button>
      </div>
      <button class="ad-btn primary" onclick="adPeopleAdd()">${icon('plus')} Завести</button>
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b id="adp-title">Загрузка…</b><small id="adp-count"></small></div>
      <div class="ad-rows" id="adp-list"><div class="empty small">Загрузка…</div></div>
    </div>
    <div id="adp-bulk" class="ad-bulk" hidden></div>
    <div id="adp-more"></div>`,'users'));
  adPeopleLoad();
}
/* Запрос на каждую букву — и лишняя нагрузка, и мигающий список. */
function adPeopleSearch(v){
  A.adQ=v; A.adPage=1;
  clearTimeout(A._adqT);
  A._adqT=setTimeout(()=>adPeopleLoad(),250);
}
/* Выделение строк и действие сразу над всеми выбранными. Перевести
   десять клиентов ушедшего специалиста по одному — это десять
   подтверждений и десять шансов кого-то забыть. */
function adPick(id,on){
  A._picked=A._picked||[];
  A._picked=on?[...new Set([...A._picked,id])]:A._picked.filter(x=>x!==id);
  adPaintBulk();
}
function adPickAll(on){
  A._picked=on?(A._adPeople||[]).map(x=>x.id):[];
  adPeoplePaint(); adPaintBulk();
}
function adPaintBulk(){
  const el=$('#adp-bulk'); if(!el)return;
  const n=(A._picked||[]).length;
  el.hidden=!n;
  if(!n)return;
  const spec=A.adTab==='spec';
  el.innerHTML=`<b>Выбрано: ${n}</b>
    <button class="ad-btn" onclick="adBulk('block')">Заблокировать</button>
    <button class="ad-btn" onclick="adBulk('unblock')">Вернуть доступ</button>
    ${spec?'':`<button class="ad-btn" onclick="adBulkMove()">Перевести к специалисту</button>`}
    <button class="ad-btn" onclick="A._picked=[];adPeoplePaint();adPaintBulk()">Снять выбор</button>`;
}
async function adBulk(action,extra){
  const ids=A._picked||[]; if(!ids.length)return;
  const kind=A.adTab==='spec'?'specialist':'client';
  if(action==='block'&&!confirm(`Заблокировать ${ids.length}? Они не смогут войти.`))return;
  try{
    const r=await api('/admin/bulk',{method:'POST',
      body:JSON.stringify({kind,ids,action,...(extra||{})})});
    toast('Готово: '+r.done,'ok');
    A._picked=[]; adPeopleLoad();
  }catch(e){ toast(e.message,'err') }
}
function adBulkMove(){
  const list=A._adSpecs||[];
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Выбрано: ${(A._picked||[]).length}</div>
      <h2>Перевести к специалисту</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <label class="full">Специалист<select id="bm_sp">
      <option value="0">— открепить —</option>
      ${list.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label>
    <button class="primary wide full" onclick="adBulkMoveSave()">Перевести</button>
    ${list.length?'':'<p class="rw-foot muted">Список специалистов появится после захода на вкладку «Специалисты».</p>'}`);
}
async function adBulkMoveSave(){
  const sp=+$('#bm_sp').value;
  closeModal();
  await adBulk('move',{specialist_id:sp});
}
/* Выгрузка того, что сейчас на экране: с тем же поиском и фильтром.
   Скачать «всех подряд», когда на экране выборка, — не то, чего ждёшь.

   Забираем файл запросом с заголовком, а не открываем ссылку: иначе
   токен пришлось бы положить в адрес, а оттуда он попадает в историю
   браузера и в журналы прокси. */
async function adExport(){
  const kind=A.adTab==='spec'?'specialists':'clients';
  const q=[A.adQ?'q='+encodeURIComponent(A.adQ):'',A.adStatus?'status='+A.adStatus:'']
    .filter(Boolean).join('&');
  try{
    const r=await fetch('/api/v1/admin/export/'+kind+(q?'?'+q:''),
      {headers:{Authorization:'Bearer '+A.token}});
    if(!r.ok)throw Error('Не удалось выгрузить');
    const blob=await r.blob();
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=url; a.download='equa-'+kind+'-'+new Date().toISOString().slice(0,10)+'.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),2000);
    toast('Файл скачан','ok');
  }catch(e){ toast(e.message||'Не удалось выгрузить','err') }
}
function adPeopleStatus(v){ A.adStatus=v; A.adPage=1; adPeople(A.adTab) }

function adPeopleSeg(v){ A.adSeg=v; A.adPage=1; adPeople('cli') }
async function adPeopleLoad(add){
  const spec=A.adTab==='spec';
  const url=(!spec&&A.adSeg)
    ? '/admin/segments?name='+A.adSeg
    : (spec?'/admin/specialists':'/admin/clients')
      +'?limit=50&page='+(A.adPage||1)
      +(A.adQ?'&q='+encodeURIComponent(A.adQ):'')
      +(A.adStatus?'&status='+A.adStatus:'');
  let j;
  try{ j=await api(url) }
  catch(e){ const el=$('#adp-list'); if(el)el.innerHTML='<div class="empty small">Не удалось загрузить</div>'; return }
  const rows=spec?j.specialists:j.clients;
  A._adPeople=add?(A._adPeople||[]).concat(rows):rows;
  if(spec)A._adSpecs=rows;          /* пригодится для формы нового клиента */
  const t=$('#adp-title'); if(t)t.textContent=spec?'Специалисты':'Клиенты';
  const c=$('#adp-count');
  if(c)c.textContent=A.adQ||A.adStatus
    ? `найдено ${j.total}`
    : `${j.total} ${plural(j.total,['человек','человека','человек'])}`;
  adPeoplePaint();
  /* «Показать ещё» вместо номеров страниц: список читают сверху вниз,
     и прыгать на седьмую страницу незачем. */
  const more=$('#adp-more');
  if(more)more.innerHTML=(j.page<j.pages)
    ? `<button class="btn-wide quiet" onclick="A.adPage=${j.page+1};adPeopleLoad(true)">Показать ещё · осталось ${j.total-A._adPeople.length}</button>`
    : '';
}
/* Строка списка — набор ячеек, а не одна подпись через точки.
   На телефоне ячейки складываются под именем, как раньше; на широком
   экране встают колонками с заголовками. Разметка при этом одна: два
   разных списка расходились бы при первой же правке. */
function adPeoplePaint(){
  const el=$('#adp-list'); if(!el)return;
  const spec=A.adTab==='spec';
  const rows=A._adPeople||[];
  if(!rows.length){
    el.innerHTML=`<div class="empty small">${A.adQ?'Никого не нашлось':'Пока никого нет'}</div>`;
    return;
  }
  const head=spec
    ? ['Специалист','Почта','Клиенты','Меню','Состояние','В сервисе с']
    : ['Клиент','Почта','Специалист','Цель','Состояние','В сервисе с'];
  el.innerHTML=`<div class="ad-tr ad-head">
      <span class="ad-td pick"><input type="checkbox" onchange="adPickAll(this.checked)"
        title="Выбрать всё на странице"></span>
      ${head.map((h,i)=>`<span class="ad-td c${i} ${spec&&(i===2||i===3)?'num':''}">${h}</span>`).join('')
      }<span class="ad-td act"></span></div>`
    +rows.map(x=>{
    const blocked=(x.status||'active')==='blocked';
    const kind=spec?'specialist':'client';
    const cells=spec
      ? [`${x.clients}`,`${x.menus}`]
      : [esc(x.specialist||'—'),esc(x.goal||'—')];
    /* На телефоне колонки не помещаются, поэтому там одна сводная
       строка под именем — как было до таблицы. Держим оба вида в одной
       разметке: две разные развалились бы при первой правке. */
    const sub=spec
      ? `${esc(x.email||'')} · ${x.clients} ${plural(x.clients,['клиент','клиента','клиентов'])} · ${x.menus} меню`
      : `${esc(x.specialist||'без специалиста')} · ${esc(x.goal||'цель не задана')}`;
    return `<div class="ad-tr ${blocked?'off':''}">
      <span class="ad-td pick"><input type="checkbox" value="${x.id}"
        ${(A._picked||[]).includes(x.id)?'checked':''} onchange="adPick(${x.id},this.checked)"></span>
      <span class="ad-td c0 tap-area" onclick="adPerson('${kind}',${x.id})">
        ${av(x.name,'sm',x.avatar_url)}<b>${esc(x.name)}</b></span>
      <span class="ad-td sub">${sub}</span>
      <span class="ad-td c1">${esc(x.email||'—')}</span>
      <span class="ad-td c2 ${spec?'num':''}">${cells[0]}</span>
      <span class="ad-td c3 ${spec?'num':''}">${cells[1]}</span>
      <span class="ad-td c4"><i class="ad-state ${blocked?'off':'on'}">${blocked?'Заблокирован':'Активен'}</i></span>
      <span class="ad-td c5 num">${esc(dmy(String(x.created_at||'').slice(0,10)))}</span>
      <span class="ad-td act">
        <button class="ad-btn ${blocked?'on':''}"
          onclick="${spec?'adToggleSpec':'adToggleClient'}(${x.id},${blocked?0:1})"
          title="${blocked?'Снять блокировку':'Заблокировать доступ'}">${blocked?'Вернуть':'Блок'}</button>
      </span>
    </div>`;
  }).join('');
}

/* --- Карточка человека ---
   Список отвечает, кто есть; карточка — что с ним.

   Раскладка здесь другая, чем на телефоне, и это не прихоть: на
   телефоне всё идёт одной колонкой сверху вниз, а на рабочем экране
   слева стоит сам человек (кто, чем занят, какие поля), справа — что он
   делал. Иначе широкий экран заполняется одной колонкой посередине и
   гигантской кнопкой во всю ширину — телефонный экран, растянутый до
   полутора тысяч точек. */
function adFields(list){
  return `<div class="ad-fields">${list.filter(([,v])=>v!==''&&v!=null).map(([k,v])=>
    `<div class="ad-field"><span>${k}</span><b>${v}</b></div>`).join('')}</div>`;
}
async function adPerson(kind,id){
  let j;
  try{ j=await api('/admin/person/'+kind+'/'+id) }
  catch(e){ toast(e.message,'err'); return }
  A._person=j;
  const p=j.person||{}, spec=kind==='specialist';
  const blocked=(p.status||'active')==='blocked';
  const tile=(lbl,val,foot)=>`<div class="wtile"><div class="wt-lbl">${lbl}</div>
    <div class="wt-big num">${val}</div><div class="wt-foot">${foot||''}</div></div>`;

  const fields=spec
    ? [['Почта',esc(p.email||'—')],['Телефон',esc(p.phone||'—')],
       ['Профессия',esc(p.profession||'—')],['Тариф',esc(p.plan||'free')],
       ['Верификация',p.verify_status==='verified'?'пройдена':esc(p.verify_status||'нет')],
       ['Код для клиентов',esc(p.join_code||'—')],
       ['В сервисе с',esc(dmy(String(p.created_at||'').slice(0,10)))],
       ['Откуда пришёл',esc(p.source||'напрямую')],
       ['Был в сети',p.last_seen_at?esc(agoLabel(p.last_seen_at)):'—']]
    : [['Почта',esc(p.email||'—')],['Телефон',esc(p.phone||'—')],
       ['Специалист',esc(p.specialist||'без специалиста')],
       ['Цель',esc(p.goal||'не задана')],
       ['В сервисе с',esc(dmy(String(p.created_at||'').slice(0,10)))],
       ['Откуда пришёл',esc(p.source||'напрямую')],
       ['Последняя отметка',j.last_log?esc(dmy(String(j.last_log).slice(0,10))):'—']];

  const money=j.money||{}, rates=j.rates||{};
  const pct=v=>Math.round((+v||0)*100)+' %';
  const right=spec?`
    <div class="wgrid">
      ${tile('Клиенты',j.counts.clients,'закреплены за ним')}
      ${tile('Оборот',rub(money.turnover_kop||0),`${money.deals||0} оплат`)}
      ${tile('Наша комиссия',rub(money.commission_kop||0),'за всё время')}
      ${tile('Заморожено',rub(j.balance.held_kop||0),'обязательства перед ним')}
      ${tile('Доступно',rub(j.balance.avail_kop||0),'можно вывести')}
      ${tile('Выплачено',rub(money.paid_out_kop||0),'переведено ему')}
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b>Ставка комиссии</b>
        <small>${rates.own==null&&rates.catalog==null?'по общим правилам':'личная договорённость'}</small></div>
      <div class="ad-rows"><div class="ad-ratebox">
        <label>Со своих клиентов, %
          <input id="rt_own" inputmode="decimal" placeholder="${pct(rates.default_own)} — общая"
            value="${rates.own==null?'':Math.round(rates.own*100)}"></label>
        <label>С клиентов из каталога, %
          <input id="rt_cat" inputmode="decimal" placeholder="${pct(rates.default_catalog)} — общая"
            value="${rates.catalog==null?'':Math.round(rates.catalog*100)}"></label>
        <button class="ad-btn primary" onclick="adRateSave(${p.id})">${icon('save')} Сохранить</button>
      </div>
      <p class="rw-foot muted">Пустое поле — значит действуют общие ставки из раздела «Деньги».
        Уже оплаченные сделки не пересчитываются: по ним причитается то, о чём договаривались тогда.</p>
      </div>
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b>Клиенты</b><small>${j.clients.length}</small></div>
      <div class="ad-rows">${j.clients.map(c=>`<div class="ad-tr">
        <span class="ad-td c0 tap-area" onclick="adPerson('client',${c.id})">
          ${av(c.name,'sm',c.avatar_url)}<b>${esc(c.name)}</b></span>
        <span class="ad-td sub">${esc(c.goal||'цель не задана')}</span>
        <span class="ad-td c1">${esc(c.goal||'—')}</span>
        <span class="ad-td c2"></span><span class="ad-td c3"></span>
        <span class="ad-td c4"><i class="ad-state ${(c.status||'active')==='blocked'?'off':'on'}">${
          (c.status||'active')==='blocked'?'Заблокирован':'Активен'}</i></span>
        <span class="ad-td c5 num">${esc(dmy(String(c.created_at||'').slice(0,10)))}</span>
        <span class="ad-td act"></span></div>`).join('')
        ||'<div class="empty small">Клиентов нет</div>'}</div>
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b>Последние меню</b><small>${j.menus.length}</small></div>
      <div class="ad-rows">${j.menus.map(m=>`<div class="ad-tr">
        <span class="ad-td c0"><b>${esc(m.title||'Меню')}</b></span>
        <span class="ad-td sub">${m.status==='published'?'опубликовано':'черновик'}</span>
        <span class="ad-td c1">${m.status==='published'?'опубликовано':'черновик'}</span>
        <span class="ad-td c2"></span><span class="ad-td c3"></span><span class="ad-td c4"></span>
        <span class="ad-td c5 num">${m.start_date?esc(dmy(String(m.start_date).slice(0,10))):''}</span>
        <span class="ad-td act"></span></div>`).join('')
        ||'<div class="empty small">Меню нет</div>'}</div>
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b>Отзывы</b><small>${j.reviews.length}</small></div>
      <div class="ad-rows">${j.reviews.map(r=>`<div class="ad-tr">
        <span class="ad-td c0"><b>${'★'.repeat(Math.max(1,Math.min(5,+r.rating||0)))}</b></span>
        <span class="ad-td sub">${esc(r.client_name||'')} · ${esc((r.body||'').slice(0,80))}</span>
        <span class="ad-td c1">${esc(r.client_name||'')}</span>
        <span class="ad-td c2 wide">${esc((r.body||'').slice(0,120))}</span>
        <span class="ad-td c3"></span>
        <span class="ad-td c4">${r.status==='hidden'?'<i class="ad-state off">скрыт</i>':''}</span>
        <span class="ad-td c5 num">${esc(dmy(String(r.created_at||'').slice(0,10)))}</span>
        <span class="ad-td act"></span></div>`).join('')
        ||'<div class="empty small">Отзывов нет</div>'}</div>
    </div>`
  :`
    <div class="wgrid">
      ${tile('Меню',j.counts.menus,'назначено всего')}
      ${tile('Отметок',j.counts.logs,'в дневнике')}
      ${tile('Записей веса',j.counts.weights,'за всё время')}
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b>Последние меню</b><small>${j.menus.length}</small></div>
      <div class="ad-rows">${j.menus.map(m=>`<div class="ad-tr">
        <span class="ad-td c0"><b>${esc(m.title||'Меню')}</b></span>
        <span class="ad-td sub">${m.status==='published'?'опубликовано':'черновик'}</span>
        <span class="ad-td c1">${m.status==='published'?'опубликовано':'черновик'}</span>
        <span class="ad-td c2"></span><span class="ad-td c3"></span><span class="ad-td c4"></span>
        <span class="ad-td c5 num">${m.start_date?esc(dmy(String(m.start_date).slice(0,10))):''}</span>
        <span class="ad-td act"></span></div>`).join('')
        ||'<div class="empty small">Меню нет</div>'}</div>
    </div>`;

  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adPeople('${spec?'spec':'cli'}')">${icon('back')}
          <span>Люди · ${spec?'Специалисты':'Клиенты'}</span></button>
        <h1>${esc(p.name||'')}</h1>
        <p class="muted small">${spec
          ? esc(p.profession||'профессия не указана')+' · тариф '+esc(p.plan||'free')
          : esc(p.specialist||'без специалиста')+' · '+esc(p.goal||'цель не задана')}</p>
      </div>
      <div class="ad-actions">
        <i class="ad-state ${blocked?'off':'on'}">${blocked?'Доступ закрыт':'Активен'}</i>
        <button class="ad-btn" onclick="adPersonEdit('${kind}',${p.id})">Изменить</button>
        ${spec?'':`<button class="ad-btn" onclick="adPersonMove(${p.id})">Сменить специалиста</button>`}
        <button class="ad-btn ${blocked?'':'danger'}"
          onclick="${spec?'adToggleSpec':'adToggleClient'}(${p.id},${blocked?0:1})">
          ${blocked?'Вернуть доступ':'Заблокировать'}</button>
      </div>
    </div>
    <div class="ad-cols">
      <aside class="ad-side">
        <div class="ad-person">${av(p.name,'',p.avatar_url)}
          <div class="grow"><b>${esc(p.name||'')}</b><span class="muted small">${esc(p.email||'')}</span></div></div>
        ${adFields(fields)}
      </aside>
      <div class="ad-main">
        ${adNotesBlock(kind,p.id,j.notes||[])}
        ${adTicketsBlock(j.tickets||[])}
        ${right}
      </div>
    </div>`,'users'));
}

/* --- Отзывы ---
   Маршрут на сервере был, а экрана не было: отзывы уже влияли на
   рейтинг в каталоге, но ни скрыть клеветнический, ни вернуть
   ошибочно скрытый владелец не мог. */
async function adReviews(){
  let j={reviews:[]};
  try{ j=await api('/admin/reviews') }catch(e){ toast(e.message,'err') }
  A._adReviews=j.reviews||[];
  A.adDishTab='reviews';
  const hidden=A._adReviews.filter(r=>r.status==='hidden').length;
  const avg=A._adReviews.length
    ? (A._adReviews.reduce((a,r)=>a+(+r.rating||0),0)/A._adReviews.length).toFixed(1).replace('.',',')
    : '—';
  go(adShell(`${adHead('Отзывы','Что клиенты пишут о специалистах')}
  ${adContentTabs()}
  <div class="wgrid">
    <div class="wtile"><div class="wt-lbl">Всего отзывов</div><div class="wt-big num">${A._adReviews.length}</div>
      <div class="wt-foot num">${hidden} скрыто</div></div>
    <div class="wtile"><div class="wt-lbl">Средняя оценка</div><div class="wt-big num">${avg}</div>
      <div class="wt-foot">по всем специалистам</div></div>
  </div>
  <div class="ad-table">
    <div class="ad-thead"><b>Отзывы</b><small>${A._adReviews.length}</small></div>
    <div class="ad-rows">${A._adReviews.length?`
      <div class="ad-tr ad-head">
        <span class="ad-td c0">Оценка</span><span class="ad-td c1">Специалист</span>
        <span class="ad-td c2 wide">Отзыв</span><span class="ad-td c3">Клиент</span>
        <span class="ad-td c4">Состояние</span><span class="ad-td c5 num">Когда</span>
        <span class="ad-td act"></span></div>`
      +A._adReviews.map(r=>{
        const hid=r.status==='hidden';
        return `<div class="ad-tr ${hid?'off':''}">
          <span class="ad-td c0"><b>${'★'.repeat(Math.max(1,Math.min(5,+r.rating||0)))}</b></span>
          <span class="ad-td sub">${esc(r.specialist_name||'')} · ${esc((r.body||'').slice(0,70))}</span>
          <span class="ad-td c1">${esc(r.specialist_name||'')}</span>
          <span class="ad-td c2 wide">${esc((r.body||'').slice(0,160))}</span>
          <span class="ad-td c3">${esc(r.client_name||'')}</span>
          <span class="ad-td c4"><i class="ad-state ${hid?'off':'on'}">${hid?'Скрыт':'Виден'}</i></span>
          <span class="ad-td c5 num">${esc(dmy(String(r.created_at||'').slice(0,10)))}</span>
          <span class="ad-td act"><button class="ad-btn ${hid?'on':''}"
            onclick="adReviewToggle(${r.id},${hid?0:1})">${hid?'Вернуть':'Скрыть'}</button></span>
        </div>`}).join('')
      :'<div class="empty small">Отзывов пока нет</div>'}</div>
  </div>`,'content'));
}
async function adReviewToggle(id,hide){
  let reason='';
  if(hide){
    /* Причину спрашиваем не для порядка: скрытый отзыв — это спор с
       клиентом, и через месяц надо помнить, за что его сняли. */
    reason=prompt('За что скрываем отзыв? Причина останется в журнале.')||'';
    if(!reason.trim())return;
  }
  try{ await api('/admin/reviews/'+id,{method:'PATCH',
      body:JSON.stringify({status:hide?'hidden':'published',reason})});
    adReviews(); }
  catch(e){ toast(e.message,'err') }
}

/* --- Завести человека вручную ---
   Специалист пришёл по телефону, клиента заводят на показе — ждать их
   самостоятельной регистрации неоткуда. */
function adPeopleAdd(){
  const spec=A.adTab==='spec';
  const list=(A._adSpecs||[]);
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Люди</div>
      <h2>${spec?'Новый специалист':'Новый клиент'}</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form class="formgrid" onsubmit="adPeopleAddSave(event,'${spec?'specialist':'client'}')">
      <label class="full">Имя<input id="np_name" required placeholder="Имя и фамилия"></label>
      <label class="full">Почта<input id="np_mail" type="email" required placeholder="mail@example.ru"></label>
      <label class="full">Телефон<input id="np_phone" placeholder="необязательно"></label>
      ${spec?'':`<label class="full">Специалист<select id="np_sp">
        <option value="0">— без специалиста —</option>
        ${list.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label>
        <label class="full">Цель<input id="np_goal" placeholder="Снижение веса"></label>`}
      <button class="primary wide full">Завести</button>
    </form>
    <p class="rw-foot muted">Пароль придумаем сами и покажем один раз — передайте его человеку.</p>`);
}
async function adPeopleAddSave(e,kind){
  e.preventDefault();
  const body={kind,name:$('#np_name').value,email:$('#np_mail').value,phone:$('#np_phone').value};
  if(kind==='client'){ body.specialist_id=+($('#np_sp')?.value||0); body.goal=$('#np_goal')?.value||''; }
  try{
    const r=await api('/admin/people',{method:'POST',body:JSON.stringify(body)});
    closeModal();
    alert('Заведён.\n\nПароль: '+r.password+'\n\nПередайте его человеку — второй раз мы его не покажем.');
    adPeople(kind==='specialist'?'spec':'cli');
  }catch(x){ toast(x.message,'err') }
}

/* --- Промокоды ---
   Скидка в комиссионной модели — это чьи-то деньги, поэтому плательщик
   виден прямо в списке: сервис отдаёт из комиссии, специалист — из своей
   доли. Потраченное считаем по фактическим применениям. */
async function adPromos(){
  let j={promos:[]};
  try{ j=await api('/admin/promos') }catch(e){ toast(e.message,'err') }
  A._promos=j.promos||[];
  const spent=A._promos.reduce((a,p)=>a+(+p.spent_kop||0),0);
  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adFinance()">${icon('back')}<span>Деньги</span></button>
        <h1>Промокоды</h1>
        <p class="muted small">Скидка клиенту на услугу специалиста</p>
      </div>
      <div class="ad-actions">
        <button class="ad-btn primary" onclick="adPromoAdd()">${icon('plus')} Новый код</button>
      </div>
    </div>
    <div class="wgrid">
      <div class="wtile"><div class="wt-lbl">Кодов</div><div class="wt-big num">${A._promos.length}</div>
        <div class="wt-foot num">${A._promos.filter(p=>p.status==='active').length} действуют</div></div>
      <div class="wtile"><div class="wt-lbl">Отдано скидками</div><div class="wt-big num">${rub(spent)}</div>
        <div class="wt-foot">по всем применениям</div></div>
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b>Коды</b><small>${A._promos.length}</small></div>
      <div class="ad-rows">${A._promos.length?`
        <div class="ad-tr ad-head">
          <span class="ad-td c0">Код</span><span class="ad-td c1">За чей счёт</span>
          <span class="ad-td c2 num">Скидка</span><span class="ad-td c3 num">Применений</span>
          <span class="ad-td c4">Состояние</span><span class="ad-td c5 num">Отдано</span>
          <span class="ad-td act"></span></div>`
        +A._promos.map(p=>{
          const off=p.status!=='active';
          const payer=p.payer==='specialist'?'специалиста':'сервиса';
          return `<div class="ad-tr ${off?'off':''}">
            <span class="ad-td c0"><b>${esc(p.code)}</b></span>
            <span class="ad-td sub">${p.percent}% за счёт ${payer}${p.specialist_name?' · только у «'+esc(p.specialist_name)+'»':''}</span>
            <span class="ad-td c1">${payer}${p.specialist_name?' · '+esc(p.specialist_name):''}</span>
            <span class="ad-td c2 num">${p.percent} %</span>
            <span class="ad-td c3 num">${p.uses}${p.max_uses?' / '+p.max_uses:''}</span>
            <span class="ad-td c4"><i class="ad-state ${off?'off':'on'}">${off?'Выключен':'Работает'}</i></span>
            <span class="ad-td c5 num">${rub(p.spent_kop||0)}</span>
            <span class="ad-td act">
              <button class="ad-btn" onclick="adPromoToggle(${p.id},'${off?'active':'off'}')">${off?'Включить':'Выключить'}</button>
              ${+p.uses?'':`<button class="ad-btn danger" aria-label="Удалить код" onclick="adPromoDel(${p.id})">${icon('trash')}</button>`}
            </span>
          </div>`}).join('')
        :'<div class="empty small">Кодов пока нет</div>'}</div>
    </div>`,'coin'));
}
function adPromoAdd(){
  const list=A._adSpecs||[];
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Промокод</div><h2>Новый код</h2></div>
      <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form class="formgrid" onsubmit="adPromoSave(event)">
      <label class="full">Код<input id="pr_code" required placeholder="START20" maxlength="24"></label>
      <label>Скидка, %<input id="pr_pct" inputmode="numeric" required placeholder="20"></label>
      <label>За чей счёт<select id="pr_payer">
        <option value="service">Сервиса — из нашей комиссии</option>
        <option value="specialist">Специалиста — из его доли</option>
      </select></label>
      <label>Ограничение применений<input id="pr_max" inputmode="numeric" placeholder="без ограничения"></label>
      <label>Действует до<input id="pr_exp" type="date"></label>
      <label class="full">Только у специалиста<select id="pr_sp">
        <option value="0">— у всех —</option>
        ${list.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></label>
      <label class="full">Пометка для себя<input id="pr_note" maxlength="200" placeholder="например: осенняя акция"></label>
      <button class="primary wide full">Создать</button>
    </form>
    <p class="rw-foot muted">Скидка за счёт сервиса уменьшает нашу комиссию, за счёт специалиста — его долю.
      Уже оплаченные сделки не меняются.</p>`);
}
async function adPromoSave(e){
  e.preventDefault();
  try{
    await api('/admin/promos',{method:'POST',body:JSON.stringify({
      code:$('#pr_code').value, percent:+$('#pr_pct').value,
      payer:$('#pr_payer').value, max_uses:+($('#pr_max').value||0),
      expires_at:$('#pr_exp').value||'', specialist_id:+$('#pr_sp').value,
      note:$('#pr_note').value})});
    closeModal(); adPromos();
  }catch(x){ toast(x.message,'err') }
}
async function adPromoToggle(id,status){
  try{ await api('/admin/promos/'+id,{method:'PATCH',body:JSON.stringify({status})}); adPromos(); }
  catch(e){ toast(e.message,'err') }
}
async function adPromoDel(id){
  if(!confirm('Удалить код?'))return;
  try{ await api('/admin/promos/'+id,{method:'DELETE'}); adPromos(); }
  catch(e){ toast(e.message,'err') }
}

async function adRateSave(id){
  try{
    await api('/admin/specialists/'+id+'/rate',{method:'POST',body:JSON.stringify({
      rate_own:$('#rt_own').value.trim(), rate_catalog:$('#rt_cat').value.trim()})});
    toast('Ставка сохранена','ok'); adPerson('specialist',id);
  }catch(e){ toast(e.message,'err') }
}
/* Заметки о человеке: то, чем CRM отличается от списка пользователей.
   Разговор по телефону, обещание, жалоба — всё это иначе остаётся в
   голове у одного человека, а с помощниками это уже не работает. */
function adNotesBlock(kind,id,notes){
  return `<div class="ad-table">
    <div class="ad-thead"><b>Заметки</b><small>${notes.length}</small></div>
    <div class="ad-rows">
      <form class="ad-noteform" onsubmit="adNoteAdd(event,'${kind}',${id})">
        <input id="ad_note" placeholder="Записать, о чём договорились" maxlength="2000">
        <button class="ad-btn primary">${icon('plus')} Добавить</button>
      </form>
      ${notes.map(n=>`<div class="ad-tr note">
        <span class="ad-td c0"><b>${esc(n.body)}</b></span>
        <span class="ad-td sub">${esc(n.author_name||'владелец')} · ${esc(agoLabel(n.created_at))}</span>
        <span class="ad-td c1">${esc(n.author_name||'владелец')}</span>
        <span class="ad-td c2"></span><span class="ad-td c3"></span><span class="ad-td c4"></span>
        <span class="ad-td c5 num">${esc(agoLabel(n.created_at))}</span>
        <span class="ad-td act"><button class="ad-btn danger" aria-label="Удалить заметку"
          onclick="adNoteDel(${n.id},'${kind}',${id})">${icon('trash')}</button></span>
      </div>`).join('')||'<div class="empty small">Заметок пока нет</div>'}
    </div></div>`;
}
async function adNoteAdd(e,kind,id){
  e.preventDefault();
  const el=$('#ad_note'), body=el.value.trim();
  if(!body)return;
  try{ await api('/admin/person/'+kind+'/'+id+'/notes',{method:'POST',body:JSON.stringify({body})});
    adPerson(kind,id); }
  catch(x){ toast(x.message,'err') }
}
async function adNoteDel(nid,kind,id){
  try{ await api('/admin/notes/'+nid,{method:'DELETE'}); adPerson(kind,id); }
  catch(e){ toast(e.message,'err') }
}
/* Обращения человека прямо в его карточке: раньше тикет и профиль жили
   порознь, и «о чём он уже писал» приходилось искать в поддержке. */
function adTicketsBlock(tickets){
  if(!tickets.length)return '';
  return `<div class="ad-table">
    <div class="ad-thead"><b>Обращения в поддержку</b><small>${tickets.length}</small></div>
    <div class="ad-rows">${tickets.map(t=>`<div class="ad-tr">
      <span class="ad-td c0 tap-area" onclick="adTicket(${t.id})"><b>${esc(t.subject||'Без темы')}</b></span>
      <span class="ad-td sub">${t.status==='closed'?'закрыто':'в работе'} · ${esc(agoLabel(t.last_reply_at||t.created_at))}</span>
      <span class="ad-td c1">${esc(SUPPORT_TOPIC_RU[t.topic]||t.topic||'')}</span>
      <span class="ad-td c2"></span><span class="ad-td c3"></span>
      <span class="ad-td c4"><i class="ad-state ${t.status==='closed'?'off':'on'}">${
        t.status==='closed'?'Закрыто':'В работе'}</i></span>
      <span class="ad-td c5 num">${esc(agoLabel(t.last_reply_at||t.created_at))}</span>
      <span class="ad-td act"></span></div>`).join('')}</div></div>`;
}
const SUPPORT_TOPIC_RU={payment:'Оплата',menu:'Меню',account:'Учётная запись',other:'Другое',bug:'Ошибка'};

/* Правка человека: имя, почта, пароль, удаление по требованию.
   Последнее — не удобство: право на удаление данных у нас по закону, и
   отрабатывать его вручную в базе неправильно. */
function adPersonEdit(kind,id){
  const spec=kind==='specialist';
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">${spec?'Специалист':'Клиент'}</div>
      <h2>Изменить данные</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form class="formgrid" onsubmit="adPersonSave(event,'${kind}',${id})">
      <label class="full">Имя<input id="pe_name" placeholder="Как зовут"></label>
      <label class="full">Почта<input id="pe_mail" type="email" placeholder="Новая почта"></label>
      <button class="primary wide full">Сохранить</button>
    </form>
    <button class="btn-wide" onclick="adPersonPassword('${kind}',${id})">${icon('lock')} Выдать новый пароль</button>
    <button class="btn-wide danger-btn" onclick="adPersonDelete('${kind}',${id})">${icon('trash')} Удалить учётную запись</button>
    <p class="rw-foot muted">Пустые поля не меняются. Удаление — по требованию человека: записи в журнале останутся.</p>`);
}
async function adPersonSave(e,kind,id){
  e.preventDefault();
  const body={};
  const n=$('#pe_name').value.trim(), m=$('#pe_mail').value.trim();
  if(n)body.name=n; if(m)body.email=m;
  if(!Object.keys(body).length){ closeModal(); return }
  try{ await api('/admin/person/'+kind+'/'+id,{method:'PATCH',body:JSON.stringify(body)});
    closeModal(); adPerson(kind,id); }
  catch(x){ toast(x.message,'err') }
}
async function adPersonPassword(kind,id){
  try{ const r=await api('/admin/person/'+kind+'/'+id,{method:'PATCH',body:JSON.stringify({reset_password:1})});
    closeModal();
    alert('Новый пароль: '+r.password+'\n\nСтарые сессии закрыты — человеку нужно войти заново.'); }
  catch(e){ toast(e.message,'err') }
}
async function adPersonDelete(kind,id){
  if(!confirm('Удалить учётную запись навсегда? Отменить будет нельзя.'))return;
  try{ await api('/admin/person/'+kind+'/'+id,{method:'DELETE'}); closeModal(); adPeople(); }
  catch(e){ toast(e.message,'err') }
}
/* Перевод клиента другому специалисту: специалист ушёл — его клиенты
   иначе зависают ни с кем. */
function adPersonMove(id){
  const list=(A._person&&A._person.specialists)||[];
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Клиент</div><h2>Сменить специалиста</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <label class="full">Специалист<select id="pm_sp">
      <option value="0">— открепить —</option>
      ${list.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join('')}
    </select></label>
    <button class="primary wide full" onclick="adPersonMoveSave(${id})">Перевести</button>
    <p class="rw-foot muted">Меню и переписка остаются у клиента. Новый специалист увидит его в своём списке.</p>`);
}
async function adPersonMoveSave(id){
  try{ await api('/admin/person/client/'+id,{method:'PATCH',
      body:JSON.stringify({specialist_id:+$('#pm_sp').value})});
    closeModal(); adPerson('client',id); }
  catch(e){ toast(e.message,'err') }
}

/* Верификация: очередь заявок.
   Решение принимает человек — сверяет скан с названием ВУЗа и годом.
   Поэтому здесь только то, что нужно глазам: документ, кто выдал,
   когда, и две кнопки. */
async function adVerifyBody(){
  let j={specialists:[]};
  try{j=await api('/admin/verifications')}catch(e){return '<div class="empty small">Не удалось загрузить</div>'}
  A._ver=j.specialists;
  if(!j.specialists.length)return '<div class="meal-sec"><div class="empty small">Заявок на верификацию пока нет</div></div>';
  const dl={pending:['Ждёт','d-wait'],approved:['Принят','d-ok'],rejected:['Отклонён','d-bad']};
  const sl={none:['Не подтверждён','v-none'],pending:['На проверке','v-pending'],verified:['Проверен','v-ok'],rejected:['Отказано','v-bad']};
  return j.specialists.map(s=>{
    const [stl,stc]=sl[s.verify_status]||sl.none;
    const approved=(s.documents||[]).some(d=>d.status==='approved');
    return `<div class="meal-sec ad-ver">
      <div class="ad-row">${av(s.name,'',s.avatar_url)}
        <div class="grow"><strong>${esc(s.name)}</strong><small>${esc(s.email||'')}${s.experience_years?' · опыт '+s.experience_years+' лет':''}</small></div>
        <span class="v-chip ${stc}">${stl}</span></div>
      ${s.education?`<div class="ver-claim"><span class="muted small">В анкете указано:</span> ${esc(s.education)}</div>`:''}
      <div class="meal-group">${(s.documents||[]).map(d=>{
        const [l,c]=dl[d.status]||dl.pending;
        return `<div class="ver-doc">
          <div class="grow"><strong>${esc(d.title)}</strong>
            <small>${[DOC_KINDS[d.kind]||'Документ',esc(d.issuer||''),esc(d.issued_on||'')].filter(Boolean).join(' · ')}</small>
            ${d.review_note?`<small class="v-reason">${esc(d.review_note)}</small>`:''}</div>
          <span class="d-chip ${c}">${l}</span>
          ${d.file_url?`<button class="ad-btn" onclick="hOpenLab('${d.file_url}')">Открыть</button>`:''}
          <button class="ad-btn" onclick="adDoc(${d.id},'approved')">Принять</button>
          <button class="ad-btn on" onclick="adDoc(${d.id},'rejected')">Отклонить</button>
        </div>`}).join('')||'<div class="empty small">Документы не приложены</div>'}</div>
      <div class="ver-foot">
        <button class="ad-btn" ${approved?'':'disabled'} onclick="adVerify(${s.id},'verified')">Подтвердить специалиста</button>
        <button class="ad-btn on" onclick="adVerify(${s.id},'rejected')">Отказать</button>
        ${s.verify_status==='verified'?`<button class="ad-btn" onclick="adVerify(${s.id},'none')">Снять отметку</button>`:''}
      </div></div>`}).join('');
}
async function adDoc(id,status){
  let note='';
  if(status==='rejected'){note=prompt('Причина отказа — её увидит специалист:')||'';if(!note.trim())return}
  try{await api('/admin/documents/'+id,{method:'PATCH',body:JSON.stringify({status,review_note:note})});adPeople('ver')}
  catch(e){toast(e.message,'err')}}
async function adVerify(id,status){
  let note='';
  if(status==='rejected'){note=prompt('Причина отказа — её увидит специалист:')||'';if(!note.trim())return}
  if(status==='none'&&!confirm('Снять отметку «Проверен»?'))return;
  try{await api('/admin/verifications/'+id,{method:'PATCH',body:JSON.stringify({status,note})});adPeople('ver')}
  catch(e){toast(e.message,'err')}}

async function adToggleSpec(id,block){try{await api('/admin/specialists/'+id,{method:'PATCH',body:JSON.stringify({status:block?'blocked':'active'})});adPeople('spec')}catch(e){toast(e.message,'err')}}
async function adToggleClient(id,block){try{await api('/admin/clients/'+id,{method:'PATCH',body:JSON.stringify({status:block?'blocked':'active'})});adPeople('cli')}catch(e){toast(e.message,'err')}}

async function adDishes(tab){
  A.adDishTab=tab||A.adDishTab||'dishes';
  A.adDishQ=A.adDishQ||''; A.adDishPage=1;
  const j=await api('/admin/dishes?limit=50'+adDishQuery());
  A._adDishes=j.dishes; A._adDishTotal=j.total; A._adDishPages=j.pages; A._adDishTags=j.tags||[];
  const pub=j.dishes.filter(d=>+d.is_public).length;
  go(adShell(`${adHead('Блюда','База блюд всего сервиса')}
  ${adContentTabs()}
  <div class="wgrid">
    <div class="wtile"><div class="wt-lbl">Всего блюд</div><div class="wt-big num">${j.dishes.length}</div><div class="wt-foot num">${pub} публичных</div></div>
    <div class="wtile"><div class="wt-lbl">Используются</div><div class="wt-big num">${j.dishes.filter(d=>+d.used).length}</div><div class="wt-foot">стоят в меню</div></div>
  </div>
  <div class="ad-toolbar">
    <div class="ad-tools">
      <div class="searchbox">${icon('search')}<input id="adq" placeholder="Поиск блюда…"
        value="${esc(A.adDishQ)}" oninput="adDishSearch(this.value)"></div>
      ${adDishFilter()}
    </div>
    <button class="ad-btn primary" onclick="adDishEditor(0)">${icon('plus')} Новое блюдо</button>
  </div>
  <div id="addishes-tags">${adDishTagStrip()}</div>
  <div class="ad-table">
    <div class="ad-thead"><b>Блюда</b><small id="addishes-count">${
      A.adDishQ?('найдено '+j.total):(j.total+' всего')}</small></div>
    <div class="ad-rows" id="addishes"></div></div>
  <div id="addishes-more"></div>`,'content'));
  adRenderDishes();
  adMoreBtn('#addishes-more',j,j.dishes.length,'A.adDishPage=2;adDishLoad(true)');
}
/* Список блюд — такая же таблица, как у людей: на широком экране
   колонки, на телефоне строка со сводкой. Числа выровнены по разряду,
   поэтому «в меню» и калорийность сравниваются взглядом по столбцу. */
/* Ищем на сервере, а не в браузере: раньше фильтровался только тот
   кусок, что успели загрузить, и всё, что за ним, найти было нельзя. */
/* Кнопка «Показать ещё» рисуется одинаково у всех списков: на первой
   отрисовке её забывали поставить, и следующая страница оставалась
   недостижимой, хотя сервер её отдавал. */
function adMoreBtn(box,j,loaded,onMore){
  const el=$(box); if(!el)return;
  el.innerHTML=(j.page<j.pages)
    ? `<button class="btn-wide quiet" onclick="${onMore}">Показать ещё · осталось ${j.total-loaded}</button>`
    : '';
}
/* --- Отбор блюд ---
   Каталог перевалил за полтысячи строк, и «найти всё постное» или
   «показать блюда без фотографии» глазами уже не делается. Отбираем на
   сервере: фильтр по видимости, по снимку и по метке складываются, а
   метки берутся из базы, а не из зашитого списка — иначе полоска
   разойдётся с тем, что специалисты навешали на блюда. */
const AD_DISH_ONLY=[['','Все'],['public','Видно'],['hidden','Скрыто'],['nophoto','Без фото']];
function adDishQuery(){
  return (A.adDishQ?'&q='+encodeURIComponent(A.adDishQ):'')
       + (A.adDishOnly?'&only='+A.adDishOnly:'')
       + (A.adDishTag?'&tag='+encodeURIComponent(A.adDishTag):'');
}
function adDishFilter(){
  return `<div class="ptabs sub" id="addishes-filter">${AD_DISH_ONLY.map(([v,l])=>
    `<button class="ptab ${(A.adDishOnly||'')===v?'on':''}"
      onclick="adDishOnly('${v}')">${l}</button>`).join('')}</div>`;
}
function adDishTagStrip(){
  const tags=A._adDishTags||[];
  if(!tags.length)return '';
  return `<div class="ad-tagstrip">
    <button class="tag-chip ${A.adDishTag?'':'on'}" onclick="adDishTag('')">Все метки</button>
    ${tags.map(t=>`<button class="tag-chip ${A.adDishTag===t.tag?'on':''}"
      onclick="adDishTag('${esc(String(t.tag)).replace(/'/g,"\\'")}')">${esc(t.tag)}
      <i class="num">${t.n}</i></button>`).join('')}</div>`;
}
function adDishOnly(v){ A.adDishOnly=v; A.adDishPage=1; adDishLoad() }
function adDishTag(v){  A.adDishTag=v;  A.adDishPage=1; adDishLoad() }
function adDishSearch(v){
  A.adDishQ=v; A.adDishPage=1;
  clearTimeout(A._addqT);
  A._addqT=setTimeout(()=>adDishLoad(),250);
}
async function adDishLoad(add){
  const j=await api('/admin/dishes?limit=50&page='+(A.adDishPage||1)+adDishQuery());
  A._adDishes=add?(A._adDishes||[]).concat(j.dishes):j.dishes;
  A._adDishTotal=j.total; A._adDishPages=j.pages; A._adDishTags=j.tags||A._adDishTags;
  const c=$('#addishes-count'); if(c)c.textContent=
    (A.adDishQ||A.adDishOnly||A.adDishTag)?('найдено '+j.total):(j.total+' всего');
  const fb=$('#addishes-filter'); if(fb)fb.outerHTML=adDishFilter();
  const tb=$('#addishes-tags');  if(tb)tb.innerHTML=adDishTagStrip();
  adRenderDishes();
  adMoreBtn('#addishes-more',j,A._adDishes.length,`A.adDishPage=${j.page+1};adDishLoad(true)`);
}
function adRenderDishes(){
  const rows=A._adDishes||[];
  const el=$('#addishes');if(!el)return;
  if(!rows.length){el.innerHTML='<div class="empty small">Ничего не найдено</div>';return}
  const head=['Блюдо','Автор','Ккал/100 г','В меню','Состояние','Метки'];
  el.innerHTML=`<div class="ad-tr ad-head">${head.map((h,i)=>
      `<span class="ad-td c${i} ${i===2||i===3?'num':''}">${h}</span>`).join('')}<span class="ad-td act"></span></div>`
    +rows.map(d=>`<div class="ad-tr">
    <span class="ad-td c0 tap-area" onclick="adDishEditor(${d.id})">
      <span class="mr-thumb" style="background-image:url(${esc(dishThumb(d))})"></span>
      <b>${esc(d.name)}</b></span>
    <span class="ad-td sub num">${R(d.kcal_100)} ккал/100 г · ${d.used?('в меню: '+d.used):'не используется'}${d.author?' · '+esc(d.author):''}</span>
    <span class="ad-td c1">${esc(d.author||'каталог')}</span>
    <span class="ad-td c2 num">${R(d.kcal_100)}</span>
    <span class="ad-td c3 num">${d.used||'—'}</span>
    <span class="ad-td c4"><i class="ad-state ${+d.is_public?'on':'off'}">${+d.is_public?'Видно':'Скрыто'}</i></span>
    <span class="ad-td c5">${dishTagList(d).map(t=>`<i class="tag-mini">${esc(t)}</i>`).join('')}</span>
    <span class="ad-td act">
      <button class="ad-btn ${+d.is_public?'on':''}" onclick="adDishPublic(${d.id},${+d.is_public?0:1})">${+d.is_public?'Скрыть':'Открыть'}</button>
      ${+d.used?'':`<button class="ad-btn danger" aria-label="Удалить блюдо" onclick="adDishDelete(${d.id})">${icon('trash')}</button>`}
    </span>
  </div>`).join('');
}
/* Сервер отдаёт метки строкой через запятую (их собирает GROUP_CONCAT),
   а редактор — массивом. Разбираем оба вида в одном месте. */
function dishTagList(d){
  const t=d&&d.tags;
  if(Array.isArray(t))return t;
  if(typeof t==='string'&&t)return t.split(',').map(x=>x.trim()).filter(Boolean);
  return [];
}
async function adDishPublic(id,val){try{await api('/admin/dishes/'+id,{method:'PATCH',body:JSON.stringify({is_public:val})});const d=(A._adDishes||[]).find(x=>+x.id===id);if(d)d.is_public=val;adRenderDishes()}catch(e){toast(e.message,'err')}}
async function adDishDelete(id){if(!confirm('Удалить блюдо навсегда?'))return;try{await api('/admin/dishes/'+id,{method:'DELETE'});A._adDishes=(A._adDishes||[]).filter(x=>+x.id!==id);adRenderDishes()}catch(e){toast(e.message,'err')}}

function adPassword(){showSheet(`<div class="sheet-head"><div><div class="eyebrow">Безопасность</div><h2>Пароль владельца</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="adSavePassword(event)" class="formgrid"><label class="full">Текущий пароль<input id="apc" type="password" required></label>
  <label class="full">Новый пароль<input id="apn" type="password" required placeholder="от 8 символов, буква и цифра"></label>
  <button class="primary wide full">Сохранить</button></form>`)}
async function adSavePassword(e){e.preventDefault();try{await api('/admin/password',{method:'POST',body:JSON.stringify({current:$('#apc').value,password:$('#apn').value})});closeModal();toast('Пароль изменён','ok');adOverview()}catch(x){toast(x.message,'err')}}

/* ============================================================
   ЛЕНТА. Общий экран для клиента и специалиста + модерация владельца.
   ============================================================ */
function ago(ts){
  if(!ts)return '';
  const t=Date.parse(String(ts).replace(' ','T')+'Z');if(isNaN(t))return '';
  const s=Math.max(0,(Date.now()-t)/1000);
  if(s<60)return 'только что';
  if(s<3600){const m=Math.floor(s/60);return m+' '+plural(m,['минуту','минуты','минут'])+' назад'}
  if(s<86400){const h=Math.floor(s/3600);return h+' '+plural(h,['час','часа','часов'])+' назад'}
  if(s<604800){const d=Math.floor(s/86400);return d+' '+plural(d,['день','дня','дней'])+' назад'}
  return new Date(t).toLocaleDateString('ru-RU',{day:'numeric',month:'long'});
}
function postCard(p){
  return `<article class="post" id="post-${p.id}">
    <header class="post-top">${av(p.author_name,'',p.author_avatar)}
      <div class="grow"><strong>${esc(p.author_name)}</strong><small>${p.author_type==='specialist'?'специалист · ':''}${ago(p.created_at)}</small></div>
      ${p.mine?`<button class="post-del" title="Удалить пост" onclick="feedDelete(${p.id})">${icon('trash')}</button>`:''}
    </header>
    ${p.photo_url?`<div class="post-photo"><img src="${esc(p.photo_url)}" alt="" loading="lazy"></div>`:''}
    ${p.text?`<p class="post-text">${esc(p.text).replace(/\n/g,'<br>')}</p>`:''}
    <footer class="post-foot">
      <button class="post-like ${p.liked?'on':''}" onclick="feedLike(${p.id},this)">${icon('star')}<b class="num">${p.likes}</b></button>
    </footer>
  </article>`;
}
async function feedScreen(){
  let j={posts:[]};let err='';
  try{j=await api('/feed')}catch(e){err=e.message}
  A._feed=j.posts;
  const body=`${clHead('Лента','',"clBackToMore()")}
  <button class="feed-new" onclick="feedCompose()"><span class="fn-ic">${icon('camera')}</span><span class="grow">Поделиться приёмом пищи или результатом</span>${icon('plus')}</button>
  ${err?`<div class="empty"><h3>Лента недоступна</h3><p class="muted">${esc(err)}</p></div>`
    :(j.posts.length?`<div class="feed">${j.posts.map(postCard).join('')}</div>`
      :`<div class="empty"><div class="orb">${icon('camera')}</div><h3>Здесь пока пусто</h3><p class="muted">Первый пост может быть вашим: фото тарелки, результат недели или мысль о том, что помогает держаться.</p></div>`)}`;
  go(A.type==='specialist'?spShell(body,'feed'):clShell(body,'more'));
}
function feedCompose(){
  showSheet(`<div class="sheet-grab"></div><div class="sheet-head"><div><div class="eyebrow">Новый пост</div><h2>Поделиться</h2></div><button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="feedSubmit(event)">
    <textarea id="ftext" class="feed-area" maxlength="1500" placeholder="Что сегодня в тарелке? Как идут дела?"></textarea>
    <label class="feed-photo" id="fphotolab"><input id="fphoto" type="file" accept="image/*" hidden onchange="feedPreview(this)">${icon('camera')}<span>Добавить фото</span></label>
    <button class="primary wide">Опубликовать</button>
  </form>`);
}
function feedPreview(inp){
  const f=inp.files&&inp.files[0];const lab=$('#fphotolab');if(!lab)return;
  if(!f){lab.innerHTML=`${icon('camera')}<span>Добавить фото</span>`;return}
  lab.classList.add('has');
  lab.innerHTML=`${icon('check')}<span>${esc(f.name.slice(0,28))}</span>`;
  lab.appendChild(inp);
}
async function feedSubmit(e){
  e.preventDefault();
  const btn=e.target.querySelector('button.primary');btn.disabled=true;btn.textContent='Публикуем…';
  try{
    const fd=new FormData();
    fd.append('text',$('#ftext').value.trim());
    const f=$('#fphoto').files[0];if(f)fd.append('photo',f);
    await api('/feed',{method:'POST',body:fd});
    closeModal();feedScreen();
  }catch(x){btn.disabled=false;btn.textContent='Опубликовать';toast(x.message,'err')}
}
async function feedLike(id,el){
  const on=el.classList.toggle('on');
  const b=el.querySelector('b');const cur=+b.textContent||0;b.textContent=on?cur+1:Math.max(0,cur-1);
  try{const j=await api('/feed/'+id+'/like',{method:'POST'});b.textContent=j.likes;el.classList.toggle('on',j.liked)}
  catch(x){el.classList.toggle('on',!on);b.textContent=cur;toast(x.message,'err')}
}
async function feedDelete(id){
  if(!confirm('Удалить пост?'))return;
  try{await api('/feed/'+id,{method:'DELETE'});const el=document.getElementById('post-'+id);if(el)el.remove()}catch(x){toast(x.message,'err')}
}

/* Точки входа */
function clQuickAdd(){actSheet('Записать','Отметьте прогресс',[['chart','Добавить вес','clAddWeight()','','good'],['doc','Замеры','clAddMeasure()','','info'],['check','Чек-ин недели','clCheckin()','','warm'],'sep',['camera','Пост в ленту','feedCompose()','','good']])}
/* Модерация ленты в панели владельца */
async function adPosts(){
  const j=await api('/admin/posts');A._adPosts=j.posts;
  A.adDishTab='posts';
  go(adShell(`${adHead('Лента','Модерация постов')}
  ${adContentTabs()}
  <div class="wgrid">
    <div class="wtile"><div class="wt-lbl">Всего постов</div><div class="wt-big num">${j.posts.length}</div><div class="wt-foot num">${j.posts.filter(p=>p.status==='hidden').length} скрыто</div></div>
    <div class="wtile"><div class="wt-lbl">С фото</div><div class="wt-big num">${j.posts.filter(p=>p.photo_url).length}</div><div class="wt-foot">из всех постов</div></div>
  </div>
  <div class="meal-sec"><div class="meal-group">${j.posts.map(p=>`<div class="ad-row ${p.status==='hidden'?'off':''}">
    ${p.photo_url?`<span class="mr-thumb" style="background-image:url(${esc(p.photo_url)})"></span>`:`<span class="mr-thumb"></span>`}
    <div class="grow"><strong>${esc(p.author_name||'—')}</strong><small>${esc((p.text||'без текста').slice(0,60))}</small></div>
    <button class="ad-btn ${p.status==='hidden'?'on':''}" onclick="adPostToggle(${p.id},'${p.status==='hidden'?'visible':'hidden'}')">${p.status==='hidden'?'Вернуть':'Скрыть'}</button>
    <button class="ad-btn danger" aria-label="Удалить пост" onclick="adPostDelete(${p.id})">${icon('trash')}</button>
  </div>`).join('')||'<div class="empty small">Постов пока нет</div>'}</div></div>`,'content'));
}
async function adPostToggle(id,status){try{await api('/admin/posts/'+id,{method:'PATCH',body:JSON.stringify({status})});adPosts()}catch(e){toast(e.message,'err')}}
async function adPostDelete(id){if(!confirm('Удалить пост навсегда?'))return;try{await api('/admin/posts/'+id,{method:'DELETE'});adPosts()}catch(e){toast(e.message,'err')}}

/* ==========================================================================
   ВИДЕОЗВОНКИ В ЧАТЕ (WebRTC)
   Медиа идут напрямую между браузерами. Сервер только перекладывает
   SDP/ICE, пока соединение поднимается: POST /calls/signal + GET /calls/poll.
   ========================================================================== */

Object.assign(IC,{
  video:'M4.3 7.6a2 2 0 0 1 2-2h7.2a2 2 0 0 1 2 2v8.8a2 2 0 0 1-2 2H6.3a2 2 0 0 1-2-2ZM15.5 10.9l3.4-2.4a.7.7 0 0 1 1.1.6v5.8a.7.7 0 0 1-1.1.6l-3.4-2.4Z',
  videooff:'M15.5 10.9l3.4-2.4a.7.7 0 0 1 1.1.6v5.8a.7.7 0 0 1-1.1.6l-1.4-1M15.5 13.7V16.4a2 2 0 0 1-2 2H6.3a2 2 0 0 1-2-2V7.6a2 2 0 0 1 2-2h5.1M3.4 3.4l17.2 17.2',
  phone:'M20.4 16.7v2.6a1.8 1.8 0 0 1-2 1.8 17.6 17.6 0 0 1-7.7-2.7 17.3 17.3 0 0 1-5.3-5.3A17.6 17.6 0 0 1 2.7 5.4a1.8 1.8 0 0 1 1.8-2h2.6a1.8 1.8 0 0 1 1.8 1.5c.1.9.3 1.7.6 2.5a1.8 1.8 0 0 1-.4 1.9L8 10.4a14.2 14.2 0 0 0 5.3 5.3l1.1-1.1a1.8 1.8 0 0 1 1.9-.4c.8.3 1.6.5 2.5.6a1.8 1.8 0 0 1 1.6 1.9Z',
  phoneoff:'M10.1 13a14.2 14.2 0 0 0 3.2 2.1l1.1-1.1a1.8 1.8 0 0 1 1.9-.4c.8.3 1.6.5 2.5.6a1.8 1.8 0 0 1 1.6 1.9v2.5a1.8 1.8 0 0 1-2 1.8 17.6 17.6 0 0 1-7.7-2.7 17.4 17.4 0 0 1-2.6-2M5.4 9.4A17.6 17.6 0 0 1 2.7 5.4a1.8 1.8 0 0 1 1.8-2h2.6a1.8 1.8 0 0 1 1.8 1.5c.1.9.3 1.7.6 2.5a1.8 1.8 0 0 1-.4 1.9L8 10.4M2.6 2.6l18.8 18.8',
  mic:'M12 3.6a2.6 2.6 0 0 1 2.6 2.6v5.2a2.6 2.6 0 0 1-5.2 0V6.2A2.6 2.6 0 0 1 12 3.6ZM6 11a6 6 0 0 0 12 0M12 17v3.4M9 20.4h6',
  micoff:'M2.6 2.6l18.8 18.8M9.3 9.6v2.2a2.7 2.7 0 0 0 4.4 2.1M14.7 10V5.9a2.7 2.7 0 0 0-5.3-.6M16.9 16.5a6.4 6.4 0 0 1-11.3-4.4v-1.2m12.8 0v1.2c0 .4 0 .8-.1 1.1M12 18.5v2.3',
  flip:'M20.3 12.4a8.3 8.3 0 0 1-14 6M3.7 11.6a8.3 8.3 0 0 1 14-6M17.4 2.5v3.4h-3.4M6.6 21.5v-3.4h3.4'
});

const CALL={id:0,role:'',peer:null,status:'',pc:null,local:null,remote:null,
  since:0,poll:null,watch:null,tick:null,startMs:0,ringTimer:0,
  pendingIce:[],remoteReady:false,micOn:true,camOn:true,facing:'user',
  incomingId:0,ringing:null,busy:false};

function callSupported(){return !!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia&&window.RTCPeerConnection)}
function callCanCall(){return callSupported()&&(A.type==='specialist'||(A.type==='client'&&A.user&&A.user.specialist_id))}
function callMediaError(e){
  if(!navigator.mediaDevices)return 'Камера доступна только по HTTPS. Откройте сайт по https://';
  const n=e&&e.name;
  if(n==='NotAllowedError'||n==='SecurityError')return 'Доступ к камере и микрофону запрещён. Разрешите его в настройках браузера и попробуйте снова.';
  if(n==='NotFoundError'||n==='OverconstrainedError')return 'Камера или микрофон не найдены.';
  if(n==='NotReadableError')return 'Камера занята другим приложением.';
  return 'Не удалось включить камеру: '+(e&&e.message||'неизвестная ошибка');
}
async function callGetMedia(){
  return navigator.mediaDevices.getUserMedia({
    audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true},
    video:{facingMode:CALL.facing,width:{ideal:1280},height:{ideal:720}}});
}

/* --- Рингтон: короткий двойной сигнал раз в 2.4 с, без внешних файлов --- */
function callRingStart(){
  callRingStop();
  const beep=()=>{try{
    const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)return;
    CALL._actx=CALL._actx||new Ctx();const ctx=CALL._actx;if(ctx.state==='suspended')ctx.resume();
    [0,0.28].forEach(off=>{const o=ctx.createOscillator(),g=ctx.createGain();
      o.type='sine';o.frequency.value=620;o.connect(g);g.connect(ctx.destination);
      const t=ctx.currentTime+off;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.14,t+.03);
      g.gain.linearRampToValueAtTime(0,t+.22);o.start(t);o.stop(t+.24);});
  }catch(e){}};
  beep();CALL.ringing=setInterval(beep,2400);
  if(navigator.vibrate)try{navigator.vibrate([300,900,300])}catch(e){}
}
function callRingStop(){if(CALL.ringing){clearInterval(CALL.ringing);CALL.ringing=null}if(navigator.vibrate)try{navigator.vibrate(0)}catch(e){}}

/* ---------- Оверлей ---------- */
function callBox(){let b=$('#callui');if(!b){b=document.createElement('div');b.id='callui';document.body.appendChild(b)}return b}
function callClose(){const b=$('#callui');if(b)b.remove();document.body.classList.remove('call-open')}
function callAv(p){return av((p&&p.name)||'?','xl',p&&p.avatar_url)}

function callRenderIncoming(){
  const b=callBox();document.body.classList.add('call-open');
  b.className='callui incoming';
  b.innerHTML=`<div class="cv-hero">${callAv(CALL.peer)}
    <div class="cv-name">${esc(CALL.peer?.name||'Собеседник')}</div>
    <div class="cv-sub">Входящий видеозвонок</div></div>
    <div class="cv-actions">
      <button class="cv-btn decline" onclick="callDecline()" aria-label="Отклонить">${icon('phoneoff')}<span>Отклонить</span></button>
      <button class="cv-btn accept" onclick="callAccept()" aria-label="Ответить">${icon('video')}<span>Ответить</span></button>
    </div>`;
}
function callRenderLive(){
  const b=callBox();document.body.classList.add('call-open');
  b.className='callui live';
  b.innerHTML=`<video class="cv-remote" id="cvRemote" autoplay playsinline></video>
    <div class="cv-wait">${callAv(CALL.peer)}
      <div class="cv-name">${esc(CALL.peer?.name||'Собеседник')}</div>
      <div class="cv-sub" id="cvState">${CALL.role==='caller'?'Вызов…':'Соединение…'}</div></div>
    <video class="cv-local" id="cvLocal" autoplay playsinline muted></video>
    <div class="cv-top"><b>${esc(CALL.peer?.name||'Собеседник')}</b><span id="cvTimer">${CALL.role==='caller'?'Вызов…':'Соединение…'}</span></div>
    <div class="cv-bar">
      <button class="cv-round ${CALL.micOn?'':'off'}" id="cvMic" onclick="callToggleMic()" aria-label="Микрофон">${icon(CALL.micOn?'mic':'micoff')}</button>
      <button class="cv-round ${CALL.camOn?'':'off'}" id="cvCam" onclick="callToggleCam()" aria-label="Камера">${icon(CALL.camOn?'video':'videooff')}</button>
      <button class="cv-round" onclick="callFlip()" aria-label="Сменить камеру">${icon('flip')}</button>
      <button class="cv-round hang" onclick="callHangup('hangup')" aria-label="Завершить">${icon('phoneoff')}</button>
    </div>`;
  callBindVideo();
}
function callBindVideo(){
  const lv=$('#cvLocal'),rv=$('#cvRemote');
  if(lv&&CALL.local){lv.srcObject=CALL.local;lv.play?.().catch(()=>{})}
  if(rv&&CALL.remote){rv.srcObject=CALL.remote;rv.play?.().catch(()=>{})}
}
function callSetState(text){const s=$('#cvState'),t=$('#cvTimer');if(s)s.textContent=text;if(t)t.textContent=text}
function callTimerStart(){
  clearInterval(CALL.tick);CALL.startMs=CALL.startMs||Date.now();
  const upd=()=>{const s=Math.max(0,Math.round((Date.now()-CALL.startMs)/1000));
    const m=Math.floor(s/60),ss=String(s%60).padStart(2,'0');callSetState(m+':'+ss)};
  upd();CALL.tick=setInterval(upd,1000);
}

/* ---------- Соединение ---------- */
function callBuildPc(ice){
  const pc=new RTCPeerConnection({iceServers:ice||[],iceCandidatePoolSize:2});
  CALL.remote=new MediaStream();
  CALL.local.getTracks().forEach(t=>pc.addTrack(t,CALL.local));
  pc.ontrack=e=>{(e.streams[0]?e.streams[0].getTracks():[e.track]).forEach(t=>{
    if(!CALL.remote.getTracks().includes(t))CALL.remote.addTrack(t)});callBindVideo()};
  pc.onicecandidate=e=>{if(e.candidate)callSend('ice',e.candidate.toJSON())};
  const up=()=>{callBox().classList.add('connected');if(CALL.status==='active')callTimerStart()};
  pc.onconnectionstatechange=()=>{
    if(pc.connectionState==='connected')up();
    if(pc.connectionState==='failed')callFail('Не удалось установить соединение. Скорее всего нужен TURN-сервер — сети собеседников не видят друг друга напрямую.');
  };
  /* В части версий Safari connectionState появляется позже, чем ICE соединяется */
  pc.oniceconnectionstatechange=()=>{
    if(['connected','completed'].includes(pc.iceConnectionState))up();
    if(pc.iceConnectionState==='failed')callFail('Не удалось установить соединение. Скорее всего нужен TURN-сервер — сети собеседников не видят друг друга напрямую.');
  };
  return pc;
}
async function callSend(kind,payload){
  if(!CALL.id)return;
  try{await api('/calls/signal',{method:'POST',body:JSON.stringify({call_id:CALL.id,kind,payload})})}catch(e){}
}
async function callApplyRemote(desc){
  await CALL.pc.setRemoteDescription(new RTCSessionDescription(desc));
  CALL.remoteReady=true;
  for(const c of CALL.pendingIce.splice(0))try{await CALL.pc.addIceCandidate(c)}catch(e){}
}
async function callHandleSignal(s){
  let p;try{p=JSON.parse(s.payload)}catch(e){return}
  if(!p||!CALL.pc)return;
  if(s.kind==='offer'&&CALL.role==='callee'){
    await callApplyRemote(p);
    const ans=await CALL.pc.createAnswer();await CALL.pc.setLocalDescription(ans);
    callSend('answer',{type:ans.type,sdp:ans.sdp});
  }else if(s.kind==='answer'&&CALL.role==='caller'){
    if(!CALL.pc.currentRemoteDescription)await callApplyRemote(p);
  }else if(s.kind==='ice'){
    if(CALL.remoteReady){try{await CALL.pc.addIceCandidate(p)}catch(e){}}
    else CALL.pendingIce.push(p);
  }
}

/* ---------- Опрос состояния активного звонка ---------- */
function callPollStart(){
  clearInterval(CALL.poll);
  CALL.poll=setInterval(callPollTick,CALL.status==='active'?1500:1000);
}
async function callPollTick(){
  if(!CALL.id)return;
  let j;try{j=await api('/calls/poll?call_id='+CALL.id+'&since='+CALL.since)}catch(e){return}
  for(const s of (j.signals||[])){CALL.since=Math.max(CALL.since,s.id);try{await callHandleSignal(s)}catch(e){}}
  const c=j.call;if(!c)return;
  if(c.status==='active'&&CALL.status!=='active'){
    CALL.status='active';callRingStop();clearTimeout(CALL.ringTimer);
    callSetState('Соединение…');callTimerStart();callPollStart();
    if(CALL.pc&&['connected','completed'].includes(CALL.pc.iceConnectionState))callBox().classList.add('connected');
  }
  if(['ended','declined','missed'].includes(c.status)){
    callTeardown();
    const t=c.status==='declined'?'Собеседник отклонил звонок'
      :c.status==='missed'?'Собеседник не ответил':'Звонок завершён';
    callToast(t);callRefreshChat();
  }
}

/* ---------- Публичные действия ---------- */
async function callStart(clientId){
  if(CALL.busy)return;
  if(!callSupported())return toast(callInsecure()
    ? 'Видеозвонки работают только по HTTPS.\n\nСейчас сайт открыт по http:// — в этом режиме браузер не даёт доступ к камере и микрофону. Это защита самого браузера, а не ограничение приложения.\n\nПодключите SSL-сертификат в панели хостинга — звонки заработают без единой правки в коде.'
    : 'Ваш браузер не поддерживает видеозвонки.','err');
  CALL.busy=true;
  try{
    CALL.local=await callGetMedia();
  }catch(e){CALL.busy=false;return toast(callMediaError(e),'err')}
  let j;
  try{j=await api('/calls/start',{method:'POST',body:JSON.stringify(clientId?{client_id:clientId}:{})})}
  catch(e){callStopLocal();CALL.busy=false;return toast(e.message,'err')}
  CALL.id=j.call.id;CALL.role='caller';CALL.peer=j.peer;CALL.status=j.call.status;
  CALL.since=0;CALL.pendingIce=[];CALL.remoteReady=false;CALL.micOn=true;CALL.camOn=true;CALL.startMs=0;
  callRenderLive();
  CALL.pc=callBuildPc(j.ice_servers);
  try{
    const off=await CALL.pc.createOffer({offerToReceiveAudio:true,offerToReceiveVideo:true});
    await CALL.pc.setLocalDescription(off);
    await callSend('offer',{type:off.type,sdp:off.sdp});
  }catch(e){return callFail('Не удалось начать звонок: '+e.message)}
  callPollStart();
  CALL.ringTimer=setTimeout(()=>{if(CALL.status!=='active')callHangup('hangup','Собеседник не ответил')},(j.ring_seconds||45)*1000);
}
async function callAccept(){
  callRingStop();
  if(!callSupported())return toast(callInsecure()?'Ответить нельзя: камера доступна только по HTTPS.':'Ваш браузер не поддерживает видеозвонки.','err');
  const id=CALL.incomingId;if(!id)return;
  CALL.busy=true;
  try{CALL.local=await callGetMedia()}
  catch(e){CALL.busy=false;await api('/calls/decline',{method:'POST',body:JSON.stringify({call_id:id})}).catch(()=>{});callClose();CALL.incomingId=0;return toast(callMediaError(e),'err')}
  let j;
  try{j=await api('/calls/accept',{method:'POST',body:JSON.stringify({call_id:id})})}
  catch(e){callStopLocal();CALL.busy=false;CALL.incomingId=0;callClose();return toast(e.message,'err')}
  CALL.id=id;CALL.role='callee';CALL.peer=j.peer;CALL.status='active';
  CALL.since=0;CALL.pendingIce=[];CALL.remoteReady=false;CALL.micOn=true;CALL.camOn=true;CALL.startMs=Date.now();CALL.incomingId=0;
  callRenderLive();
  CALL.pc=callBuildPc(j.ice_servers);
  callTimerStart();callPollStart();callPollTick();
}
async function callDecline(){
  callRingStop();const id=CALL.incomingId;CALL.incomingId=0;callClose();
  if(id)try{await api('/calls/decline',{method:'POST',body:JSON.stringify({call_id:id})})}catch(e){}
  callRefreshChat();
}
async function callHangup(reason,note){
  const id=CALL.id;callTeardown();
  if(id)try{await api('/calls/end',{method:'POST',body:JSON.stringify({call_id:id,reason:reason||'hangup'})})}catch(e){}
  if(note)callToast(note);
  callRefreshChat();
}
function callFail(msg){const id=CALL.id;callTeardown();
  if(id)api('/calls/end',{method:'POST',body:JSON.stringify({call_id:id,reason:'failed'})}).catch(()=>{});
  callToast(msg,7000);callRefreshChat();}
function callStopLocal(){if(CALL.local){CALL.local.getTracks().forEach(t=>t.stop());CALL.local=null}}
function callTeardown(){
  callRingStop();clearInterval(CALL.poll);clearInterval(CALL.tick);clearTimeout(CALL.ringTimer);
  CALL.poll=CALL.tick=null;
  if(CALL.pc){try{CALL.pc.ontrack=CALL.pc.onicecandidate=CALL.pc.onconnectionstatechange=CALL.pc.oniceconnectionstatechange=null;CALL.pc.close()}catch(e){}CALL.pc=null}
  callStopLocal();
  CALL.remote=null;CALL.id=0;CALL.role='';CALL.status='';CALL.since=0;CALL.startMs=0;
  CALL.pendingIce=[];CALL.remoteReady=false;CALL.busy=false;
  callClose();
}
function callToggleMic(){if(!CALL.local)return;CALL.micOn=!CALL.micOn;
  CALL.local.getAudioTracks().forEach(t=>t.enabled=CALL.micOn);
  const b=$('#cvMic');if(b){b.classList.toggle('off',!CALL.micOn);b.innerHTML=icon(CALL.micOn?'mic':'micoff')}}
function callToggleCam(){if(!CALL.local)return;CALL.camOn=!CALL.camOn;
  CALL.local.getVideoTracks().forEach(t=>t.enabled=CALL.camOn);
  const b=$('#cvCam');if(b){b.classList.toggle('off',!CALL.camOn);b.innerHTML=icon(CALL.camOn?'video':'videooff')}}
async function callFlip(){
  if(!CALL.local||!CALL.pc)return;
  CALL.facing=CALL.facing==='user'?'environment':'user';
  try{
    const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:CALL.facing},audio:false});
    const nt=s.getVideoTracks()[0];if(!nt)return;
    const sender=CALL.pc.getSenders().find(x=>x.track&&x.track.kind==='video');
    if(sender)await sender.replaceTrack(nt);
    CALL.local.getVideoTracks().forEach(t=>{CALL.local.removeTrack(t);t.stop()});
    CALL.local.addTrack(nt);nt.enabled=CALL.camOn;callBindVideo();
  }catch(e){CALL.facing=CALL.facing==='user'?'environment':'user'}
}
function callToast(text,ms){
  const el=document.createElement('div');el.className='call-toast';el.textContent=text;
  document.body.appendChild(el);setTimeout(()=>el.remove(),ms||3200);
}
/* Если открыт чат — перерисуем, чтобы карточка звонка появилась в переписке */
function callRefreshChat(){
  try{
    if(A.type==='client'&&document.querySelector('.shell-chat'))clChat();
    else if(A.type==='specialist'&&A._openThread)spOpenThread(A._openThread);
  }catch(e){}
}

/* ---------- Фоновый сторож входящих ---------- */
async function callWatchTick(){
  if(!A.token||!A.user||CALL.id)return;
  if(A.type!=='client'&&A.type!=='specialist')return;
  if(document.hidden&&!CALL.incomingId)return;
  let j;try{j=await api('/calls/poll')}catch(e){return}
  const inc=(j.incoming&&j.incoming.call)?j.incoming:null;
  if(CALL.incomingId){
    /* Звонящий отменил вызов или истекло время — гасим экран входящего */
    if(!inc||inc.call.id!==CALL.incomingId){
      callRingStop();CALL.incomingId=0;callClose();
      callToast('Пропущенный звонок');callRefreshChat();
    }
    return;
  }
  if(inc){CALL.incomingId=inc.call.id;CALL.peer=inc.peer;callRenderIncoming();callRingStart()}
}
setInterval(callWatchTick,3000);
/* Закрытие вкладки во время звонка — сообщаем собеседнику, что мы ушли */
window.addEventListener('pagehide',()=>{
  if(!CALL.id||!A.token)return;
  try{fetch('/api/v1/calls/end',{method:'POST',keepalive:true,
    headers:{'Content-Type':'application/json','Authorization':'Bearer '+A.token},
    body:JSON.stringify({call_id:CALL.id,reason:'hangup'})})}catch(e){}
});

/* ---------- Кнопка звонка и карточка звонка в переписке ---------- */
/* Лента сообщений: разделители дней и группировка подряд идущих реплик
   одного автора. Сплошной поток пузырей без дат читается тяжело —
   непонятно, вчерашний это разговор или сегодняшний. */
function dayDivider(iso){const d=new Date(String(iso).slice(0,10)+'T00:00:00');if(isNaN(d))return '';
  const n=new Date();n.setHours(0,0,0,0);const diff=Math.round((n-d)/864e5);
  const t=diff===0?'Сегодня':diff===1?'Вчера':d.toLocaleDateString('ru-RU',{day:'numeric',month:'long'});
  return `<div class="msg-day"><span>${t}</span></div>`}
function msgList(msgs){let out='',prevDay='',prevWho='';
  (msgs||[]).forEach(m=>{const day=String(m.created_at||'').slice(0,10);
    if(day!==prevDay){out+=dayDivider(m.created_at);prevDay=day;prevWho=''}
    const who=m.author_type||'';
    out+=msgBubble(m,who===prevWho);prevWho=who});
  return out}

/* ==========================================================================
   ГОЛОСОВОЕ СООБЩЕНИЕ

   Нативный <audio controls> в Safari показывал «00:00 / 00:00», а на
   записях с известной длительностью — «-00:03»: он считает оставшееся
   время и пишет его со знаком минус. Ни то, ни другое человеку ничего
   не говорит, поэтому рисуем свой плеер: кнопка, полоса и одно число —
   сколько длится запись, а во время игры — сколько уже прошло.

   Отдельная беда — длительность. Запись из браузера приходит потоком
   без неё в заголовке, и duration оказывается Infinity. Лечится
   известным приёмом: перемотать в заведомо недостижимый конец, дождаться
   события durationchange и вернуться в начало. Делаем это один раз при
   первом обращении, а не при отрисовке: иначе каждое открытие чата
   тянуло бы все записи разом.
   ========================================================================== */
/* ==========================================================================
   ЗАПИСЬ ГОЛОСОВОГО
   Сервер принимал голосовые с самого начала: в разрешённых типах стоят
   m4a, mp3 и aac, есть и отдельная проверка на пустой контейнер. А
   записывать их в вебе было нечем — приложить можно было только готовый
   файл через скрепку.

   Формат берём тот, что умеет браузер: Safari пишет только audio/mp4,
   Chrome и Firefox — webm с opus. Оба теперь принимает сервер.

   Нажатие начинает запись, второе отправляет. Удержание пальцем
   надёжно работает не везде: палец соскальзывает, и реплика обрывается
   на полуслове.
   ========================================================================== */
const REC={mr:null,chunks:[],t0:0,timer:null,stream:null,kind:null,id:null,busy:false};
function recSupported(){
  return !!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia&&window.MediaRecorder);
}
function recMime(){
  const want=['audio/mp4','audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'];
  for(const m of want)
    if(!MediaRecorder.isTypeSupported||MediaRecorder.isTypeSupported(m))return m;
  return '';
}
function recExt(mime){
  if(mime.indexOf('mp4')>=0)return 'm4a';
  if(mime.indexOf('ogg')>=0)return 'ogg';
  return 'webm';
}
/* Строка «идёт запись» встаёт на место поля ввода, а справа — две
   кнопки, из которых видна ровно одна: микрофон, пока не набран текст,
   и самолётик, как только он появился. */
function recBar(){
  return `<div class="rec-live" id="recLive" hidden><i></i><b id="recTime">0:00</b>
    <button type="button" class="rec-cancel" onclick="voiceRecCancel()">Отмена</button></div>`;
}
function recBtns(kind,id){
  const mic=recSupported()
    ? `<button type="button" class="chat-mic" id="chatMic" aria-label="Записать голосовое"
        onclick="voiceRecToggle('${kind}',${id||'null'})">${icon('mic')}</button>`
    : '';
  return mic+`<button class="primary send" id="chatSend" aria-label="Отправить"${mic?' hidden':''}>${icon('send')}</button>`;
}
function chatTyping(){
  const inp=$('#ci'),mic=$('#chatMic'),send=$('#chatSend');
  if(!inp||!mic||!send||REC.mr)return;
  const has=!!inp.value.trim();
  mic.hidden=has;send.hidden=!has;
}
function recFmt(s){const m=Math.floor(s/60);return m+':'+String(Math.floor(s%60)).padStart(2,'0')}
function recTick(){
  const el=$('#recTime');if(el)el.textContent=recFmt((Date.now()-REC.t0)/1000);
  /* Три минуты — предел: дальше это уже не реплика в переписке, а файл,
     и его лучше приложить скрепкой. */
  if(Date.now()-REC.t0>180000)voiceRecToggle(REC.kind,REC.id);
}
function recPaint(on){
  const inp=$('#ci'),att=$('.chatform .chat-attach'),live=$('#recLive'),
        mic=$('#chatMic'),send=$('#chatSend');
  const has=!!(inp&&inp.value.trim());
  if(inp)inp.hidden=on;
  if(att)att.hidden=on;
  if(live)live.hidden=!on;
  if(send)send.hidden=on?true:!has;
  if(mic){
    mic.hidden=on?false:has;
    mic.classList.toggle('recording',on);
    mic.setAttribute('aria-label',on?'Отправить голосовое':'Записать голосовое');
  }
}
async function voiceRecToggle(kind,id){
  if(REC.busy)return;
  if(REC.mr){REC.mr._send=true;recStop();return}
  if(!recSupported()){toast('Браузер не умеет записывать звук','err');return}
  REC.busy=true;
  try{
    REC.stream=await navigator.mediaDevices.getUserMedia({audio:true});
  }catch(e){
    REC.busy=false;
    toast('Нет доступа к микрофону. Разрешите его в настройках браузера.','err');
    return;
  }
  const mime=recMime();
  try{
    REC.mr=mime?new MediaRecorder(REC.stream,{mimeType:mime}):new MediaRecorder(REC.stream);
  }catch(e){
    recRelease();REC.busy=false;toast('Не удалось начать запись','err');return;
  }
  REC.chunks=[];REC.kind=kind;REC.id=id||null;REC.t0=Date.now();
  REC.mr.ondataavailable=e=>{if(e.data&&e.data.size)REC.chunks.push(e.data)};
  REC.mr.onstop=()=>{
    const send=!!(REC.mr&&REC.mr._send);
    const type=(REC.mr&&REC.mr.mimeType)||mime||'audio/webm';
    const blob=new Blob(REC.chunks,{type});
    const kindWas=REC.kind,idWas=REC.id;
    REC.mr=null;REC.chunks=[];recRelease();
    clearInterval(REC.timer);REC.timer=null;
    recPaint(false);
    if(!send)return;
    /* Тот же порог, что на сервере: контейнер без звука весит сотни
       байт и висит в переписке немым кружком. */
    if(blob.size<1024){toast('Запись слишком короткая','err');return}
    voiceSend(blob,recExt(type),kindWas,idWas);
  };
  REC.mr.start();
  REC.timer=setInterval(recTick,200);
  recPaint(true);
  const el=$('#recTime');if(el)el.textContent='0:00';
  REC.busy=false;
}
function recStop(){try{if(REC.mr&&REC.mr.state!=='inactive')REC.mr.stop()}catch(e){}}
function recRelease(){if(REC.stream){REC.stream.getTracks().forEach(t=>{try{t.stop()}catch(e){}});REC.stream=null}}
function voiceRecCancel(){if(!REC.mr)return;REC.mr._send=false;recStop()}
async function voiceSend(blob,ext,kind,id){
  const f=new File([blob],'voice.'+ext,{type:blob.type});
  const fd=new FormData();fd.append('file',f);fd.append('voice','1');
  try{
    if(kind==='specialist'){
      const j=await api('/specialist/attachment',{method:'POST',body:fd});
      await api('/specialist/messages',{method:'POST',
        body:JSON.stringify({client_id:id,attachment_url:j.url})});
      spOpenThread(id);
    }else{
      const j=await api('/client/attachment',{method:'POST',body:fd});
      await api('/client/messages',{method:'POST',
        body:JSON.stringify({attachment_url:j.url})});
      clChat();
    }
  }catch(e){toast(e.message||'Не удалось отправить голосовое','err')}
}

const VOICE={cur:null,id:0};
/* Столбики дорожки. Настоящую громкость пришлось бы считать, скачав
   запись целиком, — ради полоски это лишний трафик. Рисуем ровный,
   но не одинаковый профиль: высоты выводим из адреса записи, поэтому
   у каждой он свой и не меняется при перерисовке. */
function voiceBars(u,n=34){
  let h=0;for(let i=0;i<u.length;i++)h=(h*31+u.charCodeAt(i))>>>0;
  const out=[];
  for(let i=0;i<n;i++){
    h=(h*1103515245+12345)>>>0;
    const k=(h>>>16)%100/100;
    /* К краям тише — так дорожка читается как речь, а не как забор. */
    const edge=Math.min(1,Math.min(i,n-1-i)/4+0.35);
    out.push(Math.round((26+k*74)*edge));
  }
  return out;
}
function voicePlayer(u){
  const id='v'+(++VOICE.id);
  const bars=voiceBars(u).map(h=>`<i style="height:${h}%"></i>`).join('');
  return `<div class="voice" id="${id}" data-src="${u}">
    <button class="voice-btn" aria-label="Слушать" onclick="voiceToggle('${id}')">${icon('play')}</button>
    <span class="voice-wave" onclick="voiceSeek('${id}',event)">${bars}</span>
    <b class="voice-time num">··</b></div>`;
}
function voiceFmt(s){
  if(!isFinite(s)||s<0)return '··';
  const m=Math.floor(s/60),x=Math.floor(s%60);
  return m+':'+String(x).padStart(2,'0');
}
/* Длительность у потоковой записи приходит только после перемотки
   в конец — иначе Infinity. */
function voiceMeasure(a){
  return new Promise(res=>{
    if(isFinite(a.duration)&&a.duration>0)return res(a.duration);
    const done=()=>{if(isFinite(a.duration)&&a.duration>0){
      a.removeEventListener('durationchange',done);
      try{a.currentTime=0}catch(e){}
      res(a.duration)}};
    a.addEventListener('durationchange',done);
    try{a.currentTime=1e101}catch(e){}
    setTimeout(()=>res(a.duration),1200);
  });
}
function voiceEl(id){return document.getElementById(id)}
async function voiceToggle(id){
  const box=voiceEl(id);if(!box)return;
  /* Играет всегда одна запись: два голоса разом — это не «две дорожки»,
     а каша, и остановить их человек уже не успевает. */
  if(VOICE.cur&&VOICE.cur.box!==box)voiceStop();
  if(box._a&&!box._a.paused){box._a.pause();voicePaint(box);return}
  let a=box._a;
  if(!a){
    a=box._a=new Audio(box.dataset.src);
    a.preload='metadata';
    a.addEventListener('timeupdate',()=>voicePaint(box));
    a.addEventListener('ended',()=>{a.currentTime=0;voicePaint(box);voiceRelease(box)});
    a.addEventListener('pause',()=>{voicePaint(box);voiceRelease(box)});
    await voiceMeasure(a);
    if(isFinite(a.duration)&&a.duration>0)box.dataset.dur=String(a.duration);
    voicePaint(box);
  }
  VOICE.cur={box};
  try{await a.play()}catch(e){toast('Не удалось воспроизвести','err')}
  voicePaint(box);
}
function voiceStop(){
  const c=VOICE.cur;if(!c)return;
  if(c.box&&c.box._a)c.box._a.pause();
  voiceRelease(c.box);
  VOICE.cur=null;
}
/* Пока на странице есть звучавший <audio>, iOS держит карточку «сейчас
   играет» на экране блокировки и в пункте управления — она не уходила,
   пока не закроешь приложение. Освобождаем сессию, как только запись
   доиграла или её поставили на паузу: снимаем источник и гасим
   метаданные. Сам плеер при этом остаётся на месте — при следующем
   нажатии он создаётся заново. */
function voiceRelease(box){
  if(!box||!box._a)return;
  const a=box._a;
  if(!a.paused)return;
  /* Небольшая пауза: если человек просто перематывает, звук продолжится
     и рвать источник нельзя. */
  clearTimeout(box._rel);
  box._rel=setTimeout(()=>{
    if(!box._a||!box._a.paused)return;
    try{box._a.removeAttribute('src');box._a.load()}catch(e){}
    box._a=null;
    if(VOICE.cur&&VOICE.cur.box===box)VOICE.cur=null;
    voicePaint(box);
    const ms=navigator.mediaSession;
    if(ms){try{ms.metadata=null;ms.playbackState='none'}catch(e){}}
  },400);
}
/* Прослушанная часть дорожки закрашивается — видно, докуда дошло. */
function voiceWavePaint(box,p){
  const w=box.querySelector('.voice-wave');if(!w)return;
  const bars=w.children,n=bars.length,k=Math.round(p*n);
  for(let i=0;i<n;i++)bars[i].classList.toggle('on',i<k);
}
function voiceSeek(id,ev){
  const box=voiceEl(id);if(!box||!box._a||!isFinite(box._a.duration))return;
  const t=box.querySelector('.voice-wave')||box.querySelector('.voice-track');if(!t)return;
  const r=t.getBoundingClientRect();
  const p=Math.max(0,Math.min(1,(ev.clientX-r.left)/r.width));
  box._a.currentTime=p*box._a.duration;
  voicePaint(box);
}
function voicePaint(box){
  const a=box._a,btn=box.querySelector('.voice-btn'),
        fill=box.querySelector('.voice-track i'),time=box.querySelector('.voice-time');
  const playing=a&&!a.paused&&!a.ended;
  if(btn)btn.innerHTML=icon(playing?'pause':'play');
  /* Источник освобождён после прослушивания — показываем длительность
     из памяти, а не «··»: запись никуда не делась. */
  if(!a){
    if(fill)fill.style.transform='scaleX(0)';
    voiceWavePaint(box,0);
    if(time)time.textContent=+box.dataset.dur>0?voiceFmt(+box.dataset.dur):'··';
    return;
  }
  const d=isFinite(a.duration)&&a.duration>0?a.duration:0;
  const p=d?Math.min(1,a.currentTime/d):0;
  if(fill)fill.style.transform='scaleX('+p+')';
  voiceWavePaint(box,p);
  /* Пока не играет — показываем длительность записи, а во время игры —
     сколько прошло. Отрицательного времени не бывает. */
  if(time)time.textContent=playing||a.currentTime>0?voiceFmt(a.currentTime):voiceFmt(d);
}

function msgBubble(m,cont){
  const t=(m.created_at||'').slice(11,16);
  if((m.kind||'')==='call'){
    const missed=/Пропущенный|отклон/i.test(m.body||'');
    return `<div class="bub call ${(m.author_type===A.type||m.author_type==='me')?'me':'them'}">
      <span class="cb-ic ${missed?'miss':''}">${icon(missed?'phoneoff':'video')}</span>
      <span class="bub-text">${esc(m.body||'Звонок')}</span><small>${t}</small></div>`;
  }
  let att='';
  if(m.attachment_url){const u=esc(m.attachment_url);
    /* Голосовые и видео показываем плеером, а не ссылкой «открыть файл»:
       вложение из приложения — это сообщение, слушать его надо на месте. */
    att=/\.(png|jpe?g|gif|webp|avif|heic)$/i.test(m.attachment_url)
      ?`<button class="bub-img" onclick="showViewer('${u}','Вложение')"><img src="${u}" alt="вложение"></button>`
      :/\.(mp4|mov|m4v)$/i.test(m.attachment_url)
      ?`<video class="bub-video" src="${u}" controls preload="metadata"></video>`
      :/\.(m4a|mp3|aac|wav|ogg|opus|webm)$/i.test(m.attachment_url)
      ?voicePlayer(u)
      :`<a class="bub-file" href="${u}" target="_blank" rel="noopener">${icon('doc')}<span>Открыть файл</span></a>`}
  const mine=(m.author_type===A.type||m.author_type==='me');
  return `<div class="bub ${mine?'me':'them'}${cont?' cont':''}">${att}${m.body?`<span class="bub-text">${esc(m.body)}</span>`:''}<small>${t}</small></div>`;
}


/* ==========================================================================
   ЖИВОЙ ЧАТ

   Раньше каждая отправка вызывала перерисовку всего экрана: чат прыгал
   наверх, список мигал, и это читалось как зависание. Новые сообщения
   при этом не приходили вовсе — только по перезагрузке страницы.

   Теперь переписка живёт на месте: своё сообщение появляется сразу,
   чужие догружаются по одному, а экран не трогается целиком.
   ========================================================================== */
const CHAT={timer:null,lastId:0,box:null,fetchNew:null,atBottom:true,busy:false};

/** Снять опрос: вкладку закрыли, ушли на другой экран, разлогинились. */
function chatStop(){
  if(CHAT.timer){clearInterval(CHAT.timer);CHAT.timer=null}
  CHAT.box=null;CHAT.fetchNew=null;
}

/** Внизу ли человек. Если он отлистал вверх читать старое — не дёргаем. */
function chatAtBottom(box){
  return box.scrollHeight-box.scrollTop-box.clientHeight<70;
}
function chatToBottom(smooth){
  const b=CHAT.box;if(!b)return;
  b.scrollTo({top:b.scrollHeight,behavior:smooth?'smooth':'auto'});
  CHAT.atBottom=true;
  const n=$('#chatNew');if(n)n.hidden=true;
}

/**
 * Привязать живой чат к открытой переписке.
 * @param box      контейнер сообщений
 * @param msgs     то, что уже отрисовано — из него берём последний номер
 * @param fetchNew (afterId) => Promise<массив сообщений>
 */
function chatStart(box,msgs,fetchNew){
  chatStop();
  if(!box)return;
  CHAT.box=box;CHAT.fetchNew=fetchNew;CHAT.atBottom=true;
  CHAT.lastId=(msgs||[]).reduce((m,x)=>Math.max(m,+x.id||0),0);
  box.addEventListener('scroll',()=>{CHAT.atBottom=chatAtBottom(box)});
  /* Переписка открывается на последнем сообщении, а не на середине.
     Одного вызова мало: снимки и голосовые в этот момент ещё не
     загружены, лента после них подрастает, и прокрутка остаётся выше
     конца. Досылаем её, когда доедет каждое вложение. */
  box.addEventListener('load',()=>{if(CHAT.atBottom)chatToBottom()},true);
  chatToBottom();
  requestAnimationFrame(()=>chatToBottom());
  [60,200,500,1200].forEach(ms=>setTimeout(()=>{if(CHAT.atBottom)chatToBottom()},ms));
  /* Три секунды — компромисс: переписка выглядит живой, а запрос раз в
     три секунды не сажает батарею. В свёрнутой вкладке не опрашиваем
     вовсе. */
  CHAT.timer=setInterval(chatTick,3000);
}

async function chatTick(){
  const box=CHAT.box;
  /* Экран сменили — узел уже не в документе, опрос пора снимать. */
  if(!box||!box.isConnected){chatStop();return}
  if(document.hidden||CHAT.busy)return;
  CHAT.busy=true;
  try{
    const rows=await CHAT.fetchNew(CHAT.lastId);
    if(rows&&rows.length)chatAppend(rows);
  }catch(e){ /* сеть моргнула — попробуем на следующем круге */ }
  finally{CHAT.busy=false}
}

/** Дописать сообщения в конец, не трогая остальное. */
function chatAppend(rows){
  const box=CHAT.box;if(!box)return;
  /* Своё сообщение приходит дважды: сразу из ответа на отправку и потом
     опросом, если тот успел уйти с прежним номером. Пропускаем всё, что
     не новее уже показанного — иначе строка задваивается. */
  rows=(rows||[]).filter(m=>+m.id>CHAT.lastId);
  if(!rows.length)return;
  const stick=CHAT.atBottom;
  /* Пустое состояние убираем, как только появилось первое сообщение. */
  const empty=box.querySelector('.muted.small');if(empty)empty.remove();
  box.insertAdjacentHTML('beforeend',rows.map(msgBubble).join(''));
  rows.forEach(m=>{if(+m.id>CHAT.lastId)CHAT.lastId=+m.id});
  if(stick){
    chatToBottom(true);
    /* Пришло вложение — его высота появится только после загрузки. */
    [80,300,900].forEach(ms=>setTimeout(()=>{if(CHAT.atBottom)chatToBottom()},ms));
  }
  else{
    /* Человек читает выше — не вырываем у него страницу из рук, а
       показываем, что внизу появилось новое. */
    const n=$('#chatNew');if(n)n.hidden=false;
  }
}

/** Кнопка «новые сообщения» — появляется, только когда есть что показать. */
function chatNewBtn(){
  return `<button id="chatNew" class="chat-new" hidden onclick="chatToBottom(true)">
    ${icon('chevd')} Новые сообщения</button>`;
}

/* Чат клиента — добавлена кнопка звонка в шапку */
async function clChat(){
  const j=await api('/client/messages');
  /* Шапка как в мессенджере: закрыть, с кем говоришь, был ли на связи,
     звонок. Панель вкладок на этом экране убрана — выход отсюда даёт
     крестик, иначе переписка теснится между двумя полосами. */
  const peer=j.peer||{};
  const pname=peer.name||A.chatSpec||'Специалист';
  const psub=peer.last_seen_at?seenPhrase(peer.last_seen_at):'Ваш специалист';
  go(clShell(`<div class="chat-top"><button class="chat-close" aria-label="Закрыть переписку" onclick="clToday()">${icon('x')}</button>${av(pname,'',peer.avatar_url)}<div class="ct-id"><strong>${esc(pname)}</strong><span>${esc(psub)}</span></div>${callBtn()}</div>
  <div class="chat-single"><div id="messages" class="messages">${j.messages.map(msgBubble).join('')||'<div class="muted small" style="margin:auto">Напишите первое сообщение</div>'}</div>
  ${chatNewBtn()}
  <form class="chatform" onsubmit="clSend(event)"><button type="button" class="chat-attach" title="Прикрепить файл" onclick="this.nextElementSibling.click()">${icon('clip')}</button><input type="file" accept="image/*,video/mp4,video/quicktime,audio/*" hidden onchange="clAttach(this)"><input id="ci" placeholder="Сообщение…" oninput="chatTyping()">${recBar()}${recBtns('client')}</form></div>`,'chat'));
  chatStart($('#messages'),j.messages,
    after=>api('/client/messages?after_id='+after).then(r=>r.messages||[]));
}
/* Диалог специалиста — кнопка звонка рядом с «Профиль» */
async function spOpenThread(id){
  A._openThread=id;
  const c=(A.clientsCache||[]).find(x=>x.id===id)||{id};
  /* Открытие ветки помечает сообщения прочитанными на сервере — значок
     должен упасть сразу, а не после перезагрузки страницы. */
  if(c.unread){setUnread((A.unread||0)-c.unread);c.unread=0;}
  const t=$('#msgrThread');
  if(t)t.innerHTML=`<div class="thread-head"><button class="thread-back" aria-label="Назад к списку" onclick="spBackToList()">${icon('chevr')}</button>${av(c.name,'',c.avatar_url)}<div class="th-id"><strong>${esc(c.name||'Клиент')}</strong><span>${esc(c.goal||'Клиент')}</span></div>${callBtn(id)}<button class="thread-open" onclick="spClient(${id})">Профиль</button></div><div id="messages" class="messages"><div class="muted small" style="margin:auto">Загрузка…</div></div><form class="chatform" onsubmit="spSendThread(event,${id})"><button type="button" class="chat-attach" title="Прикрепить файл" onclick="this.nextElementSibling.click()">${icon('clip')}</button><input type="file" accept="image/*,.pdf" hidden onchange="spThreadAttach(this,${id})"><input id="ci" placeholder="Сообщение…" autocomplete="off" oninput="chatTyping()">${recBar()}${recBtns('specialist',id)}</form>`;
  $('#msgr')?.classList.add('show-thread');
  spRenderInbox($('#chq')?.value||'');
  let msgs=[];try{msgs=(await api('/specialist/messages?client_id='+id)).messages}catch(e){}
  const mbox=$('#messages');
  if(mbox&&A._openThread===id){
    mbox.innerHTML=msgList(msgs)||'<div class="muted small" style="margin:auto">Начните переписку — сообщения появятся здесь</div>';
    chatStart(mbox,msgs,
      after=>api('/specialist/messages?client_id='+id+'&after_id='+after).then(r=>r.messages||[]));
  }
  $('#ci')?.focus();
}
/* Вкладка «Чат» в карточке клиента */
async function spTabChat(){
  const j=await api('/specialist/messages?client_id='+A.client.id);
  $('#tabbody').innerHTML=`<div class="chat-single card"><div class="tab-chat-head">${callBtn(A.client.id)}</div><div id="messages" class="messages">${j.messages.map(msgBubble).join('')||'<div class="muted small" style="margin:auto">Начните переписку</div>'}</div>${chatNewBtn()}<form class="chatform" onsubmit="spSendChat(event)"><input id="ci" placeholder="Сообщение…"><button class="primary send" aria-label="Отправить">${icon('send')}</button></form></div>`;
  const cid=A.client.id;
  chatStart($('#messages'),j.messages,
    after=>api('/specialist/messages?client_id='+cid+'&after_id='+after).then(r=>r.messages||[]));
}

/* ==========================================================================
   СПИСОК ПОКУПОК: отметки в аккаунте, а не в localStorage
   Раньше «куплено» жило в localStorage: терялось при смене устройства
   и было не видно специалисту. Теперь состояние в БД, а нажатие не
   перерисовывает экран — меняется только строка и полоса прогресса.
   ========================================================================== */
function shopProgress(items){
  const total=items.length,done=items.filter(x=>x.checked).length;
  return `<div class="grow"><b>${done} из ${total} куплено</b>
    <div class="shop-track"><i style="width:${total?done/total*100:0}%"></i></div></div>
    ${done?`<button class="textbtn" onclick="clShopClear()">Сбросить</button>`:''}`;
}
async function clShopping(){
  const j=await api('/client/shopping');
  if(!j.menu)return clToday();
  const items=j.items||[];items.forEach((it,i)=>it._i=i);
  const pantry=j.pantry||[];
  A._shopItems=items;A._shopPantry=pantry;
  const cats={};items.forEach(it=>{(cats[it.category]=cats[it.category]||[]).push(it)});
  /* Строка списка: количество — уже в покупаемых единицах, «12 штук»
     вместо «667 г». Долгое нажатие убирает продукт в кладовку. */
  const row=it=>`<button class="shop-row ${it.checked?'done':''}" data-i="${it._i}"
      onclick="clShopToggle(${it._i})">
      <span class="shop-check">${icon('check')}</span>
      <span class="grow">${esc(it.name)}</span>
      <b class="num">${esc(it.amount?it.amount.text:it.grams+' г')}</b>
      <span class="shop-home" onclick="event.stopPropagation();clShopPantry('${esc(it.name).replace(/'/g,"\\'")}',1)" title="Уже есть дома">${icon('home')}</span>
    </button>`;
  go(clShell(`${clHead('Список покупок','',"clWeek()")}
  <div class="shop-progress card" id="shopProg">${shopProgress(items)}</div>
  ${Object.entries(cats).map(([cat,list])=>`<div class="shop-cat"><div class="shop-cat-h">${esc(cat)}</div>${
    list.map(row).join('')}</div>`).join('')}
  ${pantry.length?`<div class="shop-cat pantry"><div class="shop-cat-h">Уже есть дома</div>${
    pantry.map(it=>`<div class="shop-row home">
      <span class="grow">${esc(it.name)}</span>
      <b class="num muted">${esc(it.amount?it.amount.text:it.grams+' г')}</b>
      <button class="linkbtn" onclick="clShopPantry('${esc(it.name).replace(/'/g,"\\'")}',0)">Вернуть</button>
    </div>`).join('')}</div>`:''}
  <p class="rw-foot muted">Количество рассчитано на всё меню. Продукты, которые всегда есть дома, уберите значком домика — они перестанут появляться в списке.</p>`,'cal'));
}
/* Кладовка: соль и масло попадают в список каждую неделю и каждую
   неделю в нём не нужны. Совсем убирать их нельзя — иногда они как раз
   заканчиваются, поэтому лежат отдельным списком, а не пропадают. */
async function clShopPantry(name,add){
  try{await api('/client/shopping/pantry',{method:'POST',
    body:JSON.stringify(add?{name}:{name,remove:true})});clShopping()}
  catch(e){callToast('Не удалось сохранить')}
}
async function clShopToggle(i){
  const items=A._shopItems||[],it=items[i];
  if(!it)return;
  const next=it.checked?0:1;
  const paint=()=>{const row=document.querySelector('.shop-row[data-i="'+i+'"]');
    if(row)row.classList.toggle('done',!!it.checked);
    const p=$('#shopProg');if(p)p.innerHTML=shopProgress(items)};
  it.checked=next;paint();
  try{await api('/client/shopping/check',{method:'POST',body:JSON.stringify({name:it.name,checked:next})})}
  catch(e){it.checked=next?0:1;paint();callToast('Не удалось сохранить отметку')}
}
async function clShopClear(){
  try{await api('/client/shopping/clear',{method:'POST'})}
  catch(e){return callToast('Не удалось сбросить список')}
  clShopping();
}

/* ==========================================================================
   ПАНЕЛЬ ВЛАДЕЛЬЦА: настройка push без SSH
   tools/setup-push.php закрыт .htaccess, а на шаред-хостинге SSH может не
   быть вовсе. Поэтому ключи создаются здесь, кнопкой.
   ========================================================================== */
function adPushCard(p){
  if(!p)return '';
  const ok=p.configured&&p.library;
  const problem=p.openssl?`Ключи создать нечем: ${esc(p.openssl)}. Обратитесь в поддержку хостинга.`
    :!p.writable?'Папка <b>storage</b> недоступна для записи. Поставьте на неё права 775.'
    :!p.library?'Нет папки <b>vendor</b> — ключи создать можно, но отправлять уведомления пока нечем. Загрузите её на хостинг вместе с остальными файлами.'
    :!p.configured?'Ключи VAPID ещё не созданы — без них уведомления не отправляются.':'';
  return `<div class="meal-sec"><div class="meal-head"><b>Уведомления</b><small>push на телефоны</small></div>
    <div class="meal-group">
      <div class="hist-row"><span class="hr-date">Библиотека</span><b class="num ${p.library?'':'over'}">${p.library?'установлена':'нет'}</b><span class="hr-d"></span></div>
      <div class="hist-row"><span class="hr-date">Ключи VAPID</span><b class="num ${p.configured?'':'over'}">${p.configured?esc(p.public_key):'не созданы'}</b><span class="hr-d"></span></div>
      <div class="hist-row"><span class="hr-date">Подписок</span><b class="num">${p.subscriptions}</b><span class="hr-d"></span></div>
    </div></div>
    ${problem?`<div class="ad-note">${icon('warn')}<p>${problem}</p></div>`:''}
    ${p.writable&&!p.openssl?`<button class="btn-wide ${ok?'quiet':''}" onclick="adPushSetup(${p.configured?1:0})">${icon('bell')} ${ok?'Пересоздать ключи':'Настроить push'}</button>`:''}
    ${ok?`<p class="rw-foot muted">Ключи есть. Осталось добавить в cron хостинга строку запуска <b>cron/push.php</b> раз в минуту — без неё запланированные напоминания не уходят. Уведомление о пропущенном звонке работает и без cron.</p>`:''}`;
}
async function adPushSetup(exists){
  if(exists&&!confirm('Пересоздать ключи? Все, кто уже включил уведомления, отпишутся и должны будут включить их заново.'))return;
  try{
    const r=await api('/admin/push/setup',{method:'POST',body:JSON.stringify(exists?{force:1}:{})});
    toast('Push настроен ✓\nКлюч: '+r.public_key+'\n\nТеперь в приложении можно включить уведомления в разделе «Ещё».','ok');
  }catch(e){toast(e.message,'err')}
  adMailing();
}
/* «Ещё» — только оглавление, и только на телефоне: в нижнюю панель
   помещается пять кнопок, а разделов семь. На компьютере эти три стоят
   в боковой колонке, и заходить сюда незачем. */
function adMore(){
  const row=(key,note)=>{
    const [ic,label,fn]=AD_SECTIONS[key];
    return `<button class="feed-new" onclick="${fn}"><span class="fn-ic">${icon(ic)}</span>`
      +`<span class="grow"><strong>${label}</strong><small>${esc(note)}</small></span>${icon('chevr')}</button>`;
  };
  const notes={coin:'Выводы, споры, комиссия и тарифы',
    send:'Написать всем и настройка уведомлений',
    cog:'Сотрудники, журнал, каталог и копии базы'};
  go(adShell(`${adHead('Ещё','Остальные разделы панели')}
  ${AD_DEEP.filter(adCan).map(k=>row(k,notes[k])).join('')}`,'cog'));
}

/* --- Аналитика ---
   «Сколько всего клиентов» не отвечает на вопрос, работает ли сервис:
   регистрация ничего не стоит, и половина людей уходит молча. Отвечают
   две вещи: сколько вернулось через неделю и где именно человек
   остановился — не взял специалиста, не получил меню или получил, но ни
   разу не отметился. Считаем на сервере, чтобы экран и письмо с итогами
   недели никогда не показывали разные цифры. */
async function adAnalytics(){
  let j=null;
  try{ j=await api('/admin/analytics?days=30') }catch(e){ toast(e.message,'err'); return }
  A._an=j;
  const r=j.retention||{}, f=j.funnel||{steps:[]}, w=j.week||{};
  const pair=(t,p)=>{
    const d=(p.now||0)-(p.prev||0);
    const sign=d>0?'+':(d<0?'−':'');
    return `<div class="wtile"><div class="wt-lbl">${esc(t)}</div>
      <div class="wt-big num">${p.now||0}</div>
      <div class="wt-foot num ${d>0?'up':(d<0?'down':'')}">${sign}${Math.abs(d)} к прошлой неделе</div></div>`;
  };
  const keep=(t,x)=>`<div class="wtile"><div class="wt-lbl">${esc(t)}</div>
    <div class="wt-big num">${x.percent||0} %</div>
    <div class="wt-foot num">${x.kept||0} из ${x.cohort||0}</div></div>`;
  const max=(f.steps[0]||{}).n||1;
  go(adShell(`${adHead('Аналитика','Удержание, воронка и неделя против предыдущей')}
  <div class="ad-page-head">
    <div class="grow"><button class="ad-crumbs" onclick="adOverview()">${icon('back')}<span>Сводка</span></button></div>
  </div>

  ${adPanel('Вернулись и продолжили',null,`<div class="wgrid">
    ${keep('Через неделю',r.d7||{})}
    ${keep('Через месяц',r.d30||{})}
    </div>
    <p class="rw-foot muted">Считаем по отметкам еды: это единственное, что человек делает сам,
      каждый день и без напоминания. В расчёт берём только тех, кто прожил в сервисе нужный срок,
      иначе вчерашние регистрации тянули бы долю вниз, ничего о ней не говоря.</p>`)}

  ${adPanel('Путь клиента за 30 дней',null,`<div class="fn-list">
    ${(f.steps||[]).map((st,i)=>{
      const prev=i?f.steps[i-1].n:st.n;
      const lost=prev-st.n;
      return `<div class="fn-step">
        <div class="fn-top"><b>${esc(st.title)}</b><span class="num">${st.n} · ${st.percent} %</span></div>
        <div class="fn-bar"><i style="width:${Math.round((st.n/max)*100)}%"></i></div>
        ${i&&lost>0?`<small class="muted">не дошли ${lost}</small>`:''}
      </div>`}).join('')}
    </div>
    ${(f.steps||[]).length&&!f.steps[0].n?'<div class="empty small">За 30 дней никто не регистрировался</div>':''}`)}

  ${adPanel('Неделя',null,`<div class="wgrid">
    ${pair('Новых клиентов',w.clients||{})}
    ${pair('Новых специалистов',w.specialists||{})}
    ${pair('Опубликовано меню',w.menus||{})}
    ${pair('Отметок еды',w.logs||{})}
    <div class="wtile"><div class="wt-lbl">Комиссия за неделю</div>
      <div class="wt-big num">${rub(w.commission_kop||0)}</div>
      <div class="wt-foot">с оборота специалистов</div></div>
    </div>
    <button class="btn-wide quiet" onclick="adReports()">Присылать это письмом</button>`)}
  `,'home'));
}

/* --- Приложение ---
   Магазин проверяет новую сборку неделю, иногда дольше. Всё, что нельзя
   ждать неделю, живёт здесь: объявление людям, требование обновиться,
   если в старой версии нашлась настоящая поломка, и выключатель
   незрелой возможности — чтобы не выпускать сборку ради одной кнопки. */
async function adApp(){
  let j={app:{},features:{}};
  try{ j=await api('/admin/app') }catch(e){ toast(e.message,'err'); return }
  A._app=j;
  const a=j.app||{}, F=j.features||{}, fl=a.features||{};
  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adSystem()">${icon('back')}<span>Система</span></button>
        <h1>Приложение</h1>
        <p class="muted small">То, что меняется без новой сборки в магазине</p>
      </div>
    </div>

    <form class="formgrid" onsubmit="adAppSave(event)">
      <label class="full switchrow">
        <input type="checkbox" id="ap_on" ${a.announce_on?'checked':''}>
        <span><b>Показывать объявление</b><small>Полоска вверху экрана «Сегодня»
          у всех, кто откроет приложение. Закрывается человеком и не возвращается,
          пока текст не изменится.</small></span></label>
      <label class="full">Текст объявления
        <textarea id="ap_text" rows="3" maxlength="500"
          placeholder="Например: в субботу с 2 до 4 ночи сервис будет недоступен">${esc(a.announce_text||'')}</textarea></label>
      <label>Как показать<select id="ap_kind">
        <option value="info" ${a.announce_kind!=='warn'?'selected':''}>Обычное</option>
        <option value="warn" ${a.announce_kind==='warn'?'selected':''}>Предупреждение</option>
      </select></label>
      <label>Минимальная версия
        <input id="ap_min" value="${esc(a.min_version||'')}" placeholder="например 1.4.0"></label>
      <label class="full">Ссылка на магазин
        <input id="ap_store" value="${esc(a.store_url||'')}" placeholder="https://apps.apple.com/…"></label>
      <button class="primary green wide full">${icon('save')} Сохранить</button>
    </form>
    <p class="rw-foot muted">Минимальная версия — не способ подгонять людей к обновлению:
      кто её не набрал, увидит вместо приложения экран «обновитесь» и не сможет ничего
      сделать. Поднимать её стоит только тогда, когда старая версия правда сломана.
      Пустое поле — никого не блокируем.</p>

    <div class="ad-table">
      <div class="ad-thead"><b>Telegram</b>
        <small>${a.tg_ready?'бот подключён':'бот не подключён'}</small></div>
      <div class="ad-rows"><div class="ad-tr ${a.tg_ready?'':'off'}">
        <span class="ad-td c0"><b>Мини-приложение в Telegram</b></span>
        <span class="ad-td sub">${a.tg_ready
          ? 'токен '+(a.tg_source==='file'?'в файле config/telegram.php':'сохранён в настройках')
          : 'нужен токен бота от @BotFather'}</span>
        <span class="ad-td c1">${a.tg_bot_name?'@'+esc(a.tg_bot_name):'—'}</span>
        <span class="ad-td c2"></span><span class="ad-td c3"></span><span class="ad-td c4"></span>
        <span class="ad-td c5"><i class="ad-state ${a.tg_ready?'on':'off'}">${
          a.tg_ready?'Работает':'Выключено'}</i></span>
        <span class="ad-td act"><button class="ad-btn ${a.tg_ready?'':'on'}" onclick="adTelegram()">
          ${a.tg_ready?'Изменить':'Подключить'}</button></span>
      </div></div>
    </div>

    <div class="ad-table">
      <div class="ad-thead"><b>Возможности</b><small>${Object.keys(F).length}</small></div>
      <div class="ad-rows">${Object.entries(F).map(([k,v])=>`<div class="ad-tr ${fl[k]?'':'off'}">
        <span class="ad-td c0"><b>${esc(v.title)}</b></span>
        <span class="ad-td sub">${esc(v.about)}</span>
        <span class="ad-td c1">${esc(v.about)}</span>
        <span class="ad-td c2"></span><span class="ad-td c3"></span><span class="ad-td c4"></span>
        <span class="ad-td c5"><i class="ad-state ${fl[k]?'on':'off'}">${fl[k]?'Включена':'Выключена'}</i></span>
        <span class="ad-td act"><button class="ad-btn ${fl[k]?'':'on'}" onclick="adAppFeature('${k}',${fl[k]?0:1})">
          ${fl[k]?'Выключить':'Включить'}</button></span>
      </div>`).join('')}</div>
    </div>
    <p class="rw-foot muted">Выключенная возможность исчезает из приложения при следующем запуске:
      кнопка не прячется на полпути, а не появляется вовсе.</p>`,'cog'));
}
async function adAppSave(e){
  e.preventDefault();
  try{
    await api('/admin/app',{method:'POST',body:JSON.stringify({
      announce_on:$('#ap_on').checked, announce_text:$('#ap_text').value,
      announce_kind:$('#ap_kind').value, min_version:$('#ap_min').value,
      store_url:$('#ap_store').value})});
    toast('Сохранено','ok'); adApp();
  }catch(x){ toast(x.message,'err') }
}
/* --- Подключение бота ---
   Токен бота — это право писать от имени бота всем, кто когда-либо ему
   написал. Поэтому наружу мы его не отдаём даже владельцу: показываем
   только, задан он или нет. Правится он целиком, одной вставкой. */
function adTelegram(){
  const a=(A._app&&A._app.app)||{};
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Telegram</div>
      <h2>Мини-приложение</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form onsubmit="adTelegramSave(event)">
      <label class="full">Токен бота
        <input id="tg_token" placeholder="${a.tg_ready?'Задан — вставьте новый, чтобы заменить':'123456789:AA...'}"
          autocomplete="off" spellcheck="false"></label>
      <label class="full">Имя бота
        <input id="tg_name" value="${esc(a.tg_bot_name||'')}" placeholder="equa_bot"></label>
      <button class="primary green wide full">${icon('save')} Сохранить</button>
    </form>
    ${a.tg_ready&&a.tg_source==='settings'
      ? `<button class="btn-wide danger-btn" onclick="adTelegramClear()">Отключить бота</button>`:''}
    ${a.tg_source==='file'
      ? `<p class="rw-foot muted">Сейчас работает токен из файла <b>config/telegram.php</b>.
          Файл важнее этой формы: пока он на месте, введённое здесь не применится.</p>`
      : `<p class="rw-foot muted">Токен даёт @BotFather: команда <b>/newbot</b>, потом
          <b>/newapp</b> для мини-приложения. Адрес приложения —
          <b>${esc(location.origin)}/app/</b>. Он должен открываться по https:
          по http Telegram мини-приложение не запустит.</p>`}`);
}
async function adTelegramSave(e){
  e.preventDefault();
  const body={tg_bot_name:$('#tg_name').value};
  const t=$('#tg_token').value.trim();
  if(t)body.tg_bot_token=t;
  try{ await api('/admin/app',{method:'POST',body:JSON.stringify(body)});
    closeModal(); toast('Сохранено','ok'); adApp(); }
  catch(x){ toast(x.message,'err') }
}
async function adTelegramClear(){
  if(!confirm('Отключить бота?\nМини-приложение перестанет пускать людей по Telegram.'))return;
  try{ await api('/admin/app',{method:'POST',body:JSON.stringify({tg_clear:1})});
    closeModal(); toast('Бот отключён','ok'); adApp(); }
  catch(x){ toast(x.message,'err') }
}

async function adAppFeature(key,on){
  if(!on&&!confirm('Выключить эту возможность?\nОна исчезнет у всех при следующем запуске приложения.'))return;
  try{
    await api('/admin/app',{method:'POST',body:JSON.stringify({features:{[key]:!!on}})});
    toast(on?'Включено':'Выключено','ok'); adApp();
  }catch(x){ toast(x.message,'err') }
}

/* --- Входы и безопасность ---
   Пароль от панели вводят с чужого ноутбука и забывают выйти; узнать об
   этом до сих пор было неоткуда. Здесь видно каждый живой вход — когда
   начался, с чего и когда им пользовались в последний раз — и любой,
   кроме своего, закрывается одной кнопкой. Свой не закрывается нарочно:
   человек нажал бы её первой и вылетел, не поняв почему. */
async function adSessions(){
  let j={sessions:[]};
  try{ j=await api('/admin/sessions') }catch(e){ toast(e.message,'err'); return }
  A._sess=j;
  const rows=j.sessions||[];
  const others=rows.filter(x=>!x.current).length;
  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adSystem()">${icon('back')}<span>Система</span></button>
        <h1>Входы и безопасность</h1>
        <p class="muted small">Где открыта панель под вашей учётной записью</p>
      </div>
      ${others?`<div class="ad-actions"><button class="ad-btn danger" onclick="adSessionsCloseOthers()">
        Закрыть все, кроме этого</button></div>`:''}
    </div>

    <div class="ad-table">
      <div class="ad-thead"><b>Активные входы</b><small>${rows.length}</small></div>
      <div class="ad-rows">${rows.map(x=>`<div class="ad-tr ${x.current?'':'off'}">
        <span class="ad-td c0"><b>${esc(x.device)}</b>${x.current?' <i class="tag-mini">этот</i>':''}</span>
        <span class="ad-td sub">${esc(x.ip||'адрес неизвестен')} · вход ${esc(agoLabel(x.created_at))}</span>
        <span class="ad-td c1">${esc(x.ip||'—')}</span>
        <span class="ad-td c2">${esc(agoLabel(x.created_at))}</span>
        <span class="ad-td c3">${x.last_seen_at?esc(agoLabel(x.last_seen_at)):'не пользовались'}</span>
        <span class="ad-td c4"></span><span class="ad-td c5"></span>
        <span class="ad-td act">${x.current?'<i class="ad-state on">текущий</i>'
          :`<button class="ad-btn danger" onclick="adSessionClose('${esc(x.id)}')">Закрыть</button>`}</span>
      </div>`).join('')||'<div class="empty small">Активных входов нет</div>'}</div>
    </div>

    <div class="ad-table">
      <div class="ad-thead"><b>Вход по коду</b></div>
      <div class="ad-rows"><div class="ad-tr">
        <span class="ad-td c0"><b>Код на почту при входе</b></span>
        <span class="ad-td sub">${j.twofa?'включён':'выключен'}</span>
        <span class="ad-td c1"></span><span class="ad-td c2"></span>
        <span class="ad-td c3"></span><span class="ad-td c4"></span>
        <span class="ad-td c5"><i class="ad-state ${j.twofa?'on':'off'}">${j.twofa?'Включён':'Выключен'}</i></span>
        <span class="ad-td act"><button class="ad-btn ${j.twofa?'':'on'}" onclick="adTwofa(${j.twofa?0:1})">
          ${j.twofa?'Выключить':'Включить'}</button></span>
      </div></div>
    </div>
    <p class="rw-foot muted">При включённом коде вход в панель идёт в два шага: пароль, затем
      шестизначный код из письма. Он не спасает от подобранного пароля на чужой почте,
      но закрывает главный случай — пароль подсмотрели или он утёк вместе с архивом.
      Включить можно только при настроенной почте: иначе код отправлять некуда.
      Если почта сломается потом, единственный путь назад —
      <b>UPDATE admins SET twofa=0</b> в базе.</p>`,'cog'));
}
async function adSessionClose(id){
  if(!confirm('Закрыть этот вход? На том устройстве панель придётся открывать заново.'))return;
  try{ await api('/admin/sessions/'+id,{method:'DELETE'}); toast('Вход закрыт','ok'); adSessions() }
  catch(e){ toast(e.message,'err') }
}
async function adSessionsCloseOthers(){
  if(!confirm('Закрыть все входы, кроме текущего?'))return;
  try{ const r=await api('/admin/sessions/close-others',{method:'POST'});
    toast('Закрыто входов: '+(r.closed||0),'ok'); adSessions() }
  catch(e){ toast(e.message,'err') }
}
async function adTwofa(on){
  if(on&&!confirm('Включить вход по коду?\n\nПри каждом входе в панель на вашу почту будет приходить код.\nБез рабочей почты войти будет нельзя.'))return;
  try{ await api('/admin/twofa',{method:'POST',body:JSON.stringify({on:!!on})});
    toast(on?'Вход по коду включён':'Вход по коду выключен','ok'); adSessions() }
  catch(e){ toast(e.message,'err') }
}

/* --- Отчёты на почту ---
   Панель открывают не каждый день, а заявка на вывод лежит живыми
   деньгами. Поэтому сводка дел приходит письмом сама — но только когда
   делам есть о чём сообщить: письмо «дел нет» приучает не открывать
   письма вообще. */
const AD_WEEKDAYS=[[1,'Понедельник'],[2,'Вторник'],[3,'Среда'],[4,'Четверг'],
                   [5,'Пятница'],[6,'Суббота'],[7,'Воскресенье']];
async function adReports(){
  let j={report:{}};
  try{ j=await api('/admin/reports') }catch(e){ toast(e.message,'err'); return }
  const R=j.report||{};
  const when=t=>t?('последний раз '+agoLabel(t)):'ещё не отправляли';
  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adSystem()">${icon('back')}<span>Система</span></button>
        <h1>Отчёты на почту</h1>
        <p class="muted small">Что приходит владельцу, пока панель закрыта</p>
      </div>
    </div>
    <form class="formgrid" onsubmit="adReportsSave(event)">
      <label class="full switchrow">
        <input type="checkbox" id="rp_digest" ${R.digest?'checked':''}>
        <span><b>Сводка дел по утрам</b><small>Заявки на проверку, обращения без ответа,
          заявки на вывод. Дел нет — письма нет. ${esc(when(R.last_digest))}</small></span></label>
      <label class="full switchrow">
        <input type="checkbox" id="rp_weekly" ${R.weekly?'checked':''}>
        <span><b>Итоги недели</b><small>Клиенты, специалисты, меню, отметки и комиссия —
          против предыдущих семи дней. ${esc(when(R.last_weekly))}</small></span></label>
      <label>День недели<select id="rp_day">${AD_WEEKDAYS.map(([v,l])=>
        `<option value="${v}" ${(+R.weekday||1)===v?'selected':''}>${l}</option>`).join('')}</select></label>
      <label>Час<select id="rp_hour">${Array.from({length:24},(_,h)=>
        `<option value="${h}" ${(+R.hour||10)===h?'selected':''}>${String(h).padStart(2,'0')}:00</option>`).join('')}</select></label>
      <button class="primary green wide full">${icon('save')} Сохранить</button>
    </form>
    <button class="btn-wide quiet" onclick="adReportsTest()">Отправить итоги недели сейчас</button>
    <p class="rw-foot muted">Письма уходят с почты, настроенной в разделе «Система».
      Отправку выполняет планировщик хостинга — если он не настроен, письма не придут
      даже при включённых переключателях.</p>`,'cog'));
}
async function adReportsSave(e){
  e.preventDefault();
  try{
    await api('/admin/reports',{method:'POST',body:JSON.stringify({
      digest:$('#rp_digest').checked, weekly:$('#rp_weekly').checked,
      weekday:+$('#rp_day').value, hour:+$('#rp_hour').value})});
    toast('Сохранено','ok'); adReports();
  }catch(x){ toast(x.message,'err') }
}
async function adReportsTest(){
  try{
    const r=await api('/admin/reports/test',{method:'POST'});
    r.ok?toast('Отчёт отправлен','ok'):toast(r.error||'Не отправилось','err');
    adReports();
  }catch(x){ toast(x.message,'err') }
}

/* --- Тексты сайта ---
   Заголовок на главной меняется чаще, чем кто-то готов лезть на хостинг.
   Пустое поле означает «оставить как в разметке»: сайт не должен
   опустеть оттого, что владелец стёр строку. */
async function adTexts(){
  let j={texts:{},fields:{}};
  try{ j=await api('/admin/texts') }catch(e){ toast(e.message,'err'); return }
  const T=j.texts||{}, F=j.fields||{};
  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adSystem()">${icon('back')}<span>Система</span></button>
        <h1>Тексты сайта</h1>
        <p class="muted small">Что видят люди на страницах до входа</p>
      </div>
    </div>
    <form class="formgrid" onsubmit="adTextsSave(event)">
      ${Object.entries(F).map(([k,label])=>`<label class="full">${esc(label)}
        <input id="tx_${k}" value="${esc(T[k]||'')}" placeholder="оставить как есть"></label>`).join('')}
      <button class="primary green wide full">${icon('save')} Сохранить</button>
    </form>
    <p class="rw-foot muted">Пустое поле — значит остаётся текст, зашитый в страницу.
      Изменения видны сразу, без выкладки файлов.</p>`,'cog'));
}
async function adTextsSave(e){
  e.preventDefault();
  const body={};
  document.querySelectorAll('[id^="tx_"]').forEach(i=>{ body[i.id.slice(3)]=i.value });
  try{ await api('/admin/texts',{method:'POST',body:JSON.stringify(body)});
    toast('Тексты сохранены','ok'); adTexts(); }
  catch(x){ toast(x.message,'err') }
}

/* --- Медиатека ---
   Фотографии блюд раскладывались файлами в папку dishes/ по именам из
   таблицы: чтобы добавить снимок, нужен был доступ к хостингу. Здесь их
   видно, можно загрузить новые и сразу привязать к блюду без фото —
   ради этого сюда и заходят. */
async function adMedia(){
  let j={media:[],no_photo:[]};
  try{ j=await api('/admin/media') }catch(e){ toast(e.message,'err'); return }
  A._media=j;
  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adSystem()">${icon('back')}<span>Система</span></button>
        <h1>Медиатека</h1>
        <p class="muted small">${j.total} файлов · блюд без фотографии: ${j.no_photo.length}</p>
      </div>
      <div class="ad-actions">
        <label class="ad-btn primary" style="cursor:pointer">${icon('plus')} Загрузить
          <input type="file" accept="image/*" multiple hidden onchange="adMediaUpload(this)"></label>
      </div>
    </div>
    ${j.no_photo.length?`<div class="ad-note">${icon('warn')}<p>Без фотографии: ${j.no_photo.length} блюд.
      Выберите снимок и нажмите «Привязать» — он встанет в карточку блюда.</p></div>`:''}
    <div class="media-grid">${j.media.map(m=>`
      <button class="media-cell ${A._mediaPick===m.url?'on':''}" onclick="adMediaPick('${esc(m.url)}')"
        title="${esc(m.name)}"><img src="${esc(m.url)}" alt="" loading="lazy"></button>`).join('')
      ||'<div class="empty small">Пока ничего не загружено</div>'}</div>
    <div class="ad-table">
      <div class="ad-thead"><b>Блюда без фотографии</b><small>${j.no_photo.length}</small></div>
      <div class="ad-rows">${j.no_photo.map(d=>`<div class="ad-tr">
        <span class="ad-td c0"><b>${esc(d.name)}</b></span>
        <span class="ad-td sub">нет снимка</span>
        <span class="ad-td c1"></span><span class="ad-td c2"></span>
        <span class="ad-td c3"></span><span class="ad-td c4"></span><span class="ad-td c5"></span>
        <span class="ad-td act"><button class="ad-btn" onclick="adMediaBind(${d.id})">Привязать</button></span>
      </div>`).join('')||'<div class="empty small">У всех блюд есть фотографии</div>'}</div>
    </div>`,'cog'));
}
function adMediaPick(url){ A._mediaPick=url; adMedia() }
async function adMediaUpload(input){
  const files=[...(input.files||[])]; if(!files.length)return;
  toast('Загружаю '+files.length+'…','ok');
  for(const f of files){
    const fd=new FormData(); fd.append('photo',f);
    try{ await api('/admin/upload',{method:'POST',body:fd}) }
    catch(e){ toast(f.name+': '+e.message,'err') }
  }
  input.value='';
  adMedia();
}
async function adMediaBind(dishId){
  if(!A._mediaPick){ toast('Сначала выберите снимок в медиатеке','err'); return }
  try{
    await api('/admin/dishes/'+dishId+'/photo',{method:'POST',
      body:JSON.stringify({photo_url:A._mediaPick})});
    toast('Снимок привязан','ok'); adMedia();
  }catch(e){ toast(e.message,'err') }
}

/* --- Реквизиты организации ---
   Документы без реквизитов юридической силы не имеют, а лежали они в
   файле на хостинге: чтобы поправить адрес, приходилось идти по SSH.
   Теперь это обычная форма, а файл остаётся запасным источником. */
const LEGAL_LABELS=[
  ['operator','Наименование','ИП Иванов Иван Иванович или ООО «Название»'],
  ['inn','ИНН','7700000000'],
  ['ogrn','ОГРН / ОГРНИП','1157700000000'],
  ['address','Адрес для писем','101000, Москва, ул. Примерная, 1, оф. 2'],
  ['email','Почта для обращений','privacy@equa.ru'],
  ['site','Адрес сайта','https://nutrimenu.ru'],
];
async function adLegal(){
  let j={legal:{}};
  try{ j=await api('/admin/legal') }catch(e){ toast(e.message,'err'); return }
  const L=j.legal||{};
  const miss=LEGAL_LABELS.filter(([k])=>!String(L[k]||'').trim()&&k!=='site').length;
  go(adShell(`${navBar('Реквизиты и контакты',"adSystem()")}
    ${miss?`<div class="ad-note">${icon('warn')}<p>Не заполнено полей: ${miss}. Пока они пустые,
      в политике конфиденциальности и пользовательском соглашении на их месте стоят пропуски —
      документ с пропусками силы не имеет.</p></div>`:''}
    <form class="formgrid" onsubmit="adLegalSave(event)">
      ${LEGAL_LABELS.map(([k,label,ph])=>`<label class="full">${label}
        <input id="lg_${k}" value="${esc(L[k]||'')}" placeholder="${esc(ph)}"></label>`).join('')}
      <button class="primary green wide full">${icon('save')} Сохранить</button>
    </form>
    <p class="rw-foot muted">Дата последней редакции проставляется сама при сохранении${
      L.updated_at?' — сейчас '+esc(dmy(String(L.updated_at).slice(0,10))):''}.
      Страницы «Политика» и «Соглашение» подхватывают эти данные сразу.</p>`,'cog'));
}
async function adLegalSave(e){
  e.preventDefault();
  const body={};
  LEGAL_LABELS.forEach(([k])=>{ body[k]=$('#lg_'+k).value });
  try{ await api('/admin/legal',{method:'POST',body:JSON.stringify(body)});
    toast('Реквизиты сохранены','ok'); adLegal(); }
  catch(x){ toast(x.message,'err') }
}

/* --- Сотрудники панели ---
   Помощник получает свой вход, а не общий пароль владельца: в журнале
   тогда видно, кто именно принял решение, а уход человека закрывается
   блокировкой его учётки, а не сменой пароля у всех.

   Роли намеренно грубые. Тонкая настройка прав по каждому действию —
   это таблица на сто строк, которую никто не поддерживает; три понятные
   роли покрывают всё, что сейчас есть в панели. */
async function adStaff(){
  let j={staff:[],roles:{}};
  try{ j=await api('/admin/staff') }catch(e){ toast(e.message,'err'); return }
  A._staff=j.staff||[]; A._roles=j.roles||{};
  const rows=A._staff.map(x=>{
    const blocked=x.status==='blocked', owner=x.role==='owner', self=+x.id===+j.me;
    return `<div class="ad-tr ${blocked?'off':''}">
      <span class="ad-td c0">${av(x.name,'sm','')}<b>${esc(x.name)}</b>${self?' <i class="ad-state on">это вы</i>':''}</span>
      <span class="ad-td sub">${esc(x.email)} · ${esc(A._roles[x.role]||x.role)}${blocked?' · доступ закрыт':''}</span>
      <span class="ad-td c1">${esc(x.email)}</span>
      <span class="ad-td c2">${esc(A._roles[x.role]||x.role)}</span>
      <span class="ad-td c3"></span>
      <span class="ad-td c4"><i class="ad-state ${blocked?'off':'on'}">${blocked?'Закрыт':'Работает'}</i></span>
      <span class="ad-td c5 num">${esc(dmy(String(x.created_at||'').slice(0,10)))}</span>
      <span class="ad-td act">${owner||self?'':`
        <button class="ad-btn" onclick="adStaffEdit(${x.id})">Изменить</button>`}</span>
    </div>`;
  }).join('');
  go(adShell(`${navBar('Сотрудники',"adSystem()")}
    <button class="btn-wide" onclick="adStaffAdd()">${icon('plus')} Добавить сотрудника</button>
    <div class="ad-table">
      <div class="ad-thead"><b>Кто работает в панели</b><small>${A._staff.length}</small></div>
      <div class="ad-rows">
        <div class="ad-tr ad-head">
          <span class="ad-td c0">Сотрудник</span><span class="ad-td c1">Почта</span>
          <span class="ad-td c2">Роль</span><span class="ad-td c3"></span>
          <span class="ad-td c4">Доступ</span><span class="ad-td c5 num">Заведён</span>
          <span class="ad-td act"></span></div>
        ${rows}
      </div>
    </div>
    <div class="ad-note">${icon('lock')}<p><b>Управляющий</b> ведёт людей, содержимое, обращения и рассылки.
      <b>Поддержка</b> отвечает на обращения и видит людей, но ничего не меняет.
      Деньги, сотрудники и системные операции остаются за владельцем.</p></div>`,'cog'));
}
function adStaffAdd(){
  const opts=Object.entries(A._roles||{}).filter(([k])=>k!=='owner');
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Сотрудники</div><h2>Новый сотрудник</h2></div>
      <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form onsubmit="adStaffSave(event)" class="formgrid">
      <label class="full">Имя<input id="st_name" required placeholder="Ольга Петрова"></label>
      <label class="full">Почта<input id="st_mail" type="email" required placeholder="olga@equa.ru"></label>
      <label class="full">Роль<select id="st_role">${opts.map(([k,v])=>
        `<option value="${k}">${esc(v)}</option>`).join('')}</select></label>
      <button class="primary wide full">Завести</button>
    </form>
    <p class="rw-foot muted">Пароль придумаем сами и покажем один раз — передайте его сотруднику,
      он поменяет пароль при первом входе.</p>`);
}
async function adStaffSave(e){
  e.preventDefault();
  try{
    const r=await api('/admin/staff',{method:'POST',body:JSON.stringify({
      name:$('#st_name').value,email:$('#st_mail').value,role:$('#st_role').value})});
    closeModal();
    /* Пароль показываем один раз: сохранить его негде, а отправить
       почтой мы можем не всегда. */
    alert('Сотрудник заведён.\n\nПароль: '+r.password+'\n\nПередайте его лично — второй раз мы его не покажем.');
    adStaff();
  }catch(x){ toast(x.message,'err') }
}
function adStaffEdit(id){
  const x=(A._staff||[]).find(v=>+v.id===+id); if(!x)return;
  const opts=Object.entries(A._roles||{}).filter(([k])=>k!=='owner');
  const blocked=x.status==='blocked';
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Сотрудник</div><h2>${esc(x.name)}</h2></div>
      <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <label class="full">Роль<select id="st_role2" onchange="adStaffRole(${id},this.value)">${opts.map(([k,v])=>
      `<option value="${k}" ${x.role===k?'selected':''}>${esc(v)}</option>`).join('')}</select></label>
    <button class="btn-wide" onclick="adStaffPassword(${id})">${icon('lock')} Выдать новый пароль</button>
    <button class="btn-wide" onclick="adStaffBlock(${id},${blocked?0:1})">
      ${icon('lock')} ${blocked?'Вернуть доступ':'Закрыть доступ'}</button>
    <button class="btn-wide danger-btn" onclick="adStaffDelete(${id})">${icon('trash')} Удалить учётку</button>`);
}
async function adStaffRole(id,role){
  try{ await api('/admin/staff/'+id,{method:'PATCH',body:JSON.stringify({role})});
    toast('Роль изменена','ok'); }
  catch(e){ toast(e.message,'err') }
}
async function adStaffBlock(id,block){
  try{ await api('/admin/staff/'+id,{method:'PATCH',body:JSON.stringify({status:block?'blocked':'active'})});
    closeModal(); adStaff(); }
  catch(e){ toast(e.message,'err') }
}
async function adStaffPassword(id){
  try{ const r=await api('/admin/staff/'+id,{method:'PATCH',body:JSON.stringify({reset_password:1})});
    closeModal();
    alert('Новый пароль: '+r.password+'\n\nСтарые сессии закрыты — сотруднику нужно войти заново.');
    adStaff(); }
  catch(e){ toast(e.message,'err') }
}
async function adStaffDelete(id){
  if(!confirm('Удалить учётку? Записи в журнале останутся.'))return;
  try{ await api('/admin/staff/'+id,{method:'DELETE'}); closeModal(); adStaff(); }
  catch(e){ toast(e.message,'err') }
}

/* --- Журнал действий ---
   Панель распоряжается доступом и деньгами, и до сих пор ни одно такое
   действие не оставляло следа: через месяц ответить «кто заблокировал
   этого специалиста» было нечем. Теперь видно, кто, что и когда. */
const AD_ACTIONS={
  block:'заблокировал', unblock:'снял блокировку', delete:'удалил',
  hide:'скрыл', publish:'открыл', broadcast:'отправил рассылку',
  'verify:verified':'подтвердил верификацию', 'verify:rejected':'отказал в верификации',
  'verify:pending':'вернул заявку в очередь', 'verify:none':'сбросил верификацию',
  'payout:paid':'отметил выплату', 'payout:rejected':'отказал в выплате',
};
const AD_TARGETS={specialist:'специалист',client:'клиент',dish:'блюдо',
  ingredient:'продукт',post:'пост',payout:'заявка на вывод',catalog:'каталог'};

const AD_LOG_KINDS=[['','Все действия'],['block','Блокировки'],['verify','Верификация'],
  ['payout','Выплаты'],['delete','Удаления'],['staff','Сотрудники'],['note','Заметки']];
const AD_LOG_DAYS=[['','За всё время'],['7','7 дней'],['30','30 дней']];
function adLogFilter(k,v){ A['adLog'+k]=v; adLog() }
async function adLog(){
  let j={log:[],total:0};
  const q=[A.adLogAction?'action='+A.adLogAction:'',A.adLogDays?'days='+A.adLogDays:'',
    A.adLogQ?'q='+encodeURIComponent(A.adLogQ):''].filter(Boolean).join('&');
  try{ j=await api('/admin/log?limit=100'+(q?'&'+q:'')) }catch(e){ toast(e.message,'err') }
  const rows=j.log||[];
  go(adShell(`
    <div class="ad-page-head">
      <div class="grow">
        <button class="ad-crumbs" onclick="adSystem()">${icon('back')}<span>Система</span></button>
        <h1>Журнал действий</h1>
        <p class="muted small">Кто и что менял в панели</p>
      </div>
    </div>
    <div class="ad-toolbar">
      <div class="ptabs sub">${AD_LOG_KINDS.map(([k,l])=>
        `<button class="ptab ${(A.adLogAction||'')===k?'on':''}" onclick="adLogFilter('Action','${k}')">${l}</button>`).join('')}</div>
      <div class="ad-tools">
        <div class="searchbox">${icon('search')}<input id="adlq" placeholder="Имя сотрудника или того, кого меняли"
          value="${esc(A.adLogQ||'')}" oninput="clearTimeout(A._adlqT);A._adlqT=setTimeout(()=>adLogFilter('Q',this.value),300)"></div>
        <div class="ptabs sub">${AD_LOG_DAYS.map(([k,l])=>
          `<button class="ptab ${(A.adLogDays||'')===k?'on':''}" onclick="adLogFilter('Days','${k}')">${l}</button>`).join('')}</div>
      </div>
    </div>
    <div class="ad-table">
      <div class="ad-thead"><b>Последние действия</b><small>${
        (A.adLogAction||A.adLogDays||A.adLogQ)?('найдено '+j.total):(j.total+' '+plural(j.total,['запись','записи','записей']))}</small></div>
      <div class="ad-rows">${rows.length?`
        <div class="ad-tr ad-head">
          <span class="ad-td c0">Кто</span><span class="ad-td c1">Что сделал</span>
          <span class="ad-td c2">Над чем</span><span class="ad-td c3"></span>
          <span class="ad-td c4">Примечание</span><span class="ad-td c5">Когда</span>
          <span class="ad-td act"></span></div>`
        +rows.map(r=>{
          const what=AD_ACTIONS[r.action]||esc(r.action);
          const target=[AD_TARGETS[r.target_type]||esc(r.target_type||''),
                        r.target_name?'«'+esc(r.target_name)+'»':''].filter(Boolean).join(' ');
          return `<div class="ad-tr">
            <span class="ad-td c0"><b>${esc(r.actor_name||'владелец')}</b></span>
            <span class="ad-td sub">${what} · ${target} · ${esc(agoLabel(r.created_at))}</span>
            <span class="ad-td c1">${what}</span>
            <span class="ad-td c2">${target}</span>
            <span class="ad-td c3"></span>
            <span class="ad-td c4">${esc(r.note||'')}</span>
            <span class="ad-td c5">${esc(agoLabel(r.created_at))}</span>
            <span class="ad-td act"></span>
          </div>`}).join('')
        :'<div class="empty small">Записей пока нет</div>'}</div>
    </div>`,'cog'));
}

/* ---------------------------------------------------------------
   РАССЫЛКИ
   Письмо всем и push — это одно занятие: дотянуться до людей. Раньше
   письмо было кнопкой в «Ещё», а настройка push — карточкой там же,
   между подписками и каталогом блюд.
   --------------------------------------------------------------- */
async function adMailing(){
  let p=null;try{p=await api('/admin/push')}catch(e){}
  go(adShell(`${adHead('Рассылки','Объявления и уведомления на телефоны')}
  <button class="feed-new" onclick="adBroadcast()"><span class="fn-ic">${icon('send')}</span>
    <span class="grow"><strong>Написать всем</strong><small>Объявление специалистам, клиентам или всем сразу</small></span>${icon('chevr')}</button>
  ${adPushCard(p)}`,'send'));
}

/* ---------------------------------------------------------------
   СИСТЕМА
   Служебное: каталог блюд, копии базы, демо-учётки, доступ, оформление.
   Сюда заходят редко, но искать это среди рассылок и тарифов не должны.
   --------------------------------------------------------------- */
function adSystem(){
  go(adShell(`${adHead('Система','Журнал, каталог, копии базы, доступ')}
  <button class="feed-new" onclick="adTexts()"><span class="fn-ic">${icon('edit')}</span>
    <span class="grow"><strong>Тексты сайта</strong><small>Заголовки на главной, в каталоге и для специалистов</small></span>${icon('chevr')}</button>
  <button class="feed-new" onclick="adMedia()"><span class="fn-ic">${icon('camera')}</span>
    <span class="grow"><strong>Медиатека</strong><small>Фотографии блюд: загрузить и привязать</small></span>${icon('chevr')}</button>
  <button class="feed-new" onclick="adLegal()"><span class="fn-ic">${icon('shield')}</span>
    <span class="grow"><strong>Реквизиты и контакты</strong><small>Что стоит в политике и соглашении</small></span>${icon('chevr')}</button>
  <button class="feed-new" onclick="adStaff()"><span class="fn-ic">${icon('users')}</span>
    <span class="grow"><strong>Сотрудники</strong><small>Кто работает в панели и что ему доступно</small></span>${icon('chevr')}</button>
  <button class="feed-new" onclick="adApp()"><span class="fn-ic">${icon('device')}</span>
    <span class="grow"><strong>Приложение</strong><small>Объявление, минимальная версия, выключатели возможностей</small></span>${icon('chevr')}</button>
  <button class="feed-new" onclick="adSessions()"><span class="fn-ic">${icon('lock')}</span>
    <span class="grow"><strong>Входы и безопасность</strong><small>Где открыта панель и вход по коду из письма</small></span>${icon('chevr')}</button>
  <button class="feed-new" onclick="adReports()"><span class="fn-ic">${icon('send')}</span>
    <span class="grow"><strong>Отчёты на почту</strong><small>Сводка дел и итоги недели, пока панель закрыта</small></span>${icon('chevr')}</button>
  <button class="feed-new" onclick="adLog()"><span class="fn-ic">${icon('list')}</span>
    <span class="grow"><strong>Журнал действий</strong><small>Кто и что менял в панели</small></span>${icon('chevr')}</button>
  <div class="card pad" id="catalogcard"><h3>Каталог блюд</h3><p class="muted small">Загрузка…</p></div>
  ${themeCard()}
  <button class="btn-wide" onclick="adPassword()">${icon('lock')} Сменить пароль владельца</button>
  <button class="btn-wide danger-btn" onclick="logout()">${icon('lock')} Выйти</button>`,'cog'));
  adPaintCatalog();
}

/* ---------------------------------------------------------------
   КАТАЛОГ БЛЮД И КОПИЯ БАЗЫ
   Обе задачи нужны редко, но обязательно: залить каталог и снять копию
   перед его заменой. На shared-хостинге консоли обычно нет, поэтому
   кнопкой — как когда-то сделали с настройкой push.
   --------------------------------------------------------------- */
async function adPaintCatalog(){
  const el=$('#catalogcard'); if(!el)return;
  let j;
  try{j=await api('/admin/catalog')}
  catch(e){el.innerHTML='<h3>Каталог блюд</h3><p class="muted small">Не удалось загрузить.</p>';return}
  el.innerHTML=`<h3>Каталог блюд</h3>
  <p class="muted small">Блюда, состав и рецепты лежат в файле <code>data/dishes.json</code>. КБЖУ считается из состава — так карточка блюда, ползунок граммовки и итог дня всегда сходятся между собой. Фотографии подхватываются из папки <code>dishes/</code> по именам из таблицы.</p>
  <div class="h-list">
    <div class="h-row"><div class="grow"><strong>В файле</strong><span class="muted small">${j.file.dishes} блюд, ${j.file.ingredients} продуктов</span></div></div>
    <div class="h-row"><div class="grow"><strong>В базе</strong><span class="muted small">${j.db.dishes} блюд, ${j.db.ingredients} продуктов, ${j.db.menus} меню</span></div></div>
    <div class="h-row"><div class="grow"><strong>Без фотографии</strong><span class="muted small">${j.db.no_photo}${j.db.no_photo?' — положите файлы в папку dishes/':''}</span></div></div>
    <div class="h-row"><div class="grow"><strong>Без состава</strong><span class="muted small">${j.db.no_recipe}${j.db.no_recipe?' — такое блюдо даст в меню ноль калорий':''}</span></div></div>
    <div class="h-row"><div class="grow"><strong>Последняя копия базы</strong><span class="muted small">${esc(j.backups.last||'копий пока нет')}</span></div>
      <button class="linkbtn" onclick="adBackup()">Снять копию</button></div>
  </div>
  <button class="btn-wide" onclick="adImport(false)">${icon('layers')} Дополнить каталог из файла</button>
  <button class="btn-wide danger-btn" onclick="adImport(true)">${icon('trash')} Заменить каталог полностью</button>
  <div class="sect">Демонстрационные учётки</div>
  <p class="muted small">При первой установке заводится показательный специалист с клиентом. Если после показов в базе осталась массовка, её можно убрать — останутся первый специалист и его первый клиент. Блюда, продукты и настройки не трогаем, копию базы сохраняем.</p>
  <button class="btn-wide danger-btn" onclick="adCleanupDemo(false)">${icon('users')} Убрать демо-учётки</button>
  <p class="muted small">Замена удаляет все блюда и все меню: меню ссылается на блюдо, и убрать блюдо, оставив меню, нельзя. Без свежей копии замена не запустится.</p>`;
}
/* Уборка демо-данных из панели, а не по SSH: папка tools/ закрыта от веба
   намеренно, и на хостинге без доступа к консоли запустить скрипт нечем.
   Сначала показываем, что именно исчезнет, и только потом удаляем. */
async function adCleanupDemo(apply){
  try{
    const j=await api('/admin/cleanup-demo',{method:'POST',body:JSON.stringify({apply:apply?1:0})});
    if(j.error){toast(j.error,'err');return}
    if(!apply){
      if(!j.delete_specialists&&!j.delete_clients){toast('Демо-учёток нет — база уже чистая','ok');return}
      const keep='специалист «'+j.keep_specialist.name+'»'+(j.keep_client?' и клиент «'+j.keep_client.name+'»':'');
      if(!confirm('Останутся: '+keep+'.\n\nБудет удалено: специалистов '+j.delete_specialists+
        ', клиентов '+j.delete_clients+' — вместе со всеми их меню, перепиской и отметками.\n\n'+
        'Перед удалением сохраним копию базы. Удалить?'))return;
      return adCleanupDemo(true);
    }
    toast('Готово. Осталось: специалистов '+j.left_specialists+', клиентов '+j.left_clients+
          '. Копия базы: '+j.backup,'ok');
    adPaintCatalog();
  }catch(e){toast(e.message,'err')}
}
async function adBackup(){
  try{
    const j=await api('/admin/backup',{method:'POST'});
    toast('Копия снята: '+j.name+'\nЛежит в storage/backups, хранятся 14 последних.','err');
    adPaintCatalog();
  }catch(e){toast(e.message,'err')}
}
async function adImport(replace){
  if(replace&&!confirm('Заменить каталог полностью?\n\nБудут удалены ВСЕ блюда и ВСЕ меню, включая составленные специалистами. Вернуть их можно только из копии базы.'))return;
  try{
    const j=await api('/admin/catalog/import',{method:'POST',body:JSON.stringify({replace})});
    /* Про расхождение с таблицей говорим здесь же: другого места, где
       владелец это увидит, нет, а выбирать за автора мы не станем. */
    const gaps=(j.gaps||[]).map(g=>`${g.name}: нет в справочнике — ${g.missing.join(', ')}`);
    const diffs=(j.diffs||[]).map(d=>`${d.name}: состав ${d.calc}, в таблице ${d.book}`);
    toast(`Готово.\nДобавлено: ${j.added}\nОбновлено: ${j.updated}\nПродуктов: ${j.ingredients}`
      +(j.menus_removed?`\nУдалено меню: ${j.menus_removed}`:'')
      +(j.orphans_removed?`\nУбрано неиспользуемых продуктов: ${j.orphans_removed}`:'')
      +'\n\nКБЖУ посчитано из состава каждого блюда.'
      +(gaps.length?`\n\nПродукты, которых нет в справочнике (состав урезан!):\n`+gaps.join('\n'):'')
      +(diffs.length?`\n\nСостав расходится с КБЖУ таблицы больше чем на 10% (${diffs.length}):\n`
        +diffs.join('\n')+'\n\nСчитаем по составу. Если верна таблица — поправьте граммовку в ней.':''),'ok');
    adPaintCatalog();
  }catch(e){toast(e.message,'err')}
}

/* ==========================================================================
   ПАНЕЛЬ ВЛАДЕЛЬЦА: рабочий стол вместо узкой колонки
   Раньше содержимое было прибито к 680px и висело посреди широкого экрана.
   Здесь — плотная сетка: полоса метрик, график с разбивкой, три списка.
   Показываем только то, что реально есть в базе: выручки, подписок и
   поддержки в проекте нет, и рисовать их цифрами было бы враньём.
   ========================================================================== */

/* Спарклайн по ряду регистраций. Без осей и подписей — это индикатор
   направления, а не график для чтения значений. */
function adSpark(series,key,color){
  const v=(series||[]).map(d=>+d[key]||0);
  /* На одном всплеске спарклайн врёт: рисуем, только когда есть динамика */
  if(v.length<2||v.filter(x=>x>0).length<3)return '';
  const max=Math.max(1,...v),W=100,H=26;
  const pts=v.map((y,i)=>[i/(v.length-1)*W, H-2-(y/max)*(H-6)]);
  const d=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
  const area=d+` L${W} ${H} L0 ${H} Z`;
  const id='sp'+key+Math.random().toString(36).slice(2,7);
  return `<svg class="ad-spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true">
    <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${color}" stop-opacity=".28"/>
      <stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
    <path d="${area}" fill="url(#${id})"/>
    <path d="${d}" fill="none" stroke="${color}" stroke-width="1.6"
      stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>`;
}
function adKpi(label,value,foot,spark){
  return `<div class="ad-kpi"><div class="ad-kpi-l">${esc(label)}</div>
    <div class="ad-kpi-v num">${value}</div>
    <div class="ad-kpi-f">${foot||''}</div>${spark||''}</div>`;
}
/* Кольцо «клиенты / специалисты». Два сегмента, поэтому обходимся
   stroke-dasharray без библиотек. */
function adDonut(a,b,la,lb){
  const tot=a+b,R=52,C=2*Math.PI*R;
  const pa=tot?a/tot:0;
  return `<div class="ad-donut">
    <svg viewBox="0 0 140 140" class="ad-donut-svg">
      <circle cx="70" cy="70" r="${R}" fill="none" stroke="var(--mc)" stroke-width="16"/>
      <circle cx="70" cy="70" r="${R}" fill="none" stroke="var(--mp)" stroke-width="16"
        stroke-dasharray="${(C*pa).toFixed(1)} ${C.toFixed(1)}"
        transform="rotate(-90 70 70)" stroke-linecap="butt"/>
      <text x="70" y="66" class="ad-donut-n">${tot}</text>
      <text x="70" y="86" class="ad-donut-c">всего</text></svg>
    <div class="ad-dleg">
      <div><i style="background:var(--mp)"></i><span>${esc(la)}</span><b class="num">${a}</b>
        <small class="num">${tot?Math.round(pa*100):0}%</small></div>
      <div><i style="background:var(--mc)"></i><span>${esc(lb)}</span><b class="num">${b}</b>
        <small class="num">${tot?100-Math.round(pa*100):0}%</small></div>
    </div></div>`;
}
function adPanel(title,link,body,cls){
  return `<section class="ad-panel ${cls||''}">
    <div class="ad-panel-h"><b>${esc(title)}</b>${link?`<button class="textbtn" onclick="${link[1]}">${esc(link[0])}</button>`:''}</div>
    ${body}</section>`;
}
/* --- Очередь дел ---
   Панель открывают не ради цифр, а чтобы понять, что ждёт решения
   сегодня. Заявки на верификацию, обращения, заявки на вывод лежали по
   разным разделам: чтобы их заметить, надо было зайти в каждый. Теперь
   они встречают на первом экране, и каждая строка ведёт прямо в дело.
   Пустая очередь — это ответ «всё разобрано», а не пустое место. */
function adQueue(q){
  if(!q)return '';
  const items=[
    ['verifications','Заявки на верификацию','adPeople(\'ver\')','users'],
    ['support','Обращения без ответа','adSupport()','chat'],
    ['payouts','Заявки на вывод','adFinance()','coin'],
    ['posts','Скрытые посты','adContent(\'posts\')','camera'],
  ].filter(([k])=>adCan(k==='payouts'?'coin':k==='support'?'chat':k==='posts'?'content':'users'));
  const live=items.filter(([k])=>+q[k]>0);
  if(!live.length){
    return `<div class="ad-queue done">${icon('check')}<p>Всё разобрано — ничего не ждёт решения.</p></div>`;
  }
  return `<div class="meal-sec ad-queue"><div class="meal-head"><b>Требует внимания</b>
      <small>${live.reduce((a,[k])=>a+ +q[k],0)} ${plural(live.reduce((a,[k])=>a+ +q[k],0),['дело','дела','дел'])}</small></div>
    <div class="meal-group">${live.map(([k,label,fn,ic])=>`
      <button class="ad-qrow" onclick="${fn}">
        <span class="fn-ic">${icon(ic)}</span>
        <span class="grow">${label}</span>
        <b class="num">${q[k]}</b>${icon('chevr')}</button>`).join('')}</div></div>`;
}

async function adOverview(){
  const j=await api('/admin/overview');A._ad=j;
  /* Готовность считаем до отрисовки: карточка должна быть в первом же
     кадре, а не появляться через секунду. */
  try{A._ready=await api('/admin/readiness')}catch(e){A._ready=null}
  /* Счётчик поддержки нужен навигации на каждом экране, а не только в
     самой поддержке: обращение, о котором не знаешь, ждёт дольше. */
  try{A.adSupportOpen=(await api('/admin/support')).open}catch(e){}
  const t=j.totals,nw=j.new,s=j.series||[];
  const ago=d=>{const ms=Date.now()-new Date(String(d).replace(' ','T')+'Z').getTime();
    const m=Math.round(ms/60000);if(m<60)return m<1?'только что':m+' мин назад';
    const h=Math.round(m/60);if(h<24)return h+' ч назад';return Math.round(h/24)+' дн назад'};
  go(adShell(`${adHead('Сводка','Что требует внимания и как идут дела')}
  ${adReadinessCard()}
  ${adWarn(j.default_password)}
  ${adQueue(j.queue)}

  <div class="ad-kpis">
    ${adKpi('Клиенты',t.clients,`${t.clients_linked} со специалистом`,adSpark(s,'clients','var(--mp)'))}
    ${adKpi('Специалисты',t.specialists,'в каталоге и вне его',adSpark(s,'specialists','var(--mc)'))}
    ${adKpi('Новых за 30 дней',nw.clients_30+nw.specialists_30,`${nw.clients_30} + ${nw.specialists_30}`,'')}
    ${adKpi('Новых за 7 дней',nw.clients_7+nw.specialists_7,`${nw.clients_7} + ${nw.specialists_7}`,'')}
    ${adKpi('Активны 7 дней',j.active_7,'отмечали питание','')}
    ${adKpi('Блюд в базе',t.dishes,`${t.menus} ${plural(t.menus,['меню','меню','меню'])} опубликовано`,'')}
    ${adKpi('Проверенных специалистов',t.verified??0,(t.verify_pending?t.verify_pending+' '+plural(t.verify_pending,['заявка ждёт','заявки ждут','заявок ждут'])+' проверки':'заявок в очереди нет'),'')}
  </div>
  ${t.verify_pending?`<button class="ad-warn" onclick="adPeople('ver')"><span class="ad-warn-ic">${icon('shield')}</span><div class="grow"><strong>${t.verify_pending} ${plural(t.verify_pending,['специалист ждёт','специалиста ждут','специалистов ждут'])} проверки документов</strong><small>Пока заявка не разобрана, отметки в каталоге у них нет.</small></div>${icon('chevr')}</button>`:''}

  <div class="ad-row2">
    ${adPanel('Регистрации за 30 дней',null,adBars(j.series))}
    ${adPanel('Кто в сервисе',null,adDonut(t.clients,t.specialists,'Клиенты','Специалисты'))}
  </div>

  <div class="ad-row3">
    ${adPanel('Последние регистрации',['Все','adPeople()'],`<div class="ad-list">${
      (j.recent||[]).slice(0,6).map(r=>`<div class="ad-li">${av(r.name,'sm')}
        <div class="grow"><strong>${esc(r.name||'—')}</strong>
        <span>${r.kind==='client'?'Клиент':'Специалист'}</span></div>
        <small>${esc(ago(r.created_at))}</small></div>`).join('')||'<div class="empty small">Пока никого</div>'}</div>`)}

    ${adPanel('Специалисты',['Все','adPeople()'],`<div class="ad-list">${
      (j.top_specialists||[]).map(x=>`<div class="ad-li">${av(x.name,'sm',x.avatar_url)}
        <div class="grow"><strong>${esc(x.name)}</strong>
        <span>${x.clients} ${plural(x.clients,['клиент','клиента','клиентов'])} · ${x.menus} ${plural(x.menus,['меню','меню','меню'])}</span></div>
        <small class="ad-plan">${esc(x.plan||'free')}</small></div>`).join('')||'<div class="empty small">Нет данных</div>'}</div>`)}

    ${adPanel('Чаще всего в меню',['Блюда','adDishes()'],`<div class="ad-list">${
      (j.popular||[]).map(x=>`<div class="ad-li">
        ${x.photo_url?`<span class="ad-thumb" style="background-image:url(${esc(x.photo_url)})"></span>`:`<span class="ad-thumb empty">${icon('bowl')}</span>`}
        <div class="grow"><strong>${esc(x.name)}</strong>
        <span>назначено ${x.n} ${plural(x.n,['раз','раза','раз'])}</span></div></div>`).join('')||'<div class="empty small">Меню ещё не составляли</div>'}</div>`)}
  </div>

  <div class="ad-row3">
    ${adPanel('Быстрые действия',null,`<div class="ad-quick">
      <button onclick="adPeople()">${icon('users')}<span>Люди</span></button>
      <button onclick="adDishes()">${icon('bowl')}<span>Блюда</span></button>
      <button onclick="adPosts()">${icon('camera')}<span>Модерация ленты</span></button>
      <button onclick="adMore()">${icon('bell')}<span>Уведомления</span></button>
      <button onclick="adAnalytics()">${icon('chart')}<span>Аналитика</span></button>
    </div>`,'ad-span2')}
    ${A.adSupportOpen?adPanel('Поддержка',null,`<div class="ad-note">${icon('chat')}<p>Обращений ждут ответа: <b>${A.adSupportOpen}</b>.</p>
      <button class="ad-btn on" onclick="adSupport()">Открыть</button></div>`):''}
    ${adPanel('Как идут дела',['Аналитика','adAnalytics()'],`<div class="ad-note plain">${icon('chart')}<p>
      Удержание за неделю и месяц, воронка от регистрации до первой отметки и неделя против предыдущей —
      на отдельном экране.</p>
      <button class="ad-btn on" onclick="adAnalytics()">Открыть аналитику</button></div>`)}
  </div>`,'home'));
}

/* ==========================================================================
   ПРАЙС СПЕЦИАЛИСТА
   Оплата внутри приложения ещё не подключена: это витрина услуг. Клиент
   видит, что и почём, и договаривается в чате. Когда появятся платежи,
   к каждой карточке добавится кнопка оплаты — данные уже на месте.
   ========================================================================== */

/* Копейки в рубли. Целые суммы — без «,00», это визуальный шум в списке. */
function rub(kop){
  const v=(kop||0)/100;
  return v.toLocaleString('ru-RU',{minimumFractionDigits:v%1?2:0,maximumFractionDigits:2})+' ₽';
}
function svcPeriod(s){
  if(s.kind!=='subscription')return 'разово';
  const d=s.period_days||30;
  return d===30?'в месяц':d===7?'в неделю':'за '+d+' '+plural(d,['день','дня','дней']);
}

async function spServices(){
  let j={services:[]};try{j=await api('/specialist/services')}catch(e){}
  const list=j.services||[];A._svc=list;
  const active=list.filter(s=>s.is_active),off=list.filter(s=>!s.is_active);
  const row=s=>`<div class="svc-row ${s.is_active?'':'off'}">
    <div class="grow"><strong>${esc(s.title)}</strong>
      ${s.description?`<small>${esc(s.description)}</small>`:''}
      <span class="svc-meta">${rub(s.price_kop)} · ${esc(svcPeriod(s))}${s.duration_min?' · '+s.duration_min+' мин.':''}${s.is_active?'':' · скрыта'}</span></div>
    <button class="icon-circle sm" title="Изменить" onclick="spServiceForm(${s.id})">${icon('edit')}</button>
    ${s.is_active?`<button class="icon-circle sm" title="Скрыть" onclick="spServiceOff(${s.id})">${icon('x')}</button>`
                 :`<button class="icon-circle sm" title="Вернуть" onclick="spServiceOn(${s.id})">${icon('check')}</button>`}</div>`;
  go(spShell(`${navBar('Услуги','spBackToMore()')}
    <div class="svc-page">
    ${active.length?`<div class="meal-sec"><div class="meal-head"><b>Активные</b><small>${active.length}</small></div>
      <div class="meal-group">${active.map(row).join('')}</div></div>`:
      `<div class="empty"><div class="orb">${icon('coin')}</div><h3>Услуг пока нет</h3>
        <p class="muted">Добавьте разовую консультацию или ведение на месяц — клиент увидит цены у себя в приложении.</p>
        <button class="primary green" onclick="spServiceForm(0)">${icon('plus')} Добавить услугу</button></div>`}
    ${off.length?`<div class="meal-sec"><div class="meal-head"><b>Скрытые</b><small>не видны клиентам</small></div>
      <div class="meal-group">${off.map(row).join('')}</div></div>`:''}
    <p class="rw-foot muted">Приём оплаты внутри приложения пока не подключён — пока это витрина, а расчёты вы ведёте сами.</p>
    </div>`,'settings'));
}
function spServiceForm(id){
  const s=(A._svc||[]).find(x=>x.id===id)||{};
  const isNew=!id;
  showSheet(`<div class="sheet-head"><h2>${isNew?'Новая услуга':'Изменить услугу'}</h2>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form onsubmit="spServiceSave(event,${id||0})">
      <label>Название<input id="svTitle" required maxlength="120" placeholder="Ведение · месяц"
        value="${esc(s.title||'')}"></label>
      <label>Описание<input id="svDesc" maxlength="600" placeholder="Меню, корректировки, чат и созвоны"
        value="${esc(s.description||'')}"></label>
      <label>Цена, ₽<input id="svPrice" inputmode="decimal" required placeholder="4500"
        value="${s.price_kop?(s.price_kop/100):''}"></label>
      <label>Формат<select id="svKind" onchange="spServiceKind(this.value)">
        <option value="one_time" ${s.kind!=='subscription'?'selected':''}>Разовая услуга</option>
        <option value="subscription" ${s.kind==='subscription'?'selected':''}>Подписка на ведение</option>
      </select></label>
      <label id="svDurWrap" ${s.kind==='subscription'?'hidden':''}>Длительность, минут
        <input id="svDur" type="number" min="5" max="600" placeholder="60" value="${s.duration_min||''}">
        <small class="muted">Клиент увидит её рядом с ценой: «3000 ₽ · 60 мин.». Можно не заполнять.</small></label>
      <label id="svPeriodWrap" ${s.kind==='subscription'?'':'hidden'}>Период, дней
        <input id="svPeriod" type="number" min="7" max="31" value="${s.period_days||30}">
        <small class="muted">От 7 до 31 дня. Дольше месяца нельзя: столько деньги у платёжного сервиса не держатся.</small></label>
      <button class="primary wide">${isNew?'Добавить':'Сохранить'}</button>
    </form>`);
}
function spServiceKind(v){const w=$('#svPeriodWrap');if(w)w.hidden=(v!=='subscription');
  const d=$('#svDurWrap');if(d)d.hidden=(v==='subscription')}
async function spServiceSave(e,id){
  e.preventDefault();
  const body={title:$('#svTitle').value.trim(),description:$('#svDesc').value.trim(),
    price:$('#svPrice').value,kind:$('#svKind').value};
  if(body.kind==='subscription')body.period_days=+$('#svPeriod').value||30;
  else body.duration_min=$('#svDur').value;
  try{
    await api(id?'/specialist/services/'+id:'/specialist/services',
      {method:id?'PATCH':'POST',body:JSON.stringify(body)});
    closeModal();spServices();
  }catch(err){toast(err.message,'err')}
}
async function spServiceOff(id){
  if(!confirm('Скрыть услугу? Клиенты перестанут её видеть, прошлые заказы останутся.'))return;
  try{await api('/specialist/services/'+id,{method:'DELETE'})}catch(e){return toast(e.message,'err')}
  spServices();
}
async function spServiceOn(id){
  try{await api('/specialist/services/'+id,{method:'PATCH',body:JSON.stringify({is_active:1})})}
  catch(e){return toast(e.message,'err')}
  spServices();
}

/* --- Клиент: прайс своего специалиста --- */
/* Сколько осталось до конца подписки — словами, которыми это говорят.
   «Осталось 0 дней» у работающей услуги читается как поломка, поэтому
   последний день называем последним. */
function subLeft(sub){
  if(!sub)return '';
  if(sub.kind!=='subscription'||sub.days_left==null)return 'разовая услуга';
  const d=+sub.days_left;
  if(d<=0)return 'заканчивается сегодня';
  if(d===1)return 'остался 1 день';
  return 'осталось '+d+' '+plural(d,['день','дня','дней']);
}
function subTone(sub){
  if(!sub||sub.kind!=='subscription'||sub.days_left==null)return '';
  return sub.days_left<=3?'r':sub.days_left<=7?'a':'g';
}

async function clServices(){
  let j={services:[],specialist:null,subscription:null};
  try{j=await api('/client/services')}catch(e){}
  const list=j.services||[], sub=j.subscription;
  /* Без специалиста услуги показывать нечего и не у кого подключать —
     ведём в каталог, а не в пустой экран с ценами. */
  if(!j.specialist){
    go(clShell(`${clHead('Услуги и цены','',"clMore()")}
      <div class="empty"><div class="orb">${icon('users')}</div><h3>Сначала выберите специалиста</h3>
      <p class="muted">Услуги и цены у каждого свои — они появятся здесь, когда вы выберете, с кем работать.</p>
      <button class="primary green" onclick="clFindSpecialist()">${icon('users')} Открыть каталог</button></div>`,'more'));
    return;
  }
  go(clShell(`${clHead('Услуги и цены','',"clMore()")}
  <div class="svc-spec">${av(j.specialist.name,'',j.specialist.avatar_url)}
    <div class="grow"><div class="eyebrow">Ваш специалист</div><strong>${esc(j.specialist.name)}</strong></div>
    <button class="svc-chat" onclick="clChat()" aria-label="Написать">${icon('chat')}</button></div>
  ${clAcceptCard(sub)}
  ${sub&&!sub.awaiting_accept?`<div class="sub-card t-${subTone(sub)}">
      <div class="eyebrow">Подключено</div>
      <div class="sub-top"><strong>${esc(sub.title)}</strong>
        <b class="num">${rub(sub.price_kop)}</b></div>
      <div class="sub-left">${icon('clock')}<span>${esc(subLeft(sub))}</span>
        ${sub.expires_at?`<i class="num">до ${esc(dmy(sub.expires_at.slice(0,10)))}</i>`:''}</div>
      ${j.note?`<p class="rw-foot muted">${esc(j.note)}</p>`:''}
    </div>`:''}
  ${list.length?`<div class="meal-group svc-list">${list.map(s=>{
    const on=sub&&+sub.service_id===+s.id;
    return `<div class="svc-card${on?' on':''}">
      <div class="svc-top"><strong>${esc(s.title)}</strong>
        <b class="num">${rub(s.price_kop)}</b></div>
      ${s.description?`<p class="muted">${esc(s.description)}</p>`:''}
      <div class="svc-foot"><span class="svc-tag">${esc(svcPeriod(s))}</span>
        ${on?`<span class="svc-on">${icon('check')} подключена</span>`
            :`<button class="svc-pick" onclick="clPickService(${s.id},'${esc(s.title).replace(/'/g,"\\'")}')">Подключить</button>`}</div>
    </div>`}).join('')}</div>
    <button class="btn-wide" onclick="clChat()">${icon('chat')} Написать специалисту</button>`
  :`<div class="empty"><div class="orb">${icon('coin')}</div><h3>Цены не указаны</h3>
      <p class="muted">Специалист пока не заполнил список услуг. Спросите в чате.</p>
      <button class="primary green" onclick="clChat()">${icon('chat')} Написать</button></div>`}`,'more'));
}

/* Подключение услуги. Денег пока не берём, но подтверждение спрашиваем:
   выбор видит специалист, и случайное нажатие будет выглядеть странно. */
/* Подключение услуги: сначала показываем, что именно человек берёт, и
   даём ввести промокод. Скидку проверяем до оплаты — узнать, что код не
   подошёл, в момент списания денег хуже всего. */
function clPickService(id,title){
  A._svcId=id;
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">Услуга</div><h2>${esc(title)}</h2></div>
      <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <label class="full">Промокод, если есть
      <div class="promo-row">
        <input id="cl_promo" placeholder="Например, START20" maxlength="24" autocapitalize="characters">
        <button type="button" class="secondary" onclick="clPromoCheck()">Проверить</button>
      </div></label>
    <div id="cl_promo_res"></div>
    <button class="primary green wide full" onclick="clServiceGo()">Подключить</button>
    <p class="rw-foot muted">Специалист увидит ваш выбор. Если приём оплаты подключён,
      дальше откроется страница оплаты.</p>`);
}
async function clPromoCheck(){
  const code=($('#cl_promo')?.value||'').trim();
  const box=$('#cl_promo_res'); if(!box)return;
  if(!code){ box.innerHTML=''; return }
  try{
    const r=await api('/client/promo/check',{method:'POST',
      body:JSON.stringify({code,service_id:A._svcId})});
    box.innerHTML=`<div class="promo-ok">${icon('check')}<span>Скидка ${r.percent} % — 
      к оплате ${rub(r.total_kop)} вместо ${rub(r.price_kop)}</span></div>`;
  }catch(e){
    box.innerHTML=`<div class="promo-bad">${icon('warn')}<span>${esc(e.message)}</span></div>`;
  }
}
async function clServiceGo(){
  const promo=($('#cl_promo')?.value||'').trim();
  try{
    const r=await api('/client/services/'+A._svcId+'/activate',{method:'POST',
      body:JSON.stringify(promo?{promo}:{})});
    closeModal();
    /* Когда приём платежей подключён, сервер отдаёт ссылку на оплату:
       услуга включится не сейчас, а когда придёт подтверждение от
       платёжного сервиса. */
    if(r.confirmation_url){location.href=r.confirmation_url;return}
    toast('Услуга подключена ✓','ok');
    clServices();
  }catch(e){toast(e.message,'err')}
}


/* ==========================================================================
   БАЛАНС СПЕЦИАЛИСТА

   Два числа — заморожено и доступно — и выписка, из которой они
   складываются. Баланс на сервере не хранится, а считается движениями,
   поэтому здесь незачем ничего кэшировать: каждый заход показывает
   правду на сейчас.
   ========================================================================== */

/* Как называется движение и каким значком помечено. Ключи те же, что у
   поля kind на сервере. */
const BAL_KIND={
  hold:       ['lock','Заморожено'],
  release:    ['check','Разморожено'],
  refund:     ['back','Возврат клиенту'],
  payout:     ['coin','Заявка на вывод'],
  payout_back:['coin','Заявка отклонена'],
};
/* У движения два столбца со знаком, но меняется всегда один: показываем
   тот, который не ноль. */
function balSum(e){return e.avail_kop||e.held_kop}
/* Зелёным отмечаем только то, что прибавилось к доступным деньгам.
   Заморозка — тоже приход, но распоряжаться им ещё нельзя, и красить её
   как заработок значит обещать лишнего. */
function balTone(e){return e.avail_kop>0?'in':e.avail_kop<0?'out':'hold'}

function balNote(mode){
  if(mode==='live')return '';
  return mode==='demo'
    ? `<div class="bal-note warn">${icon('warning')}<div><b>Проверочный режим</b>
        <span>Суммы учебные: они показывают, как работает заморозка, но вывести их нельзя.</span></div></div>`
    : `<div class="bal-note">${icon('info')}<div><b>Приём платежей ещё не подключён</b>
        <span>Здесь будут деньги за ваши услуги: заморожены, пока работа не выполнена, потом доступны к выводу.</span></div></div>`;
}

async function spBalance(tab){
  tab=tab||'moves';
  let j={balance:{},entries:[],details:null,payouts:[]};
  try{j=await api('/specialist/balance')}catch(e){toast(e.message,'err')}
  A._bal=j;
  const b=j.balance||{}, pend=+b.pending_kop||0;
  let sales=[];
  if(tab==='sales'){try{sales=(await api('/specialist/sales')).sales||[]}catch(e){}}
  A._sales=sales;

  const moves=(j.entries||[]).length
    ? `<div class="meal-group">${j.entries.map(e=>{
        const [ic,label]=BAL_KIND[e.kind]||['dot','Движение'];
        const v=balSum(e), tone=balTone(e);
        /* Сверху — за что деньги, снизу — что с ними произошло. Держать
           название услуги внутри описания события значило растить строку
           в три ряда и повторять одно и то же дважды. */
        return `<div class="bal-row">
          <span class="bal-ic ${tone}">${icon(ic)}</span>
          <div class="grow"><strong>${esc(e.sub_title||e.note||label)}</strong>
            <small>${esc(e.sub_title?(e.note||label):label)}${e.client_name?' · '+esc(e.client_name):''} · ${esc(agoLabel(e.occurred_at))}</small></div>
          <b class="num ${tone}">${v>0?'+':'−'}${rub(Math.abs(v))}</b></div>`}).join('')}</div>`
    : `<div class="empty"><div class="orb">${icon('coin')}</div><h3>Движений пока нет</h3>
        <p class="muted">Первая запись появится, когда клиент оплатит вашу услугу.</p></div>`;

  const salesList=sales.length
    ? `<div class="meal-group">${sales.map(saleRow).join('')}</div>`
    : `<div class="empty"><div class="orb">${icon('gift')}</div><h3>Покупок пока нет</h3>
        <p class="muted">Здесь будут оплаченные услуги и то, что по ним нужно сделать.</p></div>`;

  go(spShell(`${navBar('Баланс','spBackToMore()')}
  <div class="bal-page">
    ${balNote(b.payments_mode)}
    <div class="bal-2">
      <div class="bal-card"><span class="eyebrow">Доступно</span>
        <b class="num">${rub(b.available_kop||0)}</b>
        <small>${b.can_payout?'можно вывести':'к выводу'}</small></div>
      <div class="bal-card held"><span class="eyebrow">Заморожено</span>
        <b class="num">${rub(b.held_kop||0)}</b>
        <small>до выполнения работы</small></div>
    </div>
    ${pend?`<div class="bal-pend">${icon('clock')}<span>В заявке на вывод — <b class="num">${rub(pend)}</b></span></div>`:''}
    <button class="primary green btn-wide" ${b.can_payout?'':'disabled'} onclick="spPayoutForm()">
      ${icon('coin')} Вывести деньги</button>
    ${(j.payouts||[]).length?`<div class="meal-sec"><div class="meal-head"><b>Заявки</b><small>${j.payouts.length}</small></div>
      <div class="meal-group">${j.payouts.map(p=>`<div class="hist-row">
        <span class="hr-date">${esc(dmy(String(p.created_at).slice(0,10)))}</span>
        <b class="num">${rub(p.amount_kop)}</b>
        <span class="hr-d payout-${esc(p.status)}">${p.status==='paid'?'отправлено':p.status==='rejected'?'отказ':'в работе'}</span>
        ${p.note?`<small class="payout-note">${esc(p.note)}</small>`:''}</div>`).join('')}</div></div>`:''}
    <div class="seg-tabs">
      <button class="seg-tab ${tab==='moves'?'active':''}" onclick="spBalance('moves')">Движения</button>
      <button class="seg-tab ${tab==='sales'?'active':''}" onclick="spBalance('sales')">Продажи</button>
    </div>
    ${tab==='moves'?moves:salesList}
    <p class="rw-foot muted">Суммы указаны за вычетом комиссии платформы.
      Деньги клиентов лежат у платёжного сервиса, а не у нас: здесь их учёт.
      Разовая услуга размораживается после вашей отметки и подтверждения клиента,
      подписка — по дням, пока идёт период.</p>
  </div>`,'more'));
}

/* Строка продажи. Что делать дальше — зависит от того, где она сейчас:
   разовую надо отметить выполненной, подписка идёт сама. */
function saleRow(s){
  const paid=+s.paid===1;
  let state='', act='';
  if(s.status==='refunded'){ state='деньги вернулись клиенту'; }
  else if(s.disputed_at){ state='клиент не принял работу'; }
  else if(s.kind==='subscription'){ state=s.days_left!=null?subLeft(s):'подписка'; }
  else if(!s.done_at){ state='ждёт вашей отметки о выполнении';
    act=`<button class="svc-pick" onclick="spSaleDone(${s.id})">Выполнено</button>`; }
  else if(!s.accepted_at){ state=s.accept_days_left!=null
    ? 'ждём клиента · '+s.accept_days_left+' '+plural(s.accept_days_left,['день','дня','дней'])
    : 'ждём подтверждения клиента'; }
  else state=s.accepted_by==='auto'?'принято без возражений':'принято клиентом';
  return `<div class="bal-row sale">
    <div class="grow"><strong>${esc(s.title)}</strong>
      <small>${esc(s.client_name||'')} · ${esc(state)}</small>
      ${s.dispute_note?`<small class="sale-dispute">${esc(s.dispute_note)}</small>`:''}</div>
    <b class="num">${rub(s.payout_kop||s.price_kop)}</b>${act}</div>`;
}

async function spSaleDone(id){
  const s=(A._sales||[]).find(x=>+x.id===+id)||{};
  const days=(A._bal&&A._bal.balance&&A._bal.balance.accept_days)||7;
  if(!confirm('Отметить «'+(s.title||'услугу')+'» выполненной?\n\nКлиент подтвердит или напишет, что не так. '
    +'Если промолчит '+days+' '+plural(days,['день','дня','дней'])+' — деньги разморозятся сами.'))return;
  try{ await api('/specialist/sales/'+id+'/done',{method:'POST',body:'{}'});
    toast('Отмечено ✓','ok'); spBalance('sales'); }
  catch(e){toast(e.message,'err')}
}

/* --- Вывод --------------------------------------------------------------
   Реквизиты и согласие с договором спрашиваем один раз, дальше в форме
   вывода остаётся только сумма. */
function spPayoutForm(){
  const j=A._bal||{}, b=j.balance||{}, d=j.details;
  if(!d)return spPayoutDetails();
  const min=Math.round((b.payout_min_kop||0)/100);
  showSheet(`<div class="sheet-head"><h2>Вывод денег</h2>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form onsubmit="spPayoutSend(event)">
      <p class="muted small">Доступно ${rub(b.available_kop||0)}. Минимальная сумма — ${min} ₽.</p>
      <label>Сумма, ₽<input id="poAmount" inputmode="decimal" required
        value="${Math.round((b.available_kop||0)/100)}"></label>
      <div class="po-det">${icon('shield')}<div><b>${esc(d.full_name)}</b>
        <span>${esc(legalWord(d.legal_type))} · счёт ···${esc(d.account_tail)}</span></div>
        <button type="button" class="linkbtn" onclick="spPayoutDetails()">Изменить</button></div>
      <button class="primary green wide" type="submit">${icon('coin')} Отправить заявку</button>
      <p class="rw-foot muted">Перевод идёт в рамках агентского договора. Обычно занимает до трёх рабочих дней.</p>
    </form>`);
}
function legalWord(t){return t==='ip'?'ИП':t==='individual'?'Физлицо':'Самозанятый'}

function spPayoutDetails(){
  const d=(A._bal||{}).details||{};
  showSheet(`<div class="sheet-head"><h2>Реквизиты для вывода</h2>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form onsubmit="spPayoutDetailsSave(event)">
      <label>Кто получает<select id="pdType" onchange="spPayoutLegal(this.value)">
        <option value="self_employed" ${d.legal_type!=='ip'&&d.legal_type!=='individual'?'selected':''}>Самозанятый</option>
        <option value="ip" ${d.legal_type==='ip'?'selected':''}>ИП</option>
        <option value="individual" ${d.legal_type==='individual'?'selected':''}>Физлицо</option>
      </select></label>
      <label>Фамилия, имя и отчество<input id="pdName" required maxlength="120"
        placeholder="Иванова Мария Сергеевна" value="${esc(d.full_name||'')}"></label>
      <label id="pdInnRow">ИНН<input id="pdInn" inputmode="numeric" maxlength="12"
        placeholder="123456789012" value="${esc(d.inn||'')}"></label>
      <label>Номер карты или счёта<input id="pdAcc" inputmode="numeric" required
        placeholder="2202 2002 0000 0000" value=""></label>
      <label>Банк <span class="muted small">(не обязательно)</span><input id="pdBank" maxlength="120"
        placeholder="Т-Банк" value="${esc(d.bank||'')}"></label>
      <label class="switch"><input id="pdAgree" type="checkbox" ${d.agreement_accepted_at?'checked':''}>
        <span>Согласен с агентским договором</span></label>
      <p class="muted small" style="margin:2px 0 12px">Платформа принимает оплату от клиентов как ваш агент
        и перечисляет вам деньги за вычетом комиссии. Налоги со своего дохода вы платите сами.</p>
      <button class="primary green wide" type="submit">${icon('save')} Сохранить</button>
    </form>`);
  spPayoutLegal(d.legal_type||'self_employed');
}
function spPayoutLegal(v){
  const row=$('#pdInnRow'); if(!row)return;
  /* Физлицу ИНН не нужен, и просить его незачем. */
  row.hidden=(v==='individual');
  const inp=$('#pdInn'); if(inp)inp.required=!row.hidden;
}
async function spPayoutDetailsSave(e){
  e.preventDefault();
  const body={legal_type:$('#pdType').value,full_name:$('#pdName').value.trim(),
    inn:$('#pdInn').value.trim(),account:$('#pdAcc').value.trim(),bank:$('#pdBank').value.trim(),
    agreement:$('#pdAgree').checked?1:0};
  try{ await api('/specialist/payout-details',{method:'POST',body:JSON.stringify(body)});
    closeModal(); toast('Реквизиты сохранены ✓','ok'); spBalance(); }
  catch(err){toast(err.message,'err')}
}
async function spPayoutSend(e){
  e.preventDefault();
  try{ await api('/specialist/payout',{method:'POST',body:JSON.stringify({amount:$('#poAmount').value})});
    closeModal(); toast('Заявка отправлена ✓','ok'); spBalance(); }
  catch(err){toast(err.message,'err')}
}

/* --- Клиент: приёмка разовой услуги -------------------------------------
   Кнопка «подтвердить» без второй кнопки ничего не значит, поэтому рядом
   всегда есть «что-то не так»: пока идёт спор, деньги остаются
   замороженными. */
function clAcceptCard(sub){
  if(!sub||!sub.awaiting_accept)return '';
  const d=sub.accept_days_left;
  return `<div class="acc-card">
    <div class="eyebrow">Требуется подтверждение</div>
    <div class="acc-top"><strong>${esc(sub.title)}</strong><b class="num">${rub(sub.price_kop)}</b></div>
    <p class="muted">Специалист отметил услугу выполненной. Подтвердите — и деньги перейдут ему.
      ${d!=null?'Если промолчать, подтвердится само через '+d+' '+plural(d,['день','дня','дней'])+'.':''}</p>
    <div class="acc-btns">
      <button class="primary green" onclick="clAcceptService(${sub.id})">${icon('check')} Подтвердить</button>
      <button class="textbtn" onclick="clDisputeForm(${sub.id})">Что-то не так</button>
    </div></div>`;
}
async function clAcceptService(id){
  if(!confirm('Подтвердить выполнение?\n\nПосле подтверждения деньги перейдут специалисту.'))return;
  try{ await api('/client/subscriptions/'+id+'/accept',{method:'POST',body:'{}'});
    toast('Спасибо ✓','ok'); clServices(); }
  catch(e){toast(e.message,'err')}
}
function clDisputeForm(id){
  showSheet(`<div class="sheet-head"><h2>Что не так?</h2>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form onsubmit="clDisputeSend(event,${id})">
      <p class="muted small">Опишите, что не сделано или сделано не так. Деньги останутся замороженными,
        пока вы и специалист не разберётесь — а если не выйдет, разберёт поддержка.</p>
      <label>Что произошло<textarea id="dsNote" required rows="4"
        placeholder="Например: консультация не состоялась, перенести не удалось"></textarea></label>
      <button class="primary green wide" type="submit">${icon('send')} Отправить</button>
    </form>`);
}
async function clDisputeSend(e,id){
  e.preventDefault();
  try{ await api('/client/subscriptions/'+id+'/dispute',
        {method:'POST',body:JSON.stringify({note:$('#dsNote').value.trim()})});
    closeModal(); toast('Отправлено — специалист увидит','ok'); clServices(); }
  catch(err){toast(err.message,'err')}
}

/* ==========================================================================
   ВЛАДЕЛЕЦ: ДЕНЬГИ ПЛАТФОРМЫ
   Заявки на вывод, споры и настройки комиссии на одном экране: решение по
   спору меняет сумму, с которой завтра придёт заявка.
   ========================================================================== */
const PAY_MODE={off:'Выключен',demo:'Проверочный',live:'Рабочий'};
async function adFinance(){
  let j={settings:{},totals:{},payouts:[],disputes:[]};
  try{j=await api('/admin/finance')}catch(e){toast(e.message,'err')}
  A._fin=j;
  const s=j.settings||{}, t=j.totals||{};
  const open=(j.payouts||[]).filter(p=>p.status==='pending');
  go(adShell(`${adHead('Деньги','Выводы, споры и комиссия')}
  <div class="bal-page">
  <div class="bal-2">
    <div class="bal-card"><span class="eyebrow">Заморожено у специалистов</span>
      <b class="num">${rub(t.held_kop||0)}</b><small>обязательства перед ними</small></div>
    <div class="bal-card held"><span class="eyebrow">Наша комиссия</span>
      <b class="num">${rub(t.net_kop!=null?t.net_kop:(t.commission_kop||0))}</b>
      <small>${t.acquirer_fee_kop?'за вычетом '+rub(t.acquirer_fee_kop)+' эквайеру':'за всё время'}</small></div>
  </div>
  <div class="meal-sec"><div class="meal-head"><b>Заявки на вывод</b><small>${open.length} в работе</small></div>
    <div class="meal-group">${(j.payouts||[]).map(p=>`<div class="bal-row">
      <div class="grow"><strong>${esc(p.specialist_name)}</strong>
        <small>${esc(dmy(String(p.created_at).slice(0,10)))} · ${p.status==='paid'?'отправлено':p.status==='rejected'?'отказ':'ждёт'}</small></div>
      <b class="num">${rub(p.amount_kop)}</b>
      ${p.status==='pending'?`<button class="svc-pick" onclick="adPayout(${p.id},'paid')">Выплачено</button>
        <button class="icon-circle sm" title="Отказать" onclick="adPayout(${p.id},'rejected')">${icon('x')}</button>`:''}</div>`)
      .join('')||'<div class="empty small">Заявок нет</div>'}</div></div>
  <div class="meal-sec"><div class="meal-head"><b>Споры</b><small>${(j.disputes||[]).length}</small></div>
    <div class="meal-group">${(j.disputes||[]).map(d=>`<div class="bal-row">
      <div class="grow"><strong>${esc(d.title)}</strong>
        <small>${esc(d.client_name)} → ${esc(d.specialist_name)}</small>
        <small class="sale-dispute">${esc(d.dispute_note||'')}</small></div>
      <b class="num">${rub(d.payout_kop||d.price_kop)}</b>
      <button class="svc-pick" onclick="adDispute(${d.id},'release')">Специалисту</button>
      <button class="textbtn" onclick="adDispute(${d.id},'refund')">Вернуть</button></div>`)
      .join('')||'<div class="empty small">Споров нет</div>'}</div></div>
  <div class="card pad">
    <h3>Комиссия и сроки</h3>
    <form onsubmit="adFinanceSave(event)">
      <label>Режим платежей<select id="fmMode">
        ${['off','demo','live'].map(m=>`<option value="${m}" ${s.payments_mode===m?'selected':''}>${PAY_MODE[m]}</option>`).join('')}
      </select></label>
      <p class="muted small" style="margin:2px 0 12px">Выключен — услуги подключаются по договорённости, денег нет.
        Проверочный — заморозка работает, суммы учебные, вывод закрыт. Рабочий — вывод разрешён.</p>
      <label>Комиссия со своих клиентов, %<input id="fmOwn" inputmode="decimal"
        value="${(+(s.rate_own||0)*100).toFixed(0)}"></label>
      <label>Комиссия с клиентов из каталога, %<input id="fmCat" inputmode="decimal"
        value="${(+(s.rate_catalog||0)*100).toFixed(0)}"></label>
      <label>Повышенная комиссия действует, дней<input id="fmCatDays" inputmode="numeric"
        value="${s.catalog_period_days||90}"></label>
      <label>Молчание клиента = согласие, дней<input id="fmAccept" inputmode="numeric"
        value="${s.accept_days||7}"></label>
      <label>Возврат, если услуга не начата, дней<input id="fmAbandon" inputmode="numeric"
        value="${s.abandon_days||45}"></label>
      <label>Минимальная сумма вывода, ₽<input id="fmMin" inputmode="decimal"
        value="${Math.round((s.payout_min_kop||0)/100)}"></label>
      <button class="primary green wide" type="submit">${icon('save')} Сохранить</button>
    </form>
  </div>
  <button class="feed-new" onclick="adPromos()"><span class="fn-ic">${icon('tag')}</span>
    <span class="grow"><strong>Промокоды</strong><small>Скидки клиентам — за счёт сервиса или специалиста</small></span>${icon('chevr')}</button>
  <div id="admoney"></div>
  </div>`,'coin'));
  adPaintMoney();
}
/* Выручка по месяцам. Одна сумма «за всё время» не отвечает на главный
   вопрос — растём мы или нет. Подгружаем отдельно, чтобы отчёт не
   задерживал выводы, ради которых в раздел заходят чаще. */
async function adPaintMoney(){
  const el=$('#admoney'); if(!el)return;
  let j={months:[],top:[]};
  try{ j=await api('/admin/money') }
  catch(e){ el.innerHTML='<div class="empty small">Отчёт не загрузился</div>'; return }
  const mName=m=>{
    const [y,mm]=String(m||'').split('-');
    const ru=['января','февраля','марта','апреля','мая','июня','июля',
      'августа','сентября','октября','ноября','декабря'][(+mm||1)-1];
    return ru?`${ru} ${y}`:m;
  };
  el.innerHTML=`
  <div class="ad-table">
    <div class="ad-thead"><b>Деньги по месяцам</b><small>оборот, комиссия, выплаты</small></div>
    <div class="ad-rows">${j.months.length?`
      <div class="ad-tr ad-head">
        <span class="ad-td c0">Месяц</span><span class="ad-td c1 num">Сделок</span>
        <span class="ad-td c2 num">Оборот</span><span class="ad-td c3 num">Комиссия</span>
        <span class="ad-td c4 num">Эквайеру</span><span class="ad-td c5 num">Выплачено</span>
        <span class="ad-td act"></span></div>`
      +j.months.map(m=>`<div class="ad-tr">
        <span class="ad-td c0"><b>${esc(mName(m.m))}</b></span>
        <span class="ad-td sub num">оборот ${rub(m.turnover_kop)} · комиссия ${rub(m.commission_kop)}</span>
        <span class="ad-td c1 num">${m.deals}</span>
        <span class="ad-td c2 num">${rub(m.turnover_kop)}</span>
        <span class="ad-td c3 num">${rub(m.commission_kop)}</span>
        <span class="ad-td c4 num">${rub(m.fee_kop)}</span>
        <span class="ad-td c5 num">${rub(m.payouts_kop)}</span>
        <span class="ad-td act"></span></div>`).join('')
      :'<div class="empty small">Оплат пока не было</div>'}</div>
  </div>
  <div class="ad-table">
    <div class="ad-thead"><b>Кто приносит оборот</b><small>${j.top.length}</small></div>
    <div class="ad-rows">${j.top.map(t=>`<div class="ad-tr">
      <span class="ad-td c0 tap-area" onclick="adPerson('specialist',${t.id})"><b>${esc(t.name)}</b></span>
      <span class="ad-td sub num">${t.deals} сделок · ${rub(t.turnover_kop)}</span>
      <span class="ad-td c1 num">${t.deals}</span>
      <span class="ad-td c2 num">${rub(t.turnover_kop)}</span>
      <span class="ad-td c3 num">${rub(t.commission_kop)}</span>
      <span class="ad-td c4"></span><span class="ad-td c5"></span>
      <span class="ad-td act"></span></div>`).join('')
      ||'<div class="empty small">Пока никто</div>'}</div>
  </div>`;
}
async function adPayout(id,status){
  let note='';
  if(status==='rejected'){
    note=prompt('Почему отказываете? Специалист увидит эту причину.')||'';
    if(note.trim().length<5)return toast('Нужна причина отказа','err');
  }else if(!confirm('Отметить заявку выплаченной?\n\nЭто запись о переводе, который вы сделали сами.'))return;
  try{ await api('/admin/payouts/'+id,{method:'PATCH',body:JSON.stringify({status,note})});
    toast('Готово ✓','ok'); adFinance(); }
  catch(e){toast(e.message,'err')}
}
async function adDispute(id,decision){
  if(!confirm(decision==='release'
    ? 'Признать услугу выполненной? Деньги разморозятся специалисту.'
    : 'Вернуть деньги клиенту? Специалист их не получит.'))return;
  try{ await api('/admin/disputes/'+id,{method:'PATCH',body:JSON.stringify({decision})});
    toast('Спор закрыт ✓','ok'); adFinance(); }
  catch(e){toast(e.message,'err')}
}
async function adFinanceSave(e){
  e.preventDefault();
  const body={payments_mode:$('#fmMode').value,rate_own:$('#fmOwn').value,rate_catalog:$('#fmCat').value,
    catalog_period_days:$('#fmCatDays').value,accept_days:$('#fmAccept').value,
    abandon_days:$('#fmAbandon').value,payout_min:$('#fmMin').value};
  try{ await api('/admin/finance',{method:'PATCH',body:JSON.stringify(body)});
    toast('Сохранено ✓','ok'); adFinance(); }
  catch(err){toast(err.message,'err')}
}


/* ==========================================================================
   EQUA INFO
   Рассказ о сервисе и его обновления. Один экран на все роли: показываем
   то, что относится к этой стороне — специалисту про выплаты, клиенту
   про награды, общее всем.
   ========================================================================== */
async function infoScreen(){
  let j={about:[],updates:[]};
  try{j=await api('/info')}catch(e){}
  const shell=A.type==='specialist'?spShell:clShell;
  const back=A.type==='specialist'?'spBackToMore()':'clBackToMore()';
  const post=x=>`<article class="info-post">
    <h3>${esc(x.title)}</h3>
    <div class="info-body">${esc(x.body).replace(/\n{2,}/g,'</p><p>').replace(/\n/g,'<br>')}</div>
    ${x.kind==='about'?'':`<small class="muted">${esc(dmy(String(x.created_at).slice(0,10)))}</small>`}
  </article>`;
  const empty=!j.about.length&&!j.updates.length;
  go(shell(`${navBar('EQUA info',back)}
  <div class="info-page">
    ${empty?`<div class="empty"><div class="orb">${icon('spark')}</div><h3>Пока пусто</h3>
      <p class="muted">Здесь будет рассказ о сервисе и о том, что в нём нового.</p></div>`:''}
    ${j.about.length?`<div class="meal-sec"><div class="meal-head"><b>О сервисе</b></div>
      <div class="info-list">${j.about.map(post).join('')}</div></div>`:''}
    ${j.updates.length?`<div class="meal-sec"><div class="meal-head"><b>Что нового</b><small>${j.updates.length}</small></div>
      <div class="info-list">${j.updates.map(post).join('')}</div></div>`:''}
  </div>`,'more'));
}

/* --- Владелец: записи раздела ------------------------------------------- */
const INFO_AUD={all:'Всем',client:'Клиентам',specialist:'Специалистам'};
async function adInfo(){
  let j={posts:[]};try{j=await api('/admin/info')}catch(e){toast(e.message,'err')}
  A._info=j.posts||[];
  A.adDishTab='info';
  go(adShell(`${adHead('EQUA info','О сервисе и обновления')}
  ${adContentTabs()}
  <div class="bal-page">
    <button class="feed-new" onclick="adInfoForm(0)"><span class="fn-ic">${icon('plus')}</span>
      <span class="grow">Новая запись</span>${icon('chevr')}</button>
    <div class="meal-group">${A._info.map(x=>`<div class="bal-row">
      <div class="grow"><strong>${esc(x.title)}</strong>
        <small>${x.kind==='about'?'О сервисе':'Обновление'} · ${esc(INFO_AUD[x.audience]||x.audience)}${+x.is_published?'':' · скрыта'}</small></div>
      <button class="icon-circle sm" title="Изменить" onclick="adInfoForm(${x.id})">${icon('edit')}</button>
      <button class="icon-circle sm" title="Удалить" onclick="adInfoDel(${x.id})">${icon('trash')}</button>
    </div>`).join('')||'<div class="empty small">Записей нет</div>'}</div>
  </div>`,'content'));
}
function adInfoForm(id){
  const x=(A._info||[]).find(p=>+p.id===+id)||{kind:'update',audience:'all',is_published:1};
  showSheet(`<div class="sheet-head"><h2>${id?'Изменить запись':'Новая запись'}</h2>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
    <form onsubmit="adInfoSave(event,${id||0})">
      <label>Раздел<select id="ifKind">
        <option value="update" ${x.kind!=='about'?'selected':''}>Что нового</option>
        <option value="about" ${x.kind==='about'?'selected':''}>О сервисе</option>
      </select></label>
      <label>Кому показывать<select id="ifAud">
        ${Object.entries(INFO_AUD).map(([k,l])=>`<option value="${k}" ${x.audience===k?'selected':''}>${l}</option>`).join('')}
      </select></label>
      <label>Заголовок<input id="ifTitle" required maxlength="160" value="${esc(x.title||'')}"></label>
      <label>Текст<textarea id="ifBody" required rows="7">${esc(x.body||'')}</textarea></label>
      <label class="switch"><input id="ifPub" type="checkbox" ${(+x.is_published!==0)?'checked':''}>
        <span>Показывать в приложении</span></label>
      <button class="primary green wide" type="submit">${icon('save')} Сохранить</button>
    </form>`);
}
async function adInfoSave(e,id){
  e.preventDefault();
  const body={kind:$('#ifKind').value,audience:$('#ifAud').value,
    title:$('#ifTitle').value.trim(),body:$('#ifBody').value.trim(),
    is_published:$('#ifPub').checked?1:0};
  try{
    await api(id?'/admin/info/'+id:'/admin/info',{method:id?'PATCH':'POST',body:JSON.stringify(body)});
    closeModal();toast('Сохранено ✓','ok');adInfo();
  }catch(err){toast(err.message,'err')}
}
async function adInfoDel(id){
  if(!confirm('Удалить запись? Она исчезнет у всех.'))return;
  try{await api('/admin/info/'+id,{method:'DELETE'});toast('Удалено','ok');adInfo()}
  catch(e){toast(e.message,'err')}
}

/* Пункты в меню «Ещё» — с сохранением всего, что там было */



/* --------------------------------------------------------------------------
   ОТЗЫВ О СПЕЦИАЛИСТЕ
   Отзыв виден всем — об этом говорим прямо на экране, а не мелким шрифтом
   после отправки. Один клиент оставляет один отзыв и может его переписать:
   мнение через месяц работы честнее первого впечатления.
   -------------------------------------------------------------------------- */
async function clReview(){
  let j={specialist:null,review:null};
  try{j=await api('/client/review')}catch(e){}
  if(!j.specialist)return go(clShell(`${clHead('Отзыв','',1)}
    <div class="card pad"><p class="muted">Отзыв можно оставить своему специалисту. Сейчас вы ни к кому не подключены.</p></div>`,'more'));
  A._review=j.review;
  const r=j.review||{rating:0,body:''};
  go(clShell(`${clHead('Отзыв','',(j.specialist.name),1)}
    <div class="card pad">
      <p class="muted small" style="margin:0 0 14px">Отзыв виден всем в каталоге. Под ним будет ваше имя и первая буква фамилии.</p>
      <div class="field-label">Оценка</div>
      <div class="stars-pick" id="rv_stars">${[1,2,3,4,5].map(n=>
        `<button type="button" class="star-btn ${n<=r.rating?'on':''}" data-n="${n}" onclick="clPickStar(${n})">★</button>`).join('')}</div>
      <form onsubmit="clSaveReview(event)">
        <label style="margin-top:14px">Что скажете<textarea id="rv_body" rows="5" placeholder="Что получилось, что было тяжело, кому подойдёт">${esc(r.body||'')}</textarea></label>
        <button class="primary green wide">${j.review?'Сохранить':'Оставить отзыв'}</button>
      </form>
      ${j.review?`<button class="textbtn danger-text" style="margin-top:12px" onclick="clDeleteReview()">Удалить отзыв</button>`:''}
    </div>`,'more'));
  A._rvRating=r.rating;
}
function clPickStar(n){
  A._rvRating=n;
  document.querySelectorAll('#rv_stars .star-btn').forEach(b=>
    b.classList.toggle('on',+b.dataset.n<=n));
}
async function clSaveReview(e){e.preventDefault();
  if(!A._rvRating){toast('Поставьте оценку','err');return}
  try{
    await api('/client/review',{method:'POST',
      body:JSON.stringify({rating:A._rvRating,body:$('#rv_body').value})});
    clReview();
  }catch(x){toast(x.message,'err')}}
async function clDeleteReview(){
  if(!confirm('Удалить свой отзыв?'))return;
  try{await api('/client/review',{method:'DELETE'});clReview()}
  catch(x){toast(x.message,'err')}}

/* ==========================================================================
   ТЕМА ОФОРМЛЕНИЯ
   Тёмная и светлая различаются только токенами: структурные правила одни
   и те же. Выбор хранится на устройстве — это настройка экрана, а не
   свойство аккаунта, и на чужом телефоне она не нужна.
   Первичная установка темы живёт в <head> приложения, до загрузки стилей,
   иначе на секунду мигает тёмный фон.
   ========================================================================== */
Object.assign(IC,{
  moon:'M20.4 14.8A8.7 8.7 0 0 1 9.2 3.6a8.7 8.7 0 1 0 11.2 11.2Z',
  sun:'M12 16.4a4.4 4.4 0 1 0 0-8.8 4.4 4.4 0 0 0 0 8.8ZM12 2.5v2.1M12 19.4v2.1M4.3 4.3l1.5 1.5M18.2 18.2l1.5 1.5M2.5 12h2.1M19.4 12h2.1M4.3 19.7l1.5-1.5M18.2 5.8l1.5-1.5',
  device:'M7.6 3.5h8.8a1.9 1.9 0 0 1 1.9 1.9v13.2a1.9 1.9 0 0 1-1.9 1.9H7.6a1.9 1.9 0 0 1-1.9-1.9V5.4a1.9 1.9 0 0 1 1.9-1.9ZM10.7 17.7h2.6'
});

const THEME_BG={dark:'#121820',light:'#F5F6F7'};
function themePref(){try{return localStorage.nm_theme||'dark'}catch(e){return 'dark'}}
function themeResolve(t){
  if(t!=='auto')return t==='light'?'light':'dark';
  return window.matchMedia&&matchMedia('(prefers-color-scheme: light)').matches?'light':'dark';
}
function applyTheme(pref){
  const t=themeResolve(pref);
  document.documentElement.setAttribute('data-theme',t);
  const m=document.querySelector('meta[name="theme-color"]');
  if(m)m.content=THEME_BG[t];
}
function setTheme(pref){
  try{localStorage.nm_theme=pref}catch(e){}
  applyTheme(pref);
  document.querySelectorAll('.theme-opt').forEach(b=>b.classList.toggle('active',b.dataset.t===pref));
}
/* Режим «как в системе» обязан реагировать на смену системной темы на лету,
   иначе выбор работает только до перезагрузки страницы. */
if(window.matchMedia){
  const mq=matchMedia('(prefers-color-scheme: light)');
  const onChange=()=>{if(themePref()==='auto')applyTheme('auto')};
  mq.addEventListener?mq.addEventListener('change',onChange):mq.addListener(onChange);
}

/* ---------------------------------------------------------------
   Верификация специалиста.
   Клиент не может сам проверить диплом, поэтому проверку берёт на
   себя сервис. Специалист прикладывает документы, владелец сверяет
   их и ставит отметку — автоматического подтверждения нет.
   --------------------------------------------------------------- */
/* Паспорт стоит первым: он подтверждает, что человек — тот, за кого
   себя выдаёт, и это важнее любого диплома. Скан паспорта видит только
   владелец при проверке; в каталог он не попадает — туда уходят лишь
   названия принятых документов. */
const DOC_KINDS={passport:'Паспорт',diploma:'Диплом',course:'Курс',certificate:'Сертификат',license:'Лицензия'};
const VERIFY_STATE={
  none:{t:'Не подтверждён',c:'v-none',d:'Пока проверка не пройдена, ваша карточка не показывается в каталоге. Приложите диплом или сертификаты о курсах — мы сверим их.'},
  pending:{t:'На проверке',c:'v-pending',d:'Документы у нас. Обычно проверка занимает пару рабочих дней. В каталоге карточка появится после неё.'},
  verified:{t:'Проверен EQUA',c:'v-ok',d:'Карточка показывается в каталоге, рядом с именем стоит отметка о проверке.'},
  rejected:{t:'Отказано',c:'v-bad',d:'Карточки в каталоге нет. Исправьте замечание и отправьте документы заново.'}
};
/* ---------------------------------------------------------------
   ПРИВИЛЕГИИ ЗА БАЛЛЫ
   Раньше список был зашит в код и обещал скидку на подписку, которой
   в сервисе нет. Выдавать привилегию будет специалист, значит он и
   решает, что предложить.
   --------------------------------------------------------------- */
function rewardsCard(){return foldCard('rewardscard','Привилегии за баллы','<p class="muted small">Загрузка…</p>','','verify')}

async function spPaintRewards(){
  const el=document.querySelector('#rewardscard .fold-body'); if(!el)return;
  let j={rewards:[]};
  try{j=await api('/specialist/rewards')}catch(e){el.innerHTML='<p class="muted small">Не удалось загрузить.</p>';return}
  const on=j.rewards.filter(r=>r.is_active).length;
  foldSub('rewardscard',on?on+' '+plural(on,['привилегия','привилегии','привилегий']):'ничего не назначено');
  el.innerHTML=`<p class="muted small">Клиенты копят баллы за отмеченные приёмы, записи веса и ваши задания. Здесь вы решаете, на что их можно обменять — выдаёте привилегию вы сами, по коду обмена.</p>
  <div class="h-list">${j.rewards.length?j.rewards.map(r=>`
    <div class="h-row ${r.is_active?'':'off'}">
      <div class="grow"><strong>${esc(r.title)}</strong>
        <span class="muted small">${[r.cost+' баллов',r.note?esc(r.note):''].filter(Boolean).join(' · ')}</span></div>
      <button class="linkbtn" onclick="spToggleReward(${r.id},${r.is_active?0:1})">${r.is_active?'Скрыть':'Вернуть'}</button>
      <button class="linkbtn danger" onclick="spDelReward(${r.id})">Убрать</button>
    </div>`).join(''):'<div class="empty small">Пока ничего не назначено</div>'}</div>
  <form class="v-add" onsubmit="spAddReward(event)">
    <label>Что получит клиент<input id="rw_t" placeholder="Бесплатный разбор анализов" required></label>
    <label>Пояснение<input id="rw_n" placeholder="30 минут по видео"></label>
    <label>Сколько баллов<input id="rw_c" type="number" value="600" min="1"></label>
    <button class="primary green">Добавить</button>
  </form>`;
}
async function spAddReward(e){e.preventDefault();
  try{await api('/specialist/rewards',{method:'POST',body:JSON.stringify({
    title:$('#rw_t').value,note:$('#rw_n').value,cost:+$('#rw_c').value||1})});spPaintRewards()}
  catch(x){toast(x.message,'err')}}
async function spToggleReward(id,on){
  try{await api('/specialist/rewards/'+id,{method:'PATCH',body:JSON.stringify({is_active:on})});spPaintRewards()}
  catch(x){toast(x.message,'err')}}
async function spDelReward(id){
  if(!confirm('Убрать привилегию?'))return;
  try{await api('/specialist/rewards/'+id,{method:'DELETE'});spPaintRewards()}
  catch(x){toast(x.message,'err')}}

/* ----------------------------------------------------------------------
   СКЛАДНЫЕ РАЗДЕЛЫ НАСТРОЕК
   Настройки специалиста — шесть длинных форм подряд, и до «Верификации»
   приходилось прокручивать три экрана полей, которые заполняют один раз
   и больше не открывают. Разделы свёрнуты; в заголовке видно главное,
   разворачивается то, что нужно сейчас. Что было открыто — помним, иначе
   после «Сохранить» экран схлопывался и терял место, где человек работал.
   ---------------------------------------------------------------------- */
const _fold={};
function foldToggle(id,open){_fold[id]=open}
function foldCard(id,title,inner,sub,cls){
  return `<details class="card fold ${cls||''}" id="${id}"${_fold[id]?' open':''} ontoggle="foldToggle('${id}',this.open)">
    <summary class="fold-sum"><b>${esc(title)}</b><span class="fold-sub">${sub||''}</span><i class="fold-ch">${icon('chevd')}</i></summary>
    <div class="fold-body">${inner}</div>
  </details>`;
}
/* Подпись сворачивается вместе с разделом, поэтому обновляем её отдельно:
   содержимое приходит с сервера уже после отрисовки. */
function foldSub(id,html){const e=document.querySelector('#'+id+' .fold-sub');if(e)e.innerHTML=html||''}

function verifyCard(){return foldCard('verifycard','Верификация','<p class="muted small">Загрузка…</p>','','verify')}

async function spPaintVerify(){
  /* Пишем в тело раздела: заголовок живёт в summary и нужен свёрнутому. */
  const el=document.querySelector('#verifycard .fold-body'); if(!el)return;
  let v={status:'none',documents:[]};
  try{v=await api('/specialist/verification')}catch(e){el.innerHTML='<p class="muted small">Не удалось загрузить.</p>';return}
  const st=VERIFY_STATE[v.status]||VERIFY_STATE.none;
  const docs=v.documents||[];
  /* Отправлять нечего, если всё приложенное уже отклонено. */
  const ready=docs.some(d=>d.status!=='rejected');
  const dstate={pending:['На проверке','d-wait'],approved:['Принят','d-ok'],rejected:['Отклонён','d-bad']};
  foldSub('verifycard',`<span class="v-chip mini ${st.c}">${st.t}</span>`);
  /* Состояние уже стоит в заголовке раздела — второй такой же значок
     сразу под ним ничего не добавляет. */
  el.innerHTML=`${v.status==='verified'&&v.verified_at?`<div class="v-head"><span class="muted small">Подтверждён с ${hDay(v.verified_at)}</span></div>`:''}
  <p class="muted small">${st.d}</p>
  ${v.status==='rejected'&&v.note?`<div class="v-note">${esc(v.note)}</div>`:''}
  <div class="h-list">${docs.length?docs.map(d=>{
    const [dl,dc]=dstate[d.status]||dstate.pending;
    return `<div class="h-row">
      <div class="grow"><strong>${esc(d.title)}</strong>
        <span class="muted small">${[DOC_KINDS[d.kind]||'Документ',esc(d.issuer||''),esc(d.issued_on||'')].filter(Boolean).join(' · ')}</span>
        ${d.status==='rejected'&&d.review_note?`<span class="v-reason">${esc(d.review_note)}</span>`:''}</div>
      <div class="v-actions"><span class="d-chip ${dc}">${dl}</span>
        ${d.file_url?`<button class="linkbtn" onclick="hOpenLab('${d.file_url}')">Открыть</button>`:''}
        ${d.status==='approved'&&d.kind!=='passport'
          ? `<label class="v-pub"><input type="checkbox" ${d.is_public?'checked':''} onchange="vDocPublic(${d.id},this.checked)"> Показывать в профиле</label>`:''}
        <button class="linkbtn danger" onclick="vDelDoc(${d.id})">Убрать</button></div>
    </div>`}).join(''):'<div class="empty small">Документов пока нет</div>'}</div>
  <form class="v-add" onsubmit="vAddDoc(event)">
    <div class="formgrid">
      <label>Документ<select id="v_kind">${Object.entries(DOC_KINDS).map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select></label>
      <label>Год выдачи<input id="v_year" placeholder="2019"></label>
    </div>
    <label>Название<input id="v_title" placeholder="Нутрициология, РНИМУ им. Пирогова" required></label>
    <label>Кто выдал<input id="v_issuer" placeholder="ВУЗ или школа"></label>
    <label>Скан или PDF<input id="v_file" type="file" accept="application/pdf,image/*" required></label>
    <button class="primary green">Приложить документ</button>
  </form>
  ${v.status==='pending'?'':`<button class="row-btn v-send" ${ready?'':'disabled'} onclick="vSubmit()">${icon('check')}<span>${v.status==='verified'?'Отправить новые документы':'Отправить на проверку'}</span></button>`}
  <p class="muted small v-priv">Сканы видит только команда EQUA. В открытом профиле показывается название документа, а сам скан — только если вы сами его открыли галочкой «Показывать в профиле». Паспорт не показывается никогда: клиент видит лишь отметку, что личность проверена.</p>`;
}
/* Открыть скан в профиле — решение специалиста, а не наше: документ
   он грузил для проверки. Паспорт сервер не отдаст в любом случае. */
async function vDocPublic(id,on){
  try{ await api('/specialist/verification/documents/'+id,{method:'PATCH',body:JSON.stringify({is_public:on?1:0})});
    toast(on?'Скан виден в профиле ✓':'Скан скрыт','ok'); }
  catch(e){ toast(e.message,'err'); spPaintVerify(); }
}
async function vAddDoc(e){e.preventDefault();
  const f=$('#v_file').files[0];
  if(!f){toast('Приложите скан или PDF','err');return}
  const fd=new FormData();
  fd.append('kind',$('#v_kind').value);
  fd.append('title',$('#v_title').value);
  fd.append('issuer',$('#v_issuer').value);
  fd.append('issued_on',$('#v_year').value);
  fd.append('file',f);
  try{await api('/specialist/verification/documents',{method:'POST',body:fd});spPaintVerify()}
  catch(x){toast(x.message,'err')}}
async function vDelDoc(id){
  if(!confirm('Убрать документ?'))return;
  try{await api('/specialist/verification/documents/'+id,{method:'DELETE'});spPaintVerify()}
  catch(x){toast(x.message,'err')}}
async function vSubmit(){
  try{await api('/specialist/verification/submit',{method:'POST'});spPaintVerify()}
  catch(x){toast(x.message,'err')}}

function themeCard(){
  const cur=themePref();
  const opts=[['dark','Тёмная','moon'],['light','Светлая','sun'],['auto','Как в системе','device']];
  return `<div class="card pad theme-card"><h3>Оформление</h3>
    <div class="theme-seg">${opts.map(([k,label,ic])=>
      `<button type="button" class="theme-opt ${cur===k?'active':''}" data-t="${k}"
        onclick="setTheme('${k}')">${icon(ic)}<span>${label}</span></button>`).join('')}</div>
    <p class="muted small theme-note">Настройка запоминается на этом устройстве.</p></div>`;
}

/* ==========================================================================
   НАВИГАЦИЯ БЕЗ ПЕРЕРИСОВКИ ОБОЛОЧКИ
   go() заменял весь #app целиком — вместе с боковым меню и нижней панелью,
   и анимировал результат. Меню каждый раз исчезало и появлялось заново, из-за
   чего переход читался как перезагрузка страницы.
   Теперь при переходе внутри одной оболочки меняется только содержимое, а
   панель остаётся в DOM: у кнопок обновляются классы, сами узлы не пересоздаются.
   ========================================================================== */
const SHELL_MAIN='.client-main, .main';
function shellKind(el){
  if(!el||!el.classList)return null;
  if(el.classList.contains('client-shell'))return el.classList.contains('admin-shell')?'admin':'client';
  if(el.classList.contains('shell'))return 'spec';
  return null;
}
/* Классы кнопок переносим, а не пересоздаём разметку: так не сбрасывается
   фокус и не моргает активный пункт. */
function syncNodes(oldRoot,newRoot,sel){
  const a=oldRoot.querySelector(sel),b=newRoot.querySelector(sel);
  if(!a||!b)return;
  if(a.children.length===b.children.length){
    for(let i=0;i<a.children.length;i++){
      if(a.children[i].className!==b.children[i].className)
        a.children[i].className=b.children[i].className;
      const ax=a.children[i],bx=b.children[i];
      if(ax.tagName===bx.tagName&&ax.innerHTML!==bx.innerHTML)ax.innerHTML=bx.innerHTML;
    }
  }else a.innerHTML=b.innerHTML;
}
/* Снимок уходящего экрана. Копия, а не сам экран: новый рисуется на
   месте немедленно, и всё, что вызывается сразу после перехода, видит
   готовый DOM. Копию чистим от проигрывателей — иначе голосовое
   зазвучит дважды, пока идёт анимация. */
function pageGhost(main){
  if(!main||reduceMotion()||!main.animate)return null;
  const r=main.getBoundingClientRect();
  const top=Math.max(0,r.top);
  const g=document.createElement('div');
  g.className='page-ghost';
  g.style.left=r.left+'px';g.style.top=top+'px';
  g.style.width=r.width+'px';g.style.height=(innerHeight-top)+'px';
  const inner=document.createElement('div');
  inner.className='pg-in';
  inner.style.marginTop=(Math.min(0,r.top)-(main.scrollTop||0))+'px';
  inner.innerHTML=main.innerHTML;
  inner.querySelectorAll('audio,video,iframe').forEach(x=>x.remove());
  g.appendChild(inner);document.body.appendChild(g);
  const an=g.animate([{transform:'none',opacity:1},
                      {transform:'translateX(100%)',opacity:.65}],
                     {duration:300,easing:EASE});
  const off=()=>g.remove();
  an.finished.then(off,off);
  setTimeout(off,700);            /* если анимацию оборвали — не оставляем мусор */
  return g;
}
function go(html){
  /* Внутри Telegram кнопку «назад» показывает сам мессенджер — сверяем
     её с тем, есть ли своя на новом экране. Делаем это здесь, а не в
     каждом экране: экранов полсотни, и любой забытый оставил бы
     системную кнопку висеть без дела. */
  if(window.TG_MINIAPP&&typeof tgSyncBack==='function')setTimeout(tgSyncBack,0);
  const app=$('#app'),cur=app.firstElementChild;
  const kind=shellKind(cur);
  if(kind){
    const tmp=document.createElement('div');tmp.innerHTML=html;
    const nxt=tmp.firstElementChild;
    if(shellKind(nxt)===kind){
      const a=cur.querySelector(SHELL_MAIN),b=nxt.querySelector(SHELL_MAIN);
      if(a&&b){
        /* Назад — перелистывание: старое уезжает вправо, новое приходит
           слева с отставанием, как нижний экран из-под верхнего. */
        const back=A._swipeDir===-1;
        const ghost=back?pageGhost(a):null;
        if(cur.className!==nxt.className)cur.className=nxt.className;
        a.innerHTML=b.innerHTML;
        syncNodes(cur,nxt,'.client-nav');
        syncNodes(cur,nxt,'.bottom');
        syncNodes(cur,nxt,'.nav');
        const oa=cur.querySelector('.client-aside'),na=nxt.querySelector('.client-aside');
        if(oa&&na&&oa.innerHTML!==na.innerHTML)oa.innerHTML=na.innerHTML;
        a.scrollTop=0;window.scrollTo(0,0);
        if(ghost){
          A._swipeDir=0;
          a.animate([{transform:'translateX(-26%)'},{transform:'none'}],
                    {duration:300,easing:EASE});
        }else fx(a.firstElementChild);    /* анимируем содержимое, не оболочку */
        return;
      }
    }
  }
  app.innerHTML=html;window.scrollTo(0,0);fx(app.firstElementChild);
}

/* --- Звонки по HTTP: объясняем, а не прячем кнопку ---
   navigator.mediaDevices существует только в защищённом контексте. На http://
   кнопка исчезала молча, и выглядело это как отсутствующая функция. */
function callInsecure(){
  return location.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(location.hostname);
}
function callBtn(clientId){
  const hasPeer=A.type==='specialist'||(A.type==='client'&&A.user&&A.user.specialist_id);
  if(!hasPeer)return '';
  /* Звонки выключаются с сервера: когда сервер сигналов лежит, кнопка
     ведёт к экрану, который так и не соединится. */
  if(!feat('calls'))return '';
  return `<button class="call-btn" title="Видеозвонок" aria-label="Видеозвонок" onclick="callStart(${clientId||''})">${icon('video')}</button>`;
}

/* ==========================================================================
   ПАНЕЛЬ ВЛАДЕЛЬЦА: каталог, справочник, поддержка, рассылка.

   Каталог блюд ведёт владелец: это общая база, которую видят все
   специалисты, и следить за ней больше некому. Личное блюдо
   специалиста остаётся его — владелец может только убрать его из
   общего доступа.
   ========================================================================== */

/* Вкладки раздела «Контент».
   Блюда, продукты, лента и записи EQUA info — это всё содержимое
   сервиса, которое ведёт владелец. Раньше блюда с продуктами жили в
   своей вкладке, а лента и EQUA info — кнопками в «Ещё», хотя занятие
   одно и то же: проверить и поправить то, что видят люди. */
function adContentTabs(){
  const t=[['dishes','Блюда'],['ing','Продукты'],['posts','Лента'],
           ['reviews','Отзывы'],['showcase','Витрина'],['info','EQUA info']];
  return `<div class="ptabs">${t.map(([k,l])=>
    `<button class="ptab ${A.adDishTab===k?'on':''}" onclick="adContent('${k}')">${l}</button>`).join('')}</div>`;
}
function adDishTabs(){ return adContentTabs() }
/* Один вход в раздел: запоминаем вкладку, дальше каждая рисует себя сама. */
async function adContent(tab){
  A.adDishTab=tab||A.adDishTab||'dishes';
  if(A.adDishTab==='ing')  return adIngredients();
  if(A.adDishTab==='posts')return adPosts();
  if(A.adDishTab==='reviews')return adReviews();
  if(A.adDishTab==='showcase')return adShowcase();
  if(A.adDishTab==='info') return adInfo();
  return adDishes(A.adDishTab);
}

/* --- Редактор блюда каталога ---
   Тот же состав-и-рецепт, что у специалиста: разводить два разных
   редактора для одной сущности значит чинить каждую правку дважды. */
/* --- Витрина каталога ---
   Человек, который ещё никого не выбрал, открывает каталог и берёт из
   первых строк. Значит, порядок — это решение владельца, а не побочный
   эффект сортировки по рейтингу. Здесь два действия: закрепить наверху
   и убрать с витрины; всё остальное специалист ведёт сам. */
async function adShowcase(){
  A.adDishTab='showcase';
  let j={specialists:[],live:0};
  try{ j=await api('/admin/catalog/specialists') }catch(e){ toast(e.message,'err'); return }
  A._showcase=j.specialists;
  go(adShell(`${adHead('Витрина каталога','Кого и в каком порядке видят на nutrimenu.ru')}
  ${adContentTabs()}
  <div class="wgrid">
    <div class="wtile"><div class="wt-lbl">В каталоге</div><div class="wt-big num">${j.live}</div>
      <div class="wt-foot">видят посетители</div></div>
    <div class="wtile"><div class="wt-lbl">Закреплено</div>
      <div class="wt-big num">${j.specialists.filter(s=>+s.featured).length}</div>
      <div class="wt-foot">наверху списка</div></div>
  </div>
  <div class="ad-table">
    <div class="ad-thead"><b>Специалисты с публичным профилем</b><small>${j.specialists.length}</small></div>
    <div class="ad-rows" id="adshowcase"></div></div>
  <p class="rw-foot muted">Закреплённые идут первыми, остальные — по рейтингу.
    Снятый с витрины не пропадает: клиенты остаются при нём, его просто
    не показывают тем, кто выбирает специалиста впервые.</p>`,'content'));
  adPaintShowcase();
}
function adPaintShowcase(){
  const el=$('#adshowcase'); if(!el)return;
  const rows=A._showcase||[];
  if(!rows.length){el.innerHTML='<div class="empty small">Публичных профилей пока нет</div>';return}
  const head=['Специалист','Город','Рейтинг','Клиентов','Заявок','Состояние'];
  el.innerHTML=`<div class="ad-tr ad-head">${head.map((h,i)=>
      `<span class="ad-td c${i} ${i===2||i===3||i===4?'num':''}">${h}</span>`).join('')}<span class="ad-td act"></span></div>`
    +rows.map(s=>{
      const off=+s.blocked||!+s.is_public||s.verify_status!=='verified';
      const why=+s.blocked?'Снят с витрины'
        :(!+s.is_public?'Профиль закрыт им самим'
        :(s.verify_status!=='verified'?'Не проверен':'В каталоге'));
      return `<div class="ad-tr ${off?'off':''}">
    <span class="ad-td c0"><b>${esc(s.name)}</b>${+s.featured?` <i class="tag-mini">${icon('star')} ${s.featured}</i>`:''}</span>
    <span class="ad-td sub">${esc(s.city||'город не указан')} · ${why}</span>
    <span class="ad-td c1">${esc(s.city||'—')}</span>
    <span class="ad-td c2 num">${s.rating?(+s.rating).toFixed(1):'—'}</span>
    <span class="ad-td c3 num">${s.clients||0}</span>
    <span class="ad-td c4 num">${s.leads||0}</span>
    <span class="ad-td c5"><i class="ad-state ${off?'off':'on'}">${why}</i></span>
    <span class="ad-td act">
      <button class="ad-btn ${+s.featured?'on':''}" onclick="adShowcasePin(${s.id},${+s.featured?0:1})">
        ${+s.featured?'Открепить':'Закрепить'}</button>
      ${+s.featured?`<button class="ad-btn" onclick="adShowcasePin(${s.id},${+s.featured+1})">Выше</button>`:''}
      <button class="ad-btn ${+s.blocked?'':'danger'}" onclick="adShowcaseBlock(${s.id},${+s.blocked?0:1})">
        ${+s.blocked?'Вернуть':'Снять'}</button>
    </span>
  </div>`}).join('');
}
async function adShowcasePin(id,val){
  try{ await api('/admin/catalog/specialists/'+id,{method:'POST',body:JSON.stringify({featured:val})}) }
  catch(e){ toast(e.message,'err'); return }
  adShowcase();
}
async function adShowcaseBlock(id,val){
  if(val&&!confirm('Убрать специалиста с витрины каталога?\nЕго клиенты останутся при нём.'))return;
  try{ await api('/admin/catalog/specialists/'+id,{method:'POST',body:JSON.stringify({blocked:val})}) }
  catch(e){ toast(e.message,'err'); return }
  adShowcase();
}

async function adDishEditor(id){
  if(!A.ingredients?.length){
    try{A.ingredients=(await api('/admin/ingredients')).ingredients}catch(e){A.ingredients=[]}
  }
  let d=null;
  if(id){
    try{d=(await api('/admin/dishes/'+id)).dish}
    catch(e){toast(e.message,'err');return}
    if(!+d.is_public&&d.created_by){
      toast('Это личное блюдо специалиста — его правит только автор.\nВы можете убрать его из общего каталога, но не менять содержимое.','err');
      return;
    }
  }
  const rows=((d?.ingredients?.length)?d.ingredients:[{}]).map(ingRow).join('');
  let steps=[];try{steps=JSON.parse(d?.steps||'[]')||[]}catch(e){}
  if(!steps.length)steps=[{}];
  const meals=(()=>{try{return JSON.parse(d?.meal_types||'[]')||[]}catch(e){return[]}})();
  showModal(`<div class="sheet-head"><div><div class="eyebrow">${id?'Блюдо каталога':'Новое блюдо'}</div>
      <h2>${id?esc(d.name):'Блюдо каталога'}</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="adSaveDish(event,${id||0})">
    <div class="dish-cover" id="dishcover" style="${d?.photo_url?`background-image:url(${esc(d.photo_url)})`:''}">
      <input type="file" accept="image/*" hidden onchange="spCoverPhoto(this)">
      <input type="hidden" id="d_photo" value="${esc(d?.photo_url||'')}">
      <button type="button" class="cover-btn" onclick="this.parentElement.querySelector('input[type=file]').click()">
        ${icon('camera')} ${d?.photo_url?'Изменить фото':'Заглавное фото'}</button>
    </div>
    <label>Название<input id="d_n" required value="${esc(d?.name||'')}"></label>
    <div class="formgrid">
      <label>Время, мин<input id="d_t" type="number" value="${d?.cook_minutes||15}"></label>
      <label>Тип приёма<select id="d_m">${[['breakfast','Завтрак'],['lunch','Обед'],['dinner','Ужин'],['snack1','Перекус']]
        .map(([v,l])=>`<option value="${v}" ${meals.includes(v)?'selected':''}>${l}</option>`).join('')}</select></label>
    </div>
    <div class="sect editrow">Состав<button type="button" class="link" onclick="spAddIngRow()">${icon('plus')} ингредиент</button></div>
    <div id="ingrows">${rows}</div>
    <div class="dish-macros" id="dishmacros"></div>
    <div class="sect editrow">Как готовить<button type="button" class="link" onclick="spAddStep()">${icon('plus')} шаг</button></div>
    <div id="steprows">${steps.map(stepRow).join('')}</div>
    <label>Теги (через запятую)<input id="d_tags" value="${esc((d?.tags||[]).join(', '))}"></label>
    <button class="primary wide">${id?'Сохранить блюдо':'Создать блюдо'}</button>
  </form>`);
  recalcDish();
}

async function adSaveDish(e,id){
  e.preventDefault();
  const ings=[...document.querySelectorAll('#ingrows .ingrow')].map(r=>({
    ingredient_id:+r.querySelector('[data-ing]').value,
    grams:+r.querySelector('[data-g]').value||0,
  })).filter(x=>x.ingredient_id&&x.grams>0);
  if(!ings.length){toast('Добавьте хотя бы один продукт — из состава считается КБЖУ блюда.','err');return}
  const steps=[...document.querySelectorAll('#steprows .step-row')].map(r=>({
    text:r.querySelector('[data-step]').value.trim(),
    photo_url:r.querySelector('[data-sphoto]').value||null,
  })).filter(x=>x.text);
  const body={
    name:$('#d_n').value.trim(),
    cook_minutes:+$('#d_t').value||null,
    meal_types:[$('#d_m').value],
    photo_url:$('#d_photo').value||null,
    steps,
    /* Сплошной текст держим рядом с шагами: по нему ищут и его печатают. */
    instructions:steps.map(x=>x.text).join(' '),
    ingredients:ings,
    tags:$('#d_tags').value.split(',').map(x=>x.trim()).filter(Boolean),
  };
  try{
    if(id) await api('/admin/dishes/'+id,{method:'PATCH',body:JSON.stringify(body)});
    else    await api('/admin/dishes',{method:'POST',body:JSON.stringify(body)});
    closeModal(); adDishes('dishes');
  }catch(err){toast(err.message,'err')}
}

/* --- Справочник продуктов ---
   От этих чисел зависит КБЖУ всех блюд, поэтому у каждой строки видно,
   в скольких блюдах продукт стоит: правка «молока» задевает шесть блюд,
   и знать это надо до правки. Блюда пересчитываются сами. */
async function adIngredients(){
  A.adIngQ=A.adIngQ||''; A.adIngPage=1;
  const j=await api('/admin/ingredients?limit=100'+(A.adIngQ?'&q='+encodeURIComponent(A.adIngQ):''));
  A._adIngTotal=j.total; A._adIngPages=j.pages;
  A._adIng=j.ingredients; A._adDups=j.duplicates||[];
  go(adShell(`${adHead('Продукты','Справочник, из которого считается КБЖУ блюд')}
  ${adContentTabs()}
  ${A._adDups.length?`<div class="ad-note">${icon('warn')}<p>Одинаковые названия в разном регистре: ${A._adDups.length}. Такие продукты делят состав блюд между собой — объедините их, ссылки блюд переедут сами.</p></div>
    ${A._adDups.map(ids=>{
      const list=ids.map(i=>A._adIng.find(x=>x.id===i)).filter(Boolean);
      if(list.length<2)return '';
      return `<div class="ad-row"><div class="grow"><strong>${esc(list[0].name)}</strong>
        <small>${list.map(x=>`«${esc(x.name)}» в ${x.used} блюд`).join(' · ')}</small></div>
        <button class="ad-btn" onclick="adIngMerge(${list[0].id},${list[1].id})">Объединить</button></div>`;
    }).join('')}`:''}
  <div class="ad-toolbar">
    <div class="ad-tools">
      <div class="searchbox">${icon('search')}<input id="adiq" placeholder="Поиск продукта…"
        value="${esc(A.adIngQ)}" oninput="adIngSearch(this.value)"></div>
    </div>
    <button class="ad-btn primary" onclick="adIngEditor(0)">${icon('plus')} Новый продукт</button>
  </div>
  <div class="ad-table">
    <div class="ad-thead"><b>Продукты</b><small id="ading-count">${
      A.adIngQ?('найдено '+j.total):(j.total+' всего')}</small></div>
    <div class="ad-rows" id="adinglist"></div></div>
  <div id="ading-more"></div>`,'content'));
  adRenderIng();
  adMoreBtn('#ading-more',j,j.ingredients.length,'A.adIngPage=2;adIngLoad(true)');
}
function adIngSearch(v){
  A.adIngQ=v; A.adIngPage=1;
  clearTimeout(A._adiqT);
  A._adiqT=setTimeout(()=>adIngLoad(),250);
}
async function adIngLoad(add){
  const j=await api('/admin/ingredients?limit=100&page='+(A.adIngPage||1)
    +(A.adIngQ?'&q='+encodeURIComponent(A.adIngQ):''));
  A._adIng=add?(A._adIng||[]).concat(j.ingredients):j.ingredients;
  const c=$('#ading-count'); if(c)c.textContent=A.adIngQ?('найдено '+j.total):(j.total+' всего');
  adRenderIng();
  adMoreBtn('#ading-more',j,A._adIng.length,`A.adIngPage=${j.page+1};adIngLoad(true)`);
}
function adRenderIng(){
  const rows=A._adIng||[];
  const el=$('#adinglist');if(!el)return;
  if(!rows.length){el.innerHTML='<div class="empty small">Ничего не найдено</div>';return}
  const head=['Продукт','Б / Ж / У','Ккал','В блюдах','',''];
  el.innerHTML=`<div class="ad-tr ad-head">${head.map((h,i)=>
      `<span class="ad-td c${i} ${i===2||i===3?'num':''}">${h}</span>`).join('')}<span class="ad-td act"></span></div>`
    +rows.map(x=>`<div class="ad-tr">
    <span class="ad-td c0 tap-area" onclick="adIngEditor(${x.id})"><b>${esc(x.name)}</b></span>
    <span class="ad-td sub num">${R(x.kcal)} ккал · Б ${R(x.protein)} · Ж ${R(x.fat)} · У ${R(x.carbs)} / 100 г${x.used?` · в ${x.used} блюд`:' · не используется'}</span>
    <span class="ad-td c1 num">${R(x.protein)} / ${R(x.fat)} / ${R(x.carbs)}</span>
    <span class="ad-td c2 num">${R(x.kcal)}</span>
    <span class="ad-td c3 num">${x.used||'—'}</span>
    <span class="ad-td c4"></span><span class="ad-td c5"></span>
    <span class="ad-td act">
      ${+x.used?'':`<button class="ad-btn danger" aria-label="Удалить продукт" onclick="adIngDelete(${x.id})">${icon('trash')}</button>`}
    </span>
  </div>`).join('');
}
function adIngEditor(id){
  const x=id?(A._adIng||[]).find(v=>v.id===id):null;
  showModal(`<div class="sheet-head"><div><div class="eyebrow">${id?'Продукт':'Новый продукт'}</div>
      <h2>${id?esc(x.name):'Продукт'}</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="adSaveIng(event,${id||0})">
    <label>Название<input id="i_n" required value="${esc(x?.name||'')}"></label>
    <label>Категория<input id="i_c" value="${esc(x?.category||'Прочее')}" placeholder="Овощи, Крупы и гарниры…"></label>
    <div class="formgrid">
      <label>Ккал / 100 г<input id="i_k" type="number" step="0.1" required value="${x?.kcal??0}"></label>
      <label>Белки, г<input id="i_p" type="number" step="0.1" value="${x?.protein??0}"></label>
    </div>
    <div class="formgrid">
      <label>Жиры, г<input id="i_f" type="number" step="0.1" value="${x?.fat??0}"></label>
      <label>Углеводы, г<input id="i_u" type="number" step="0.1" value="${x?.carbs??0}"></label>
    </div>
    <div class="formgrid">
      <label>Мера<select id="i_unit">${[['g','граммы'],['ml','миллилитры'],['pc','штуки']]
        .map(([v,l])=>`<option value="${v}" ${(x?.unit||'g')===v?'selected':''}>${l}</option>`).join('')}</select></label>
      <label>Вес штуки, г<input id="i_pg" type="number" step="1" value="${x?.piece_g??''}" placeholder="для штучных"></label>
    </div>
    ${id&&+x.used?`<p class="muted small">Продукт стоит в ${x.used} блюдах — после сохранения они пересчитаются.</p>`:''}
    <button class="primary wide">Сохранить</button>
  </form>`);
}
async function adSaveIng(e,id){
  e.preventDefault();
  const body={
    name:$('#i_n').value.trim(), category:$('#i_c').value.trim()||'Прочее',
    kcal:+$('#i_k').value||0, protein:+$('#i_p').value||0,
    fat:+$('#i_f').value||0, carbs:+$('#i_u').value||0,
    unit:$('#i_unit').value, piece_g:$('#i_pg').value,
  };
  try{
    const r=id? await api('/admin/ingredients/'+id,{method:'PATCH',body:JSON.stringify(body)})
              : await api('/admin/ingredients',{method:'POST',body:JSON.stringify(body)});
    closeModal();
    if(r.dishes_recalculated) toast(`Сохранено. Пересчитано блюд: ${r.dishes_recalculated}`,'ok');
    A.ingredients=null; adIngredients();
  }catch(err){toast(err.message,'err')}
}
async function adIngDelete(id){
  const x=(A._adIng||[]).find(v=>v.id===id);
  if(!confirm(`Убрать «${x?.name||'продукт'}» из справочника?`))return;
  try{await api('/admin/ingredients/'+id,{method:'DELETE'});A.ingredients=null;adIngredients()}
  catch(e){toast(e.message,'err')}
}
async function adIngMerge(keep,drop){
  const a=(A._adIng||[]).find(v=>v.id===keep), b=(A._adIng||[]).find(v=>v.id===drop);
  if(!confirm(`Объединить «${b?.name}» в «${a?.name}»?\n\nСостав блюд переедет на «${a?.name}», лишний продукт удалится. Если оба стояли в одном блюде, их граммовки сложатся.`))return;
  try{
    const r=await api('/admin/ingredients/merge',{method:'POST',body:JSON.stringify({keep_id:keep,drop_id:drop})});
    toast(`Объединено. Пересчитано блюд: ${r.dishes_recalculated}`,'ok');
    A.ingredients=null; adIngredients();
  }catch(e){toast(e.message,'err')}
}

/* --- Техподдержка ---
   Очередь сортирует сервер по последнему сообщению: обращение недельной
   давности с новым ответом важнее свежего, на которое уже ответили.
   Закрытые уходят вниз, но не пропадают — по ним ищут прошлые решения. */
async function adSupport(){
  const j=await api('/admin/support');
  A._adTickets=j.tickets; A.adSupportOpen=j.open;
  const wait=j.tickets.filter(t=>t.status!=='closed').length;
  go(adShell(`${adHead('Поддержка','Обращения клиентов и специалистов')}
  <div class="wgrid">
    <div class="wtile"><div class="wt-lbl">Ждут ответа</div><div class="wt-big num">${wait}</div>
      <div class="wt-foot">${j.tickets.filter(t=>+t.unread&&t.status!=='closed').length} с новыми сообщениями</div></div>
    <div class="wtile"><div class="wt-lbl">Закрыто</div><div class="wt-big num">${j.tickets.filter(t=>t.status==='closed').length}</div>
      <div class="wt-foot">всего обращений ${j.tickets.length}</div></div>
  </div>
  <div class="meal-sec"><div class="meal-group">${j.tickets.length?j.tickets.map(t=>`
    <div class="ad-row" onclick="adTicket(${t.id})" style="cursor:pointer">
      <div class="grow"><strong>${esc(t.subject)}${+t.unread&&t.status!=='closed'?' <i class="dot-new"></i>':''}</strong>
        <small>${esc(t.author_name)} · ${esc(t.topic_label)} · ${esc((t.last_body||'').slice(0,70))}</small></div>
      <span class="ad-btn ${t.status==='closed'?'':'on'}">${
        t.status==='closed'?'Закрыто':t.status==='in_progress'?'В работе':'Новое'}</span>
    </div>`).join(''):'<div class="empty small">Обращений пока нет</div>'}</div></div>`,'chat'));
}
async function adTicket(id){
  let j;try{j=await api('/admin/support/'+id)}catch(e){toast(e.message,'err');return}
  const t=j.ticket;
  showModal(`<div class="sheet-head"><div><div class="eyebrow">${esc(t.topic_label)} · ${esc(t.author_name)}</div>
      <h2>${esc(t.subject)}</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <div class="thread-body">${j.messages.map(m=>`
    <div class="tmsg ${m.from_admin?'mine':''}">
      <div class="tm-who">${m.from_admin?'Поддержка':esc(t.author_name)}</div>
      <p>${esc(m.body)}</p>
      <time>${esc((m.created_at||'').slice(0,16).replace('T',' '))}</time>
    </div>`).join('')}</div>
  <form onsubmit="adTicketReply(event,${id})">
    <label>Ответ<textarea id="tk_b" rows="4" required placeholder="Напишите ответ — он придёт уведомлением и письмом"></textarea></label>
    <label class="chk"><input type="checkbox" id="tk_close"> Закрыть обращение после ответа</label>
    <button class="primary wide">Ответить</button>
  </form>
  ${t.status==='closed'?'':`<button class="btn-wide" onclick="adTicketStatus(${id},'closed')">Закрыть без ответа</button>`}
  <p class="muted small">Почта адресата: ${esc(t.author_email||'не указана')}. Если письма не настроены, ответ придёт только уведомлением в приложении.</p>`);
}
async function adTicketReply(e,id){
  e.preventDefault();
  const body=$('#tk_b').value.trim();
  if(!body)return;
  try{
    await api('/admin/support/'+id+'/reply',{method:'POST',
      body:JSON.stringify({body,close:$('#tk_close').checked})});
    closeModal(); adSupport();
  }catch(err){toast(err.message,'err')}
}
async function adTicketStatus(id,status){
  try{await api('/admin/support/'+id,{method:'PATCH',body:JSON.stringify({status})});closeModal();adSupport()}
  catch(e){toast(e.message,'err')}
}

/* --- Рассылка ---
   Отправленное письмо не отзовёшь, поэтому история лежит прямо под
   формой: перед отправкой видно, что и когда уже уходило. */
async function adBroadcast(){
  const j=await api('/admin/broadcasts');
  showModal(`<div class="sheet-head"><div><div class="eyebrow">Панель владельца</div>
      <h2>Написать всем</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="adSendBroadcast(event)">
    <label>Кому<select id="bc_a" onchange="adBcAud(this.value)">
      <option value="specialists">Специалистам (${j.audience.specialists})</option>
      <option value="clients">Клиентам (${j.audience.clients})</option>
      <option value="all">Всем (${j.audience.specialists+j.audience.clients})</option>
    </select></label>
    <label id="bc_seg_wrap" hidden>Кому именно<select id="bc_seg">
      <option value="">Всем клиентам</option>
      ${Object.entries(j.segments||{}).map(([k,v])=>`<option value="${k}">${esc(v)}</option>`).join('')}
    </select></label>
    <label>Заголовок<input id="bc_t" required maxlength="120" placeholder="Каталог обновлён"></label>
    <label>Текст<textarea id="bc_b" rows="6" required placeholder="Коротко и по делу — это увидят все."></textarea></label>
    <label class="chk"><input type="checkbox" id="bc_m" ${j.mail_configured?'checked':'disabled'}> Отправить ещё и письмом${
      j.mail_configured?'':' (почта не настроена — config/mail.php)'}</label>
    <label>Когда отправить<input id="bc_when" type="datetime-local"></label>
    <button class="primary wide">Отправить</button>
  </form>
  <p class="rw-foot muted">Пустое время — отправить сейчас. Письмо в три часа ночи читают хуже,
    чем в десять утра, поэтому рассылку можно отложить: её отправит крон.</p>
  <div class="sect">Что уже отправляли</div>
  <div class="meal-group">${j.broadcasts.length?j.broadcasts.map(b=>`
    <div class="hist-row"><span class="hr-date">${esc((b.created_at||'').slice(0,10))}</span>
      <div class="grow"><strong>${esc(b.title)}</strong>
        <small>${b.status==='planned'
          ? 'запланировано на '+esc(String(b.send_at||'').slice(0,16))
          : (b.audience==='specialists'?'специалистам':b.audience==='clients'?'клиентам':'всем')
            +(b.segment?' · '+esc((j.segments||{})[b.segment]||b.segment):'')
            +` · ${b.recipients} получателей`
            +(b.emails_sent?` · писем ${b.emails_sent}`:'')
            +(b.emails_failed?` · не дошло ${b.emails_failed}`:'')}</small></div>
      ${b.status==='planned'?`<button class="ad-btn danger" onclick="adBroadcastCancel(${b.id})">Отменить</button>`:''}
    </div>`).join(''):'<div class="empty small">Рассылок ещё не было</div>'}</div>`);
}
/* Сегменты бывают только у клиентов: письмо «вернитесь, вы давно не
   отмечали» специалисту не адресуешь. */
function adBcAud(v){
  const w=$('#bc_seg_wrap'); if(w)w.hidden=(v!=='clients');
}
async function adSendBroadcast(e){
  e.preventDefault();
  const audience=$('#bc_a').value, title=$('#bc_t').value.trim();
  const seg=(audience==='clients'&&$('#bc_seg'))?$('#bc_seg').value:'';
  const when=$('#bc_when')?.value||'';
  const segName=seg?($('#bc_seg').selectedOptions[0].textContent):null;
  const who=segName||{specialists:'всем специалистам',clients:'всем клиентам',all:'всем пользователям'}[audience];
  const q=when
    ? `Запланировать «${title}» (${who}) на ${when.replace('T',' ')}?`
    : `Отправить «${title}» — ${who}?\n\nОтменить отправку нельзя.`;
  if(!confirm(q))return;
  try{
    const r=await api('/admin/broadcasts',{method:'POST',body:JSON.stringify({
      audience,title,body:$('#bc_b').value.trim(),by_email:$('#bc_m').checked,
      segment:seg,send_at:when?when.replace('T',' '):''})});
    if(r.planned_at)toast('Запланировано на '+r.planned_at.slice(0,16),'ok');
    else toast(`Отправлено.\nПолучателей: ${r.recipients}`
      +(r.emails_sent?`\nПисем отправлено: ${r.emails_sent}`:'')
      +(r.emails_failed?`\nПисьма не дошли: ${r.emails_failed} — адреса могли быть неверны`:''),'ok');
    closeModal();
  }catch(err){toast(err.message,'err')}
}
async function adBroadcastCancel(id){
  if(!confirm('Отменить запланированную рассылку?'))return;
  try{ await api('/admin/broadcasts/'+id,{method:'DELETE'}); closeModal(); adBroadcast(); }
  catch(e){ toast(e.message,'err') }
}

/* ==========================================================================
   ПОДДЕРЖКА, СТОРОНА ПОЛЬЗОВАТЕЛЯ.
   Один экран на клиента и специалиста: вопросы у них разные, а порядок
   один — написали, ответили, закрыли.
   ========================================================================== */
async function supportScreen(){
  let j;try{j=await api('/support')}catch(e){toast(e.message,'err');return}
  A._tickets=j.tickets; A._topics=j.topics;
  showSheet(`<div class="sheet-head"><div><h2>Поддержка</h2>
      <p class="muted">Вопросы о сервисе. Про питание пишите специалисту в чат.</p></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <button class="primary wide" onclick="supportNew()">${icon('plus')} Новое обращение</button>
  ${j.tickets.length?`<div class="sect">Ваши обращения</div>
  <div class="meal-group">${j.tickets.map(t=>`
    <div class="ad-row" onclick="supportOpen(${t.id})" style="cursor:pointer">
      <div class="grow"><strong>${esc(t.subject)}${+t.unread?' <i class="dot-new"></i>':''}</strong>
        <small>${esc((t.last_body||'').slice(0,64))}</small></div>
      <span class="ad-btn ${t.status==='closed'?'':'on'}">${
        t.status==='closed'?'Закрыто':t.status==='in_progress'?'Ответили':'Ждёт'}</span>
    </div>`).join('')}</div>`:'<p class="muted small" style="margin-top:14px">Обращений пока не было.</p>'}`);
}
function supportNew(){
  showSheet(`<div class="sheet-head"><div><h2>Новое обращение</h2>
      <p class="muted">Опишите, что случилось — ответим на почту и в приложение.</p></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <form onsubmit="supportSend(event)">
    <label>О чём вопрос<select id="sp_t">${Object.entries(A._topics||{other:'Другое'})
      .map(([k,l])=>`<option value="${k}">${esc(l)}</option>`).join('')}</select></label>
    <label>Тема<input id="sp_s" required maxlength="120" placeholder="Коротко: что не так"></label>
    <label>Опишите подробнее<textarea id="sp_b" rows="6" required
      placeholder="Что вы делали, что ожидали и что получилось"></textarea></label>
    <button class="primary wide">Отправить</button>
  </form>`);
}
async function supportSend(e){
  e.preventDefault();
  try{
    await api('/support',{method:'POST',body:JSON.stringify({
      topic:$('#sp_t').value, subject:$('#sp_s').value.trim(), body:$('#sp_b').value.trim()})});
    closeModal(); supportScreen();
  }catch(err){toast(err.message,'err')}
}
async function supportOpen(id){
  let j;try{j=await api('/support/'+id)}catch(e){toast(e.message,'err');return}
  const t=j.ticket;
  showSheet(`<div class="sheet-head"><div><div class="eyebrow">${esc((A._topics||{})[t.topic]||'')}</div>
      <h2>${esc(t.subject)}</h2></div>
    <button class="close" aria-label="Закрыть" onclick="closeModal()">${icon('x')}</button></div>
  <div class="thread-body">${j.messages.map(m=>`
    <div class="tmsg ${m.from_admin?'':'mine'}">
      <div class="tm-who">${m.from_admin?'Поддержка':'Вы'}</div>
      <p>${esc(m.body)}</p>
      <time>${esc((m.created_at||'').slice(0,16).replace('T',' '))}</time>
    </div>`).join('')}</div>
  ${t.status==='closed'?`<p class="muted small">Обращение закрыто. Напишите — и оно откроется снова.</p>`:''}
  <form onsubmit="supportReply(event,${id})">
    <label>Дописать<textarea id="sr_b" rows="3" required placeholder="Ваше сообщение"></textarea></label>
    <button class="primary wide">Отправить</button>
  </form>
  ${t.status==='closed'?'':`<button class="btn-wide" onclick="supportClose(${id})">Вопрос решён, закрыть</button>`}`);
}
async function supportReply(e,id){
  e.preventDefault();
  try{
    await api('/support/'+id+'/reply',{method:'POST',body:JSON.stringify({body:$('#sr_b').value.trim()})});
    supportOpen(id);
  }catch(err){toast(err.message,'err')}
}
async function supportClose(id){
  try{await api('/support/'+id+'/close',{method:'POST'});supportScreen()}
  catch(e){toast(e.message,'err')}
}

/* ==========================================================================
   ПРЕДЛОЖЕНИЕ ПОСТАВИТЬ НА ЭКРАН «ДОМОЙ».

   На iPhone приложения EQUA в App Store нет, и веб-версия — единственный
   способ. Safari сам ставить не предлагает: пользователь должен знать
   про «Поделиться» → «На экран Домой», а он не знает.

   Показываем один раз и мягко: не поверх работы, а полосой снизу, и
   только тому, кто уже вошёл. Отказ запоминаем — второй раз с тем же
   предложением лезть нельзя.
   ========================================================================== */
const A2HS_KEY='nm_a2hs';

function a2hsStandalone(){
  return matchMedia('(display-mode: standalone)').matches || navigator.standalone===true;
}
function a2hsIOS(){
  const ua=navigator.userAgent;
  /* iPadOS с 13-й версии представляется Mac'ом, отличаем по тач-вводу. */
  const ios=/iPhone|iPod/.test(ua)||(/iPad|Macintosh/.test(ua)&&navigator.maxTouchPoints>1);
  /* В Chrome и Firefox на iOS пункта «На экран Домой» нет — предлагать
     нечего, только раздражать. */
  return ios && /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS|YaBrowser/.test(ua);
}
function a2hsDismissed(){
  try{
    const v=localStorage.getItem(A2HS_KEY);
    if(!v)return false;
    if(v==='installed')return true;
    /* Отложенное предложение возвращаем через месяц: за это время
       человек успевает понять, нужен ли ему сервис каждый день. */
    return Date.now()-(+v||0) < 30*24*3600*1000;
  }catch(e){return true}
}
function a2hsRemember(v){try{localStorage.setItem(A2HS_KEY,v)}catch(e){}}

/* Android и десктопный Chrome дают событие — тогда установка в одно
   нажатие, без объяснений. */
let a2hsPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault(); a2hsPrompt=e;
  if(!a2hsDismissed()&&A.token) a2hsShow(false);
});
window.addEventListener('appinstalled',()=>{a2hsRemember('installed');a2hsHide()});

function a2hsHide(){
  const el=$('#a2hs'); if(!el)return;
  el.classList.remove('on');
  setTimeout(()=>el.remove(),260);
}
function a2hsShow(manual){
  if($('#a2hs')||a2hsStandalone())return;
  const ios=a2hsIOS();
  if(!ios&&!a2hsPrompt)return;              // ставить нечем и объяснять нечего
  const el=document.createElement('div');
  el.id='a2hs'; el.className='a2hs';
  el.innerHTML=`
    <span class="a2hs-ic">${icon('add')}</span>
    <div class="grow">
      <strong>EQUA на экран «Домой»</strong>
      <small>${ios
        ? 'Кнопка «Поделиться» внизу → «На экран „Домой“»'
        : 'Откроется как приложение и будет под рукой.'}</small>
    </div>
    ${ios?'':'<button class="a2hs-go">Установить</button>'}
    <button class="a2hs-x" aria-label="Закрыть">${icon('x')}</button>`;
  document.body.appendChild(el);
  requestAnimationFrame(()=>el.classList.add('on'));
  el.querySelector('.a2hs-x').onclick=()=>{a2hsRemember(String(Date.now()));a2hsHide()};
  const go=el.querySelector('.a2hs-go');
  if(go)go.onclick=async()=>{
    a2hsHide();
    try{ await a2hsPrompt.prompt(); const r=await a2hsPrompt.userChoice;
         a2hsRemember(r.outcome==='accepted'?'installed':String(Date.now())); }
    catch(e){}
    a2hsPrompt=null;
  };
}

/* На iOS события установки нет — показываем сами, но не в первую
   секунду: человек пришёл смотреть меню, а не ставить приложение. */
function a2hsMaybe(){
  if(a2hsStandalone()||a2hsDismissed()||!a2hsIOS())return;
  setTimeout(()=>{ if(A.token&&!$('#a2hs')) a2hsShow(false); },12000);
}

/* ==========================================================================
   ГОТОВНОСТЬ К РАБОТЕ С ЖИВЫМИ ЛЮДЬМИ.

   Почта, реквизиты в документах, пароль и копия базы настраиваются один
   раз руками на хостинге — и ровно поэтому забываются. Узнать о
   пропущенном от первого пользователя, который не смог восстановить
   пароль, — плохой способ. Пока всё в порядке, карточки нет.
   ========================================================================== */
function adReadinessCard(){
  const r=A._ready;
  if(!r||!r.items)return '';
  const bad=r.items.filter(x=>!x.ok);
  if(!bad.length)return '';
  return adPanel('Перед тем как звать людей',null,
    `<div class="ready-list">${bad.map(x=>`
      <div class="ready-row">
        <span class="ready-ic">${icon('warn')}</span>
        <div class="grow">
          <strong>${esc(x.title)}</strong>
          <p>${esc(x.why)}</p>
          ${x.how?`<small>${esc(x.how)}</small>`:''}
        </div>
      </div>`).join('')}</div>`);
}


/* ---------------------------------------------------------------------
   ОЖИДАНИЕ И ОШИБКА НА ЭКРАНАХ
   Экраны берут данные по-разному, но вести себя должны одинаково: пока
   ответа нет — форма будущего содержимого, если ответа не будет —
   объяснение и кнопка «Повторить». До этого неудачный запрос не делал
   ничего: человек жал на вкладку, и экран просто не менялся.
   Оборачиваем в одном месте, а не правим три десятка функций: так
   поведение не разъедется, когда появится следующий экран.
   --------------------------------------------------------------------- */
const skel=(n=3)=>`<div class="skel">${Array.from({length:n},(_,i)=>`<div class="skel-row${i?'':' tall'}"></div>`).join('')}</div>`;

function screenError(msg,offline,host){
  const box=`<div class="empty screen-err">
    <span class="orb">${icon('warn')}</span>
    <h3>${offline?'Нет связи':'Не удалось загрузить'}</h3>
    <p>${esc(msg||'Попробуйте ещё раз.')}</p>
    <div class="empty-btns"><button class="primary green" onclick="retryScreen()">Повторить</button></div>
  </div>`;
  const el=(host&&$(host))||document.querySelector(SHELL_MAIN);
  if(el){el.innerHTML=box;return}
  $('#app').innerHTML=`<div class="shell"><main class="main">${box}</main></div>`;
}
function retryScreen(){const f=A._retry;if(typeof f==='function')f()}

function wrapScreen(name,tab){
  const f=window[name]; if(typeof f!=='function'||f._wrapped)return;
  const w=async function(...a){
    A._retry=()=>w.apply(this,a);
    /* Вкладку подсвечиваем сразу, поэтому и её содержимое должно сразу
       перестать быть содержимым прошлой вкладки. */
    if(tab){const h=$('#tabbody');if(h)h.innerHTML=skel(3)}
    try{ return await f.apply(this,a) }
    catch(e){ screenError(e&&e.message,!!(e&&e.offline),tab?'#tabbody':null) }
  };
  w._wrapped=true; window[name]=w;
}
'spHome spClients spClient clHealth spIngredients spTemplates spAnalytics spChatList spDishes spProfile clToday clDish clWeek clProfile clFindSpecialist clProgress adPeople adDishes feedScreen adPosts clChat clShopping adMore adOverview spServices clServices adIngredients adSupport spBalance adFinance infoScreen adInfo clSpecProfile'
  .split(' ').forEach(n=>wrapScreen(n,false));
'spTabHealth spTabTasks spTabOverview spTabMenu spTabProfile spTabProgress spTabActivity spTabChat'
  .split(' ').forEach(n=>wrapScreen(n,true));


/* Сообщения показываем полосой внизу, а не системным окном: alert
   останавливает всё до нажатия «ОК», а на телефоне ещё и накрывает то
   место, о котором говорит. Полоса сама уходит через несколько секунд и
   не мешает продолжать. */
let _toastT=null;
function toast(msg,kind='err'){
  /* Галочку в тексте убираем: её же рисует значок слева. */
  msg=String(msg==null?'':msg).trim().replace(/\s*✓$/,''); if(!msg)return;
  /* Получилось или нет — палец узнаёт об этом раньше, чем глаз найдёт
     всплывшую подсказку. */
  haptic(kind==='ok'?'ok':'err');
  let el=$('#toast');
  if(!el){
    el=document.createElement('div'); el.id='toast'; el.setAttribute('role','status');
    el.addEventListener('click',()=>el.classList.remove('show'));
    document.body.appendChild(el);
  }
  el.innerHTML=`<span class="t-ic">${icon(kind==='ok'?'check':'warn')}</span><span>${esc(msg)}</span>`;
  el.className='t-'+kind;
  /* Перерисовка нужна, чтобы полоса заехала заново, а не осталась стоять,
     когда второе сообщение приходит следом за первым. */
  void el.offsetWidth; el.classList.add('show');
  clearTimeout(_toastT);
  _toastT=setTimeout(()=>el.classList.remove('show'),kind==='ok'?2600:4200);
}
