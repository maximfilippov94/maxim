/* ======================================================================
   Слой Telegram Mini App.

   Внутри Telegram открывается тот же самый SPA, что и в браузере, —
   отдельного клиента у нас нет и не будет: каждый лишний клиент пришлось
   бы чинить отдельно. Этот файл только объясняет приложению, что оно
   внутри Telegram, и снимает четыре расхождения:

     1. Вход. Пароля нет: личность подтверждает подпись Telegram.
     2. Кнопка «назад». У Telegram своя, системная. Две кнопки назад на
        одном экране — верный способ нажать не ту.
     3. Сервис-воркер. В Telegram он или не работает, или держит чужой
        кэш, и правки перестают доезжать. Отключаем.
     4. Высота окна. Telegram отдаёт свою — клавиатура и шапка съедают
        часть экрана, и 100vh врёт.

   Тему оставляем свою. Telegram даёт цвета пользовательской темы, но
   наши палитры проверены на контраст, а чужая тема эти проверки обходит:
   человек с кастомной темой получил бы серый текст на сером фоне, и мы
   бы об этом не узнали. Синхронизируем только цвет шапки, чтобы полоса
   Telegram не висела чужим цветом над нашим экраном.
   ================================================================== */
(function(){
  const TG = window.Telegram && window.Telegram.WebApp;
  /* Внутри Telegram мы, только если есть подписанная строка. Пустой
     объект WebApp появляется и в обычном браузере, если скрипт Telegram
     подключён, — по нему судить нельзя. */
  const inside = !!(TG && TG.initData && TG.initData.length > 0);
  window.TG_MINIAPP = inside;
  if (!TG) return;

  /* Приложение узнаёт о Telegram отсюда, а не из своих проверок:
     одно место на весь файл app.js. */
  if (typeof A === 'object' && A) A.tg = inside ? TG : null;

  if (!inside) return;

  document.documentElement.classList.add('tg-mini');

  try { TG.ready(); TG.expand(); } catch (e) {}

  /* Свайп вниз закрывает Mini App. У нас свайпом листают вкладки и
     закрывают карточки — жест бы срабатывал вместо нашего. */
  try { if (TG.disableVerticalSwipes) TG.disableVerticalSwipes(); } catch (e) {}

  /* Высота окна у Telegram своя: шапка и клавиатура отъедают часть, и
     100vh показывает больше, чем видно. Кладём настоящую высоту в
     переменную — вёрстка берёт её оттуда. */
  const setH = () => {
    const h = TG.viewportStableHeight || TG.viewportHeight || window.innerHeight;
    document.documentElement.style.setProperty('--tg-vh', h + 'px');
  };
  setH();
  try { TG.onEvent('viewportChanged', setH); } catch (e) {}

  /* Цвет шапки — наш, чтобы полоса Telegram не спорила с экраном.
     Значение берём из вычисленного фона: так оно не разойдётся с темой,
     когда её поменяют в «Оформлении». */
  const paintHeader = () => {
    try {
      /* Фон у body прозрачный — он нарисован на html, и с body мы
         получали чёрный вместо тёмно-синего. Берём первый непрозрачный
         из трёх источников, последним — переменную темы. */
      const solid = v => v && !/rgba\(0,\s*0,\s*0,\s*0\)|transparent/.test(v);
      const cs = getComputedStyle(document.documentElement);
      let bg = cs.backgroundColor;
      if (!solid(bg)) bg = getComputedStyle(document.body).backgroundColor;
      if (!solid(bg)) bg = cs.getPropertyValue('--color-bg') || cs.getPropertyValue('--bg');
      const hex = rgbToHex(bg) || (String(bg).trim().match(/^#[0-9a-f]{6}$/i) ? bg.trim() : null);
      if (!hex) return;
      if (TG.setHeaderColor) TG.setHeaderColor(hex);
      if (TG.setBackgroundColor) TG.setBackgroundColor(hex);
    } catch (e) {}
  };
  function rgbToHex(v) {
    const m = String(v).match(/(\d+)[,\s]+(\d+)[,\s]+(\d+)/);
    if (!m) return null;
    return '#' + [1, 2, 3].map(i => (+m[i]).toString(16).padStart(2, '0')).join('');
  }
  window.tgPaintHeader = paintHeader;
  setTimeout(paintHeader, 0);
  /* Тему меняют в «Оформлении» — перекрашиваем вслед за атрибутом. */
  try {
    new MutationObserver(paintHeader).observe(document.documentElement,
      { attributes: true, attributeFilter: ['data-theme'] });
  } catch (e) {}

  /* --- Системная кнопка «назад» ---
     Наши экраны прячут свою кнопку (правило в app-parity.css по классу
     .tg-mini), а нажатие системной отдаём тому же обработчику: иначе
     «назад» вело бы из приложения наружу. */
  const backBtn = TG.BackButton;
  /* Своя кнопка «назад» на экране — значит, есть куда возвращаться.
     Видимость проверяем по-настоящему: разметка навбара остаётся и на
     корневых экранах, просто сама кнопка там не нарисована, и по одному
     только наличию узла системная кнопка висела бы всегда. */
  const ownBack = () => {
    const sel = '.navbar .nb-back, .ad-crumbs, .viewer-top .close, .chat-close, .thread-back';
    for (const el of document.querySelectorAll(sel)) {
      /* Уходящий экран ещё триста миллисекунд живёт копией в body —
         это перелистывание. Кнопка внутри копии уже ничего не открывает,
         и по ней системная «назад» оставалась висеть на корневом экране. */
      if (el.closest('.page-ghost')) continue;
      const cs = getComputedStyle(el);
      if (cs.display !== 'none' && cs.visibility !== 'hidden' && el.offsetParent !== null) return el;
      /* Свою кнопку навбара мы прячем сами — но возвращаться по ней всё
         равно есть куда, поэтому она считается. */
      if (el.classList.contains('nb-back')) return el;
    }
    return null;
  };
  const syncBack = () => {
    if (!backBtn) return;
    try { ownBack() ? backBtn.show() : backBtn.hide(); } catch (e) {}
  };
  window.tgSyncBack = syncBack;
  if (backBtn) {
    try {
      backBtn.onClick(() => {
        /* Открытый лист закрываем первым: системная кнопка при открытом
           листе должна убирать лист, а не уводить с экрана под ним. */
        if (typeof closeModal === 'function' && document.querySelector('#modal')) {
          closeModal(); syncBack(); return;
        }
        const own = ownBack();
        if (own) { own.click(); return; }
        history.back();
      });
    } catch (e) {}
  }

  /* Отклик на нажатие — системный, а не наш: внутри Telegram он совпадает
     с тем, как отзывается сам мессенджер. */
  window.tgHaptic = kind => {
    try {
      const h = TG.HapticFeedback;
      if (!h) return;
      if (kind === 'ok') h.notificationOccurred('success');
      else if (kind === 'err') h.notificationOccurred('error');
      else h.impactOccurred('light');
    } catch (e) {}
  };

  /* --- Вход ---
     Возвращает true, если вошли: тогда app.js не показывает форму
     с почтой и паролем, которых у пришедшего из Telegram нет. */
  window.tgSignIn = async function () {
    try {
      const r = await api('/auth/telegram', {
        method: 'POST',
        body: JSON.stringify({ init_data: TG.initData }),
      });
      if (!r || !r.token) return false;
      saveAuth(r);
      A._tgLinked = r.linked_specialist || null;
      return true;
    } catch (e) {
      /* Не вышло — показываем обычный вход: человек хотя бы попадёт
         внутрь по паролю, если он у него есть. */
      A._authError = e.message;
      return false;
    }
  };
})();
