<?php
declare(strict_types=1);require __DIR__.'/../config/config.php';

/* --- Ответ всегда JSON -------------------------------------------------
   Без этого любой сбой внутри маршрута отдавал страницу с текстом ошибки
   PHP или вовсе пустоту, а приложение показывало безликое «Ошибка
   сервера» — по такому сообщению не понять ни что сломалось, ни где.
   Теперь причина доходит до человека, который жмёт кнопку. */
ini_set('display_errors','0');   // вывод ошибок сломал бы JSON — причина уходит в ответ ниже
set_exception_handler(function(\Throwable $e){
  error_log('API '.($_SERVER['REQUEST_URI']??'').': '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine());
  if(!headers_sent())json_response(['error'=>'Сбой на сервере: '.$e->getMessage(),
    'where'=>basename($e->getFile()).':'.$e->getLine()],500);
});
register_shutdown_function(function(){
  $e=error_get_last();
  if($e&&in_array($e['type'],[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR],true)&&!headers_sent())
    json_response(['error'=>'Сбой на сервере: '.$e['message'],
      'where'=>basename($e['file']).':'.$e['line']],500);
});
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)??'/';$path=preg_replace('#^.*/api/v1#','',$path);$method=$_SERVER['REQUEST_METHOD'];
function specialist():array{return require_role('specialist');}function client():array{return require_role('client');}
function ownedClient(int $cid,int $sid):array{$q=db()->prepare('SELECT * FROM clients WHERE id=? AND specialist_id=?');$q->execute([$cid,$sid]);$r=$q->fetch();if(!$r)json_response(['error'=>'Клиент не найден'],404);return $r;}
function ownedMenu(int $mid,int $sid):array{$q=db()->prepare('SELECT m.*,c.name client_name,c.target_kcal,c.target_protein,c.target_fat,c.target_carbs FROM menus m JOIN clients c ON c.id=m.client_id WHERE m.id=? AND m.specialist_id=?');$q->execute([$mid,$sid]);$r=$q->fetch();if(!$r)json_response(['error'=>'Меню не найдено'],404);return $r;}
function menuItems(int $mid):array{$q=db()->prepare('SELECT mi.*,d.name dish_name,d.instructions,d.photo_url,d.photo_thumb_url,d.base_portion_g FROM menu_items mi JOIN dishes d ON d.id=mi.dish_id WHERE mi.menu_id=? ORDER BY day_number,sort_order,id');$q->execute([$mid]);$a=$q->fetchAll();foreach($a as &$x)$x['nutrition']=nutrition((int)$x['dish_id'],(float)$x['portion_g'],$x['overrides']);return $a;}
/* Итоги дня. По умолчанию — весь план: столько получится, если съесть
   всё назначенное. С $eatenOnly считаются только отмеченные приёмы —
   это то, что человек уже съел, и только от него имеет смысл «осталось».
   Пропущенные не в счёт: пропуск — это не еда. */
function totals(array $items,int $day,bool $eatenOnly=false):array{$a=['kcal'=>0,'protein'=>0,'fat'=>0,'carbs'=>0];foreach($items as $x){if((int)$x['day_number']!==$day)continue;if($eatenOnly&&($x['log_status']??null)!=='eaten')continue;foreach($a as $k=>$v)$a[$k]+=$x['nutrition'][$k]??0;}foreach($a as $k=>$v)$a[$k]=round($v,1);return $a;}
function menuPayload(array $menu,array $items):array{$days=[];for($d=1;$d<=(int)$menu['days_count'];$d++)$days[$d]=totals($items,$d);return ['menu'=>$menu,'items'=>$items,'days'=>$days];}

/* --- Атрибуция клиента ------------------------------------------------
   Источник связи определяет ставку комиссии и восстановлению задним числом
   не подлежит, поэтому пишется в момент связывания — во всех четырёх местах,
   где связь может возникнуть. Повторная запись источник не переписывает:
   первый ответ и есть правда. */
function clientBelongsToSpecialist(int $cid,int $sid):void{ ownedClient($cid,$sid); }
function createNotification(int $cid,string $type,string $title,string $body):void{db()->prepare('INSERT INTO notifications(client_id,type,title,body,created_at) VALUES(?,?,?,?,?)')->execute([$cid,$type,$title,$body,now()]);}
function publicAppUrl():string{ $https=(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')||((int)($_SERVER['SERVER_PORT']??0)===443);$host=$_SERVER['HTTP_HOST']??'localhost';return ($https?'https://':'http://').$host; }
/* --- Список покупок ---------------------------------------------------
   Агрегируем ингредиенты меню в один список. Раньше эта выкладка была
   скопирована в трёх местах и уже начала расходиться (в одной копии не
   округлялись граммы и терялась категория «Прочее»). */
/**
 * Сколько этого купить — словами, которыми говорят в магазине.
 *
 * «Яйцо куриное — 667 г» и «Молоко — 1296 г» формально верны и
 * бесполезны: яйца считают штуками, жидкость берут литрами, а больше
 * килограмма пишут в килограммах. Пересчёт делаем здесь, в одном
 * месте, чтобы веб и приложение показывали одно и то же.
 *
 * Штуки округляем вверх: половину яйца в магазине не продадут.
 */
function shoppingAmount(array $x):array{
  $g=(float)$x['grams'];
  $unit=(string)($x['unit']??'g');
  $piece=$x['piece_g']!==null?(float)$x['piece_g']:null;

  if($unit==='pc'&&$piece&&$piece>0){
    $n=max(1,(int)ceil($g/$piece));
    $a=$n%100; $b=$a%10;
    $w=($a>10&&$a<20)?'штук':($b===1?'штука':(($b>1&&$b<5)?'штуки':'штук'));
    return ['value'=>$n,'unit'=>'шт','text'=>$n.' '.$w];
  }
  if($unit==='ml'){
    /* Для покупки миллилитры и граммы считаем равными: разница в
       плотности меньше, чем шаг фасовки. */
    if($g>=1000){ $l=round($g/1000,1); return ['value'=>$l,'unit'=>'л','text'=>rtrim(rtrim(number_format($l,1,',',''),'0'),',').' л']; }
    return ['value'=>round($g),'unit'=>'мл','text'=>round($g).' мл'];
  }
  if($g>=1000){
    $kgv=round($g/1000,1);
    return ['value'=>$kgv,'unit'=>'кг','text'=>rtrim(rtrim(number_format($kgv,1,',',''),'0'),',').' кг'];
  }
  /* До килограмма округляем до десятков: «326 г» — точность, которой
     в магазине всё равно не будет. */
  $r=(int)(ceil($g/10)*10);
  return ['value'=>$r,'unit'=>'г','text'=>$r.' г'];
}

function shoppingAggregate(int $menuId,?int $days=null):array{
  $pdo=db();$agg=[];
  $dq=$pdo->prepare('SELECT base_portion_g FROM dishes WHERE id=?');
  $iq=$pdo->prepare("SELECT di.grams,i.name,i.category,COALESCE(i.unit,'g') unit,i.piece_g FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=?");
  foreach(menuItems($menuId) as $it){
    if($days!==null&&(int)$it['day_number']>$days)continue;
    $dq->execute([$it['dish_id']]);$scale=(float)$it['portion_g']/max(1,(float)$dq->fetchColumn());
    $iq->execute([$it['dish_id']]);
    foreach($iq->fetchAll() as $r){
      $key=mb_strtolower($r['name']);
      if(!isset($agg[$key]))$agg[$key]=['key'=>$key,'name'=>$r['name'],'category'=>$r['category']?:'Прочее',
        'grams'=>0,'unit'=>$r['unit'],'piece_g'=>$r['piece_g']!==null?(float)$r['piece_g']:null];
      $agg[$key]['grams']+=(float)$r['grams']*$scale;
    }
  }
  $list=array_values($agg);
  foreach($list as &$x){ $x['grams']=round($x['grams']); $x['amount']=shoppingAmount($x); }
  unset($x);
  usort($list,fn($a,$b)=>strcmp($a['category'].$a['name'],$b['category'].$b['name']));
  return $list;
}
/* Отметки «куплено» лежат в БД по ключу ингредиента, а не в localStorage:
   список одинаков на всех устройствах клиента, и специалист видит прогресс. */
function shoppingWithChecks(int $clientId,int $menuId,array $list):array{
  $q=db()->prepare('SELECT ingredient_name FROM shopping_items WHERE client_id=? AND menu_id=? AND checked=1');
  $q->execute([$clientId,$menuId]);
  $done=[];foreach($q->fetchAll() as $r)$done[$r['ingredient_name']]=true;
  foreach($list as &$x)$x['checked']=isset($done[$x['key']])?1:0;unset($x);
  return $list;
}
function shoppingMenu(int $clientId):?array{
  $q=db()->prepare('SELECT * FROM menus WHERE client_id=? AND status="published" ORDER BY id DESC LIMIT 1');
  $q->execute([$clientId]);return $q->fetch()?:null;
}
/* ==========================================================================
   ПРАЙС СПЕЦИАЛИСТА
   Деньги пока не принимаются: это витрина услуг и подготовка к оплате.
   Суммы везде в копейках (*_kop) — целыми, без плавающей точки.
   ========================================================================== */
function serviceKinds():array{return ['one_time','subscription'];}
/* Продукт наружу: без служебных полей, зато с тем, что нужно экрану
   выбора — сколько весит штука и порция с упаковки. */
function foodPublic(array $r):array{
  return ['id'=>(int)$r['id'],'name'=>$r['name'],'category'=>$r['category']??null,
    'brand'=>$r['brand']??null,'barcode'=>$r['barcode']??null,
    'kcal'=>round((float)($r['kcal']??0),1),'protein'=>round((float)($r['protein']??0),1),
    'fat'=>round((float)($r['fat']??0),1),'carbs'=>round((float)($r['carbs']??0),1),
    'fiber'=>round((float)($r['fiber']??0),1),
    'unit'=>$r['unit']??'g',
    'piece_g'=>isset($r['piece_g'])&&$r['piece_g']!==null?(float)$r['piece_g']:null,
    'per_serving_g'=>isset($r['per_serving_g'])&&$r['per_serving_g']!==null?(float)$r['per_serving_g']:null];
}
function servicePublic(array $r):array{
  return ['id'=>(int)$r['id'],'title'=>$r['title'],'description'=>$r['description'],
    'kind'=>$r['kind'],'price_kop'=>(int)$r['price_kop'],
    'period_days'=>$r['period_days']===null?null:(int)$r['period_days'],
    'duration_min'=>isset($r['duration_min'])&&$r['duration_min']!==null?(int)$r['duration_min']:null,
    'is_active'=>(int)$r['is_active'],'sort_order'=>(int)$r['sort_order']];
}
/* Из формы приходят рубли, в базе копейки. Разбор здесь один на все методы,
   чтобы «199,90» и «199.9» не превращались в разные суммы. */
function servicePrice($v):int{
  $s=str_replace([' ',"\xC2\xA0",','],['','','.'],trim((string)$v));
  if(!is_numeric($s))json_response(['error'=>'Цена указана неверно'],422);
  $kop=(int)round((float)$s*100);
  if($kop<10000)json_response(['error'=>'Минимальная цена — 100 ₽'],422);
  if($kop>100000000)json_response(['error'=>'Слишком большая цена'],422);
  return $kop;
}
function serviceInput(array $in,bool $isNew):array{
  $title=trim((string)($in['title']??''));
  if($isNew&&$title==='')json_response(['error'=>'Название услуги обязательно'],422);
  $kind=in_array($in['kind']??'',serviceKinds(),true)?$in['kind']:'one_time';
  $period=null;
  if($kind==='subscription'){
    /* Не дольше месяца: платёжный сервис держит деньги ограниченный
       срок, и подписка на полгода означала бы, что незаработанную часть
       уже нечем вернуть клиенту. */
    $period=(int)($in['period_days']??30);
    if($period<7||$period>31)
      json_response(['error'=>'Период подписки — от 7 до 31 дня. Дольше месяца нельзя: столько деньги у платёжного сервиса не держатся'],422);
  }
  /* Сколько длится разовая услуга. В карточке каталога это стоит рядом
     с ценой: «Разбор рациона · 3000 ₽ · 60 мин.» — по одной цене без
     длительности сравнить двух специалистов нельзя. У подписки
     длительности нет, там мера — период. */
  $dur=null;
  if($kind!=='subscription'&&array_key_exists('duration_min',$in)&&trim((string)$in['duration_min'])!==''){
    $dur=(int)$in['duration_min'];
    if($dur<5||$dur>600)json_response(['error'=>'Длительность — от 5 до 600 минут'],422);
  }
  return ['title'=>mb_substr($title,0,120),'description'=>mb_substr(trim((string)($in['description']??'')),0,600),
    'kind'=>$kind,'period_days'=>$period,'duration_min'=>$dur];
}
try{$pdo=db();
/* --- Уведомления эквайера ---------------------------------------------
   Без авторизации: эквайер наших токенов не носит, подлинность
   проверяет подписью сам провайдер в parseWebhook. Отвечаем 200 почти
   всегда — на любой другой код уведомление будет приходить снова, а
   разбирать его повторно нам нечем: в журнале оно уже есть. */
/* --- EQUA info ---------------------------------------------------------
   Один раздел для всех ролей: рассказ о сервисе и его обновления.
   Кому что показывать, решает audience — специалисту незачем читать
   новость про награды клиентов, и наоборот. */
if($method==='GET'&&$path==='/info'){
  $a=auth();
  $role=$a['user_type']==='specialist'?'specialist':($a['user_type']==='client'?'client':'all');
  $q=$pdo->prepare("SELECT id,kind,title,body,created_at FROM info_posts
                     WHERE is_published=1 AND (audience='all' OR audience=?)
                     ORDER BY kind='about' DESC, sort_order, id DESC");
  $q->execute([$role]);
  $rows=$q->fetchAll();
  json_response([
    'about'  =>array_values(array_filter($rows,fn($r)=>$r['kind']==='about')),
    'updates'=>array_values(array_filter($rows,fn($r)=>$r['kind']!=='about')),
  ]);
}

if($method==='POST'&&preg_match('#^/payments/webhook/([a-z0-9_-]{1,32})$#',$path,$m)){
  $body=file_get_contents('php://input')?:'';
  if(strlen($body)>262144)json_response(['error'=>'Слишком большое уведомление'],413);
  $r=webhookReceive($m[1],$body,function_exists('getallheaders')?(getallheaders()?:[]):[]);
  json_response(['ok'=>true],$r['ok']?200:202);
}

if($method==='POST'&&$path==='/auth/register'){ $in=input();$email=trim((string)($in['email']??''));$name=trim((string)($in['name']??''));$pass=(string)($in['password']??'');if(!filter_var($email,FILTER_VALIDATE_EMAIL)||!$name||!password_ok($pass))json_response(['error'=>'Нужны имя, корректный email и пароль от 8 символов с цифрой'],422);
 /* Клиент заводит себя сам — без специалиста: найдёт его позже по коду
    или в каталоге. Раньше эту учётку мог создать только специалист. */
 if(($in['role']??'')==='client'){ $pdo=db();
   $q=$pdo->prepare('SELECT 1 FROM clients WHERE lower(email)=lower(?)');$q->execute([$email]);
   $q2=$pdo->prepare('SELECT 1 FROM specialists WHERE lower(email)=lower(?)');$q2->execute([$email]);
   if($q->fetch()||$q2->fetch())json_response(['error'=>'Email уже зарегистрирован'],422);
   $a=is_array($in['profile']??null)?$in['profile']:[];
   $t=estimateTargets($a);
   $pdo->prepare('INSERT INTO clients(specialist_id,name,email,password_hash,sex,birth_year,height_cm,weight_kg,activity_level,goal,target_kcal,target_protein,target_fat,target_carbs,status,created_at) VALUES(NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
     ->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT),
       ($a['sex']??null)==='m'?'m':(($a['sex']??null)==='f'?'f':null),
       !empty($a['age'])?(int)date('Y')-(int)$a['age']:null,
       $a['height_cm']??null,$a['weight_kg']??null,$a['activity_level']??null,$a['goal']??null,
       $t['target_kcal']??null,$t['target_protein']??null,$t['target_fat']??null,$t['target_carbs']??null,
       'active',now()]);
   $cid=(int)$pdo->lastInsertId();
   if($a){$pdo->prepare('INSERT INTO client_onboarding(client_id,answers_json,completed_at,updated_at) VALUES(?,?,?,?) ON CONFLICT(client_id) DO UPDATE SET answers_json=excluded.answers_json,updated_at=excluded.updated_at')
     ->execute([$cid,json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),now(),now()]);}
   if(!empty($a['weight_kg']))$pdo->prepare('INSERT OR IGNORE INTO weight_logs(client_id,weight_kg,measured_on) VALUES(?,?,?)')->execute([$cid,(float)$a['weight_kg'],date('Y-m-d')]);
   $tok=sessionStart('client',(int)$cid);
   json_response(['token'=>$tok,'user_type'=>'client','user_id'=>$cid,'name'=>$name],201);
 }
 $prof=in_array($in['profession']??'',['nutritionist','trainer','coach'],true)?$in['profession']:'nutritionist';try{db()->prepare('INSERT INTO specialists(email,password_hash,name,profession,source,created_at) VALUES(?,?,?,?,?,?)')->execute([$email,password_hash($pass,PASSWORD_DEFAULT),$name,$prof,signupSource($in),now()]);}catch(PDOException $e){json_response(['error'=>'Email уже зарегистрирован'],422);} $id=(int)db()->lastInsertId();$t=sessionStart('specialist',(int)$id);json_response(['token'=>$t,'user_type'=>'specialist','user_id'=>$id,'name'=>$name],201);}
/* --- Вход через Apple, Google и VK -------------------------------------
   Обмен кодом делает сервер: секрет провайдера на устройство не уезжает,
   а приложение и браузер ходят одним и тем же путём. Кнопки показываются
   только для настроенных провайдеров — см. config/oauth.php. */
if($method==='GET'&&$path==='/auth/providers'){ json_response(['providers'=>oauthProviders()]); }

if($method==='GET'&&preg_match('#^/auth/oauth/(apple|google|vk)/start$#',$path,$m)){
  $prov=$m[1];
  if(!oauthReady($prov))json_response(['error'=>'Вход через '.$prov.' ещё не настроен'],404);
  $target=(string)($_GET['target']??'web');
  if(oauthTarget($target)===null)json_response(['error'=>'Неизвестный адрес возврата'],422);
  $state=token(16);$verifier=token(32);
  db()->prepare('INSERT INTO oauth_states(state,provider,verifier,target,created_at) VALUES(?,?,?,?,?)')
     ->execute([$state,$prov,$verifier,$target,now()]);
  /* Хвосты незавершённых входов копятся молча — подчищаем на входе */
  db()->prepare("DELETE FROM oauth_states WHERE created_at < ?")
     ->execute([gmdate('Y-m-d H:i:s',time()-3600)]);
  header('Location: '.oauthAuthorizeUrl($prov,$state,$verifier),true,302);
  exit;
}

if(($method==='GET'||$method==='POST')&&preg_match('#^/auth/oauth/(apple|google|vk)/callback$#',$path,$m)){
  $prov=$m[1];
  $req=$method==='POST'?$_POST:$_GET;
  $state=(string)($req['state']??'');
  $q=db()->prepare('SELECT * FROM oauth_states WHERE state=? AND provider=?');
  $q->execute([$state,$prov]);$st=$q->fetch();
  $back=$st?oauthTarget((string)$st['target']):oauthTarget('web');
  $fail=function(string $why)use($back){
    header('Location: '.$back.(str_contains((string)$back,'?')?'&':'?').'auth_error='.rawurlencode($why),true,302);
    exit;
  };
  if(!$st)$fail('Ссылка устарела, попробуйте войти заново');
  db()->prepare('DELETE FROM oauth_states WHERE state=?')->execute([$state]);
  if(!empty($req['error']))$fail('Вход отменён');
  $code=(string)($req['code']??'');
  if($code==='')$fail('Провайдер не вернул код');
  try{
    $st['state']=$state;
    [$uid,$email,$name]=oauthFetchProfile($prov,$code,$st,$req);
    $r=oauthSignIn($prov,$uid,$email,$name);
  }catch(Throwable $e){error_log('oauth '.$prov.': '.$e->getMessage());$fail($e->getMessage());}
  $sep=str_contains((string)$back,'?')?'&':'?';
  header('Location: '.$back.$sep.'token='.rawurlencode($r['token']).'&user_type='.$r['user_type'],true,302);
  exit;
}

/* Перебор пароля здесь ничем не ограничивался, хотя восстановление
   пароля защищено с самого начала. В базе данные о здоровье, поэтому
   считаем неудачные попытки по адресу и по IP. */
if($method==='POST'&&$path==='/auth/login'){
  $in=input();
  $email=trim((string)($in['email']??''));
  $pass=(string)($in['password']??'');
  $lip=(string)($_SERVER['REMOTE_ADDR']??'');
  if($wait=loginBlocked(mb_strtolower($email),$lip))
    json_response(['error'=>'Слишком много попыток. Попробуйте '.waitWord($wait).'.'],429);
  $q=db()->prepare('SELECT * FROM admins WHERE email=?');$q->execute([$email]);$u=$q->fetch();$type='admin';if(!$u){$q=db()->prepare('SELECT * FROM specialists WHERE email=?');$q->execute([$email]);$u=$q->fetch();$type='specialist';}if(!$u){$q=db()->prepare('SELECT * FROM clients WHERE email=?');$q->execute([$email]);$u=$q->fetch();$type='client';}if(!$u||!$u['password_hash']||!password_verify($pass,$u['password_hash'])){
    loginFailed(mb_strtolower($email),$lip);
    json_response(['error'=>'Неверный email или пароль'],422);
  }
  loginOk(mb_strtolower($email));
  if($type!=='admin'&&($u['status']??'active')==='blocked')
    json_response(['error'=>'Доступ приостановлен. Напишите в поддержку.'],403);
  /* Второй фактор у панели: пароль верный, но токена ещё нет — сначала
     код на почту. Отдаём не токен, а признак «нужен код»: до ввода кода
     сессии не существует, и перехваченный ответ ничего не даёт. */
  if($type==='admin'&&(int)($u['twofa']??0)===1){
    if($err=twofaSend($u))json_response(['error'=>$err],503);
    json_response(['need_code'=>true,'email'=>$email,
      'message'=>'Код отправлен на '.$email.'. Он действует 10 минут.']);
  }
  $t=sessionStart($type,(int)$u['id']);
  json_response(['token'=>$t,'user_type'=>$type,'user_id'=>(int)$u['id'],'name'=>$u['name']]);}
/* Второй шаг входа владельца: код из письма.

   Пароль проверяем заново — иначе код в чужих руках сам по себе даёт
   вход, и второй фактор оказывается вместо пароля, а не вдобавок. */
if($method==='POST'&&$path==='/auth/login/code'){
  $in=input();
  $email=trim((string)($in['email']??''));
  $pass=(string)($in['password']??'');
  $code=preg_replace('/\D+/','',(string)($in['code']??''));
  $lip=(string)($_SERVER['REMOTE_ADDR']??'');
  if($wait=loginBlocked(mb_strtolower($email),$lip))
    json_response(['error'=>'Слишком много попыток. Попробуйте '.waitWord($wait).'.'],429);
  $q=db()->prepare('SELECT * FROM admins WHERE email=?');$q->execute([$email]);$u=$q->fetch();
  if(!$u||!password_verify($pass,(string)$u['password_hash'])){
    loginFailed(mb_strtolower($email),$lip);
    json_response(['error'=>'Неверный email или пароль'],422);
  }
  if($err=twofaCheck($u,$code)){
    loginFailed(mb_strtolower($email),$lip);
    json_response(['error'=>$err],422);
  }
  loginOk(mb_strtolower($email));
  $t=sessionStart('admin',(int)$u['id']);
  json_response(['token'=>$t,'user_type'=>'admin','user_id'=>(int)$u['id'],'name'=>$u['name']]);
}
/* Вход из Telegram Mini App.

   Пароля здесь нет вовсе: доказательство личности — подпись Telegram по
   токену бота. Поэтому проверка подписи и есть вся защита, и обойти её
   нечем: initData приходит из браузера, где человек волен подменить
   что угодно. */
if($method==='POST'&&$path==='/auth/telegram'){
  if(!telegramReady())
    json_response(['error'=>'Вход через Telegram не настроен: нет токена бота'],503);
  $in=input();
  $data=telegramVerify((string)($in['init_data']??''));
  if(!$data)json_response(['error'=>'Telegram не подтвердил вход'],401);

  $u=$data['user'];
  try{
    $r=oauthSignIn('telegram',(string)$u['id'],'',telegramName($u));
  }catch(Throwable $e){
    json_response(['error'=>$e->getMessage()],403);
  }
  /* Пришёл по ссылке от специалиста — привязываем сразу. Ради этого
     Mini App и затевается: ни регистрации, ни пароля, ни кода руками. */
  $linked=null;
  if($r['user_type']==='client')
    $linked=telegramStartLink($data['start_param'],(int)$r['user_id']);
  json_response($r+['linked_specialist'=>$linked]);
}
if($method==='POST'&&$path==='/auth/invite'){ $in=input();$q=db()->prepare('SELECT * FROM clients WHERE invite_token=?');$q->execute([(string)($in['invite_token']??'')]);$c=$q->fetch();if(!$c)json_response(['error'=>'Неверная ссылка'],422);$p=(string)($in['password']??'');if(!password_ok($p))json_response(['error'=>'Пароль от 8 символов и с цифрой'],422);db()->prepare('UPDATE clients SET password_hash=?,invite_token=NULL,email=COALESCE(email,?) WHERE id=?')->execute([password_hash($p,PASSWORD_DEFAULT),$in['email']??null,$c['id']]);$t=sessionStart('client',(int)$c['id']);json_response(['token'=>$t,'user_type'=>'client','user_id'=>(int)$c['id'],'name'=>$c['name']]);}
/* Забыли пароль. Ответ всегда одинаковый: по нему нельзя проверить,
   заведён ли адрес в сервисе. Настоящая ошибка попадает только в лог. */
if($method==='POST'&&$path==='/auth/forgot'){
  $in=input();$email=strtolower(trim((string)($in['email']??'')));
  $ok=['ok'=>true,'message'=>'Если такой адрес у нас есть, письмо со ссылкой уже в пути. Проверьте и папку «Спам».'];
  /* Почта не настроена — письма не будет. Человек, которому сказали
     «письмо в пути», будет ждать и обновлять ящик; честнее сразу
     отправить его туда, где ему помогут. */
  if(!mailReady())
    json_response(['error'=>'Восстановление пароля по почте пока не работает. Напишите нам — поможем войти.'],503);
  if(!filter_var($email,FILTER_VALIDATE_EMAIL))json_response(['error'=>'Введите корректный email'],422);
  $ip=$_SERVER['REMOTE_ADDR']??'';
  if(resetThrottled($email,$ip))json_response($ok);
  $found=userByEmail($email);
  /* Пришедшим через Google или VK пароль менять нечего: у них его нет. */
  if($found&&$found['row']['password_hash']){
    if($err=sendPasswordReset($found,$email,$ip))error_log('password reset mail: '.$err);
  }
  json_response($ok);
}
/* Проверка ссылки до показа формы: истёкшую лучше объяснить сразу,
   а не после того, как человек придумал новый пароль. */
if($method==='GET'&&preg_match('#^/auth/reset/([a-f0-9]{16,})$#',$path,$m)){
  $r=resetByToken($m[1]);
  if(!$r)json_response(['error'=>'Ссылка устарела или уже использована'],422);
  json_response(['ok'=>true,'email'=>$r['email']]);
}
/* Смена пароля. Все прежние входы сбрасываем: если пароль угнали,
   чужая сессия не должна пережить восстановление. */
if($method==='POST'&&$path==='/auth/reset'){
  $in=input();$raw=(string)($in['token']??'');$pass=(string)($in['password']??'');
  $r=preg_match('#^[a-f0-9]{16,}$#',$raw)?resetByToken($raw):null;
  if(!$r)json_response(['error'=>'Ссылка устарела или уже использована'],422);
  if(!password_ok($pass))json_response(['error'=>'Пароль от 8 символов и с цифрой'],422);
  $type=$r['user_type'];$uid=(int)$r['user_id'];
  $table=['admin'=>'admins','specialist'=>'specialists','client'=>'clients'][$type]??null;
  if(!$table)json_response(['error'=>'Ссылка устарела или уже использована'],422);
  $pdo=db();
  $pdo->prepare("UPDATE $table SET password_hash=? WHERE id=?")->execute([password_hash($pass,PASSWORD_DEFAULT),$uid]);
  $pdo->prepare('UPDATE password_resets SET used_at=? WHERE id=?')->execute([now(),$r['id']]);
  $pdo->prepare('DELETE FROM password_resets WHERE user_type=? AND user_id=? AND used_at IS NULL')->execute([$type,$uid]);
  $pdo->prepare('DELETE FROM sessions WHERE user_type=? AND user_id=?')->execute([$type,$uid]);
  $q=$pdo->prepare("SELECT name FROM $table WHERE id=?");$q->execute([$uid]);$name=(string)($q->fetchColumn()?:'');
  $t=sessionStart($type,$uid);
  json_response(['token'=>$t,'user_type'=>$type,'user_id'=>$uid,'name'=>$name]);
}
if($method==='POST'&&$path==='/auth/logout'){if($t=bearer())db()->prepare('DELETE FROM sessions WHERE token=?')->execute([$t]);json_response(['ok'=>true]);}
if($method==='GET'&&$path==='/me'){ $a=auth();if($a['user_type']==='admin'){
  $q=db()->prepare("SELECT id,email,name,COALESCE(role,'owner') role,COALESCE(status,'active') status FROM admins WHERE id=?");
  $q->execute([$a['user_id']]);$u=$q->fetch();
  /* Права отдаём вместе с учёткой: панель прячет по ним разделы, чтобы
     помощник не стучался в закрытую дверь. Решает всё равно сервер. */
  json_response(['user'=>$u,'user_type'=>'admin',
    'role'=>$u['role']??'owner','rights'=>adminRights($u['role']??'owner'),
    'roles'=>ADMIN_ROLES]);
} $table=$a['user_type']==='specialist'?'specialists':'clients';$q=db()->prepare("SELECT * FROM $table WHERE id=?");$q->execute([$a['user_id']]);$u=$q->fetch();/* Хеш пароля и пригласительный токен клиенту не нужны и не должны покидать сервер */foreach(['password_hash','invite_token','join_code'] as $secret)unset($u[$secret]);json_response(['user'=>$u,'user_type'=>$a['user_type']]);}
/* Публичный ключ берём тем же путём, что и отправка (vapidKeys читает и
   vapid.php, и старый vapid.json) — иначе созданные кнопкой ключи
   браузер не увидит и подписаться будет нечем. */
if($method==='GET'&&$path==='/public/config'){ $key=getenv('EQUA_VAPID_PUBLIC_KEY')?:getenv('NUTRIMENU_VAPID_PUBLIC_KEY')?:(vapidKeys()['publicKey']??'');
  /* Приложение спрашивает это при запуске: объявление, требование
     обновиться и выключенные возможности. Версию оно присылает своим
     параметром — решение «пора обновиться» принимает сервер, чтобы в
     старых сборках не пришлось ничего чинить. */
  $cfg=appConfig();
  $have=preg_replace('/[^0-9.]/','',(string)($_GET['v']??''));
  $cfg['update_required']=versionOlder($have,$cfg['min_version']);
  json_response(['app_name'=>APP_NAME,'vapid_public_key'=>$key]+$cfg);}
/* Файл анализа. Случайного имени мало: проверяем, что просящий —
   либо сам клиент, либо его специалист. Иначе ссылка, однажды попавшая
   не в те руки, работала бы вечно. */
if($method==='GET'&&preg_match('#^/labs/file/([A-Za-z0-9._-]+)$#',$path,$m)){
  $a=auth();$name=basename($m[1]);
  $own=labFileOwner($name);
  if(!$own)json_response(['error'=>'Не найдено'],404);
  $cid=(int)$own['client_id'];
  $ok=false;
  if($a['user_type']==='client') $ok=((int)$a['user_id']===$cid);
  elseif($a['user_type']==='specialist'){
    $q=db()->prepare('SELECT 1 FROM clients WHERE id=? AND specialist_id=?');
    $q->execute([$cid,(int)$a['user_id']]);$ok=(bool)$q->fetch();
  }
  if(!$ok)json_response(['error'=>'Нет доступа'],403);
  $file=__DIR__.'/../storage/uploads/'.$name;
  if(!is_file($file))json_response(['error'=>'Не найдено'],404);
  $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
  $mime=['pdf'=>'application/pdf','jpg'=>'image/jpeg','jpeg'=>'image/jpeg',
         'png'=>'image/png','webp'=>'image/webp'][$ext]??'application/octet-stream';
  /* Приватный файл в общий кэш попадать не должен. */
  serveFile($file,$mime,'private, no-store');
}
/* Диплом специалиста. Видит его только сам специалист и владелец
   сервиса: клиенту в каталоге показывают название и отметку о проверке,
   но не скан документа. */
if($method==='GET'&&preg_match('#^/docs/file/([A-Za-z0-9._-]+)$#',$path,$m)){
  $a=auth();$name=basename($m[1]);
  $own=docFileOwner($name);
  if(!$own)json_response(['error'=>'Не найдено'],404);
  $ok=($a['user_type']==='admin')||($a['user_type']==='specialist'&&(int)$a['user_id']===$own);
  if(!$ok)json_response(['error'=>'Нет доступа'],403);
  $file=__DIR__.'/../storage/uploads/'.$name;
  if(!is_file($file))json_response(['error'=>'Не найдено'],404);
  $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
  $mime=['pdf'=>'application/pdf','jpg'=>'image/jpeg','jpeg'=>'image/jpeg',
         'png'=>'image/png','webp'=>'image/webp'][$ext]??'application/octet-stream';
  serveFile($file,$mime,'private, no-store');
}
if($method==='GET'&&preg_match('#^/avatar/([A-Za-z0-9._-]+)$#',$path,$m)){ $name=basename($m[1]);$file=__DIR__.'/../storage/uploads/'.$name;if(!is_file($file))json_response(['error'=>'Не найдено'],404);$ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));$mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','mp4'=>'video/mp4','mov'=>'video/quicktime','m4a'=>'audio/mp4','mp3'=>'audio/mpeg','aac'=>'audio/aac','webm'=>'audio/webm','ogg'=>'audio/ogg'][$ext]??'application/octet-stream';serveFile($file,$mime);}
/* Скан документа, который специалист открыл в своём профиле. Отдаём
   только одобренные владельцем и только не-паспорт: проверка личности
   в профиле остаётся галочкой, а не сканом паспорта. */
if($method==='GET'&&preg_match('#^/public/documents/([A-Za-z0-9._-]+)$#',$path,$m)){
  $name=basename($m[1]);
  $q=db()->prepare("SELECT d.file_url FROM specialist_documents d
                     JOIN public_profiles p ON p.specialist_id=d.specialist_id
                     JOIN specialists s ON s.id=d.specialist_id
                    WHERE d.status='approved' AND d.kind<>'passport' AND d.is_public=1
                      AND p.is_public=1 AND s.verify_status='verified' AND d.file_url LIKE ?");
  $q->execute(['%/'.$name]);
  if(!$q->fetch())json_response(['error'=>'Не найдено'],404);
  $file=__DIR__.'/../storage/uploads/'.$name;
  if(!is_file($file))json_response(['error'=>'Не найдено'],404);
  $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));
  $mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','pdf'=>'application/pdf'][$ext]??'application/octet-stream';
  serveFile($file,$mime);
}
if($method==='GET'&&$path==='/public/specialists'){ $q=db()->query('SELECT s.id,s.name,s.avatar_url,p.slug,p.bio,p.city,p.rating,p.reviews_count FROM specialists s JOIN public_profiles p ON p.specialist_id=s.id WHERE p.is_public=1 AND s.verify_status=\'verified\' ORDER BY p.rating DESC');json_response(['specialists'=>$q->fetchAll()]);}
if($method==='GET'&&preg_match('#^/public/specialists/([A-Za-z0-9_-]+)$#',$path,$m)){ $q=db()->prepare('SELECT s.id,s.name,s.avatar_url,COALESCE(s.profession,"nutritionist") profession,CASE WHEN s.verify_status=\'verified\' THEN 1 ELSE 0 END verified,s.verified_at,p.*,(SELECT COUNT(*) FROM clients c WHERE c.specialist_id=s.id AND c.status="active") active_clients FROM specialists s JOIN public_profiles p ON p.specialist_id=s.id WHERE p.slug=? AND p.is_public=1 AND s.verify_status=\'verified\'');$q->execute([$m[1]]);$r=$q->fetch();if(!$r)json_response(['error'=>'Не найдено'],404);/* Названия подтверждённых документов показываем, сканы — нет. *//* Паспорт в каталог не выносим: клиенту важно, что личность проверена
   (об этом говорит галочка), а не серия и кем выдан. */
/* Скан показываем только если специалист сам его открыл (is_public).
   Документы грузились для проверки владельцем, а не для витрины:
   публиковать их без спроса нельзя. Паспорт не показываем никогда. */
$d=db()->prepare("SELECT id,kind,title,issuer,issued_on,is_public,file_url FROM specialist_documents WHERE specialist_id=? AND status='approved' AND kind<>'passport' ORDER BY issued_on DESC, id DESC");$d->execute([(int)$r['id']]);
$docs=[];
foreach($d->fetchAll() as $row){
  $docs[]=['id'=>(int)$row['id'],'kind'=>$row['kind'],'title'=>$row['title'],
    'issuer'=>$row['issuer'],'issued_on'=>$row['issued_on'],
    'scan_url'=>!empty($row['is_public'])&&$row['file_url']
      ? '/api/v1/public/documents/'.basename((string)$row['file_url']) : null];
}
$r['documents']=$docs;
$sv=db()->prepare("SELECT id,title,description,kind,price_kop,period_days,duration_min FROM specialist_services WHERE specialist_id=? AND is_active=1 ORDER BY sort_order,price_kop");
$sv->execute([(int)$r['id']]);$r['services']=$sv->fetchAll();
$sq=db()->prepare('SELECT last_seen_at,created_at FROM specialists WHERE id=?');$sq->execute([(int)$r['id']]);
$sr=$sq->fetch()?:[];$r['last_seen_at']=$sr['last_seen_at']??null;$r['joined_at']=$sr['created_at']??null;
$pp=db()->prepare("SELECT COUNT(*) FROM specialist_documents WHERE specialist_id=? AND kind='passport' AND status='approved'");
$pp->execute([(int)$r['id']]);
$r['identity_verified']=(int)$pp->fetchColumn()>0;
$r['reviews']=reviewsOf((int)$r['id']);json_response(['specialist'=>$r]);}
/* В каталог попадают только проверенные специалисты: клиент выбирает
   здесь вслепую, и обещание «диплом проверен» должно стоять за каждой
   карточкой. По коду приглашения специалист работает и без проверки —
   там клиент знает, к кому идёт. */
if($method==='GET'&&$path==='/catalog'){ $prof=$_GET['profession']??'';$q=trim((string)($_GET['q']??''));$sql='SELECT s.id,s.name,s.avatar_url,COALESCE(s.profession,"nutritionist") profession,CASE WHEN s.verify_status=\'verified\' THEN 1 ELSE 0 END verified,s.last_seen_at,s.created_at joined_at,p.slug,p.bio,p.city,p.rating,p.reviews_count,(SELECT MIN(v.price_kop)/100 FROM specialist_services v WHERE v.specialist_id=s.id AND v.is_active=1) price,(SELECT CASE WHEN v.kind=\'subscription\' AND v.period_days<=7 THEN \'нед\' WHEN v.kind=\'subscription\' THEN \'мес\' ELSE \'разово\' END FROM specialist_services v WHERE v.specialist_id=s.id AND v.is_active=1 ORDER BY v.price_kop LIMIT 1) price_unit,p.education,p.experience_years,p.specializations,p.advantages,(SELECT COUNT(*) FROM clients c WHERE c.specialist_id=s.id AND c.status="active") active_clients FROM specialists s JOIN public_profiles p ON p.specialist_id=s.id WHERE p.is_public=1 AND COALESCE(p.catalog_block,0)=0 AND s.verify_status=\'verified\'';$args=[];if(in_array($prof,['nutritionist','trainer','coach'],true)){$sql.=' AND COALESCE(s.profession,"nutritionist")=?';$args[]=$prof;}if($q!==''){$sql.=' AND (s.name LIKE ? OR p.bio LIKE ? OR p.specializations LIKE ? OR p.city LIKE ?)';$like='%'.$q.'%';array_push($args,$like,$like,$like,$like);}$sql.=' ORDER BY COALESCE(p.featured,0) DESC, p.rating DESC, p.reviews_count DESC';$st=db()->prepare($sql);$st->execute($args);
  $rows=$st->fetchAll();
  /* Карточке в каталоге нужны те же три вещи, по которым выбирают
     человека: что он делает и почём, проверена ли личность, что о нём
     говорят. Без услуг карточка — просто имя с городом. */
  $sv=db()->prepare("SELECT id,title,kind,price_kop,period_days,duration_min FROM specialist_services
                      WHERE specialist_id=? AND is_active=1 ORDER BY sort_order,price_kop LIMIT 3");
  $sn=db()->prepare("SELECT COUNT(*) FROM specialist_services WHERE specialist_id=? AND is_active=1");
  $pp=db()->prepare("SELECT COUNT(*) FROM specialist_documents
                      WHERE specialist_id=? AND kind='passport' AND status='approved'");
  foreach($rows as &$r){
    $sv->execute([(int)$r['id']]); $r['services']=$sv->fetchAll();
    $sn->execute([(int)$r['id']]); $r['services_count']=(int)$sn->fetchColumn();
    $pp->execute([(int)$r['id']]); $r['identity_verified']=(int)$pp->fetchColumn()>0;
  }
  unset($r);
  json_response(['specialists'=>$rows]);}
if($method==='POST'&&preg_match('#^/catalog/(\d+)/lead$#',$path,$m)){ $spid=(int)$m[1];$chk=db()->prepare('SELECT 1 FROM public_profiles p JOIN specialists s ON s.id=p.specialist_id WHERE p.specialist_id=? AND p.is_public=1 AND s.verify_status=\'verified\'');$chk->execute([$spid]);if(!$chk->fetch())json_response(['error'=>'Специалист не найден'],404);$in=input();$name=trim((string)($in['name']??''));$contact=trim((string)($in['contact']??''));if(!$name||!$contact)json_response(['error'=>'Укажите имя и контакт'],422);db()->prepare('INSERT INTO catalog_leads(specialist_id,name,contact,message,created_at) VALUES(?,?,?,?,?)')->execute([$spid,mb_substr($name,0,120),mb_substr($contact,0,120),mb_substr((string)($in['message']??''),0,1000),now()]);notifySpecialist($spid,'lead','Заявка из каталога',$name.' оставил контакт: '.$contact);json_response(['ok'=>true],201);}

if($method==='GET'&&$path==='/public/foods'){
  $q=trim((string)($_GET['q']??''));$pdo=db();$st=$pdo->prepare('SELECT id,name,category,kcal,protein,fat,carbs FROM ingredients WHERE is_public=1 AND name LIKE ? ORDER BY name LIMIT 30');$st->execute(['%'.$q.'%']);json_response(['foods'=>$st->fetchAll()]);
}
if($method==='POST'&&$path==='/public/client-register'){
  $in=input();$name=trim((string)($in['name']??''));$email=trim((string)($in['email']??''));$pass=(string)($in['password']??'');$sid=(int)($in['specialist_id']??0);$answers=$in['answers']??[];
  if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||!password_ok($pass))json_response(['error'=>'Нужны имя, корректный email и пароль от 8 символов с цифрой'],422);
  if($sid){$q=$pdo->prepare('SELECT id FROM specialists WHERE id=?');$q->execute([$sid]);if(!$q->fetch())json_response(['error'=>'Специалист не найден'],422);}
  $q=$pdo->prepare('SELECT id FROM clients WHERE email=?');$q->execute([$email]);if($q->fetch())json_response(['error'=>'Этот email уже зарегистрирован'],422);
  $pdo->beginTransaction();try{$a=$answers;$goal=$a['goal']??'Поддержание питания';$birth=!empty($a['age'])?(int)date('Y')-(int)$a['age']:null;$pdo->prepare('INSERT INTO clients(specialist_id,name,email,password_hash,sex,birth_year,height_cm,weight_kg,activity_level,goal,target_kcal,target_protein,target_fat,target_carbs,excluded_ingredients,notes,status,source,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$sid?:null,$name,$email,password_hash($pass,PASSWORD_DEFAULT),$a['sex']??null,$birth,$a['height_cm']??null,$a['weight_kg']??null,$a['activity_level']??null,$goal,$a['target_kcal']??1800,$a['target_protein']??110,$a['target_fat']??60,$a['target_carbs']??190,json_encode($a['dislikes']??[]),$a['notes']??null,'active',signupSource($in),now()]);$cid=(int)$pdo->lastInsertId();$pdo->prepare('INSERT INTO client_onboarding(client_id,answers_json,completed_at,updated_at) VALUES(?,?,?,?)')->execute([$cid,json_encode($answers,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),now(),now()]);$t=sessionStart('client',(int)$cid);if($sid)attributeClient($cid,$sid,'catalog');$pdo->commit();json_response(['token'=>$t,'user_type'=>'client','user_id'=>$cid,'name'=>$name],201);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
if(str_starts_with($path,'/specialist/progress/photos/')){$a=specialist();$sid=(int)$a['user_id'];$name=basename($path);$q=db()->prepare('SELECT pp.photo_url FROM progress_photos pp JOIN clients c ON c.id=pp.client_id WHERE c.specialist_id=? AND pp.photo_url LIKE ?');$q->execute([$sid,'%/'.$name]);$row=$q->fetch();if(!$row)json_response(['error'=>'Не найдено'],404);$file=__DIR__.'/../storage/uploads/'.$name;if(!is_file($file))json_response(['error'=>'Не найдено'],404);$ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));$mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'][$ext]??'application/octet-stream';header('Content-Type:'.$mime);header('Cache-Control:private,max-age=3600');readfile($file);exit;}
/* ============================================================
   ТЕХПОДДЕРЖКА, СТОРОНА ПОЛЬЗОВАТЕЛЯ.
   Пишут и клиенты, и специалисты — маршруты общие, автор берётся из
   токена. Владелец сюда не пишет: у него та же переписка со своей
   стороны, в разделе поддержки панели.
   ============================================================ */
if($path==='/support'||preg_match('#^/support/\d+#',$path)){
  $a=auth();$utype=$a['user_type'];$uid=(int)$a['user_id'];
  if($utype==='admin')json_response(['error'=>'Обращения владелец читает в панели'],403);

  /* Своё обращение — только своё: чужую переписку с поддержкой видеть
     нельзя, там и учётные данные, и здоровье. */
  $own=function(int $id)use($pdo,$utype,$uid){
    $q=$pdo->prepare('SELECT * FROM support_tickets WHERE id=? AND author_type=? AND author_id=?');
    $q->execute([$id,$utype,$uid]); $t=$q->fetch();
    if(!$t)json_response(['error'=>'Обращение не найдено'],404);
    return $t;
  };

  if($method==='GET'&&$path==='/support'){
    $q=$pdo->prepare("SELECT t.*,
        (SELECT COUNT(*) FROM support_messages m WHERE m.ticket_id=t.id AND m.from_admin=1 AND m.read_at IS NULL) unread,
        (SELECT body FROM support_messages m WHERE m.ticket_id=t.id ORDER BY m.id DESC LIMIT 1) last_body
        FROM support_tickets t WHERE t.author_type=? AND t.author_id=?
        ORDER BY t.last_reply_at DESC, t.id DESC");
    $q->execute([$utype,$uid]);
    json_response(['tickets'=>$q->fetchAll(),'topics'=>SUPPORT_TOPICS]);
  }
  if($method==='POST'&&$path==='/support'){
    $in=input();
    $subject=trim((string)($in['subject']??''));
    $body=trim((string)($in['body']??''));
    $topic=(string)($in['topic']??'other');
    if(!isset(SUPPORT_TOPICS[$topic]))$topic='other';
    if($subject===''||mb_strlen($body)<5)
      json_response(['error'=>'Напишите тему и опишите вопрос'],422);
    $pdo->beginTransaction();
    $pdo->prepare('INSERT INTO support_tickets(author_type,author_id,topic,subject,status,created_at,last_reply_at)
                   VALUES(?,?,?,?,?,?,?)')->execute([$utype,$uid,$topic,$subject,'new',now(),now()]);
    $tid=(int)$pdo->lastInsertId();
    $pdo->prepare('INSERT INTO support_messages(ticket_id,from_admin,body,created_at) VALUES(?,0,?,?)')
        ->execute([$tid,$body,now()]);
    $pdo->commit();
    $who=ticketAuthor($utype,$uid);
    mailOwner('Обращение в поддержку: '.$subject,
      ...plainLetter($who['name'].' ('.SUPPORT_TOPICS[$topic].') пишет:',$body,
                     'Ответить можно в панели владельца, раздел «Поддержка».'));
    json_response(['ticket_id'=>$tid],201);
  }
  if($method==='GET'&&preg_match('#^/support/(\d+)$#',$path,$m)){
    $t=$own((int)$m[1]);
    /* Открыли переписку — ответы поддержки прочитаны. */
    $pdo->prepare('UPDATE support_messages SET read_at=? WHERE ticket_id=? AND from_admin=1 AND read_at IS NULL')
        ->execute([now(),(int)$t['id']]);
    json_response(['ticket'=>$t,'messages'=>ticketThread((int)$t['id']),'topics'=>SUPPORT_TOPICS]);
  }
  if($method==='POST'&&preg_match('#^/support/(\d+)/reply$#',$path,$m)){
    $t=$own((int)$m[1]);
    $body=trim((string)(input()['body']??''));
    if(mb_strlen($body)<2)json_response(['error'=>'Пустое сообщение'],422);
    $pdo->prepare('INSERT INTO support_messages(ticket_id,from_admin,body,created_at) VALUES(?,0,?,?)')
        ->execute([(int)$t['id'],$body,now()]);
    /* Закрытое обращение с новым сообщением снова открыто: человек
       написал, значит вопрос не решён. */
    $pdo->prepare("UPDATE support_tickets SET last_reply_at=?, status=CASE WHEN status='closed' THEN 'new' ELSE status END, closed_at=NULL WHERE id=?")
        ->execute([now(),(int)$t['id']]);
    mailOwner('Ответ в обращении: '.$t['subject'],
      ...plainLetter('Пользователь дописал в обращение.',$body,'Панель владельца, раздел «Поддержка».'));
    json_response(['ok'=>true],201);
  }
  if($method==='POST'&&preg_match('#^/support/(\d+)/close$#',$path,$m)){
    $t=$own((int)$m[1]);
    $pdo->prepare("UPDATE support_tickets SET status='closed', closed_at=? WHERE id=?")->execute([now(),(int)$t['id']]);
    json_response(['ok'=>true]);
  }
  json_response(['error'=>'Метод не поддерживается'],404);
}

/* ============================================================
   ЛЕНТА. Пишут клиенты и специалисты, читают все авторизованные.
   ============================================================ */
if($path==='/feed'||preg_match('#^/feed/\d+#',$path)){
  $a=auth();$utype=$a['user_type'];$uid=(int)$a['user_id'];
  if($utype==='admin')json_response(['error'=>'Панель владельца читает ленту в разделе модерации'],403);

  $hydrate=function(array $rows)use($pdo,$utype,$uid){
    if(!$rows)return [];
    $ids=array_column($rows,'id');
    $in=implode(',',array_fill(0,count($ids),'?'));
    $likes=[];$q=$pdo->prepare("SELECT post_id,COUNT(*) n FROM post_likes WHERE post_id IN ($in) GROUP BY post_id");
    $q->execute($ids);foreach($q->fetchAll() as $r)$likes[(int)$r['post_id']]=(int)$r['n'];
    $mine=[];$q=$pdo->prepare("SELECT post_id FROM post_likes WHERE user_type=? AND user_id=? AND post_id IN ($in)");
    $q->execute(array_merge([$utype,$uid],$ids));foreach($q->fetchAll() as $r)$mine[(int)$r['post_id']]=true;
    $names=['client'=>[],'specialist'=>[]];
    foreach(['client'=>'clients','specialist'=>'specialists'] as $t=>$tbl){
      $tids=array_values(array_unique(array_map(fn($r)=>(int)$r['author_id'],array_filter($rows,fn($r)=>$r['author_type']===$t))));
      if(!$tids)continue;
      $tin=implode(',',array_fill(0,count($tids),'?'));
      $q=$pdo->prepare("SELECT id,name,avatar_url FROM $tbl WHERE id IN ($tin)");$q->execute($tids);
      foreach($q->fetchAll() as $r)$names[$t][(int)$r['id']]=$r;
    }
    return array_map(function($r)use($likes,$mine,$names,$utype,$uid){
      $au=$names[$r['author_type']][(int)$r['author_id']]??null;
      return [
        'id'=>(int)$r['id'],'text'=>$r['text'],'photo_url'=>$r['photo_url'],'created_at'=>$r['created_at'],
        'author_type'=>$r['author_type'],'author_id'=>(int)$r['author_id'],
        'author_name'=>$au['name']??'Пользователь','author_avatar'=>$au['avatar_url']??null,
        'likes'=>$likes[(int)$r['id']]??0,'liked'=>isset($mine[(int)$r['id']]),
        'mine'=>($r['author_type']===$utype&&(int)$r['author_id']===$uid),
      ];
    },$rows);
  };

  if($method==='GET'&&$path==='/feed'){
    $before=isset($_GET['before'])?(int)$_GET['before']:0;
    $sql="SELECT * FROM posts WHERE status='visible'".($before?' AND id<'.$before:'').' ORDER BY id DESC LIMIT 20';
    json_response(['posts'=>$hydrate($pdo->query($sql)->fetchAll())]);
  }

  if($method==='POST'&&$path==='/feed'){
    $text=trim((string)($_POST['text']??(input()['text']??'')));
    $photo=null;
    if(!empty($_FILES['photo'])&&$_FILES['photo']['error']===UPLOAD_ERR_OK)$photo=saveAvatar();
    if($text===''&&!$photo)json_response(['error'=>'Напишите текст или добавьте фото'],422);
    if(mb_strlen($text)>1500)json_response(['error'=>'Текст длиннее 1500 символов'],422);
    $last=$pdo->prepare("SELECT COUNT(*) FROM posts WHERE author_type=? AND author_id=? AND created_at>=datetime('now','-1 hour')");
    $last->execute([$utype,$uid]);
    if((int)$last->fetchColumn()>=10)json_response(['error'=>'Слишком много постов за час — сделайте паузу'],429);
    $pdo->prepare('INSERT INTO posts(author_type,author_id,text,photo_url,status,created_at) VALUES(?,?,?,?,?,?)')
        ->execute([$utype,$uid,$text?:null,$photo,'visible',now()]);
    $id=(int)$pdo->lastInsertId();
    $q=$pdo->prepare('SELECT * FROM posts WHERE id=?');$q->execute([$id]);
    json_response(['post'=>$hydrate([$q->fetch()])[0]],201);
  }

  if($method==='POST'&&preg_match('#^/feed/(\d+)/like$#',$path,$m)){
    $pid=(int)$m[1];
    $q=$pdo->prepare("SELECT 1 FROM posts WHERE id=? AND status='visible'");$q->execute([$pid]);
    if(!$q->fetch())json_response(['error'=>'Пост не найден'],404);
    $has=$pdo->prepare('SELECT 1 FROM post_likes WHERE post_id=? AND user_type=? AND user_id=?');
    $has->execute([$pid,$utype,$uid]);$had=(bool)$has->fetch();
    if($had)$pdo->prepare('DELETE FROM post_likes WHERE post_id=? AND user_type=? AND user_id=?')->execute([$pid,$utype,$uid]);
    else $pdo->prepare('INSERT INTO post_likes(post_id,user_type,user_id,created_at) VALUES(?,?,?,?)')->execute([$pid,$utype,$uid,now()]);
    $n=$pdo->prepare('SELECT COUNT(*) FROM post_likes WHERE post_id=?');$n->execute([$pid]);
    json_response(['likes'=>(int)$n->fetchColumn(),'liked'=>!$had]);
  }

  if($method==='DELETE'&&preg_match('#^/feed/(\d+)$#',$path,$m)){
    $pid=(int)$m[1];
    $q=$pdo->prepare('SELECT author_type,author_id FROM posts WHERE id=?');$q->execute([$pid]);$p=$q->fetch();
    if(!$p)json_response(['error'=>'Пост не найден'],404);
    if($p['author_type']!==$utype||(int)$p['author_id']!==$uid)json_response(['error'=>'Можно удалить только свой пост'],403);
    $pdo->prepare('DELETE FROM post_likes WHERE post_id=?')->execute([$pid]);
    $pdo->prepare('DELETE FROM posts WHERE id=?')->execute([$pid]);
    json_response(['ok'=>true]);
  }
  json_response(['error'=>'Not found'],404);
}

/* ============================================================
   ПАНЕЛЬ ВЛАДЕЛЬЦА. Доступна только роли admin.
   ============================================================ */
if(str_starts_with($path,'/admin/')){ $a=require_role('admin'); $aid=(int)$a['user_id'];
 /* Права сотрудника. Проверяем здесь, одним местом на все маршруты
    панели: разрешение, расставленное по каждому обработчику отдельно,
    рано или поздно забудут поставить на новом. Читать — уровень 1,
    менять — 2. Заблокированный сотрудник не проходит дальше вовсе. */
 $me=$pdo->prepare("SELECT id,name,email,COALESCE(role,'owner') role,COALESCE(status,'active') status FROM admins WHERE id=?");
 $me->execute([$aid]); $meRow=$me->fetch();
 if(!$meRow||$meRow['status']==='blocked'){
   $pdo->prepare('DELETE FROM sessions WHERE user_type="admin" AND user_id=?')->execute([$aid]);
   json_response(['error'=>'Доступ к панели закрыт'],403);
 }
 $myRole=(string)$meRow['role'];
 $section=adminSection($path);
 $need=$method==='GET'?1:2;
 if(adminLevel($myRole,$section)<$need){
   json_response(['error'=>'Этот раздел доступен только владельцу'],403);
 }
 $defaultPass=(function()use($pdo,$aid){$q=$pdo->prepare('SELECT password_hash,email FROM admins WHERE id=?');$q->execute([$aid]);$r=$q->fetch();return $r&&password_verify(OWNER_PASSWORD,$r['password_hash']);})();

 if($method==='GET'&&$path==='/admin/overview'){
   $one=fn($sql)=>(int)$pdo->query($sql)->fetchColumn();
   $series=[];for($i=29;$i>=0;$i--){$d=gmdate('Y-m-d',time()-$i*86400);$series[$d]=['date'=>$d,'clients'=>0,'specialists'=>0];}
   foreach($pdo->query("SELECT date(created_at) d,COUNT(*) n FROM clients WHERE created_at>=datetime('now','-30 day') GROUP BY d") as $r) if(isset($series[$r['d']]))$series[$r['d']]['clients']=(int)$r['n'];
   foreach($pdo->query("SELECT date(created_at) d,COUNT(*) n FROM specialists WHERE created_at>=datetime('now','-30 day') GROUP BY d") as $r) if(isset($series[$r['d']]))$series[$r['d']]['specialists']=(int)$r['n'];
   $recent=$pdo->query("SELECT name,email,created_at,'client' kind FROM clients ORDER BY id DESC LIMIT 8")->fetchAll();
   foreach($pdo->query("SELECT name,email,created_at,'specialist' kind FROM specialists ORDER BY id DESC LIMIT 8") as $r)$recent[]=$r;
   usort($recent,fn($x,$y)=>strcmp((string)$y['created_at'],(string)$x['created_at']));
   /* Что специалисты реально ставят в меню — считаем по назначениям, без выдумок */
   $popular=$pdo->query("SELECT d.name,COALESCE(d.photo_thumb_url,d.photo_url) photo_url,COUNT(mi.id) n FROM menu_items mi JOIN dishes d ON d.id=mi.dish_id GROUP BY d.id ORDER BY n DESC, d.name LIMIT 6")->fetchAll();
   /* Топ специалистов по числу активных клиентов */
   $top=$pdo->query("SELECT s.id,s.name,s.avatar_url,COALESCE(s.plan,'free') plan,
       (SELECT COUNT(*) FROM clients c WHERE c.specialist_id=s.id AND c.status='active') clients,
       (SELECT COUNT(*) FROM menus m WHERE m.specialist_id=s.id AND m.status='published') menus,
       s.created_at FROM specialists s ORDER BY clients DESC, s.id LIMIT 6")->fetchAll();
   /* Очередь дел. Панель открывают не «посмотреть цифры», а узнать, что
      требует решения сегодня: заявки на верификацию ждут человека,
      обращения — ответа, заявки на вывод — денег. Раньше всё это лежало
      по разным разделам, и заметить их можно было только зайдя в каждый. */
   $queue=[
     'verifications'=>(int)fetchOne($pdo,"SELECT COUNT(*) FROM specialists WHERE verify_status='pending'"),
     'support'      =>(int)fetchOne($pdo,"SELECT COUNT(*) FROM support_tickets WHERE status<>'closed'"),
     'payouts'      =>(int)fetchOne($pdo,"SELECT COUNT(*) FROM payout_requests WHERE status='pending'"),
     'posts'        =>(int)fetchOne($pdo,"SELECT COUNT(*) FROM posts WHERE status='hidden'"),
     'blocked'      =>(int)fetchOne($pdo,"SELECT COUNT(*) FROM specialists WHERE status='blocked'")
                     +(int)fetchOne($pdo,"SELECT COUNT(*) FROM clients WHERE status='blocked'"),
   ];
   /* Откуда приходят люди: без этого рекламу оценивать нечем. */
   $sources=$pdo->query("SELECT COALESCE(NULLIF(source,''),'напрямую') src,COUNT(*) n
     FROM clients GROUP BY src ORDER BY n DESC LIMIT 8")->fetchAll();
   json_response(['popular'=>$popular,'top_specialists'=>$top,'sources'=>$sources,
     'default_password'=>$defaultPass,'queue'=>$queue,'my_role'=>$myRole,
     'totals'=>[
       'specialists'=>$one('SELECT COUNT(*) FROM specialists'),
       'clients'=>$one('SELECT COUNT(*) FROM clients'),
       'clients_linked'=>$one('SELECT COUNT(*) FROM clients WHERE specialist_id IS NOT NULL'),
       'dishes'=>$one('SELECT COUNT(*) FROM dishes'),
       'menus'=>$one("SELECT COUNT(*) FROM menus WHERE status='published'"),
       'messages'=>$one('SELECT COUNT(*) FROM messages'),
       'verify_pending'=>$one("SELECT COUNT(*) FROM specialists WHERE verify_status='pending'"),
       'verified'=>$one("SELECT COUNT(*) FROM specialists WHERE verify_status='verified'"),
     ],
     'new'=>[
       'clients_7'=>$one("SELECT COUNT(*) FROM clients WHERE created_at>=datetime('now','-7 day')"),
       'clients_30'=>$one("SELECT COUNT(*) FROM clients WHERE created_at>=datetime('now','-30 day')"),
       'specialists_7'=>$one("SELECT COUNT(*) FROM specialists WHERE created_at>=datetime('now','-7 day')"),
       'specialists_30'=>$one("SELECT COUNT(*) FROM specialists WHERE created_at>=datetime('now','-30 day')"),
     ],
     'active_7'=>$one("SELECT COUNT(DISTINCT client_id) FROM meal_logs WHERE logged_at>=datetime('now','-7 day')"),
     'series'=>array_values($series),
     'recent'=>array_slice($recent,0,10),
   ]);
 }

 /* Готовность к работе с живыми людьми.
    Всё это владелец делает руками на хостинге и легко забывает: почта
    настраивается один раз, реквизиты в документы вносятся один раз, а
    узнаётся о пропущенном от первого же пользователя, который не смог
    восстановить пароль. Показываем прямо в сводке.

    Про пароль владельца здесь молчим: о нём предупреждает отдельная
    полоса в самом верху, и дублировать её значит учить не читать ни
    то, ни другое. */
 /* --- Приложение ---
    Объявление, требование обновиться и выключатели возможностей.
    Магазин проверяет новую сборку неделю; всё, что нельзя ждать неделю,
    должно управляться отсюда. */
 if($method==='GET'&&$path==='/admin/app'){
   $labels=[];
   foreach(APP_FEATURES as $k=>[$title,$about]) $labels[$k]=['title'=>$title,'about'=>$about];
   /* Токен бота наружу не отдаём даже владельцу: он уходит в журнал
      браузера и в историю запросов. Показываем только, задан ли он. */
   $tg=telegramConfig();
   json_response(['app'=>appConfig()+[
     'announce_on'=>settingGet('announce_on')==='1',
     'announce_text'=>(string)(settingGet('announce_text')??''),
     'announce_kind'=>settingGet('announce_kind')?:'info',
     'tg_ready'=>telegramReady(),
     'tg_bot_name'=>$tg['bot_name'],
     'tg_source'=>$tg['source'],   // file — токен в config/telegram.php
   ],'features'=>$labels]);
 }
 if($method==='POST'&&$path==='/admin/app'){
   $in=input();
   if(array_key_exists('announce_text',$in))
     settingSet('announce_text',mb_substr(trim((string)$in['announce_text']),0,500));
   if(array_key_exists('announce_on',$in))
     settingSet('announce_on',!empty($in['announce_on'])?'1':'0');
   if(array_key_exists('announce_kind',$in))
     settingSet('announce_kind',in_array($in['announce_kind'],['info','warn'],true)?$in['announce_kind']:'info');
   if(array_key_exists('min_version',$in))
     settingSet('min_version',preg_replace('/[^0-9.]/','',(string)$in['min_version']));
   if(array_key_exists('store_url',$in))
     settingSet('store_url',mb_substr(trim((string)$in['store_url']),0,300));
   /* Токен принимаем только целиком и только непустой: пустая строка
      здесь означала бы «оставить как есть», а не «стереть» — стирают
      отдельной кнопкой, чтобы не потерять его случайным сохранением
      формы. */
   if(!empty($in['tg_bot_token'])){
     $tok=trim((string)$in['tg_bot_token']);
     if(!preg_match('/^\d{5,}:[A-Za-z0-9_\-]{20,}$/',$tok))
       json_response(['error'=>'Это не похоже на токен бота. Он выглядит так: 123456789:AA...'],422);
     settingSet('tg_bot_token',$tok);
   }
   if(array_key_exists('tg_clear',$in)&&!empty($in['tg_clear'])) settingSet('tg_bot_token','');
   if(array_key_exists('tg_bot_name',$in))
     settingSet('tg_bot_name',ltrim(trim((string)$in['tg_bot_name']),'@'));
   if(isset($in['features'])&&is_array($in['features']))
     foreach(APP_FEATURES as $k=>$v)
       if(array_key_exists($k,$in['features']))
         settingSet('feature_'.$k,empty($in['features'][$k])?'0':'1');
   adminLog('settings','app',null,'Настройки приложения');
   json_response(['ok'=>true,'app'=>appConfig()]);
 }

 /* --- Активные входы ---
    Пароль от панели вводят с чужого ноутбука и забывают выйти. Пока
    список входов не показать, узнать об этом нельзя вообще никак, а
    закрыть чужой сеанс — тем более. Свой вход отмечаем отдельно, чтобы
    человек не завершил его первым же нажатием. */
 if($method==='GET'&&$path==='/admin/sessions'){
   $me=bearer();
   $st=$pdo->prepare("SELECT token,user_type,user_id,created_at,last_seen_at,expires_at,ip,user_agent
     FROM sessions WHERE user_type='admin' AND user_id=? AND expires_at>datetime('now')
     ORDER BY COALESCE(last_seen_at,created_at) DESC");
   $st->execute([$aid]);
   $out=[];
   foreach($st->fetchAll() as $r){
     $out[]=[
       'id'=>substr((string)$r['token'],0,12),   // целый токен наружу не отдаём
       'current'=>hash_equals((string)$r['token'],(string)$me),
       'device'=>deviceName($r['user_agent']),
       'ip'=>$r['ip'],'created_at'=>$r['created_at'],
       'last_seen_at'=>$r['last_seen_at'],'expires_at'=>$r['expires_at'],
     ];
   }
   json_response(['sessions'=>$out,'twofa'=>(int)($meRow['twofa']??0)===1]);
 }
 /* Закрыть один чужой вход. Свой не закрываем: человек нажал бы её по
    ошибке и вылетел из панели, не поняв почему. */
 if($method==='DELETE'&&preg_match('#^/admin/sessions/([a-f0-9]{6,64})$#',$path,$m)){
   $pre=$m[1]; $me=bearer();
   $st=$pdo->prepare("SELECT token FROM sessions WHERE user_type='admin' AND user_id=? AND token LIKE ?");
   $st->execute([$aid,$pre.'%']);
   $tok=(string)($st->fetchColumn()?:'');
   if($tok==='')json_response(['error'=>'Вход не найден'],404);
   if(hash_equals($tok,(string)$me))json_response(['error'=>'Это ваш текущий вход — выйдите обычной кнопкой'],422);
   $pdo->prepare('DELETE FROM sessions WHERE token=?')->execute([$tok]);
   adminLog('session','admin',$aid,(string)($meRow['name']??''),'закрыт чужой вход');
   json_response(['ok'=>true]);
 }
 /* Закрыть все, кроме текущего — то, ради чего сюда и заходят, когда
    ноутбук потерян. */
 if($method==='POST'&&$path==='/admin/sessions/close-others'){
   $me=bearer();
   $st=$pdo->prepare("DELETE FROM sessions WHERE user_type='admin' AND user_id=? AND token<>?");
   $st->execute([$aid,$me]);
   $n=$st->rowCount();
   adminLog('session','admin',$aid,(string)($meRow['name']??''),'закрыты все входы, кроме текущего: '.$n);
   json_response(['ok'=>true,'closed'=>$n]);
 }
 /* Второй фактор: код на почту при входе. Без рабочей почты включать
    нечем — код просто некуда отправить, и владелец запрёт сам себя. */
 if($method==='POST'&&$path==='/admin/twofa'){
   $on=!empty(input()['on']);
   if($on&&!mailReady())
     json_response(['error'=>'Сначала настройте почту: код входа отправлять некуда'],422);
   $pdo->prepare('UPDATE admins SET twofa=?,twofa_code=NULL,twofa_until=NULL WHERE id=?')
       ->execute([$on?1:0,$aid]);
   adminLog('settings','admin',$aid,(string)($meRow['name']??''),
     $on?'включён вход по коду':'выключен вход по коду');
   json_response(['ok'=>true,'twofa'=>$on]);
 }

 /* --- Аналитика ---
    Сводка отвечает «сколько людей», аналитика — «работает ли сервис».
    Обе цифры считаются на сервере: одинаковое определение удержания
    на экране и в письме важнее, чем возможность посчитать иначе. */
 if($method==='GET'&&$path==='/admin/analytics'){
   $days=max(7,min(180,(int)($_GET['days']??30)));
   json_response([
     'retention'=>retentionStats(),
     'funnel'=>funnelStats($days),
     'week'=>weeklyReport(),
   ]);
 }

 /* --- Отчёты на почту ---
    Владелец не будет заходить в панель каждый понедельник; отчёт
    приходит сам. День и час выбирает он, потому что «утро понедельника»
    у всех разное. */
 if($method==='GET'&&$path==='/admin/reports'){
   json_response(['report'=>[
     'weekly'=>settingGet('report_weekly')==='1',
     'weekday'=>(int)(settingGet('report_weekday')??1),
     'hour'=>(int)(settingGet('report_hour')??10),
     'digest'=>settingGet('report_digest')!=='0',
     'last_weekly'=>settingGet('owner_mail_weekly'),
     'last_digest'=>settingGet('owner_mail_digest'),
   ]]);
 }
 if($method==='POST'&&$path==='/admin/reports'){
   $in=input();
   settingSet('report_weekly',!empty($in['weekly'])?'1':'0');
   settingSet('report_digest',!empty($in['digest'])?'1':'0');
   settingSet('report_weekday',(string)max(1,min(7,(int)($in['weekday']??1))));
   settingSet('report_hour',(string)max(0,min(23,(int)($in['hour']??10))));
   adminLog('settings','reports',null,'Отчёты на почту');
   json_response(['ok'=>true]);
 }
 /* Отправить отчёт сейчас: иначе проверить настройку почты можно только
    дождавшись понедельника. */
 if($method==='POST'&&$path==='/admin/reports/test'){
   settingSet('owner_mail_weekly','2000-01-01 00:00:00');
   $sent=sendWeeklyReport();
   json_response(['ok'=>$sent,'error'=>$sent?null:'Не удалось отправить — проверьте настройки почты']);
 }

 if($method==='GET'&&$path==='/admin/readiness'){
   $legal=legalData();
   $legalMiss=[];
   foreach(['operator'=>'наименование','inn'=>'ИНН','ogrn'=>'ОГРН','address'=>'адрес','email'=>'почта для обращений'] as $k=>$label)
     if(trim((string)($legal[$k]??''))==='') $legalMiss[]=$label;

   $backups=glob(__DIR__.'/../storage/backups/equa-*.sqlite')?:[];
   $lastBackup=null;
   foreach($backups as $f){ $t=filemtime($f); if($lastBackup===null||$t>$lastBackup)$lastBackup=$t; }

   $items=[];
   $items[]=['key'=>'mail','ok'=>mailReady(),'title'=>'Отправка почты',
     'why'=>'Без неё не работают восстановление пароля, приглашения и ответы поддержки на почту.',
     'how'=>'Заполните config/mail.php — рядом лежит mail.sample.php.'];
   $items[]=['key'=>'legal','ok'=>!$legalMiss,'title'=>'Реквизиты в документах',
     'why'=>'Вы обрабатываете данные о здоровье. Пока поля пустые, в политике стоят пропуски вместо названия и ИНН.',
     'how'=>$legalMiss ? 'Не заполнено: '.implode(', ',$legalMiss).' — в разделе «Система» → «Реквизиты».' : ''];
   $items[]=['key'=>'backup','ok'=>$lastBackup!==null && (time()-$lastBackup) < 7*86400,
     'title'=>'Свежая копия базы',
     'why'=>'Данные клиентов есть только здесь. Потеряете базу — потеряете и работу специалистов.',
     'how'=>'Снимите копию кнопкой ниже и поставьте cron/backup.php в планировщик хостинга.'];

   json_response(['items'=>$items,'ready'=>count(array_filter($items,fn($i)=>$i['ok'])),'total'=>count($items)]);
 }
 /* Списки людей в панели — рабочие, а не витрина: владелец приходит
    сюда с вопросом про конкретного человека. Поэтому поиск по имени и
    почте, фильтр по состоянию и страницы. Раньше специалисты грузились
    все разом, а клиенты обрезались на двухстах без предупреждения —
    двести первого нельзя было ни найти, ни заблокировать. */
 if($method==='GET'&&$path==='/admin/specialists'){
   [$where,$args]=adminPeopleFilter('s',$_GET);
   $total=(int)fetchOne($pdo,"SELECT COUNT(*) FROM specialists s $where",$args);
   [$limit,$offset,$page]=adminPage($_GET);
   $st=$pdo->prepare("SELECT s.id,s.name,s.email,s.profession,s.plan,s.status,s.created_at,s.avatar_url,
     (SELECT COUNT(*) FROM clients c WHERE c.specialist_id=s.id) clients,
     (SELECT COUNT(*) FROM menus m WHERE m.specialist_id=s.id AND m.status='published') menus
     FROM specialists s $where ORDER BY s.id DESC LIMIT $limit OFFSET $offset");
   $st->execute($args);
   json_response(['specialists'=>$st->fetchAll(),
     'total'=>$total,'page'=>$page,'pages'=>(int)ceil($total/$limit)]);
 }
 if($method==='PATCH'&&preg_match('#^/admin/specialists/(\d+)$#',$path,$m)){
   $in=input();$st=($in['status']??'')==='blocked'?'blocked':'active';
   $id=(int)$m[1];
   $name=fetchOne($pdo,'SELECT name FROM specialists WHERE id=?',[$id]);
   $pdo->prepare('UPDATE specialists SET status=? WHERE id=?')->execute([$st,$id]);
   if($st==='blocked')$pdo->prepare('DELETE FROM sessions WHERE user_type="specialist" AND user_id=?')->execute([$id]);
   adminLog($st==='blocked'?'block':'unblock','specialist',$id,$name);
   json_response(['ok'=>true,'status'=>$st]);
 }

 /* --- Каталог блюд и копия базы из панели ---
    На shared-хостинге консоли обычно нет, а обе задачи нужны редко, но
    обязательно: залить каталог и снять копию перед его заменой. Раньше
    это требовало SSH — как когда-то настройка push. */
 /* --- Витрина каталога ---
    Каталог видят люди, которые ещё никого не выбрали, и порядок в нём
    решает, к кому они попадут. Поэтому у владельца два рычага:
    закрепить наверху и убрать с витрины. Снятие держим отдельным
    признаком, а не чужим переключателем «показывать профиль»:
    специалист включит его обратно, не зная, что его убрали намеренно. */
 if($method==='GET'&&$path==='/admin/catalog/specialists'){
   $st=$pdo->query("SELECT s.id,s.name,s.avatar_url,s.verify_status,
     COALESCE(p.featured,0) featured,COALESCE(p.catalog_block,0) blocked,
     COALESCE(p.is_public,0) is_public,p.city,p.rating,p.reviews_count,
     (SELECT COUNT(*) FROM clients c WHERE c.specialist_id=s.id AND c.status='active') clients,
     (SELECT COUNT(*) FROM catalog_leads l WHERE l.specialist_id=s.id) leads
     FROM specialists s JOIN public_profiles p ON p.specialist_id=s.id
     ORDER BY COALESCE(p.featured,0) DESC, p.rating DESC, p.reviews_count DESC, s.name");
   $rows=$st->fetchAll();
   $live=0; foreach($rows as $r) if($r['is_public']&&!$r['blocked']&&$r['verify_status']==='verified')$live++;
   json_response(['specialists'=>$rows,'live'=>$live]);
 }
 /* Закрепление и снятие. Место закреплённого — число: чем больше, тем
    выше, поэтому «поднять» не перетасовывает соседей. */
 if($method==='POST'&&preg_match('#^/admin/catalog/specialists/(\d+)$#',$path,$m)){
   $sid=(int)$m[1]; $in=input();
   $has=fetchOne($pdo,'SELECT 1 FROM public_profiles WHERE specialist_id=?',[$sid]);
   if(!$has)json_response(['error'=>'У специалиста нет публичного профиля'],404);
   $name=fetchOne($pdo,'SELECT name FROM specialists WHERE id=?',[$sid]);
   if(array_key_exists('featured',$in)){
     $f=max(0,min(999,(int)$in['featured']));
     $pdo->prepare('UPDATE public_profiles SET featured=? WHERE specialist_id=?')->execute([$f,$sid]);
     adminLog('catalog','specialist',$sid,$name,$f?('закреплён, место '.$f):'откреплён');
   }
   if(array_key_exists('blocked',$in)){
     $b=!empty($in['blocked'])?1:0;
     $pdo->prepare('UPDATE public_profiles SET catalog_block=? WHERE specialist_id=?')->execute([$b,$sid]);
     adminLog('catalog','specialist',$sid,$name,$b?'убран с витрины':'возвращён на витрину');
   }
   json_response(['ok'=>true]);
 }
 if($method==='GET'&&$path==='/admin/catalog'){
   $d=dishesData();
   $backups=glob(__DIR__.'/../storage/backups/equa-*.sqlite')?:[];
   sort($backups);
   $last=$backups?basename(end($backups)):null;
   $noPhoto=(int)$pdo->query("SELECT COUNT(*) FROM dishes WHERE photo_url IS NULL OR photo_url=''")->fetchColumn();
   /* Блюдо без состава считать не из чего: в меню оно даст ноль калорий,
      и заметить это по каталогу нельзя — карточка выглядит обычной. */
   $noRecipe=(int)$pdo->query('SELECT COUNT(*) FROM dishes WHERE id NOT IN (SELECT dish_id FROM dish_ingredients)')->fetchColumn();
   json_response([
     'file'=>['dishes'=>count($d['dishes']),'ingredients'=>count($d['ingredients'])],
     'db'=>[
       'dishes'=>(int)$pdo->query('SELECT COUNT(*) FROM dishes')->fetchColumn(),
       'ingredients'=>(int)$pdo->query('SELECT COUNT(*) FROM ingredients')->fetchColumn(),
       'menus'=>(int)$pdo->query('SELECT COUNT(*) FROM menus')->fetchColumn(),
       'no_photo'=>$noPhoto,
       'no_recipe'=>$noRecipe,
     ],
     'backups'=>['count'=>count($backups),'last'=>$last],
   ]);
 }
 /* Уборка демо-данных. Папка tools/ закрыта от веба намеренно, а на
    хостинге без SSH запустить скрипт нечем — поэтому то же самое доступно
    владельцу из панели. Без ключа apply только считает, ничего не трогая. */
 if($method==='POST'&&$path==='/admin/cleanup-demo'){
   $in=input();
   json_response(cleanupDemo(!empty($in['apply']),!empty($in['keep_catalog'])));
 }
 if($method==='POST'&&$path==='/admin/backup'){
   $r=makeBackup();
   if(isset($r['error']))json_response(['error'=>$r['error']],422);
   json_response($r,201);
 }
 if($method==='POST'&&$path==='/admin/catalog/import'){
   $in=input();
   $replace=!empty($in['replace']);
   /* Замена сносит и меню. Требуем свежую копию — не как формальность:
      вернуть удалённые меню больше неоткуда. */
   if($replace){
     $b=glob(__DIR__.'/../storage/backups/equa-*.sqlite')?:[];
     $fresh=false;
     foreach($b as $f) if(time()-filemtime($f) < 3600) $fresh=true;
     if(!$fresh)json_response(['error'=>'Сначала снимите копию базы — замена удалит все меню'],422);
   }
   $r=importDishes($replace);
   if(isset($r['error']))json_response(['error'=>$r['error']],422);
   json_response($r,201);
 }

 /* Отзывы у владельца — только чтобы убрать брань или чужие личные
    данные. Причину сохраняем: скрытый без объяснения отзыв — это тот
    же поддельный рейтинг, только наоборот. */
 if($method==='GET'&&$path==='/admin/reviews'){
   $total=(int)fetchOne($pdo,'SELECT COUNT(*) FROM specialist_reviews');
   [$limit,$offset,$page]=adminPage($_GET);
   $st=$pdo->prepare("SELECT r.*, c.name client_name, s.name specialist_name
     FROM specialist_reviews r
     JOIN clients c ON c.id=r.client_id
     JOIN specialists s ON s.id=r.specialist_id
     ORDER BY r.id DESC LIMIT $limit OFFSET $offset");
   $st->execute();
   json_response(['reviews'=>$st->fetchAll(),'total'=>$total,'page'=>$page,'pages'=>(int)ceil($total/$limit)]);
 }
 if($method==='PATCH'&&preg_match('#^/admin/reviews/(\d+)$#',$path,$m)){
   $in=input();$st=($in['status']??'')==='hidden'?'hidden':'published';
   $why=trim((string)($in['reason']??''));
   if($st==='hidden'&&$why==='')json_response(['error'=>'Укажите причину'],422);
   $q=$pdo->prepare('SELECT specialist_id FROM specialist_reviews WHERE id=?');
   $q->execute([(int)$m[1]]);$spid=(int)($q->fetchColumn()?:0);
   if(!$spid)json_response(['error'=>'Не найдено'],404);
   $pdo->prepare('UPDATE specialist_reviews SET status=?,hidden_reason=? WHERE id=?')
       ->execute([$st,$st==='hidden'?$why:null,(int)$m[1]]);
   refreshRating($spid);
   json_response(['ok'=>true,'status'=>$st]);
 }

 /* --- Верификация: сторона владельца ---
    Очередь сверху вниз: сначала те, кто ждёт ответа. */
 if($method==='GET'&&$path==='/admin/verifications'){
   $rows=$pdo->query("SELECT s.id,s.name,s.email,COALESCE(s.profession,'nutritionist') profession,
       COALESCE(s.verify_status,'none') verify_status,s.verify_note,s.verify_submitted_at,s.verified_at,s.avatar_url,
       p.education,p.experience_years,p.specializations,
       (SELECT COUNT(*) FROM specialist_documents d WHERE d.specialist_id=s.id) docs,
       (SELECT COUNT(*) FROM specialist_documents d WHERE d.specialist_id=s.id AND d.status='pending') docs_pending
       FROM specialists s LEFT JOIN public_profiles p ON p.specialist_id=s.id
       WHERE COALESCE(s.verify_status,'none')<>'none'
          OR EXISTS(SELECT 1 FROM specialist_documents d WHERE d.specialist_id=s.id)
       ORDER BY (COALESCE(s.verify_status,'none')='pending') DESC, s.verify_submitted_at DESC, s.id DESC")->fetchAll();
   $docs=$pdo->query('SELECT * FROM specialist_documents ORDER BY id DESC')->fetchAll();
   $by=[];foreach($docs as $d)$by[(int)$d['specialist_id']][]=$d;
   foreach($rows as &$r)$r['documents']=$by[(int)$r['id']]??[];
   unset($r);
   json_response(['specialists'=>$rows]);
 }
 /* Решение по одному документу. Отказ без причины — это спор без
    разбора, поэтому причину просим обязательно. */
 if($method==='PATCH'&&preg_match('#^/admin/documents/(\d+)$#',$path,$m)){
   $in=input();$st=(string)($in['status']??'');
   if(!in_array($st,['pending','approved','rejected'],true))json_response(['error'=>'Неизвестный статус'],422);
   $note=trim((string)($in['review_note']??''));
   if($st==='rejected'&&$note==='')json_response(['error'=>'Укажите причину отказа'],422);
   $q=$pdo->prepare('SELECT specialist_id FROM specialist_documents WHERE id=?');
   $q->execute([(int)$m[1]]);$spid=(int)($q->fetchColumn()?:0);
   if(!$spid)json_response(['error'=>'Не найдено'],404);
   $pdo->prepare('UPDATE specialist_documents SET status=?,review_note=?,reviewed_at=? WHERE id=?')
       ->execute([$st,$note?:null,now(),(int)$m[1]]);
   refreshVerification($spid);
   if($st==='rejected')
     notifySpecialist($spid,'verification','Документ отклонён',$note);
   json_response(['ok'=>true]);
 }
 /* Итоговое решение по специалисту. Подтвердить можно только тогда,
    когда хотя бы один документ действительно принят: иначе галочка
    ничего не значит. */
 if($method==='PATCH'&&preg_match('#^/admin/verifications/(\d+)$#',$path,$m)){
   $spid=(int)$m[1];$in=input();$st=(string)($in['status']??'');
   if(!in_array($st,['none','pending','verified','rejected'],true))json_response(['error'=>'Неизвестный статус'],422);
   $note=trim((string)($in['note']??''));
   if($st==='rejected'&&$note==='')json_response(['error'=>'Укажите причину отказа'],422);
   if($st==='verified'){
     $n=$pdo->prepare("SELECT COUNT(*) FROM specialist_documents WHERE specialist_id=? AND status='approved'");
     $n->execute([$spid]);
     if((int)$n->fetchColumn()===0)json_response(['error'=>'Сначала примите хотя бы один документ'],422);
   }
   $pdo->prepare('UPDATE specialists SET verify_status=?,verify_note=?,verified_at=? WHERE id=?')
       ->execute([$st,$note?:null,$st==='verified'?now():null,$spid]);
   adminLog('verify:'.$st,'specialist',$spid,
     fetchOne($pdo,'SELECT name FROM specialists WHERE id=?',[$spid]),$note?:null);
   /* Человек ждёт ответа: сообщаем и в сервисе, и письмом. */
   if($st==='verified'){
     notifySpecialist($spid,'verification','Верификация пройдена',
       'Ваша карточка появилась в каталоге, рядом с именем стоит отметка «Проверен».');
     [$h,$t]=plainLetter('Верификация пройдена.',
       'Мы сверили ваши документы. Карточка появилась в каталоге '.APP_NAME
       .', рядом с именем стоит отметка «Проверен».');
     mailSpecialist($spid,'Верификация пройдена — '.APP_NAME,$h,$t);
   } elseif($st==='rejected'){
     notifySpecialist($spid,'verification','В верификации отказано',$note);
     [$h,$t]=plainLetter('В верификации отказано.',$note,
       'Исправьте замечание и отправьте документы заново в разделе «Верификация».');
     mailSpecialist($spid,'Верификация: нужны правки — '.APP_NAME,$h,$t);
   }
   json_response(['ok'=>true,'status'=>$st]);
 }

 if($method==='GET'&&$path==='/admin/clients'){
   [$where,$args]=adminPeopleFilter('c',$_GET);
   $total=(int)fetchOne($pdo,"SELECT COUNT(*) FROM clients c $where",$args);
   [$limit,$offset,$page]=adminPage($_GET);
   $st=$pdo->prepare("SELECT c.id,c.name,c.email,c.goal,c.status,c.created_at,c.avatar_url,s.name specialist
     FROM clients c LEFT JOIN specialists s ON s.id=c.specialist_id
     $where ORDER BY c.id DESC LIMIT $limit OFFSET $offset");
   $st->execute($args);
   json_response(['clients'=>safeClients($st->fetchAll()),
     'total'=>$total,'page'=>$page,'pages'=>(int)ceil($total/$limit)]);
 }
 /* --- Промокоды ---
    В комиссионной модели скидка — это чьи-то деньги, поэтому плательщик
    указывается явно: сервис отдаёт из комиссии, специалист — из своей
    доли. Молча поделить между ними нельзя. */
 if($method==='GET'&&$path==='/admin/promos'){
   $rows=$pdo->query("SELECT p.*, s.name specialist_name,
       (SELECT COALESCE(SUM(amount_kop),0) FROM promo_uses u WHERE u.promo_id=p.id) spent_kop
     FROM promo_codes p LEFT JOIN specialists s ON s.id=p.specialist_id
     ORDER BY p.id DESC LIMIT 200")->fetchAll();
   json_response(['promos'=>$rows]);
 }
 if($method==='POST'&&$path==='/admin/promos'){
   $in=input();
   $code=strtoupper(preg_replace('~[^A-Za-z0-9\-]~','',(string)($in['code']??'')));
   $pct=(int)($in['percent']??0);
   if(strlen($code)<3)json_response(['error'=>'Код — минимум 3 символа, латиница и цифры'],422);
   if($pct<1||$pct>100)json_response(['error'=>'Скидка — от 1 до 100 %'],422);
   $payer=($in['payer']??'service')==='specialist'?'specialist':'service';
   if(fetchOne($pdo,'SELECT 1 FROM promo_codes WHERE code=?',[$code]))
     json_response(['error'=>'Такой код уже есть'],422);
   $pdo->prepare('INSERT INTO promo_codes(code,percent,payer,specialist_id,max_uses,expires_at,status,note,created_at)
     VALUES(?,?,?,?,?,?,?,?,?)')->execute([$code,$pct,$payer,
     ((int)($in['specialist_id']??0))?:null,
     ((int)($in['max_uses']??0))?:null,
     trim((string)($in['expires_at']??''))?:null,'active',
     mb_substr(trim((string)($in['note']??'')),0,200)?:null,now()]);
   adminLog('promo:add','promo',(int)$pdo->lastInsertId(),$code,$pct.'% за счёт '.($payer==='service'?'сервиса':'специалиста'));
   json_response(['ok'=>true],201);
 }
 if($method==='PATCH'&&preg_match('#^/admin/promos/(\d+)$#',$path,$m)){
   $id=(int)$m[1]; $in=input();
   $st=($in['status']??'')==='off'?'off':'active';
   $code=fetchOne($pdo,'SELECT code FROM promo_codes WHERE id=?',[$id]);
   $pdo->prepare('UPDATE promo_codes SET status=? WHERE id=?')->execute([$st,$id]);
   adminLog($st==='off'?'promo:off':'promo:on','promo',$id,$code);
   json_response(['ok'=>true,'status'=>$st]);
 }
 if($method==='DELETE'&&preg_match('#^/admin/promos/(\d+)$#',$path,$m)){
   $id=(int)$m[1];
   $code=fetchOne($pdo,'SELECT code FROM promo_codes WHERE id=?',[$id]);
   if((int)fetchOne($pdo,'SELECT COUNT(*) FROM promo_uses WHERE promo_id=?',[$id]))
     json_response(['error'=>'Кодом уже пользовались — его можно только выключить'],422);
   $pdo->prepare('DELETE FROM promo_codes WHERE id=?')->execute([$id]);
   adminLog('promo:delete','promo',$id,$code);
   json_response(['ok'=>true]);
 }

 /* --- Деньги по месяцам ---
    Комиссия — вся наша выручка, и до сих пор она была видна одной
    суммой «за всё время». Месяц к месяцу — единственный разрез, по
    которому понятно, растём мы или нет. */
 if($method==='GET'&&$path==='/admin/money'){
   $months=$pdo->query("SELECT strftime('%Y-%m',paid_at) m,
       COUNT(*) deals,
       COALESCE(SUM(price_kop),0) turnover_kop,
       COALESCE(SUM(commission_kop),0) commission_kop,
       COALESCE(SUM(acquirer_fee_kop),0) fee_kop
     FROM client_subscriptions
     WHERE paid=1 AND paid_at IS NOT NULL
     GROUP BY m ORDER BY m DESC LIMIT 18")->fetchAll();
   $payouts=$pdo->query("SELECT strftime('%Y-%m',decided_at) m,COUNT(*) n,
       COALESCE(SUM(amount_kop),0) kop
     FROM payout_requests WHERE status='paid' AND decided_at IS NOT NULL
     GROUP BY m ORDER BY m DESC LIMIT 18")->fetchAll();
   $byPayout=[]; foreach($payouts as $r)$byPayout[$r['m']]=$r;
   foreach($months as &$r){
     $r['payouts_kop']=(int)($byPayout[$r['m']]['kop']??0);
     $r['payouts_n']=(int)($byPayout[$r['m']]['n']??0);
     $r['net_kop']=(int)$r['commission_kop']-(int)$r['fee_kop'];
   }
   /* Кто приносит больше всего — тот, с кем стоит договариваться лично. */
   $top=$pdo->query("SELECT s.id,s.name,COUNT(cs.id) deals,
       COALESCE(SUM(cs.price_kop),0) turnover_kop,
       COALESCE(SUM(cs.commission_kop),0) commission_kop
     FROM client_subscriptions cs JOIN specialists s ON s.id=cs.specialist_id
     WHERE cs.paid=1 GROUP BY s.id ORDER BY turnover_kop DESC LIMIT 10")->fetchAll();
   json_response(['months'=>$months,'top'=>$top]);
 }

 /* --- Ставка комиссии конкретного специалиста ---
    Пустое поле означает «по общим правилам»: так видно, что человек на
    общих условиях, а не что ему случайно проставили ноль. */
 if($method==='POST'&&preg_match('#^/admin/specialists/(\d+)/rate$#',$path,$m)){
   $id=(int)$m[1]; $in=input();
   $norm=function($v){
     if($v===''||$v===null)return null;
     $f=(float)str_replace(',','.',(string)$v);
     if($f<0||$f>90)json_response(['error'=>'Ставка — от 0 до 90 %'],422);
     return $f/100;
   };
   $own=$norm($in['rate_own']??null); $cat=$norm($in['rate_catalog']??null);
   $pdo->prepare('UPDATE specialists SET rate_own=?,rate_catalog=? WHERE id=?')
       ->execute([$own,$cat,$id]);
   adminLog('rate','specialist',$id,fetchOne($pdo,'SELECT name FROM specialists WHERE id=?',[$id]),
     ($own===null?'общая':round($own*100).'%').' / '.($cat===null?'общая':round($cat*100).'%'));
   json_response(['ok'=>true]);
 }

 /* --- Сегменты ---
    Готовые выборки, за которыми владелец приходит чаще всего: кому не
    назначен специалист, кто перестал отмечать еду, у кого есть меню, но
    ни одной отметки. Без них такие вопросы решались глазами по списку. */
 if($method==='GET'&&$path==='/admin/segments'){
   $seg=(string)($_GET['name']??'');
   $sql=null;
   if($seg==='no_specialist'){
     $sql="SELECT c.id,c.name,c.email,c.goal,c.status,c.created_at,c.avatar_url,NULL specialist
       FROM clients c WHERE c.specialist_id IS NULL ORDER BY c.id DESC";
   }elseif($seg==='silent'){
     $sql="SELECT c.id,c.name,c.email,c.goal,c.status,c.created_at,c.avatar_url,s.name specialist
       FROM clients c LEFT JOIN specialists s ON s.id=c.specialist_id
       WHERE NOT EXISTS(SELECT 1 FROM meal_logs l WHERE l.client_id=c.id
         AND l.logged_at>=datetime('now','-14 day'))
       ORDER BY c.id DESC";
   }elseif($seg==='menu_no_log'){
     $sql="SELECT c.id,c.name,c.email,c.goal,c.status,c.created_at,c.avatar_url,s.name specialist
       FROM clients c LEFT JOIN specialists s ON s.id=c.specialist_id
       WHERE EXISTS(SELECT 1 FROM menus m WHERE m.client_id=c.id AND m.status='published')
         AND NOT EXISTS(SELECT 1 FROM meal_logs l WHERE l.client_id=c.id)
       ORDER BY c.id DESC";
   }else json_response(['error'=>'Неизвестный сегмент'],422);
   $rows=$pdo->query($sql)->fetchAll();
   json_response(['clients'=>safeClients($rows),'total'=>count($rows),'page'=>1,'pages'=>1]);
 }

 /* --- Действие сразу над несколькими ---
    Перевести десять клиентов ушедшего специалиста по одному — это
    десять подтверждений и десять шансов забыть кого-то. */
 if($method==='POST'&&$path==='/admin/bulk'){
   $in=input();
   $kind=($in['kind']??'')==='specialist'?'specialist':'client';
   $ids=array_values(array_filter(array_map('intval',(array)($in['ids']??[]))));
   $act=(string)($in['action']??'');
   if(!$ids)json_response(['error'=>'Никто не выбран'],422);
   if(count($ids)>500)json_response(['error'=>'За раз не больше 500'],422);
   $table=$kind==='specialist'?'specialists':'clients';
   $in_ph=implode(',',array_fill(0,count($ids),'?'));
   $done=0;
   if($act==='block'||$act==='unblock'){
     $st=$act==='block'?'blocked':'active';
     $q=$pdo->prepare("UPDATE $table SET status=? WHERE id IN ($in_ph)");
     $q->execute(array_merge([$st],$ids)); $done=$q->rowCount();
     if($act==='block'){
       $pdo->prepare("DELETE FROM sessions WHERE user_type=? AND user_id IN ($in_ph)")
           ->execute(array_merge([$kind],$ids));
     }
   }elseif($act==='move'&&$kind==='client'){
     $sp=(int)($in['specialist_id']??0);
     if($sp&&!fetchOne($pdo,'SELECT 1 FROM specialists WHERE id=?',[$sp]))
       json_response(['error'=>'Специалист не найден'],422);
     $q=$pdo->prepare("UPDATE clients SET specialist_id=? WHERE id IN ($in_ph)");
     $q->execute(array_merge([$sp?:null],$ids)); $done=$q->rowCount();
   }else json_response(['error'=>'Неизвестное действие'],422);
   adminLog('bulk:'.$act,$kind,null,null,$done.' записей');
   json_response(['ok'=>true,'done'=>$done]);
 }

 /* --- Заметки о человеке ---
    То, чем CRM отличается от списка пользователей: с человеком уже
    говорили, и это надо помнить не в голове одного владельца. */
 if($method==='POST'&&preg_match('#^/admin/person/(specialist|client)/(\d+)/notes$#',$path,$m)){
   $body=trim((string)(input()['body']??''));
   if($body==='')json_response(['error'=>'Пустая заметка'],422);
   $pdo->prepare('INSERT INTO person_notes(target_type,target_id,author_id,author_name,body,created_at)
     VALUES(?,?,?,?,?,?)')->execute([$m[1],(int)$m[2],$aid,$meRow['name']??null,mb_substr($body,0,2000),now()]);
   adminLog('note',$m[1],(int)$m[2],null,mb_substr($body,0,120));
   json_response(['ok'=>true,'notes'=>personNotes($m[1],(int)$m[2])],201);
 }
 if($method==='DELETE'&&preg_match('#^/admin/notes/(\d+)$#',$path,$m)){
   $pdo->prepare('DELETE FROM person_notes WHERE id=?')->execute([(int)$m[1]]);
   json_response(['ok'=>true]);
 }

 /* --- Завести человека вручную ---
    Специалист пришёл по телефону, клиента заводит сам владелец на
    показе — ждать, пока они зарегистрируются сами, неоткуда. */
 if($method==='POST'&&$path==='/admin/people'){
   $in=input();
   $kind=($in['kind']??'')==='specialist'?'specialist':'client';
   $name=trim((string)($in['name']??''));
   $email=mb_strtolower(trim((string)($in['email']??'')));
   if($name==='')json_response(['error'=>'Укажите имя'],422);
   if(!filter_var($email,FILTER_VALIDATE_EMAIL))json_response(['error'=>'Проверьте почту'],422);
   $table=$kind==='specialist'?'specialists':'clients';
   if(fetchOne($pdo,"SELECT 1 FROM $table WHERE LOWER(email)=?",[$email]))
     json_response(['error'=>'Такая почта уже заведена'],422);
   $pass=bin2hex(random_bytes(4)).'A1';
   $hash=password_hash($pass,PASSWORD_DEFAULT);
   if($kind==='specialist'){
     $pdo->prepare('INSERT INTO specialists(email,password_hash,name,phone,profession,plan,status,join_code,created_at)
       VALUES(?,?,?,?,?,?,?,?,?)')->execute([$email,$hash,$name,
       trim((string)($in['phone']??'')) ?: null,
       (string)($in['profession']??'nutritionist'),'free','active',
       strtoupper(bin2hex(random_bytes(3))),now()]);
   }else{
     $sp=(int)($in['specialist_id']??0);
     $pdo->prepare('INSERT INTO clients(specialist_id,name,email,phone,password_hash,goal,status,created_at)
       VALUES(?,?,?,?,?,?,?,?)')->execute([$sp?:null,$name,$email,
       trim((string)($in['phone']??'')) ?: null,$hash,
       trim((string)($in['goal']??'')) ?: null,'active',now()]);
   }
   $id=(int)$pdo->lastInsertId();
   adminLog('create',$kind,$id,$name);
   json_response(['ok'=>true,'id'=>$id,'password'=>$pass],201);
 }

 /* --- Что можно сделать с человеком ---
    Раньше единственным действием была блокировка. Смена специалиста,
    сброс пароля и удаление по требованию делались руками в базе — а
    удаление данных по требованию у нас вообще-то обязанность. */
 if($method==='PATCH'&&preg_match('#^/admin/person/(specialist|client)/(\d+)$#',$path,$m)){
   $kind=$m[1]; $id=(int)$m[2]; $in=input();
   $table=$kind==='specialist'?'specialists':'clients';
   $name=fetchOne($pdo,"SELECT name FROM $table WHERE id=?",[$id]);
   if($name===false)json_response(['error'=>'Не найден'],404);
   if(isset($in['email'])){
     $email=mb_strtolower(trim((string)$in['email']));
     if(!filter_var($email,FILTER_VALIDATE_EMAIL))json_response(['error'=>'Проверьте почту'],422);
     if(fetchOne($pdo,"SELECT 1 FROM $table WHERE LOWER(email)=? AND id<>?",[$email,$id]))
       json_response(['error'=>'Почта занята'],422);
     $pdo->prepare("UPDATE $table SET email=? WHERE id=?")->execute([$email,$id]);
     adminLog('edit:email',$kind,$id,$name,$email);
   }
   if(isset($in['name'])&&trim((string)$in['name'])!==''){
     $pdo->prepare("UPDATE $table SET name=? WHERE id=?")->execute([mb_substr(trim((string)$in['name']),0,120),$id]);
     adminLog('edit:name',$kind,$id,$name);
   }
   if($kind==='client'&&array_key_exists('specialist_id',$in)){
     $sp=(int)$in['specialist_id'];
     $to=$sp?fetchOne($pdo,'SELECT name FROM specialists WHERE id=?',[$sp]):null;
     if($sp&&!$to)json_response(['error'=>'Специалист не найден'],422);
     $pdo->prepare('UPDATE clients SET specialist_id=? WHERE id=?')->execute([$sp?:null,$id]);
     adminLog('move','client',$id,$name,$to?('к «'.$to.'»'):'откреплён');
   }
   if(!empty($in['reset_password'])){
     $pass=bin2hex(random_bytes(4)).'A1';
     $pdo->prepare("UPDATE $table SET password_hash=? WHERE id=?")
         ->execute([password_hash($pass,PASSWORD_DEFAULT),$id]);
     $pdo->prepare('DELETE FROM sessions WHERE user_type=? AND user_id=?')->execute([$kind,$id]);
     adminLog('password',$kind,$id,$name);
     json_response(['ok'=>true,'password'=>$pass]);
   }
   json_response(['ok'=>true]);
 }
 if($method==='DELETE'&&preg_match('#^/admin/person/(specialist|client)/(\d+)$#',$path,$m)){
   $kind=$m[1]; $id=(int)$m[2];
   $table=$kind==='specialist'?'specialists':'clients';
   $name=fetchOne($pdo,"SELECT name FROM $table WHERE id=?",[$id]);
   if($name===false)json_response(['error'=>'Не найден'],404);
   if($kind==='specialist'){
     $n=(int)fetchOne($pdo,'SELECT COUNT(*) FROM clients WHERE specialist_id=?',[$id]);
     if($n)json_response(['error'=>'У специалиста ещё '.$n.' клиент(ов) — сначала переведите их к другому'],422);
   }
   $pdo->prepare('DELETE FROM sessions WHERE user_type=? AND user_id=?')->execute([$kind,$id]);
   $pdo->prepare("DELETE FROM $table WHERE id=?")->execute([$id]);
   adminLog('delete',$kind,$id,$name,'удалён по требованию');
   json_response(['ok'=>true]);
 }

 /* --- Тексты сайта ---
    Заголовок на главной меняется чаще, чем кто-то готов лезть по SSH. */
 if($method==='GET'&&$path==='/admin/texts'){
   json_response(['texts'=>siteTexts(),'fields'=>SITE_TEXTS]);
 }
 if($method==='POST'&&$path==='/admin/texts'){
   if(!siteTextsSave(input()))json_response(['error'=>'Не удалось сохранить'],500);
   adminLog('settings','site',null,'Тексты сайта');
   json_response(['ok'=>true,'texts'=>siteTexts()]);
 }

 /* --- Медиатека ---
    Фотографии блюд раскладывались файлами в папку dishes/ по именам из
    таблицы: чтобы добавить снимок, нужен был доступ к хостингу. Здесь
    их можно загрузить прямо в панели и сразу привязать к блюду. */
 if($method==='GET'&&$path==='/admin/media'){
   $dir=__DIR__.'/../storage/uploads';
   $files=glob($dir.'/*.{jpg,jpeg,png,webp}',GLOB_BRACE)?:[];
   usort($files,fn($a,$b)=>filemtime($b)<=>filemtime($a));
   $out=[];
   foreach(array_slice($files,0,200) as $f){
     $out[]=['name'=>basename($f),'url'=>'/api/v1/avatar/'.basename($f),
             'size'=>filesize($f),'at'=>gmdate('Y-m-d H:i:s',filemtime($f))];
   }
   /* Блюда без фотографии — главный повод сюда зайти. */
   $noPhoto=$pdo->query("SELECT id,name FROM dishes
     WHERE photo_url IS NULL OR photo_url='' ORDER BY name LIMIT 100")->fetchAll();
   json_response(['media'=>$out,'total'=>count($files),'no_photo'=>$noPhoto]);
 }
 if($method==='POST'&&preg_match('#^/admin/dishes/(\d+)/photo$#',$path,$m)){
   $id=(int)$m[1]; $in=input();
   $url=trim((string)($in['photo_url']??''));
   if($url==='')json_response(['error'=>'Не выбран снимок'],422);
   $pdo->prepare('UPDATE dishes SET photo_url=?,photo_thumb_url=? WHERE id=?')
       ->execute([$url,$url,$id]);
   adminLog('photo','dish',$id,fetchOne($pdo,'SELECT name FROM dishes WHERE id=?',[$id]));
   json_response(['ok'=>true]);
 }
 /* --- Реквизиты организации ---
    Их правит владелец, а не файл на хостинге: адрес и почта для
    обращений меняются чаще, чем кто-то готов лезть по SSH. */
 if($method==='GET'&&$path==='/admin/legal'){
   json_response(['legal'=>legalData(),'fields'=>LEGAL_FIELDS]);
 }
 if($method==='POST'&&$path==='/admin/legal'){
   $in=input();
   if(!legalSave($in))json_response(['error'=>'Не удалось сохранить'],500);
   adminLog('settings','legal',null,'Реквизиты организации');
   json_response(['ok'=>true,'legal'=>legalData()]);
 }

 /* --- Выгрузка списков ---
    Таблицу владельцу рано или поздно нужно унести к себе: посчитать в
    таблице, отдать бухгалтеру, сверить. Отдаём CSV с разделителем
    «точка с запятой» и BOM — так его открывает Excel по-русски, без
    пляски с кодировками. */
 if($method==='GET'&&preg_match('#^/admin/export/(specialists|clients)$#',$path,$m)){
   $kind=$m[1];
   if($kind==='specialists'){
     [$where,$args]=adminPeopleFilter('s',$_GET);
     $st=$pdo->prepare("SELECT s.id,s.name,s.email,s.phone,COALESCE(s.profession,'') profession,
       COALESCE(s.plan,'free') plan,COALESCE(s.status,'active') status,
       COALESCE(s.verify_status,'none') verify_status,s.created_at,
       (SELECT COUNT(*) FROM clients c WHERE c.specialist_id=s.id) clients,
       (SELECT COUNT(*) FROM menus m WHERE m.specialist_id=s.id AND m.status='published') menus
       FROM specialists s $where ORDER BY s.id");
     $head=['ID','Имя','Почта','Телефон','Профессия','Тариф','Состояние','Верификация','Заведён','Клиентов','Меню'];
   }else{
     [$where,$args]=adminPeopleFilter('c',$_GET);
     $st=$pdo->prepare("SELECT c.id,c.name,c.email,c.phone,COALESCE(c.goal,'') goal,
       COALESCE(c.status,'active') status,c.created_at,COALESCE(s.name,'') specialist
       FROM clients c LEFT JOIN specialists s ON s.id=c.specialist_id $where ORDER BY c.id");
     $head=['ID','Имя','Почта','Телефон','Цель','Состояние','Заведён','Специалист'];
   }
   $st->execute($args); $rows=$st->fetchAll();
   adminLog('export',$kind==='specialists'?'specialist':'client',null,null,count($rows).' строк');
   header('Content-Type: text/csv; charset=utf-8');
   header('Content-Disposition: attachment; filename="equa-'.$kind.'-'.gmdate('Y-m-d').'.csv"');
   $out=fopen('php://output','w');
   fwrite($out,"\xEF\xBB\xBF");           /* BOM: без него Excel читает кириллицу как крякозябры */
   fputcsv($out,$head,';');
   foreach($rows as $r)fputcsv($out,array_values($r),';');
   fclose($out); exit;
 }

 /* --- Сотрудники панели ---
    Владелец заводит помощников сам: почта, имя, роль, временный пароль.
    Пароль показываем один раз в ответе — хранить его негде, а слать
    почтой мы не всегда можем. */
 if($method==='GET'&&$path==='/admin/staff'){
   $rows=$pdo->query("SELECT id,name,email,COALESCE(role,'owner') role,
     COALESCE(status,'active') status,created_at FROM admins ORDER BY id")->fetchAll();
   json_response(['staff'=>$rows,'roles'=>ADMIN_ROLES,'me'=>$aid,'my_role'=>$myRole]);
 }
 if($method==='POST'&&$path==='/admin/staff'){
   $in=input();
   $email=mb_strtolower(trim((string)($in['email']??'')));
   $name=trim((string)($in['name']??''));
   $role=(string)($in['role']??'support');
   if(!filter_var($email,FILTER_VALIDATE_EMAIL))json_response(['error'=>'Проверьте почту'],422);
   if($name==='')json_response(['error'=>'Укажите имя'],422);
   if(!isset(ADMIN_ROLES[$role])||$role==='owner')json_response(['error'=>'Выберите роль помощника'],422);
   if(fetchOne($pdo,'SELECT 1 FROM admins WHERE LOWER(email)=?',[$email]))
     json_response(['error'=>'Такая почта уже заведена'],422);
   /* Временный пароль выдаём сами: помощник поменяет его при первом
      входе, а придумывать за него нечего. */
   $pass=bin2hex(random_bytes(4)).'A1';
   $pdo->prepare('INSERT INTO admins(email,password_hash,name,role,status,created_by,created_at)
     VALUES(?,?,?,?,?,?,?)')->execute([$email,password_hash($pass,PASSWORD_DEFAULT),$name,$role,'active',$aid,now()]);
   $id=(int)$pdo->lastInsertId();
   adminLog('staff:add','admin',$id,$name,ADMIN_ROLES[$role]);
   json_response(['ok'=>true,'id'=>$id,'password'=>$pass],201);
 }
 if($method==='PATCH'&&preg_match('#^/admin/staff/(\d+)$#',$path,$m)){
   $id=(int)$m[1]; $in=input();
   $row=$pdo->prepare('SELECT id,name,role FROM admins WHERE id=?'); $row->execute([$id]); $row=$row->fetch();
   if(!$row)json_response(['error'=>'Сотрудник не найден'],404);
   if($id===$aid)json_response(['error'=>'Свою роль и доступ менять нельзя — так недолго закрыть себе вход'],422);
   if(($row['role']??'')==='owner')json_response(['error'=>'Учётку владельца менять нельзя'],422);
   if(isset($in['role'])){
     $role=(string)$in['role'];
     if(!isset(ADMIN_ROLES[$role])||$role==='owner')json_response(['error'=>'Выберите роль помощника'],422);
     $pdo->prepare('UPDATE admins SET role=? WHERE id=?')->execute([$role,$id]);
     adminLog('staff:role','admin',$id,$row['name'],ADMIN_ROLES[$role]);
   }
   if(isset($in['status'])){
     $st=$in['status']==='blocked'?'blocked':'active';
     $pdo->prepare('UPDATE admins SET status=? WHERE id=?')->execute([$st,$id]);
     if($st==='blocked')$pdo->prepare('DELETE FROM sessions WHERE user_type="admin" AND user_id=?')->execute([$id]);
     adminLog($st==='blocked'?'staff:block':'staff:unblock','admin',$id,$row['name']);
   }
   if(!empty($in['reset_password'])){
     $pass=bin2hex(random_bytes(4)).'A1';
     $pdo->prepare('UPDATE admins SET password_hash=? WHERE id=?')->execute([password_hash($pass,PASSWORD_DEFAULT),$id]);
     $pdo->prepare('DELETE FROM sessions WHERE user_type="admin" AND user_id=?')->execute([$id]);
     adminLog('staff:password','admin',$id,$row['name']);
     json_response(['ok'=>true,'password'=>$pass]);
   }
   json_response(['ok'=>true]);
 }
 if($method==='DELETE'&&preg_match('#^/admin/staff/(\d+)$#',$path,$m)){
   $id=(int)$m[1];
   if($id===$aid)json_response(['error'=>'Свою учётку удалить нельзя'],422);
   $row=$pdo->prepare('SELECT name,role FROM admins WHERE id=?'); $row->execute([$id]); $row=$row->fetch();
   if(!$row)json_response(['error'=>'Сотрудник не найден'],404);
   if(($row['role']??'')==='owner')json_response(['error'=>'Учётку владельца удалить нельзя'],422);
   $pdo->prepare('DELETE FROM sessions WHERE user_type="admin" AND user_id=?')->execute([$id]);
   $pdo->prepare('DELETE FROM admins WHERE id=?')->execute([$id]);
   adminLog('staff:delete','admin',$id,$row['name']);
   json_response(['ok'=>true]);
 }

 /* Журнал: последние действия в панели. Фильтр по разделу не нужен —
    записей немного, а глазами полезнее видеть всё подряд по времени. */
 if($method==='GET'&&$path==='/admin/log'){
   /* Фильтры: по исполнителю, по виду действия и по сроку. Сорок
      записей читаются и так, четыреста — уже нет. */
   $cond=[];$args=[];
   if(($q=trim((string)($_GET['q']??'')))!==''){
     $cond[]='(fold(actor_name) LIKE ? OR fold(target_name) LIKE ?)';
     $like='%'.foodFold($q).'%'; $args[]=$like; $args[]=$like;
   }
   if(($act=trim((string)($_GET['action']??'')))!==''){ $cond[]='action LIKE ?'; $args[]=$act.'%'; }
   if(($days=(int)($_GET['days']??0))>0){ $cond[]="created_at>=datetime('now','-$days day')"; }
   $where=$cond?('WHERE '.implode(' AND ',$cond)):'';
   [$limit,$offset,$page]=adminPage($_GET,60);
   $total=(int)fetchOne($pdo,"SELECT COUNT(*) FROM admin_log $where",$args);
   $st=$pdo->prepare("SELECT * FROM admin_log $where ORDER BY id DESC LIMIT $limit OFFSET $offset");
   $st->execute($args);
   json_response(['log'=>$st->fetchAll(),'total'=>$total,'page'=>$page,'pages'=>(int)ceil($total/$limit)]);
 }

 /* --- Карточка человека ---
    Список отвечает на вопрос «кто есть», карточка — на вопрос «что с
    ним». Раньше второго вопроса задать было негде: у строки была одна
    кнопка «Блок», и чтобы понять, кого блокируешь, приходилось лезть в
    базу. Здесь всё, что о человеке знает сервис, на одном экране. */
 if($method==='GET'&&preg_match('#^/admin/person/(specialist|client)/(\d+)$#',$path,$m)){
   $kind=$m[1]; $id=(int)$m[2];
   if($kind==='specialist'){
     $st=$pdo->prepare("SELECT id,name,email,phone,profession,plan,status,created_at,avatar_url,
       verify_status,verified_at,join_code,last_seen_at,rate_own,rate_catalog,source
       FROM specialists WHERE id=?");
     $st->execute([$id]); $p=$st->fetch();
     if(!$p) json_response(['error'=>'Специалист не найден'],404);
     $st=$pdo->prepare("SELECT id,name,goal,status,created_at,avatar_url FROM clients
       WHERE specialist_id=? ORDER BY id DESC LIMIT 50");
     $st->execute([$id]); $clients=safeClients($st->fetchAll());
     $st=$pdo->prepare("SELECT id,title,status,start_date,created_at FROM menus
       WHERE specialist_id=? ORDER BY id DESC LIMIT 10");
     $st->execute([$id]); $menus=$st->fetchAll();
     $st=$pdo->prepare("SELECT r.id,r.rating,r.body,r.status,r.created_at,c.name client_name
       FROM specialist_reviews r LEFT JOIN clients c ON c.id=r.client_id
       WHERE r.specialist_id=? ORDER BY r.id DESC LIMIT 10");
     $st->execute([$id]); $reviews=$st->fetchAll();
     /* Деньги этого специалиста: оборот, наша комиссия, выплаты. Без
        них разговор «давай снизим ставку» ведётся вслепую. */
     $money=$pdo->prepare("SELECT COUNT(*) deals,COALESCE(SUM(price_kop),0) turnover_kop,
         COALESCE(SUM(commission_kop),0) commission_kop
       FROM client_subscriptions WHERE specialist_id=? AND paid=1");
     $money->execute([$id]); $money=$money->fetch()?:['deals'=>0,'turnover_kop'=>0,'commission_kop'=>0];
     $paidOut=(int)fetchOne($pdo,"SELECT COALESCE(SUM(amount_kop),0) FROM payout_requests
       WHERE specialist_id=? AND status='paid'",[$id]);
     $bal=['held_kop'=>0,'avail_kop'=>0];
     try{
       $st=$pdo->prepare("SELECT COALESCE(SUM(held_kop),0) held_kop, COALESCE(SUM(avail_kop),0) avail_kop
         FROM balance_entries WHERE specialist_id=?");
       $st->execute([$id]); $bal=$st->fetch()?:$bal;
     }catch(Throwable $e){}
     $st=balanceSettings();
     json_response(['kind'=>'specialist','person'=>$p,'clients'=>$clients,'menus'=>$menus,
       'reviews'=>$reviews,'balance'=>$bal,
       'money'=>array_merge($money,['paid_out_kop'=>$paidOut]),
       'rates'=>['own'=>$p['rate_own'],'catalog'=>$p['rate_catalog'],
                 'default_own'=>$st['rate_own'],'default_catalog'=>$st['rate_catalog']],
       'notes'=>personNotes('specialist',$id),'tickets'=>personTickets('specialist',$id),
       'counts'=>[
         'clients'=>(int)fetchOne($pdo,"SELECT COUNT(*) FROM clients WHERE specialist_id=?",[$id]),
         'menus'  =>(int)fetchOne($pdo,"SELECT COUNT(*) FROM menus WHERE specialist_id=?",[$id]),
       ]]);
   }
   $st=$pdo->prepare("SELECT c.id,c.name,c.email,c.phone,c.goal,c.status,c.created_at,c.avatar_url,
     c.specialist_id,c.source,s.name specialist FROM clients c LEFT JOIN specialists s ON s.id=c.specialist_id
     WHERE c.id=?");
   $st->execute([$id]); $p=$st->fetch();
   if(!$p) json_response(['error'=>'Клиент не найден'],404);
   $p=safeClient($p);
   $st=$pdo->prepare("SELECT id,title,status,start_date FROM menus WHERE client_id=? ORDER BY id DESC LIMIT 5");
   $st->execute([$id]); $menus=$st->fetchAll();
   $last=fetchOne($pdo,"SELECT MAX(logged_at) FROM meal_logs WHERE client_id=?",[$id]);
   json_response(['kind'=>'client','person'=>$p,'menus'=>$menus,
     'notes'=>personNotes('client',$id),'tickets'=>personTickets('client',$id),
     'specialists'=>$pdo->query("SELECT id,name FROM specialists ORDER BY name")->fetchAll(),
     'counts'=>[
       'menus'  =>(int)fetchOne($pdo,"SELECT COUNT(*) FROM menus WHERE client_id=?",[$id]),
       'logs'   =>(int)fetchOne($pdo,"SELECT COUNT(*) FROM meal_logs WHERE client_id=?",[$id]),
       'weights'=>(int)fetchOne($pdo,"SELECT COUNT(*) FROM weight_logs WHERE client_id=?",[$id]),
     ],
     'last_log'=>$last]);
 }

 if($method==='PATCH'&&preg_match('#^/admin/clients/(\d+)$#',$path,$m)){
   $in=input();$st=($in['status']??'')==='blocked'?'blocked':'active';
   $id=(int)$m[1];
   $name=fetchOne($pdo,'SELECT name FROM clients WHERE id=?',[$id]);
   $pdo->prepare('UPDATE clients SET status=? WHERE id=?')->execute([$st,$id]);
   if($st==='blocked')$pdo->prepare('DELETE FROM sessions WHERE user_type="client" AND user_id=?')->execute([$id]);
   adminLog($st==='blocked'?'block':'unblock','client',$id,$name);
   json_response(['ok'=>true,'status'=>$st]);
 }

 /* Списки содержимого — с поиском и страницами, как списки людей.
    Раньше блюда обрезались на трёхстах, продукты грузились целиком (это
    уже четыреста строк одним запросом), а искали по ним в браузере: всё,
    что не попало в выборку, найти было нельзя в принципе. */
 if($method==='GET'&&$path==='/admin/dishes'){
   [$where,$args]=adminSearchFilter('d.name',$_GET);
   if(($_GET['only']??'')==='public')  $where.=($where?' AND ':'WHERE ').'d.is_public=1';
   if(($_GET['only']??'')==='hidden')  $where.=($where?' AND ':'WHERE ').'COALESCE(d.is_public,0)=0';
   if(($_GET['only']??'')==='nophoto') $where.=($where?' AND ':'WHERE ')."(d.photo_url IS NULL OR d.photo_url='')";
   /* Метка приходит из того же списка, что нарисован в панели, поэтому
      сравниваем точным равенством, а не поиском по куску строки. */
   $tag=trim((string)($_GET['tag']??''));
   if($tag!==''){ $where.=($where?' AND ':'WHERE ').'EXISTS(SELECT 1 FROM dish_tags tx WHERE tx.dish_id=d.id AND tx.tag=?)'; $args[]=$tag; }
   $total=(int)fetchOne($pdo,"SELECT COUNT(*) FROM dishes d $where",$args);
   [$limit,$offset,$page]=adminPage($_GET);
   $st=$pdo->prepare("SELECT d.id,d.name,d.meal_types,d.is_public,d.kcal_100,d.base_portion_g,
     (SELECT GROUP_CONCAT(t.tag,',') FROM dish_tags t WHERE t.dish_id=d.id) tags,
     COALESCE(d.photo_thumb_url,d.photo_url) photo_url,d.created_at,s.name author,
     (SELECT COUNT(*) FROM menu_items mi WHERE mi.dish_id=d.id) used
     FROM dishes d LEFT JOIN specialists s ON s.id=d.created_by
     $where ORDER BY d.id DESC LIMIT $limit OFFSET $offset");
   $st->execute($args);
   /* Метки отдаём все и с числом блюд: полоска фильтра рисуется из
      живого списка, а не из зашитого перечня, который разойдётся с базой. */
   $tags=$pdo->query("SELECT tag,COUNT(*) n FROM dish_tags GROUP BY tag ORDER BY n DESC,tag")->fetchAll();
   json_response(['dishes'=>$st->fetchAll(),'total'=>$total,'page'=>$page,
     'pages'=>(int)ceil($total/$limit),'tags'=>$tags]);
 }
 /* Одно блюдо целиком — для редактора. */
 if($method==='GET'&&preg_match('#^/admin/dishes/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT * FROM dishes WHERE id=?');$q->execute([(int)$m[1]]);
   $d=$q->fetch();if(!$d)json_response(['error'=>'Блюдо не найдено'],404);
   $q=$pdo->prepare('SELECT di.ingredient_id,di.grams,i.name ingredient_name,i.unit,i.piece_g
                     FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id
                     WHERE di.dish_id=? ORDER BY di.sort_order');
   $q->execute([(int)$m[1]]);$d['ingredients']=$q->fetchAll();
   $q=$pdo->prepare('SELECT tag FROM dish_tags WHERE dish_id=?');$q->execute([(int)$m[1]]);
   $d['tags']=$q->fetchAll(PDO::FETCH_COLUMN);
   json_response(['dish'=>$d]);
 }

 /* Создание и правка блюда каталога.
    Владелец ведёт общий каталог — тот, что видят все специалисты.
    Личное блюдо специалиста (is_public=0) остаётся его: он собрал его
    под своего клиента, и менять такое из-за спины неправильно. Скрыть
    его из общего доступа владелец по-прежнему может — это ниже.

    КБЖУ здесь не принимаем ни в каком виде: его считает recalc_dish()
    по составу, как и у специалиста. Один писатель на эти столбцы. */
 if($method==='POST'&&$path==='/admin/dishes'){
   $in=input();
   $name=trim((string)($in['name']??''));
   $ings=$in['ingredients']??[];
   if($name===''||!is_array($ings)||!$ings)json_response(['error'=>'Название и состав обязательны'],422);
   $pdo->beginTransaction();
   try{
     $pdo->prepare('INSERT INTO dishes(name,meal_types,cook_minutes,instructions,steps,photo_url,is_public,created_at)
                    VALUES(?,?,?,?,?,?,1,?)')
         ->execute([$name,json_encode($in['meal_types']??['lunch'],JSON_UNESCAPED_UNICODE),
                    $in['cook_minutes']??null,$in['instructions']??null,
                    isset($in['steps'])?json_encode($in['steps'],JSON_UNESCAPED_UNICODE):null,
                    $in['photo_url']??null,now()]);
     $did=(int)$pdo->lastInsertId();
     adminSaveDishParts($did,$in);
     recalc_dish($did);
     $pdo->commit();
   }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); json_response(['error'=>$e->getMessage()],422); }
   json_response(['dish_id'=>$did],201);
 }
 if($method==='PATCH'&&preg_match('#^/admin/dishes/(\d+)$#',$path,$m)){
   $did=(int)$m[1];$in=input();
   $q=$pdo->prepare('SELECT id,is_public,created_by FROM dishes WHERE id=?');$q->execute([$did]);
   $d=$q->fetch();if(!$d)json_response(['error'=>'Блюдо не найдено'],404);

   /* Переключатель «в каталоге / скрыто» приходит один, без остального:
      это старая кнопка из списка блюд, и трогать ею содержимое нельзя. */
   if(array_key_exists('is_public',$in)&&count($in)===1){
     $pub=!empty($in['is_public'])?1:0;
     $pdo->prepare('UPDATE dishes SET is_public=? WHERE id=?')->execute([$pub,$did]);
     adminLog($pub?'publish':'hide','dish',$did,fetchOne($pdo,'SELECT name FROM dishes WHERE id=?',[$did]));
     json_response(['ok'=>true]);
   }

   if((int)$d['is_public']!==1&&$d['created_by'])
     json_response(['error'=>'Это личное блюдо специалиста — его правит только автор'],403);

   $pdo->beginTransaction();
   try{
     $sets=[];$vals=[];
     foreach(['name','cook_minutes','instructions','photo_url'] as $k)
       if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=$in[$k];}
     foreach(['meal_types','steps'] as $k)
       if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=json_encode($in[$k],JSON_UNESCAPED_UNICODE);}
     if(array_key_exists('is_public',$in)){$sets[]='is_public=?';$vals[]=!empty($in['is_public'])?1:0;}
     if($sets){$vals[]=$did;$pdo->prepare('UPDATE dishes SET '.implode(',',$sets).' WHERE id=?')->execute($vals);}
     if(isset($in['ingredients'])||isset($in['tags'])){ adminSaveDishParts($did,$in); }
     if(isset($in['ingredients'])) recalc_dish($did);
     $pdo->commit();
   }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); json_response(['error'=>$e->getMessage()],422); }
   json_response(['ok'=>true]);
 }
 if($method==='POST'&&$path==='/admin/upload'){ json_response(['url'=>saveAvatar()]); }

 /* --- Рассылка ---
    Отправленное письмо не отзовёшь, поэтому история рассылок лежит
    рядом с формой: перед отправкой видно, что и когда уже уходило. */
 if($method==='GET'&&$path==='/admin/broadcasts'){
   json_response([
     'broadcasts'=>$pdo->query('SELECT * FROM broadcasts ORDER BY id DESC LIMIT 50')->fetchAll(),
     'audience'=>[
       'specialists'=>(int)$pdo->query('SELECT COUNT(*) FROM specialists')->fetchColumn(),
       'clients'=>(int)$pdo->query('SELECT COUNT(*) FROM clients')->fetchColumn(),
     ],
     'mail_configured'=>is_file(__DIR__.'/../config/mail.php'),
     'segments'=>BROADCAST_SEGMENTS,
   ]);
 }
 if($method==='POST'&&$path==='/admin/broadcasts'){
   $in=input();
   $seg=(string)($in['segment']??'');
   $when=trim((string)($in['send_at']??''));
   $r=$when!==''
     ? scheduleBroadcast((string)($in['audience']??''),(string)($in['title']??''),
                         (string)($in['body']??''),!empty($in['by_email']),$seg,$when)
     : sendBroadcast((string)($in['audience']??''),(string)($in['title']??''),
                     (string)($in['body']??''),!empty($in['by_email']),$seg);
   if(isset($r['error']))json_response($r,422);
   adminLog($when!==''?'broadcast:planned':'broadcast','broadcast',null,
     (string)($in['title']??''),$seg?BROADCAST_SEGMENTS[$seg]:null);
   json_response($r,201);
 }
 /* Отменить запланированную рассылку, пока она не ушла. */
 if($method==='DELETE'&&preg_match('#^/admin/broadcasts/(\d+)$#',$path,$m)){
   $st=$pdo->prepare("DELETE FROM broadcasts WHERE id=? AND status='planned'");
   $st->execute([(int)$m[1]]);
   if(!$st->rowCount())json_response(['error'=>'Эта рассылка уже ушла — отменить нельзя'],422);
   adminLog('broadcast:cancel','broadcast',(int)$m[1],null);
   json_response(['ok'=>true]);
 }

 /* --- Техподдержка, сторона владельца ---
    Очередь по последнему сообщению, а не по дате создания: обращение
    недельной давности с новым ответом важнее свежего, на который уже
    ответили. */
 if($method==='GET'&&$path==='/admin/support'){
   $rows=$pdo->query("SELECT t.*,
       (SELECT COUNT(*) FROM support_messages m WHERE m.ticket_id=t.id) messages,
       (SELECT COUNT(*) FROM support_messages m WHERE m.ticket_id=t.id AND m.from_admin=0 AND m.read_at IS NULL) unread,
       (SELECT body FROM support_messages m WHERE m.ticket_id=t.id ORDER BY m.id DESC LIMIT 1) last_body
       FROM support_tickets t
       ORDER BY (t.status='closed'), t.last_reply_at DESC, t.id DESC LIMIT 200")->fetchAll();
   foreach($rows as &$r){
     $w=ticketAuthor((string)$r['author_type'],(int)$r['author_id']);
     $r['author_name']=$w['name']; $r['author_email']=$w['email'];
     $r['topic_label']=SUPPORT_TOPICS[$r['topic']]??$r['topic'];
   }
   json_response(['tickets'=>$rows,'topics'=>SUPPORT_TOPICS,
     'open'=>(int)$pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status<>'closed'")->fetchColumn()]);
 }
 if($method==='GET'&&preg_match('#^/admin/support/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT * FROM support_tickets WHERE id=?');$q->execute([(int)$m[1]]);
   $t=$q->fetch();if(!$t)json_response(['error'=>'Обращение не найдено'],404);
   $w=ticketAuthor((string)$t['author_type'],(int)$t['author_id']);
   $t['author_name']=$w['name']; $t['author_email']=$w['email'];
   $t['topic_label']=SUPPORT_TOPICS[$t['topic']]??$t['topic'];
   $pdo->prepare('UPDATE support_messages SET read_at=? WHERE ticket_id=? AND from_admin=0 AND read_at IS NULL')
       ->execute([now(),(int)$t['id']]);
   json_response(['ticket'=>$t,'messages'=>ticketThread((int)$t['id'])]);
 }
 if($method==='POST'&&preg_match('#^/admin/support/(\d+)/reply$#',$path,$m)){
   $q=$pdo->prepare('SELECT * FROM support_tickets WHERE id=?');$q->execute([(int)$m[1]]);
   $t=$q->fetch();if(!$t)json_response(['error'=>'Обращение не найдено'],404);
   $in=input();$body=trim((string)($in['body']??''));
   if(mb_strlen($body)<2)json_response(['error'=>'Пустой ответ'],422);
   $close=!empty($in['close']);
   $pdo->prepare('INSERT INTO support_messages(ticket_id,from_admin,body,created_at) VALUES(?,1,?,?)')
       ->execute([(int)$t['id'],$body,now()]);
   $pdo->prepare('UPDATE support_tickets SET last_reply_at=?, status=?, closed_at=? WHERE id=?')
       ->execute([now(),$close?'closed':'in_progress',$close?now():null,(int)$t['id']]);
   notifyTicketReply($t,$body);
   json_response(['ok'=>true,'status'=>$close?'closed':'in_progress'],201);
 }
 if($method==='PATCH'&&preg_match('#^/admin/support/(\d+)$#',$path,$m)){
   $st=(string)(input()['status']??'');
   if(!in_array($st,['new','in_progress','closed'],true))json_response(['error'=>'Неизвестный статус'],422);
   $pdo->prepare('UPDATE support_tickets SET status=?, closed_at=? WHERE id=?')
       ->execute([$st,$st==='closed'?now():null,(int)$m[1]]);
   json_response(['ok'=>true,'status'=>$st]);
 }

 /* --- Справочник продуктов ---
    От этих чисел зависит КБЖУ всех блюд, поэтому здесь всё
    сопровождается пересчётом. Показываем сразу, в скольких блюдах
    продукт стоит: правка «молока» задевает пятнадцать блюд, и знать об
    этом надо до правки, а не после. */
 if($method==='GET'&&$path==='/admin/ingredients'){
   [$where,$args]=adminSearchFilter('i.name',$_GET);
   $total=(int)fetchOne($pdo,"SELECT COUNT(*) FROM ingredients i $where",$args);
   [$limit,$offset,$page]=adminPage($_GET,100);
   $st=$pdo->prepare("SELECT i.*, s.name author,
       (SELECT COUNT(*) FROM dish_ingredients di WHERE di.ingredient_id=i.id) used
       FROM ingredients i LEFT JOIN specialists s ON s.id=i.created_by
       $where ORDER BY i.category, i.name LIMIT $limit OFFSET $offset");
   $st->execute($args);
   $rows=$st->fetchAll();
   /* Дубли ищем по всей таблице, а не по странице: иначе «молоко» на
      первой странице и «Молоко» на третьей никогда не встретятся. */
   $allNames=$pdo->query("SELECT id,name FROM ingredients")->fetchAll();
   /* Дубли по имени без учёта регистра ищем в PHP: встроенный lower()
      у SQLite не трогает кириллицу, и «молоко» с «Молоко» он считает
      разными строками — то есть ровно тот случай, что мы ищем. */
   $seen=[];$dups=[];
   foreach($allNames as $r){
     $k=mb_strtolower(trim((string)$r['name']));
     if(isset($seen[$k]))$dups[$k][]=(int)$r['id'];
     else $seen[$k]=(int)$r['id'];
   }
   foreach($dups as $k=>&$ids)array_unshift($ids,$seen[$k]);
   json_response(['ingredients'=>$rows,'duplicates'=>array_values($dups),'total'=>$total,'page'=>$page,'pages'=>(int)ceil($total/$limit)]);
 }
 if($method==='POST'&&$path==='/admin/ingredients'){
   $in=input();$name=trim((string)($in['name']??''));
   if($name==='')json_response(['error'=>'Название обязательно'],422);
   $pdo->prepare('INSERT INTO ingredients(name,category,kcal,protein,fat,carbs,fiber,cooked_ratio,unit,piece_g,is_public,created_at)
                  VALUES(?,?,?,?,?,?,?,?,?,?,1,?)')
       ->execute([$name,$in['category']??'Прочее',(float)($in['kcal']??0),(float)($in['protein']??0),
                  (float)($in['fat']??0),(float)($in['carbs']??0),(float)($in['fiber']??0),
                  max(0.01,(float)($in['cooked_ratio']??1)),$in['unit']??'g',
                  isset($in['piece_g'])&&$in['piece_g']!==''?(float)$in['piece_g']:null,now()]);
   json_response(['ingredient_id'=>(int)$pdo->lastInsertId()],201);
 }
 if($method==='PATCH'&&preg_match('#^/admin/ingredients/(\d+)$#',$path,$m)){
   $id=(int)$m[1];$in=input();
   $q=$pdo->prepare('SELECT id FROM ingredients WHERE id=?');$q->execute([$id]);
   if(!$q->fetch())json_response(['error'=>'Продукт не найден'],404);
   $sets=[];$vals=[];
   foreach(['name','category','unit'] as $k)
     if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=trim((string)$in[$k]);}
   foreach(['kcal','protein','fat','carbs','fiber'] as $k)
     if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=max(0,(float)$in[$k]);}
   if(array_key_exists('cooked_ratio',$in)){$sets[]='cooked_ratio=?';$vals[]=max(0.01,(float)$in['cooked_ratio']);}
   if(array_key_exists('piece_g',$in)){$sets[]='piece_g=?';$vals[]=$in['piece_g']===''||$in['piece_g']===null?null:(float)$in['piece_g'];}
   if(!$sets)json_response(['error'=>'Нечего менять'],422);
   $vals[]=$id;
   $pdo->prepare('UPDATE ingredients SET '.implode(',',$sets).' WHERE id=?')->execute($vals);
   /* Блюда с этим продуктом пересчитываем сразу: иначе каталог до
      следующего импорта показывал бы прежние числа. */
   $q=$pdo->prepare('SELECT DISTINCT dish_id FROM dish_ingredients WHERE ingredient_id=?');
   $q->execute([$id]);$hit=$q->fetchAll(PDO::FETCH_COLUMN);
   foreach($hit as $d)recalc_dish((int)$d);
   json_response(['ok'=>true,'dishes_recalculated'=>count($hit)]);
 }
 if($method==='DELETE'&&preg_match('#^/admin/ingredients/(\d+)$#',$path,$m)){
   $id=(int)$m[1];
   $q=$pdo->prepare('SELECT COUNT(*) FROM dish_ingredients WHERE ingredient_id=?');$q->execute([$id]);
   if((int)$q->fetchColumn())
     json_response(['error'=>'Продукт стоит в блюдах — удалить его значит молча урезать их состав. Объедините его с другим или уберите из блюд.'],422);
   $name=fetchOne($pdo,'SELECT name FROM ingredients WHERE id=?',[$id]);
   $pdo->prepare('DELETE FROM ingredients WHERE id=?')->execute([$id]);
   adminLog('delete','ingredient',$id,$name);
   json_response(['ok'=>true]);
 }
 /* Объединение дублей: ссылки блюд переезжают на оставшийся продукт,
    лишний удаляется. Это единственный способ убрать дубль, не потеряв
    состав блюд, которые на него ссылались. */
 if($method==='POST'&&$path==='/admin/ingredients/merge'){
   $in=input();$keep=(int)($in['keep_id']??0);$drop=(int)($in['drop_id']??0);
   if(!$keep||!$drop||$keep===$drop)json_response(['error'=>'Укажите, какой продукт оставить и какой убрать'],422);
   $q=$pdo->prepare('SELECT id,name FROM ingredients WHERE id IN (?,?)');$q->execute([$keep,$drop]);
   if(count($q->fetchAll())!==2)json_response(['error'=>'Продукт не найден'],404);
   $pdo->beginTransaction();
   try{
     $q=$pdo->prepare('SELECT DISTINCT dish_id FROM dish_ingredients WHERE ingredient_id IN (?,?)');
     $q->execute([$keep,$drop]);$hit=$q->fetchAll(PDO::FETCH_COLUMN);
     /* Если оба продукта стоят в одном блюде, простой UPDATE дал бы там
        две строки одного и того же. Складываем их граммовки в одну. */
     $q=$pdo->prepare('SELECT dish_id,SUM(grams) g,MIN(sort_order) so FROM dish_ingredients
                       WHERE ingredient_id IN (?,?) GROUP BY dish_id');
     $q->execute([$keep,$drop]);$merged=$q->fetchAll();
     $pdo->prepare('DELETE FROM dish_ingredients WHERE ingredient_id IN (?,?)')->execute([$keep,$drop]);
     $add=$pdo->prepare('INSERT INTO dish_ingredients(dish_id,ingredient_id,grams,sort_order) VALUES(?,?,?,?)');
     foreach($merged as $r)$add->execute([(int)$r['dish_id'],$keep,(float)$r['g'],(int)$r['so']]);
     /* Кладовая клиента ссылается на продукт так же, как блюдо. */
     try{ $pdo->prepare('UPDATE OR IGNORE client_pantry SET ingredient_id=? WHERE ingredient_id=?')->execute([$keep,$drop]);
          $pdo->prepare('DELETE FROM client_pantry WHERE ingredient_id=?')->execute([$drop]); }catch(Throwable $e){}
     $pdo->prepare('DELETE FROM ingredients WHERE id=?')->execute([$drop]);
     $pdo->commit();
     foreach($hit as $d)recalc_dish((int)$d);
     json_response(['ok'=>true,'dishes_recalculated'=>count($hit)]);
   }catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); json_response(['error'=>$e->getMessage()],422); }
 }
 if($method==='DELETE'&&preg_match('#^/admin/dishes/(\d+)$#',$path,$m)){
   $id=(int)$m[1];$used=$pdo->prepare('SELECT COUNT(*) FROM menu_items WHERE dish_id=?');$used->execute([$id]);
   if((int)$used->fetchColumn())json_response(['error'=>'Блюдо используется в меню — сначала уберите его оттуда'],422);
   $name=fetchOne($pdo,'SELECT name FROM dishes WHERE id=?',[$id]);   /* имя нужно до удаления */
   $pdo->prepare('DELETE FROM dishes WHERE id=?')->execute([$id]);
   adminLog('delete','dish',$id,$name);json_response(['ok'=>true]);
 }

 if($method==='GET'&&$path==='/admin/posts'){
   $total=(int)fetchOne($pdo,'SELECT COUNT(*) FROM posts');
   [$limit,$offset,$page]=adminPage($_GET);
   $st=$pdo->prepare("SELECT p.*,
     COALESCE((SELECT name FROM clients WHERE id=p.author_id AND p.author_type='client'),
              (SELECT name FROM specialists WHERE id=p.author_id AND p.author_type='specialist')) author_name,
     (SELECT COUNT(*) FROM post_likes l WHERE l.post_id=p.id) likes
     FROM posts p ORDER BY p.id DESC LIMIT $limit OFFSET $offset");
   $st->execute();
   json_response(['posts'=>$st->fetchAll(),'total'=>$total,'page'=>$page,'pages'=>(int)ceil($total/$limit)]);
 }
 if($method==='PATCH'&&preg_match('#^/admin/posts/(\d+)$#',$path,$m)){
   $in=input();$st=($in['status']??'')==='hidden'?'hidden':'visible';
   $pdo->prepare('UPDATE posts SET status=? WHERE id=?')->execute([$st,(int)$m[1]]);
   adminLog($st==='hidden'?'hide':'publish','post',(int)$m[1],null);
   json_response(['ok'=>true,'status'=>$st]);
 }
 if($method==='DELETE'&&preg_match('#^/admin/posts/(\d+)$#',$path,$m)){
   $pid=(int)$m[1];$pdo->prepare('DELETE FROM post_likes WHERE post_id=?')->execute([$pid]);
   $pdo->prepare('DELETE FROM posts WHERE id=?')->execute([$pid]);
   adminLog('delete','post',$pid,null);json_response(['ok'=>true]);
 }

 /* Подписок в проекте нет: показываем распределение по тарифным полям как есть */
 if($method==='GET'&&$path==='/admin/subscriptions'){
   $plans=$pdo->query("SELECT COALESCE(plan,'free') plan,COUNT(*) n FROM specialists GROUP BY COALESCE(plan,'free')")->fetchAll();
   json_response(['billing'=>false,'plans'=>$plans,
     'note'=>'Биллинг в проекте не подключён. Тариф — это поле в базе, деньги через него не проходят.']);
 }

 /* ---------------------------------------------------------------------
    ДЕНЬГИ ПЛАТФОРМЫ.
    Заявки на вывод, споры и настройки комиссии. Держать это в одном
    экране правильнее, чем в трёх: решение по спору меняет сумму, с
    которой завтра придёт заявка.
    --------------------------------------------------------------------- */
 /* --- EQUA info: записи владельца ------------------------------------ */
 if($method==='GET'&&$path==='/admin/info'){
   json_response(['posts'=>$pdo->query('SELECT * FROM info_posts ORDER BY kind=\'about\' DESC,sort_order,id DESC')->fetchAll()]);
 }
 if($method==='POST'&&$path==='/admin/info'){
   $in=input();
   $title=mb_substr(trim((string)($in['title']??'')),0,160);
   $body=mb_substr(trim((string)($in['body']??'')),0,8000);
   if($title===''||$body==='')json_response(['error'=>'Нужны заголовок и текст'],422);
   $kind=in_array($in['kind']??'',['about','update'],true)?$in['kind']:'update';
   $aud=in_array($in['audience']??'',['all','client','specialist'],true)?$in['audience']:'all';
   $pdo->prepare('INSERT INTO info_posts(kind,title,body,audience,is_published,sort_order,created_at,updated_at)
                  VALUES(?,?,?,?,?,?,?,?)')
      ->execute([$kind,$title,$body,$aud,!empty($in['is_published'])?1:1,(int)($in['sort_order']??0),now(),now()]);
   json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()],201);
 }
 if($method==='PATCH'&&preg_match('#^/admin/info/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT * FROM info_posts WHERE id=?');$q->execute([(int)$m[1]]);
   $cur=$q->fetch(); if(!$cur)json_response(['error'=>'Запись не найдена'],404);
   $in=input();
   $title=array_key_exists('title',$in)?mb_substr(trim((string)$in['title']),0,160):$cur['title'];
   $body=array_key_exists('body',$in)?mb_substr(trim((string)$in['body']),0,8000):$cur['body'];
   if($title===''||$body==='')json_response(['error'=>'Нужны заголовок и текст'],422);
   $kind=in_array($in['kind']??'',['about','update'],true)?$in['kind']:$cur['kind'];
   $aud=in_array($in['audience']??'',['all','client','specialist'],true)?$in['audience']:$cur['audience'];
   $pub=array_key_exists('is_published',$in)?(!empty($in['is_published'])?1:0):(int)$cur['is_published'];
   $pdo->prepare('UPDATE info_posts SET kind=?,title=?,body=?,audience=?,is_published=?,sort_order=?,updated_at=? WHERE id=?')
      ->execute([$kind,$title,$body,$aud,$pub,(int)($in['sort_order']??$cur['sort_order']),now(),(int)$m[1]]);
   json_response(['ok'=>true]);
 }
 if($method==='DELETE'&&preg_match('#^/admin/info/(\d+)$#',$path,$m)){
   $st=$pdo->prepare('DELETE FROM info_posts WHERE id=?');$st->execute([(int)$m[1]]);
   if(!$st->rowCount())json_response(['error'=>'Запись не найдена'],404);
   json_response(['ok'=>true]);
 }

 if($method==='GET'&&$path==='/admin/finance'){
   balanceAccrue();
   $t=$pdo->query('SELECT COALESCE(SUM(held_kop),0) held,COALESCE(SUM(avail_kop),0) avail FROM balance_entries')->fetch();
   $c=$pdo->query('SELECT COALESCE(SUM(commission_kop),0) gross,COALESCE(SUM(acquirer_fee_kop),0) fee
                     FROM client_subscriptions WHERE paid=1')->fetch();
   $comm=(int)$c['gross']; $fee=(int)$c['fee'];
   $pay=$pdo->query("SELECT p.*,s.name specialist_name FROM payout_requests p
                       JOIN specialists s ON s.id=p.specialist_id ORDER BY p.status='pending' DESC,p.id DESC LIMIT 50")->fetchAll();
   $dis=$pdo->query("SELECT s.id,s.title,s.price_kop,s.payout_kop,s.disputed_at,s.dispute_note,
                            c.name client_name,sp.name specialist_name
                       FROM client_subscriptions s
                       JOIN clients c ON c.id=s.client_id
                       JOIN specialists sp ON sp.id=s.specialist_id
                      WHERE s.disputed_at IS NOT NULL AND s.accepted_at IS NULL
                      ORDER BY s.disputed_at")->fetchAll();
   json_response(['settings'=>balanceSettings(),
     'totals'=>['held_kop'=>(int)$t['held'],'available_kop'=>(int)$t['avail'],
                'commission_kop'=>$comm,'acquirer_fee_kop'=>$fee,'net_kop'=>$comm-$fee],
     'payouts'=>$pay,'disputes'=>$dis]);
 }

 if($method==='PATCH'&&$path==='/admin/finance'){
   $in=input(); $s=balanceSettings(); $set=[]; $args=[];
   $rate=function($v){ $f=(float)str_replace(',','.',(string)$v)/100;
     if($f<0||$f>0.5)json_response(['error'=>'Ставка комиссии — от 0 до 50 %'],422); return $f; };
   if(array_key_exists('rate_own',$in)){ $set[]='rate_own=?'; $args[]=$rate($in['rate_own']); }
   if(array_key_exists('rate_catalog',$in)){ $set[]='rate_catalog=?'; $args[]=$rate($in['rate_catalog']); }
   foreach(['catalog_period_days'=>[1,3650],'accept_days'=>[1,60],'abandon_days'=>[7,365]] as $k=>[$lo,$hi]){
     if(!array_key_exists($k,$in))continue;
     $v=(int)$in[$k];
     if($v<$lo||$v>$hi)json_response(['error'=>'Срок «'.$k.'» — от '.$lo.' до '.$hi.' дней'],422);
     $set[]=$k.'=?'; $args[]=$v;
   }
   if(array_key_exists('payout_min',$in)){ $set[]='payout_min_kop=?'; $args[]=servicePrice($in['payout_min']); }
   if(array_key_exists('payments_mode',$in)){
     $mode=(string)$in['payments_mode'];
     if(!in_array($mode,['off','demo','live'],true))json_response(['error'=>'Режим платежей: off, demo или live'],422);
     $set[]='payments_mode=?'; $args[]=$mode;
   }
   if($set){ $set[]='updated_at=?'; $args[]=now();
     $pdo->prepare('UPDATE commission_settings SET '.implode(',',$set).' WHERE id=1')->execute($args); }
   json_response(['settings'=>balanceSettings()]);
 }

 /* Отметка «выплачено» — это запись о переводе, который владелец сделал
    руками. Отказ возвращает сумму в доступные: деньги специалиста никуда
    не делись, просто заявка не прошла. */
 if($method==='PATCH'&&preg_match('#^/admin/payouts/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT * FROM payout_requests WHERE id=?');$q->execute([(int)$m[1]]);
   $p=$q->fetch(); if(!$p)json_response(['error'=>'Заявка не найдена'],404);
   if($p['status']!=='pending')json_response(['error'=>'Заявка уже закрыта'],409);
   $in=input(); $st=($in['status']??'')==='rejected'?'rejected':'paid';
   $note=mb_substr(trim((string)($in['note']??'')),0,300);
   if($st==='rejected'&&mb_strlen($note)<5)json_response(['error'=>'Напишите специалисту причину отказа'],422);
   $upd=$pdo->prepare('UPDATE payout_requests SET status=?,note=?,decided_at=? WHERE id=? AND status=\'pending\'');
   $upd->execute([$st,$note?:null,now(),(int)$p['id']]);
   if(!$upd->rowCount())json_response(['error'=>'Заявка уже закрыта'],409);
   adminLog($st==='paid'?'payout:paid':'payout:rejected','payout',(int)$p['id'],
     $p['specialist_name']??null,
     number_format((int)$p['amount_kop']/100,0,',',' ').' ₽'.($note?' · '.$note:''));
   if($st==='rejected'){
     balanceAdd((int)$p['specialist_id'],null,'payout_back',0,(int)$p['amount_kop'],
                'Заявка №'.$p['id'].' отклонена',null,(int)$p['id']);
     /* Деньги вернулись на баланс — значит и покупки снова свободны для
        следующей заявки. */
     $pdo->prepare('DELETE FROM payout_orders WHERE payout_id=?')->execute([(int)$p['id']]);
   }else{
     /* Закрываем сделки у эквайера. С заглушкой это ничего не делает, но
        результат пишем: по нему потом сверять переводы. */
     $q=$pdo->prepare('SELECT o.sub_id,o.amount_kop,s.provider_deal_id
                         FROM payout_orders o
                         JOIN client_subscriptions s ON s.id=o.sub_id
                        WHERE o.payout_id=?');
     $q->execute([(int)$p['id']]);
     try{
       $r=paymentProvider()->settle($p,$q->fetchAll(),json_decode((string)$p['details_json'],true)?:[]);
       if(!empty($r['payout_id']))
         $pdo->prepare('UPDATE payout_requests SET provider_payout_id=? WHERE id=?')
             ->execute([$r['payout_id'],(int)$p['id']]);
     }catch(Throwable $e){
       error_log('Выплата №'.$p['id'].': '.$e->getMessage());
     }
   }
   pushSend('specialist',(int)$p['specialist_id'],
     $st==='paid'?'Деньги отправлены':'Заявка на вывод отклонена',
     $st==='paid'?'Вывод на сумму '.round($p['amount_kop']/100).' ₽ отправлен':$note,
     '/app/','payout');
   json_response(['ok'=>true]);
 }

 /* Спор разбирает человек: либо услуга всё-таки выполнена и деньги идут
    специалисту, либо нет — и возвращаются клиенту. */
 if($method==='PATCH'&&preg_match('#^/admin/disputes/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT * FROM client_subscriptions WHERE id=? AND disputed_at IS NOT NULL');
   $q->execute([(int)$m[1]]); $sub=$q->fetch();
   if(!$sub)json_response(['error'=>'Спор не найден'],404);
   if(!empty($sub['accepted_at']))json_response(['error'=>'Спор уже закрыт'],409);
   $in=input(); $decision=($in['decision']??'')==='refund'?'refund':'release';
   $left=subHeld((int)$sub['id']);
   if($decision==='release'){
     if($left>0)balanceAdd((int)$sub['specialist_id'],(int)$sub['id'],'release',-$left,$left,
       'Спор решён в вашу пользу');
     $pdo->prepare("UPDATE client_subscriptions SET accepted_at=?,accepted_by='admin',disputed_at=NULL WHERE id=?")
         ->execute([now(),(int)$sub['id']]);
   }else{
     if($left>0)balanceAdd((int)$sub['specialist_id'],(int)$sub['id'],'refund',-$left,0,
       'Возврат клиенту по спору');
     $pdo->prepare("UPDATE client_subscriptions SET status='refunded',accepted_at=?,accepted_by='refund',disputed_at=NULL WHERE id=?")
         ->execute([now(),(int)$sub['id']]);
   }
   pushSend('specialist',(int)$sub['specialist_id'],'Спор закрыт',
     $decision==='release'?'Деньги по «'.$sub['title'].'» разморожены':'Деньги по «'.$sub['title'].'» вернулись клиенту',
     '/app/','dispute');
   createNotification((int)$sub['client_id'],'service','Спор закрыт',
     $decision==='refund'?'Деньги за «'.$sub['title'].'» вернутся вам.':'Услуга «'.$sub['title'].'» признана выполненной.');
   json_response(['ok'=>true]);
 }

 if($method==='POST'&&$path==='/admin/password'){
   $in=input();$cur=(string)($in['current']??'');$new=(string)($in['password']??'');
   $q=$pdo->prepare('SELECT password_hash FROM admins WHERE id=?');$q->execute([$aid]);$h=(string)$q->fetchColumn();
   if(!password_verify($cur,$h))json_response(['error'=>'Текущий пароль неверный'],422);
   if(!password_ok($new))json_response(['error'=>'Пароль от 8 символов, с буквой и цифрой'],422);
   $pdo->prepare('UPDATE admins SET password_hash=? WHERE id=?')->execute([password_hash($new,PASSWORD_DEFAULT),$aid]);
   $pdo->prepare('DELETE FROM sessions WHERE user_type="admin" AND user_id=? AND token<>?')->execute([$aid,bearer()]);
   json_response(['ok'=>true]);
 }

/* --- Push: состояние и первичная настройка (только владелец) ---
   tools/setup-push.php закрыт .htaccess и требует SSH, которого на шаред-хостинге
   может не быть. Поэтому ключи создаются кнопкой в панели владельца. */
if($method==='GET'&&$path==='/admin/push'){
  $v=vapidKeys();$has=$v!==null;$key=$v['publicKey']??'';
  json_response([
    'library'=>is_file(__DIR__.'/../vendor/autoload.php'),
    'configured'=>$has&&$key!=='',
    'writable'=>is_writable(__DIR__.'/../storage'),
    'openssl'=>vapidBlocker()===''?'':vapidBlocker(),   // пусто — всё на месте
    'php'=>PHP_VERSION,
    'subscriptions'=>(int)$pdo->query('SELECT COUNT(*) FROM push_subscriptions')->fetchColumn(),
    'public_key'=>$key?substr($key,0,12).'…':'']);
}
if($method==='POST'&&$path==='/admin/push/setup'){
  $dir=__DIR__.'/../storage';if(!is_dir($dir))@mkdir($dir,0775,true);
  if(!is_writable($dir))json_response(['error'=>'Папка storage недоступна для записи — поставьте права 775'],500);
  $in=input();
  if(vapidKeys()!==null&&empty($in['force']))
    json_response(['error'=>'Ключи уже созданы. Пересоздание отключит все существующие подписки.'],409);
  /* Генерируем сами (см. vapidCreate) — библиотека нужна только для
     отправки. Причину отказа передаём владельцу словами, а не молчанием. */
  try{ $keys=vapidCreate(); }
  catch(\Throwable $e){ json_response(['error'=>'Не удалось создать ключи: '.$e->getMessage()],500); }
  if(!vapidSave($keys))
    json_response(['error'=>'Не удалось записать storage/vapid.php — проверьте права на папку storage'],500);
  @chmod($dir.'/vapid.php',0640);
  @unlink($dir.'/vapid.json');   // старый незащищённый файл больше не нужен
  /* Старые подписки подписаны прежним ключом и больше не примут уведомления */
  $pdo->exec('DELETE FROM push_subscriptions');
  json_response(['ok'=>true,'public_key'=>substr($keys['publicKey'],0,12).'…']);
}
 json_response(['error'=>'Not found'],404);
}

if(str_starts_with($path,'/specialist/')){$a=specialist();$sid=(int)$a['user_id'];
 if($method==='GET'&&$path==='/specialist/invite-code'){ $q=$pdo->prepare('SELECT join_code FROM specialists WHERE id=?');$q->execute([$sid]);$code=$q->fetchColumn();
  if(!$code){ $exists=$pdo->prepare('SELECT 1 FROM specialists WHERE join_code=?'); do{ $code=strtoupper(substr(bin2hex(random_bytes(4)),0,6)); $exists->execute([$code]); }while($exists->fetch()); $pdo->prepare('UPDATE specialists SET join_code=? WHERE id=?')->execute([$code,$sid]); }
  json_response(['code'=>$code,'url'=>publicAppUrl().'/app/?join='.$code]);}
 if($method==='GET'&&$path==='/specialist/dashboard'){ $q=$pdo->prepare('SELECT COUNT(*) FROM clients WHERE specialist_id=? AND status="active"');$q->execute([$sid]);$clients=(int)$q->fetchColumn();$q=$pdo->prepare('SELECT COUNT(*) FROM menus WHERE specialist_id=? AND status="published"');$q->execute([$sid]);$published=(int)$q->fetchColumn();$q=$pdo->prepare('SELECT COUNT(*) FROM messages m JOIN clients c ON c.id=m.client_id WHERE c.specialist_id=? AND m.author_type="client" AND m.read_at IS NULL');$q->execute([$sid]);$unread=(int)$q->fetchColumn();$q=$pdo->prepare('SELECT c.id,c.name,c.avatar_url,c.weight_kg,(SELECT MAX(logged_at) FROM meal_logs ml WHERE ml.client_id=c.id) last_meal,(SELECT COUNT(*) FROM meal_logs ml WHERE ml.client_id=c.id AND ml.status="skipped" AND ml.logged_at>=datetime("now","-7 day")) skips,(SELECT MAX(measured_on) FROM weight_logs wl WHERE wl.client_id=c.id) last_weight,(SELECT COUNT(*) FROM messages mm WHERE mm.client_id=c.id AND mm.author_type="client" AND mm.read_at IS NULL) unread FROM clients c WHERE c.specialist_id=? AND c.status="active" ORDER BY c.name');$q->execute([$sid]);$attention=[];foreach($q->fetchAll() as $r){$reasons=[];if((int)$r['unread'])$reasons[]='Новое сообщение';if(!$r['last_meal']||strtotime($r['last_meal'])<time()-172800)$reasons[]='Не отмечает питание 2+ дня';if((int)$r['skips']>=3)$reasons[]='Много пропусков';if(!$r['last_weight']||strtotime($r['last_weight'])<time()-604800)$reasons[]='Не обновлял вес 7 дней';if($reasons)$attention[]=array_merge($r,['reasons'=>$reasons]);}$adh=$pdo->prepare('SELECT SUM(CASE WHEN ml.status="eaten" THEN 1 ELSE 0 END) e,COUNT(*) t FROM meal_logs ml JOIN clients c ON c.id=ml.client_id WHERE c.specialist_id=? AND ml.logged_at>=datetime("now","-7 day")');$adh->execute([$sid]);$ar=$adh->fetch();$avg_adherence=$ar&&(int)$ar['t']>0?(int)round((int)$ar['e']/(int)$ar['t']*100):null;$wq=$pdo->prepare('SELECT (SELECT weight_kg FROM weight_logs w WHERE w.client_id=c.id ORDER BY measured_on DESC LIMIT 1) w_last,(SELECT weight_kg FROM weight_logs w WHERE w.client_id=c.id ORDER BY measured_on ASC LIMIT 1) w_first FROM clients c WHERE c.specialist_id=? AND c.status="active"');$wq->execute([$sid]);$deltas=[];foreach($wq->fetchAll() as $wr){if($wr['w_last']!==null&&$wr['w_first']!==null&&(float)$wr['w_last']!=(float)$wr['w_first'])$deltas[]=(float)$wr['w_last']-(float)$wr['w_first'];}$avg_weight_delta=count($deltas)?round(array_sum($deltas)/count($deltas),1):null;$mt=$pdo->prepare('SELECT SUM(CASE WHEN ml.status="eaten" THEN 1 ELSE 0 END) FROM meal_logs ml JOIN clients c ON c.id=ml.client_id WHERE c.specialist_id=? AND date(ml.logged_at)=date("now")');$mt->execute([$sid]);$meals_today=(int)$mt->fetchColumn();$mw=$pdo->prepare('SELECT SUM(CASE WHEN ml.status="eaten" THEN 1 ELSE 0 END) FROM meal_logs ml JOIN clients c ON c.id=ml.client_id WHERE c.specialist_id=? AND ml.logged_at>=datetime("now","-7 day")');$mw->execute([$sid]);$meals_week=(int)$mw->fetchColumn();$aw=$pdo->prepare('SELECT COUNT(DISTINCT ml.client_id) FROM meal_logs ml JOIN clients c ON c.id=ml.client_id WHERE c.specialist_id=? AND ml.logged_at>=datetime("now","-7 day")');$aw->execute([$sid]);$active_week=(int)$aw->fetchColumn();$me=$pdo->prepare("SELECT COUNT(*) FROM (SELECT c.id,(SELECT date(m.start_date,'+'||m.days_count||' day') FROM menus m WHERE m.client_id=c.id AND m.status='published' ORDER BY m.id DESC LIMIT 1) endd,(SELECT COUNT(*) FROM menus m2 WHERE m2.client_id=c.id AND m2.status='published') hasm FROM clients c WHERE c.specialist_id=? AND c.status='active') t WHERE hasm>0 AND date(endd)<=date('now','+3 day')");$me->execute([$sid]);$menus_ending=(int)$me->fetchColumn();$noMenu=$pdo->prepare("SELECT COUNT(*) FROM clients c WHERE c.specialist_id=? AND c.status='active' AND NOT EXISTS(SELECT 1 FROM menus m WHERE m.client_id=c.id AND m.status='published')");$noMenu->execute([$sid]);$no_menu=(int)$noMenu->fetchColumn();json_response(['clients'=>$clients,'published_menus'=>$published,'unread_messages'=>$unread,'attention'=>$attention,'avg_adherence'=>$avg_adherence,'avg_weight_delta'=>$avg_weight_delta,'meals_today'=>$meals_today,'meals_week'=>$meals_week,'active_week'=>$active_week,'menus_ending'=>$menus_ending,'no_menu'=>$no_menu]);}
 if($method==='GET'&&$path==='/specialist/clients'){ $q=$pdo->prepare('SELECT c.*,(SELECT COUNT(*) FROM messages m WHERE m.client_id=c.id AND m.author_type="client" AND m.read_at IS NULL) unread,(SELECT status FROM menus x WHERE x.client_id=c.id ORDER BY id DESC LIMIT 1) menu_status,(SELECT MAX(logged_at) FROM meal_logs ml WHERE ml.client_id=c.id) last_activity,(SELECT COUNT(*) FROM meal_logs ml WHERE ml.client_id=c.id AND ml.status="eaten" AND ml.logged_at>=datetime("now","-7 day")) eaten7,(SELECT COUNT(*) FROM meal_logs ml WHERE ml.client_id=c.id AND ml.logged_at>=datetime("now","-7 day")) logged7,(SELECT COUNT(*) FROM menu_items mi JOIN menus mn ON mn.id=mi.menu_id WHERE mn.id=(SELECT x.id FROM menus x WHERE x.client_id=c.id AND x.status="published" ORDER BY x.id DESC LIMIT 1) AND date(mn.start_date,"+"||(mi.day_number-1)||" day") BETWEEN date("now","-6 day") AND date("now")) planned7,(SELECT body FROM messages m WHERE m.client_id=c.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) last_msg,(SELECT created_at FROM messages m WHERE m.client_id=c.id ORDER BY m.created_at DESC,m.id DESC LIMIT 1) last_msg_at FROM clients c WHERE specialist_id=? ORDER BY c.name');$q->execute([$sid]);$rows=$q->fetchAll();$sd=$pdo->prepare("SELECT DISTINCT date(logged_at) d FROM meal_logs WHERE client_id=? AND status='eaten' AND logged_at>=datetime('now','-40 day') ORDER BY d DESC");/* «Не ел» и «не отметил» — разные вещи, и раньше они сходились в один
   процент: клиент, который отметил один приём из двадцати и съел его,
   выглядел стопроцентным. Считаем отдельно: сколько стояло в плане,
   сколько отмечено, сколько из отмеченного съедено. */
 foreach($rows as &$r){$r['compliance']=(int)$r['logged7']>0?(int)round((int)$r['eaten7']/(int)$r['logged7']*100):null;
  $r['skipped7']=max(0,(int)$r['logged7']-(int)$r['eaten7']);
  $r['unlogged7']=max(0,(int)$r['planned7']-(int)$r['logged7']);
  $r['marked_pct']=(int)$r['planned7']>0?(int)round((int)$r['logged7']/(int)$r['planned7']*100):null;$r['points']=(int)$r['eaten7']*10;$sd->execute([$r['id']]);$dates=[];foreach($sd->fetchAll() as $dr)$dates[$dr['d']]=true;$streak=0;$cur=strtotime(date('Y-m-d'));if(empty($dates[date('Y-m-d',$cur)]))$cur-=86400;while(!empty($dates[date('Y-m-d',$cur)])){$streak++;$cur-=86400;}$r['streak']=$streak;}json_response(['clients'=>safeClients($rows)]);}
 if($method==='POST'&&$path==='/specialist/clients'){ $in=input();$name=trim((string)($in['name']??''));if(!$name)json_response(['error'=>'Имя обязательно'],422);$invite=token(16);$q=$pdo->prepare('INSERT INTO clients(specialist_id,name,email,phone,invite_token,sex,birth_year,height_cm,weight_kg,activity_level,goal,target_kcal,target_protein,target_fat,target_carbs,notes,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');$q->execute([$sid,$name,$in['email']??null,$in['phone']??null,$invite,$in['sex']??null,$in['birth_year']??null,$in['height_cm']??null,$in['weight_kg']??null,$in['activity_level']??null,$in['goal']??null,$in['target_kcal']??1800,$in['target_protein']??110,$in['target_fat']??60,$in['target_carbs']??190,$in['notes']??null,'active',now()]);$nid=(int)$pdo->lastInsertId();attributeClient($nid,$sid,'invite');json_response(['client_id'=>$nid,'invite_token'=>$invite,'invite_url'=>selfOrigin().'/invite.html?token='.$invite],201);}
 if(preg_match('#^/specialist/clients/(\d+)$#',$path,$m)){ $cid=(int)$m[1];$c=ownedClient($cid,$sid);if($method==='GET')json_response(['client'=>safeClient($c),
   /* Какую услугу клиент подключил и до какого числа: специалист должен
      видеть, на что человек согласился, не спрашивая его об этом. */
   'subscription'=>subActive($cid)]);if($method==='PATCH'){ $in=input();$allowed=['name','email','phone','sex','birth_year','height_cm','weight_kg','activity_level','goal','target_kcal','target_protein','target_fat','target_carbs','excluded_ingredients','notes','status'];$sets=[];$vals=[];foreach($allowed as $k)if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=$k==='excluded_ingredients'?(is_string($in[$k])?$in[$k]:json_encode($in[$k])):$in[$k];}if($sets){$vals[]=$cid;$vals[]=$sid;$pdo->prepare('UPDATE clients SET '.implode(',',$sets).' WHERE id=? AND specialist_id=?')->execute($vals);}json_response(['client'=>safeClient(ownedClient($cid,$sid))]);}if($method==='DELETE'){$pdo->prepare('DELETE FROM clients WHERE id=? AND specialist_id=?')->execute([$cid,$sid]);json_response(['ok'=>true]);}}

 /* Прогресс клиента глазами специалиста. Раньше отдавались только веса,
    хотя замеры и фото клиент вносит ровно для того, чтобы их посмотрел
    специалист: для работы с телом одной цифры на весах мало.
    Право на карточку проверяет ownedClient — чужой прогресс не откроется. */
 /* Съеденное мимо меню — специалисту. Без этого он смотрит на
    «съедено 30%» и строит догадки, почему вес стоит: половина
    съеденного просто не попадала ему на глаза. */
 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/food-log$#',$path,$m)){
   $c=ownedClient((int)$m[1],$sid); $id=(int)$c['id'];
   $to=preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($_GET['to']??''))?$_GET['to']:date('Y-m-d');
   $from=preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($_GET['from']??''))?$_GET['from']:date('Y-m-d',strtotime($to.' -13 day'));
   $q=$pdo->prepare('SELECT DISTINCT eaten_on FROM food_entries WHERE client_id=? AND eaten_on BETWEEN ? AND ? ORDER BY eaten_on DESC');
   $q->execute([$id,$from,$to]);
   $days=[];
   foreach($q->fetchAll() as $r){
     $e=foodEntries($id,$r['eaten_on']);
     $days[]=['date'=>$r['eaten_on'],'entries'=>$e,'totals'=>foodTotals($e)];
   }
   json_response(['from'=>$from,'to'=>$to,'days'=>$days]);
 }

 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/progress$#',$path,$m)){
   $c=ownedClient((int)$m[1],$sid); $id=(int)$c['id'];
   $all=function(string $sql)use($pdo,$id){ $q=$pdo->prepare($sql);$q->execute([$id]);return $q->fetchAll(); };

   $weights=$all('SELECT * FROM weight_logs WHERE client_id=? ORDER BY measured_on');
   $measurements=$all('SELECT * FROM progress_measurements WHERE client_id=? ORDER BY measured_on');
   $photos=$all('SELECT * FROM progress_photos WHERE client_id=? ORDER BY measured_on DESC, id DESC');
   /* Снимок уходит содержимым, а не ссылкой: <img> в вебе и expo-image
      не отправляют заголовок авторизации, а токен в адресе осел бы в
      истории браузера. Большие снимки photoData уменьшает — раньше всё
      тяжелее 512 КБ молча превращалось в пустую строку, то есть обычное
      фото с телефона просто исчезало. */
   foreach($photos as &$pp)$pp['photo_url']=photoData($pp['photo_url']);
   unset($pp);

   $q=$pdo->prepare("SELECT COUNT(*) FROM meal_logs WHERE client_id=? AND status='eaten'");
   $q->execute([$id]);
   json_response([
     'weights'=>$weights,
     'measurements'=>$measurements,
     'photos'=>$photos,
     'eaten_count'=>(int)$q->fetchColumn(),
   ]);
 }
 if($method==='GET'&&$path==='/specialist/ingredients'){
   /* Поиск тот же, что в дневнике клиента: по свёрнутому имени, иначе
      «свёкл» не находит «Свёклу» — SQLite сравнивает без учёта
      регистра только латиницу. Без запроса отдаём весь справочник:
      на него опирается редактор блюд. */
   $qs=trim((string)($_GET['q']??''));
   $limit=(int)($_GET['limit']??0);
   if($qs!==''){
     $st=$pdo->prepare('SELECT * FROM ingredients WHERE name_fold LIKE ? ORDER BY category,name LIMIT ?');
     $st->execute(['%'.foodFold($qs).'%',$limit>0?min(100,$limit):40]);
   }elseif($limit>0){
     $st=$pdo->prepare('SELECT * FROM ingredients ORDER BY category,name LIMIT ?');
     $st->execute([min(100,$limit)]);
   }else{
     $st=$pdo->query('SELECT * FROM ingredients ORDER BY category,name');
   }
   json_response(['ingredients'=>$st->fetchAll()]);}
 if($method==='POST'&&$path==='/specialist/ingredients'){ $in=input();if(!trim((string)($in['name']??'')))json_response(['error'=>'Название обязательно'],422);$pdo->prepare('INSERT INTO ingredients(name,category,kcal,protein,fat,carbs,fiber,cooked_ratio,is_public,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([trim($in['name']),$in['category']??'Прочее',(float)($in['kcal']??0),(float)($in['protein']??0),(float)($in['fat']??0),(float)($in['carbs']??0),(float)($in['fiber']??0),(float)($in['cooked_ratio']??1),0,$sid,now()]);json_response(['ingredient_id'=>(int)$pdo->lastInsertId()],201);}
 if($method==='GET'&&$path==='/specialist/dishes'){ $q=trim((string)($_GET['q']??''));$tag=trim((string)($_GET['tag']??''));/* Блюда-однокомпонентники под назначенные продукты в базе блюд не
   показываем: это не рецепты, а способ положить продукт в меню. */
   $sql='SELECT d.*,GROUP_CONCAT(t.tag) tags FROM dishes d LEFT JOIN dish_tags t ON t.dish_id=d.id WHERE d.from_ingredient_id IS NULL AND (d.is_public=1 OR d.created_by=?) AND (d.name LIKE ? OR ?="")';$params=[$sid,'%'.$q.'%',$q];if($tag){$sql.=' AND EXISTS(SELECT 1 FROM dish_tags tx WHERE tx.dish_id=d.id AND tx.tag=?)';$params[]=$tag;}$sql.=' GROUP BY d.id ORDER BY d.name';$st=$pdo->prepare($sql);$st->execute($params);json_response(['dishes'=>$st->fetchAll()]);}
 /* Проверка метода обязательна: без неё этот маршрут перехватывал PATCH
    и DELETE того же адреса ниже и отвечал карточкой блюда — правка и
    удаление молча не срабатывали ни в приложении, ни в браузере. */
 if($method==='GET'&&preg_match('#^/specialist/dishes/(\d+)$#',$path,$m)){ $did=(int)$m[1];$q=$pdo->prepare('SELECT d.* FROM dishes d WHERE d.id=? AND (d.is_public=1 OR d.created_by=?)');$q->execute([$did,$sid]);$d=$q->fetch();if(!$d)json_response(['error'=>'Блюдо не найдено'],404);$q=$pdo->prepare('SELECT di.*,i.name ingredient_name,i.category,i.kcal,i.protein,i.fat,i.carbs,i.cooked_ratio FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=? ORDER BY di.sort_order');$q->execute([$did]);$d['ingredients']=$q->fetchAll();json_response(['dish'=>$d]);}
 if($method==='POST'&&$path==='/specialist/dishes'){ $in=input();$ings=$in['ingredients']??[];$name=trim((string)($in['name']??''));if(!$name||!is_array($ings)||!$ings)json_response(['error'=>'Название и состав обязательны'],422);$pdo->beginTransaction();$pdo->prepare('INSERT INTO dishes(name,meal_types,cook_minutes,instructions,photo_url,steps,is_public,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$name,json_encode($in['meal_types']??['lunch']),$in['cook_minutes']??null,$in['instructions']??null,$in['photo_url']??null,isset($in['steps'])?json_encode($in['steps'],JSON_UNESCAPED_UNICODE):null,0,$sid,now()]);$did=(int)$pdo->lastInsertId();$di=$pdo->prepare('INSERT INTO dish_ingredients(dish_id,ingredient_id,grams,sort_order) VALUES(?,?,?,?)');foreach($ings as $i=>$x)$di->execute([$did,(int)$x['ingredient_id'],(float)$x['grams'],$i]);$dt=$pdo->prepare('INSERT OR IGNORE INTO dish_tags(dish_id,tag) VALUES(?,?)');foreach(($in['tags']??[]) as $tag)$dt->execute([$did,trim((string)$tag)]);recalc_dish($did);$pdo->commit();json_response(['dish_id'=>$did],201);}
 if($method==='PATCH'&&preg_match('#^/specialist/dishes/(\d+)$#',$path,$m)){ $did=(int)$m[1];$q=$pdo->prepare('SELECT * FROM dishes WHERE id=? AND created_by=?');$q->execute([$did,$sid]);if(!$q->fetch())json_response(['error'=>'Можно менять только свои блюда'],403);$in=input();$sets=[];$vals=[];foreach(['name','meal_types','cook_minutes','instructions','photo_url','steps'] as $k)if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=($k==='meal_types'||$k==='steps')?json_encode($in[$k],JSON_UNESCAPED_UNICODE):$in[$k];}if($sets){$vals[]=$did;$pdo->prepare('UPDATE dishes SET '.implode(',',$sets).' WHERE id=?')->execute($vals);}if(isset($in['ingredients'])){$pdo->prepare('DELETE FROM dish_ingredients WHERE dish_id=?')->execute([$did]);$st=$pdo->prepare('INSERT INTO dish_ingredients(dish_id,ingredient_id,grams,sort_order) VALUES(?,?,?,?)');foreach($in['ingredients'] as $i=>$x)$st->execute([$did,(int)$x['ingredient_id'],(float)$x['grams'],$i]);recalc_dish($did);}json_response(['ok'=>true]);}
 if($method==='DELETE'&&preg_match('#^/specialist/dishes/(\d+)$#',$path,$m)){ $pdo->prepare('DELETE FROM dishes WHERE id=? AND created_by=?')->execute([(int)$m[1],$sid]);json_response(['ok'=>true]);}
 if($method==='GET'&&$path==='/specialist/menus'){ $cid=(int)($_GET['client_id']??0);$q=$pdo->prepare('SELECT * FROM menus WHERE specialist_id=?'.($cid?' AND client_id=?':'').' ORDER BY id DESC');$q->execute($cid?[$sid,$cid]:[$sid]);json_response(['menus'=>$q->fetchAll()]);}
 if($method==='POST'&&$path==='/specialist/menus'){ $in=input();$cid=(int)($in['client_id']??0);ownedClient($cid,$sid);$days=max(1,min(31,(int)($in['days_count']??7)));$pdo->prepare('INSERT INTO menus(client_id,specialist_id,title,start_date,days_count,status,created_at) VALUES(?,?,?,?,?,?,?)')->execute([$cid,$sid,$in['title']??'Меню на неделю',$in['start_date']??date('Y-m-d'),$days,'draft',now()]);json_response(['menu_id'=>(int)$pdo->lastInsertId()],201);}
 if(preg_match('#^/specialist/menus/(\d+)$#',$path,$m)){ $mid=(int)$m[1];$menu=ownedMenu($mid,$sid);if($method==='GET')json_response(menuPayload($menu,menuItems($mid)));if($method==='PATCH'){ $in=input();$sets=[];$vals=[];foreach(['title','start_date','days_count'] as $k)if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=$in[$k];}if($sets){$vals[]=$mid;$pdo->prepare('UPDATE menus SET '.implode(',',$sets).' WHERE id=?')->execute($vals);}json_response(['menu'=>ownedMenu($mid,$sid)]);} }
 if($method==='POST'&&preg_match('#^/specialist/menus/(\d+)/items$#',$path,$m)){ $menu=ownedMenu((int)$m[1],$sid);$in=input();
   /* Кроме блюда специалист может назначить просто продукт: под него
      заводится блюдо из одного ингредиента, и дальше позиция ничем не
      отличается от обычной — считается, отмечается, заменяется. */
   if(!empty($in['ingredient_id'])){
     try{ $in['dish_id']=dishForIngredient((int)$in['ingredient_id'],$sid); }
     catch(Throwable $e){ json_response(['error'=>$e->getMessage()],422); }
     if(!isset($in['portion_g']))$in['portion_g']=100;
   }
   $dish=(int)($in['dish_id']??0);$q=$pdo->prepare('SELECT * FROM dishes WHERE id=? AND (is_public=1 OR created_by=?)');$q->execute([$dish,$sid]);if(!$q->fetch())json_response(['error'=>'Блюдо недоступно'],422);$portion=max(1,(float)($in['portion_g']??250));$pdo->prepare('INSERT INTO menu_items(menu_id,day_number,meal_type,dish_id,portion_g,overrides,comment,sort_order) VALUES(?,?,?,?,?,?,?,?)')->execute([$menu['id'],(int)$in['day_number'],$in['meal_type']??'lunch',$dish,$portion,isset($in['overrides'])?json_encode($in['overrides']):null,$in['comment']??null,(int)($in['sort_order']??0)]);json_response(['item_id'=>(int)$pdo->lastInsertId()],201);}
 if(preg_match('#^/specialist/menu-items/(\d+)$#',$path,$m)){ $iid=(int)$m[1];$q=$pdo->prepare('SELECT mi.*,m.specialist_id FROM menu_items mi JOIN menus m ON m.id=mi.menu_id WHERE mi.id=? AND m.specialist_id=?');$q->execute([$iid,$sid]);if(!$q->fetch())json_response(['error'=>'Не найдено'],404);if($method==='PATCH'){ $in=input();$sets=[];$vals=[];foreach(['portion_g','meal_type','day_number','comment','overrides','sort_order'] as $k)if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=$k==='overrides'?(is_string($in[$k])?$in[$k]:json_encode($in[$k])):$in[$k];}if($sets){$vals[]=$iid;$pdo->prepare('UPDATE menu_items SET '.implode(',',$sets).' WHERE id=?')->execute($vals);}json_response(['ok'=>true]);}if($method==='DELETE'){$pdo->prepare('DELETE FROM menu_items WHERE id=?')->execute([$iid]);json_response(['ok'=>true]);}}
 if($method==='POST'&&preg_match('#^/specialist/menus/(\d+)/copy-day$#',$path,$m)){ $menu=ownedMenu((int)$m[1],$sid);$in=input();$from=(int)($in['from_day']??1);$to=(int)($in['to_day']??2);$items=menuItems($menu['id']);$types=is_array($in['meal_types']??null)?$in['meal_types']:[];$pdo->prepare('DELETE FROM menu_items WHERE menu_id=? AND day_number=?'.($types?' AND meal_type IN ('.implode(',',array_fill(0,count($types),'?')).')':'') )->execute(array_merge([$menu['id'],$to],$types));$st=$pdo->prepare('INSERT INTO menu_items(menu_id,day_number,meal_type,dish_id,portion_g,overrides,comment,sort_order) VALUES(?,?,?,?,?,?,?,?)');foreach($items as $x)if((int)$x['day_number']===$from&&(!$types||in_array($x['meal_type'],$types,true)))$st->execute([$menu['id'],$to,$x['meal_type'],$x['dish_id'],$x['portion_g'],$x['overrides'],$x['comment'],$x['sort_order']]);json_response(['ok'=>true]);}
 if($method==='POST'&&preg_match('#^/specialist/menus/(\d+)/duplicate$#',$path,$m)){ $menu=ownedMenu((int)$m[1],$sid);$in=input();$start=$in['start_date']??date('Y-m-d');$pdo->beginTransaction();$pdo->prepare('INSERT INTO menus(client_id,specialist_id,title,start_date,days_count,status,created_at) VALUES(?,?,?,?,?,?,?)')->execute([$menu['client_id'],$sid,$in['title']??$menu['title'].' · копия',$start,$menu['days_count'],'draft',now()]);$new=(int)$pdo->lastInsertId();$st=$pdo->prepare('INSERT INTO menu_items(menu_id,day_number,meal_type,dish_id,portion_g,overrides,comment,sort_order) SELECT ?,day_number,meal_type,dish_id,portion_g,overrides,comment,sort_order FROM menu_items WHERE menu_id=?');$st->execute([$new,$menu['id']]);$pdo->commit();json_response(['menu_id'=>$new],201);}
 if($method==='POST'&&preg_match('#^/specialist/menus/(\d+)/publish$#',$path,$m)){
   $menu=ownedMenu((int)$m[1],$sid);
   $pdo->prepare('UPDATE menus SET status="published",published_at=? WHERE id=? AND specialist_id=?')
       ->execute([now(),(int)$m[1],$sid]);
   /* Уведомление уходит отсюда, а не из планировщика: тот просыпается
      раз в пять минут, и клиент узнавал о новом меню с опозданием, а
      при пропущенном запуске — вовсе не узнавал. */
   $cid=(int)$menu['client_id'];
   createNotification($cid,'menu','Меню обновлено','Специалист опубликовал ваше меню.');
   $pq=$pdo->prepare('SELECT menu_updates FROM notification_preferences WHERE user_type="client" AND user_id=?');
   $pq->execute([$cid]);
   $want=$pq->fetchColumn();
   if($want===false||(int)$want===1){
     $sq=$pdo->prepare('SELECT name FROM specialists WHERE id=?');$sq->execute([$sid]);
     $who=(string)($sq->fetchColumn()?:'Специалист');
     pushSend('client',$cid,$who,'Опубликовал ваше меню — посмотрите, что на неделю.',
              '/app/','menu','/client/week');
   }
   json_response(['ok'=>true]);}
 if($method==='GET'&&$path==='/specialist/messages'){ $cid=(int)($_GET['client_id']??0);ownedClient($cid,$sid);
   /* after_id — догрузка только новых сообщений. Чат опрашивает сервер
      каждые несколько секунд, и гонять всю переписку ради одной строки
      значит греть и телефон, и сервер. */
   $after=(int)($_GET['after_id']??0);
   $q=$pdo->prepare('SELECT * FROM messages WHERE client_id=?'.($after?' AND id>?':'').' ORDER BY id');
   $q->execute($after?[$cid,$after]:[$cid]);
  /* Открыл переписку — значит прочитал. Без этого счётчик непрочитанных
     у специалиста не обнулялся никогда: пометку ставил только клиент. */
  $pdo->prepare('UPDATE messages SET read_at=? WHERE client_id=? AND author_type="client" AND read_at IS NULL')->execute([now(),$cid]);
  json_response(['messages'=>$q->fetchAll()]);}
 if($method==='POST'&&$path==='/specialist/messages'){ $in=input();$cid=(int)$in['client_id'];ownedClient($cid,$sid);$body=trim((string)($in['body']??''));$att=trim((string)($in['attachment_url']??''));if(!$body&&!$att)json_response(['error'=>'Сообщение пустое'],422);$pdo->prepare('INSERT INTO messages(client_id,author_type,body,attachment_url,created_at) VALUES(?,?,?,?,?)')->execute([$cid,'specialist',$body,$att?:null,now()]);
   $mid=(int)$pdo->lastInsertId();
   $pdo->prepare('INSERT INTO notifications(client_id,type,title,body,created_at) VALUES(?,?,?,?,?)')->execute([$cid,'message','Новое сообщение','Специалист написал вам.',now()]);
   /* В заголовке — имя того, кто написал: система подставляет рядом
      название приложения, и «Новое сообщение от EQUA» ничего не
      говорило о том, кто именно написал. */
   $nq=$pdo->prepare('SELECT s.name FROM specialists s JOIN clients c ON c.specialist_id=s.id WHERE c.id=?');
   $nq->execute([$cid]);
   $who=(string)($nq->fetchColumn()?:'Специалист');
   pushSend('client',$cid,$who,mb_substr($body!==''?$body:'Вложение',0,120),'/app/','message');
   /* Возвращаем строку целиком: экран вставляет её сразу, не перезагружая
      переписку. Раньше после отправки перерисовывался весь чат — он
      прыгал наверх, и это читалось как зависание. */
   $q=$pdo->prepare('SELECT * FROM messages WHERE id=?');$q->execute([$mid]);
   json_response(['ok'=>true,'message'=>$q->fetch()],201);}
 if($method==='GET'&&$path==='/specialist/profile'){ $q=$pdo->prepare('SELECT s.*,p.slug,p.bio,p.city,p.rating,p.reviews_count,p.is_public,p.price,p.price_unit,p.education,p.experience_years,p.specializations,p.advantages FROM specialists s LEFT JOIN public_profiles p ON p.specialist_id=s.id WHERE s.id=?');$q->execute([$sid]);$pr=$q->fetch()?:[];unset($pr['password_hash']);json_response(['profile'=>$pr]);}
 /* Черновик меню под цели клиента.
    Программа набирает блюда так, чтобы день сходился по калориям, и не
    ставит то, что клиенту нельзя. Состав тарелки, сочетаемость и
    повторы остаются за специалистом — поэтому меню создаётся
    черновиком, а в ответ идёт отчёт с расхождениями. */
 if($method==='POST'&&preg_match('#^/specialist/clients/(\d+)/menu/generate$#',$path,$m)){
   $c=ownedClient((int)$m[1],$sid);
   $in=input();
   try{
     json_response(generateMenu((int)$c['id'],$sid,[
       'days_count'=>$in['days_count']??7,
       'start_date'=>$in['start_date']??date('Y-m-d'),
       'meals'=>$in['meals']??null,
       'title'=>$in['title']??'',
     ]),201);
   }catch(RuntimeException $e){
     json_response(['error'=>$e->getMessage()],422);
   }
 }

 /* --- Задания клиенту ---
    Зашитые «отметить приёмы» и «записать вес» — правила сервиса, а не
    задания специалиста. Здесь он ставит личные: сдать анализы, пройти
    шаги, приготовить по рецепту и прислать фото. */
 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/tasks$#',$path,$m)){
   $c=ownedClient((int)$m[1],$sid);
   $q=$pdo->prepare("SELECT * FROM client_tasks WHERE client_id=?
                     ORDER BY (status='open') DESC, COALESCE(due_on,'9999') ASC, id DESC LIMIT 200");
   $q->execute([(int)$c['id']]);
   $rows=$q->fetchAll();
   foreach($rows as &$r) if($r['photo_url']) $r['photo_url']=photoData($r['photo_url']);
   unset($r);
   json_response(['tasks'=>$rows]);
 }
 if($method==='POST'&&preg_match('#^/specialist/clients/(\d+)/tasks$#',$path,$m)){
   $c=ownedClient((int)$m[1],$sid);
   $in=input();
   $title=trim((string)($in['title']??''));
   if($title==='')json_response(['error'=>'Что нужно сделать?'],422);
   $kind=($in['kind']??'simple')==='photo'?'photo':'simple';
   /* Баллы держим в разумных рамках: задание за 5000 баллов обесценило
      бы всё остальное, а отрицательное — просто ошибка ввода. */
   $pts=max(0,min(500,(int)($in['points']??20)));
   $pdo->prepare('INSERT INTO client_tasks(client_id,specialist_id,title,note,kind,points,due_on,status,created_at)
                  VALUES(?,?,?,?,?,?,?,?,?)')
       ->execute([(int)$c['id'],$sid,mb_substr($title,0,200),
                  mb_substr(trim((string)($in['note']??'')),0,1000)?:null,
                  $kind,$pts,trim((string)($in['due_on']??''))?:null,'open',now()]);
   /* Идентификатор снимаем до уведомления: createNotification делает
      свой INSERT, и lastInsertId() после него вернёт чужую строку. */
   $tid=(int)$pdo->lastInsertId();
   createNotification((int)$c['id'],'task','Новое задание',$title);
   json_response(['ok'=>true,'id'=>$tid],201);
 }
 /* Задание не удаляем, а отменяем: закрытые задания — история работы,
    и стирать её задним числом нечестно по отношению к клиенту. */
 if($method==='DELETE'&&preg_match('#^/specialist/tasks/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT t.id FROM client_tasks t JOIN clients c ON c.id=t.client_id
                     WHERE t.id=? AND c.specialist_id=?');
   $q->execute([(int)$m[1],$sid]);
   if(!$q->fetch())json_response(['error'=>'Не найдено'],404);
   $pdo->prepare("UPDATE client_tasks SET status='cancelled' WHERE id=?")->execute([(int)$m[1]]);
   json_response(['ok'=>true]);
 }

 /* --- Привилегии за баллы ---
    Раньше список был зашит в код и обещал скидку на подписку, которой
    в сервисе нет. Теперь что специалист написал, то он и выдаёт. */
 if($method==='GET'&&$path==='/specialist/rewards'){
   $q=$pdo->prepare('SELECT * FROM specialist_rewards WHERE specialist_id=? ORDER BY cost');
   $q->execute([$sid]);
   json_response(['rewards'=>$q->fetchAll()]);
 }
 if($method==='POST'&&$path==='/specialist/rewards'){
   $in=input();
   $title=trim((string)($in['title']??''));
   if($title==='')json_response(['error'=>'Название обязательно'],422);
   $cost=max(1,(int)($in['cost']??500));
   $pdo->prepare('INSERT INTO specialist_rewards(specialist_id,title,note,cost,is_active,created_at) VALUES(?,?,?,?,1,?)')
       ->execute([$sid,mb_substr($title,0,160),mb_substr(trim((string)($in['note']??'')),0,500)?:null,$cost,now()]);
   json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()],201);
 }
 if($method==='PATCH'&&preg_match('#^/specialist/rewards/(\d+)$#',$path,$m)){
   $in=input();
   $pdo->prepare('UPDATE specialist_rewards SET is_active=? WHERE id=? AND specialist_id=?')
       ->execute([empty($in['is_active'])?0:1,(int)$m[1],$sid]);
   json_response(['ok'=>true]);
 }
 if($method==='DELETE'&&preg_match('#^/specialist/rewards/(\d+)$#',$path,$m)){
   $pdo->prepare('DELETE FROM specialist_rewards WHERE id=? AND specialist_id=?')->execute([(int)$m[1],$sid]);
   json_response(['ok'=>true]);
 }

 /* --- Верификация: сторона специалиста --- */
 /* Свои отзывы специалист видит, но не трогает: отзыв, который можно
    стереть, ничего не стоит. Убрать брань может только владелец. */
 if($method==='GET'&&$path==='/specialist/reviews'){
   $q=$pdo->prepare("SELECT COUNT(*) n, AVG(rating) r FROM specialist_reviews
                     WHERE specialist_id=? AND status='published'");
   $q->execute([$sid]); $a=$q->fetch();
   json_response([
     'rating'=>((int)$a['n'])? round((float)$a['r'],1) : null,
     'count'=>(int)$a['n'],
     'reviews'=>reviewsOf($sid,200),
   ]);
 }

 if($method==='GET'&&$path==='/specialist/verification'){ json_response(verificationOf($sid)); }

 /* Документ приходит формой: файл плюс поля. Заявку это ещё не создаёт —
    специалист может собрать несколько дипломов и отправить их разом. */
 if($method==='POST'&&$path==='/specialist/verification/documents'){
   $title=trim((string)($_POST['title']??''));
   if($title==='')json_response(['error'=>'Укажите, что это за документ'],422);
   $kind=(string)($_POST['kind']??'diploma');
   if(!in_array($kind,VERIFY_KINDS,true))$kind='diploma';
   $url=saveDocFile();
   if(!$url)json_response(['error'=>'Приложите скан или PDF'],422);
   $pdo->prepare('INSERT INTO specialist_documents(specialist_id,kind,title,issuer,issued_on,file_url,status,created_at)
                  VALUES(?,?,?,?,?,?,?,?)')
       ->execute([$sid,$kind,mb_substr($title,0,200),
                  mb_substr(trim((string)($_POST['issuer']??'')),0,200)?:null,
                  trim((string)($_POST['issued_on']??''))?:null,$url,'pending',now()]);
   json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()],201);
 }
 /* Показывать скан в открытом профиле или нет — решает специалист.
    По умолчанию нет: документ грузили для проверки, а не для витрины.
    Паспорт нельзя открыть вовсе — ни через это переключение, ни иначе. */
 if($method==='PATCH'&&preg_match('#^/specialist/verification/documents/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT kind FROM specialist_documents WHERE id=? AND specialist_id=?');
   $q->execute([(int)$m[1],$sid]);$row=$q->fetch();
   if(!$row)json_response(['error'=>'Не найдено'],404);
   if($row['kind']==='passport')json_response(['error'=>'Паспорт нельзя показывать в открытом профиле'],422);
   $in=input();
   $pdo->prepare('UPDATE specialist_documents SET is_public=? WHERE id=? AND specialist_id=?')
       ->execute([!empty($in['is_public'])?1:0,(int)$m[1],$sid]);
   json_response(['ok'=>true]);
 }
 if($method==='DELETE'&&preg_match('#^/specialist/verification/documents/(\d+)$#',$path,$m)){
   $q=$pdo->prepare('SELECT file_url FROM specialist_documents WHERE id=? AND specialist_id=?');
   $q->execute([(int)$m[1],$sid]);$row=$q->fetch();
   if(!$row)json_response(['error'=>'Не найдено'],404);
   $pdo->prepare('DELETE FROM specialist_documents WHERE id=? AND specialist_id=?')->execute([(int)$m[1],$sid]);
   /* Файл на диске без записи в базе никому не нужен и всё ещё лежит. */
   $name=basename((string)$row['file_url']);
   $file=__DIR__.'/../storage/uploads/'.$name;
   if($name!==''&&is_file($file))@unlink($file);
   refreshVerification($sid);
   json_response(['ok'=>true]);
 }
 /* Отправка на проверку. Ставим статус «на проверке» и будим владельца
    уведомлением — очередь он и так видит, но так не придётся заглядывать. */
 if($method==='POST'&&$path==='/specialist/verification/submit'){
   $n=$pdo->prepare("SELECT COUNT(*) FROM specialist_documents WHERE specialist_id=? AND status<>'rejected'");
   $n->execute([$sid]);
   if((int)$n->fetchColumn()===0)json_response(['error'=>'Приложите хотя бы один документ'],422);
   $pdo->prepare("UPDATE specialists SET verify_status='pending',verify_note=NULL,verify_submitted_at=? WHERE id=?")
       ->execute([now(),$sid]);
   $me=$pdo->prepare('SELECT name,email FROM specialists WHERE id=?');$me->execute([$sid]);$who=$me->fetch()?:[];
   [$h,$t]=plainLetter('Новая заявка на верификацию.',
     ($who['name']??'Специалист').' ('.($who['email']??'').') отправил документы на проверку.',
     'Откройте панель владельца: «Люди → Верификация».');
   mailOwner('Заявка на верификацию — '.APP_NAME,$h,$t);
   json_response(['ok'=>true,'status'=>'pending']);
 }

 if($method==='GET'&&$path==='/specialist/leads'){ $q=$pdo->prepare('SELECT * FROM catalog_leads WHERE specialist_id=? ORDER BY id DESC LIMIT 100');$q->execute([$sid]);json_response(['leads'=>$q->fetchAll()]);}
 if($method==='POST'&&preg_match('#^/specialist/leads/(\d+)/read$#',$path,$m)){ $pdo->prepare('UPDATE catalog_leads SET read_at=? WHERE id=? AND specialist_id=?')->execute([now(),(int)$m[1],$sid]);json_response(['ok'=>true]);}
 if($method==='POST'&&$path==='/specialist/avatar'){ $url=saveAvatar();$pdo->prepare('UPDATE specialists SET avatar_url=? WHERE id=?')->execute([$url,$sid]);json_response(['avatar_url'=>$url]);}
 if($method==='DELETE'&&$path==='/specialist/avatar'){ $pdo->prepare('UPDATE specialists SET avatar_url=NULL WHERE id=?')->execute([$sid]);json_response(['ok'=>true]);}
 if($method==='POST'&&$path==='/specialist/upload'){ json_response(['url'=>saveAvatar()]);}
 if($method==='DELETE'&&$path==='/specialist/account'){ deleteSpecialistAccount($sid);json_response(['ok'=>true]); }
 if($method==='POST'&&$path==='/specialist/attachment'){ json_response(['url'=>saveAttachment()]);}
 if($method==='PATCH'&&$path==='/specialist/profile'){ $in=input();if(isset($in['profession'])&&in_array($in['profession'],['nutritionist','trainer','coach'],true))$pdo->prepare('UPDATE specialists SET profession=? WHERE id=?')->execute([$in['profession'],$sid]);$pdo->prepare('UPDATE specialists SET name=?,phone=?,avatar_url=? WHERE id=?')->execute([$in['name']??'', $in['phone']??null,$in['avatar_url']??null,$sid]);$slug=preg_replace('/[^a-z0-9-]+/i','-',strtolower((string)($in['slug']??'specialist-'.$sid)));$pdo->prepare('INSERT INTO public_profiles(specialist_id,slug,bio,city,is_public,education,experience_years,specializations,advantages) VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(specialist_id) DO UPDATE SET slug=excluded.slug,bio=excluded.bio,city=excluded.city,is_public=excluded.is_public,education=excluded.education,experience_years=excluded.experience_years,specializations=excluded.specializations,advantages=excluded.advantages')->execute([$sid,$slug,$in['bio']??null,$in['city']??null,(int)($in['is_public']??0),$in['education']??null,isset($in['experience_years'])?(int)$in['experience_years']:null,$in['specializations']??null,$in['advantages']??null]);json_response(['ok'=>true]);}
 if($method==='GET'&&$path==='/specialist/templates'){ $q=$pdo->prepare('SELECT t.*, m.title source_title, m.days_count, (SELECT COUNT(*) FROM menu_items mi WHERE mi.menu_id=t.source_menu_id) items_count FROM menu_templates t LEFT JOIN menus m ON m.id=t.source_menu_id WHERE t.specialist_id=? ORDER BY t.id DESC');$q->execute([$sid]);json_response(['templates'=>$q->fetchAll()]);}
 if($method==='POST'&&$path==='/specialist/templates'){ $in=input();$mid=(int)$in['source_menu_id'];ownedMenu($mid,$sid);$pdo->prepare('INSERT INTO menu_templates(specialist_id,name,source_menu_id,created_at) VALUES(?,?,?,?)')->execute([$sid,$in['name']??'Шаблон',$mid,now()]);json_response(['template_id'=>(int)$pdo->lastInsertId()],201);}
 if($method==='POST'&&preg_match('#^/specialist/templates/(\d+)/apply$#',$path,$m)){ $q=$pdo->prepare('SELECT * FROM menu_templates WHERE id=? AND specialist_id=?');$q->execute([(int)$m[1],$sid]);$t=$q->fetch();if(!$t)json_response(['error'=>'Шаблон не найден'],404);$in=input();$src=ownedMenu((int)$t['source_menu_id'],$sid);if(!empty($in['menu_id'])){$target=ownedMenu((int)$in['menu_id'],$sid);}else{$cid=(int)($in['client_id']??0);ownedClient($cid,$sid);$days=max(1,(int)($src['days_count']??7));$pdo->prepare('INSERT INTO menus(client_id,specialist_id,title,start_date,days_count,status,created_at) VALUES(?,?,?,?,?,?,?)')->execute([$cid,$sid,$t['name'],date('Y-m-d'),$days,'draft',now()]);$target=ownedMenu((int)$pdo->lastInsertId(),$sid);}$items=menuItems($src['id']);$pdo->prepare('DELETE FROM menu_items WHERE menu_id=?')->execute([$target['id']]);$st=$pdo->prepare('INSERT INTO menu_items(menu_id,day_number,meal_type,dish_id,portion_g,overrides,comment,sort_order) VALUES(?,?,?,?,?,?,?,?)');foreach($items as $x)$st->execute([$target['id'],$x['day_number'],$x['meal_type'],$x['dish_id'],$x['portion_g'],$x['overrides'],$x['comment'],$x['sort_order']]);json_response(['ok'=>true,'menu_id'=>(int)$target['id']],201);}
 if($method==='DELETE'&&preg_match('#^/specialist/templates/(\d+)$#',$path,$m)){ $q=$pdo->prepare('SELECT id FROM menu_templates WHERE id=? AND specialist_id=?');$q->execute([(int)$m[1],$sid]);if(!$q->fetch())json_response(['error'=>'Шаблон не найден'],404);$pdo->prepare('DELETE FROM menu_templates WHERE id=?')->execute([(int)$m[1]]);json_response(['ok'=>true]);}
 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/engagement$#',$path,$m)){ $cid=(int)$m[1];ownedClient($cid,$sid);json_response(gamification($cid));}
 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/feedback$#',$path,$m)){ $cid=(int)$m[1];ownedClient($cid,$sid);$q=$pdo->prepare('SELECT lf.*,mi.meal_type,d.name dish_name FROM meal_log_feedback lf JOIN menu_items mi ON mi.id=lf.menu_item_id JOIN dishes d ON d.id=mi.dish_id WHERE lf.client_id=? ORDER BY lf.created_at DESC LIMIT 30');$q->execute([$cid]);json_response(['feedback'=>$q->fetchAll()]);}
 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/profile$#',$path,$m)){ $c=ownedClient((int)$m[1],$sid);ensurePrefs('client',(int)$c['id']);$q=$pdo->prepare('SELECT * FROM client_preferences WHERE client_id=?');$q->execute([$c['id']]);$prefs=$q->fetch();$q=$pdo->prepare('SELECT * FROM progress_measurements WHERE client_id=? ORDER BY measured_on DESC');$q->execute([$c['id']]);$measurements=$q->fetchAll();$q=$pdo->prepare('SELECT * FROM progress_photos WHERE client_id=? ORDER BY measured_on DESC,id DESC');$q->execute([$c['id']]);$photos=$q->fetchAll();foreach($photos as &$pp){$pp['photo_url']=photoData($pp['photo_url']);}json_response(['client'=>safeClient($c),'preferences'=>$prefs,'measurements'=>$measurements,'photos'=>$photos]);}
 if($method==='PATCH'&&preg_match('#^/specialist/clients/(\d+)/preferences$#',$path,$m)){ $cid=(int)$m[1];ownedClient($cid,$sid);$in=input();$pdo->prepare('INSERT INTO client_preferences(client_id,likes,dislikes,excluded,allowed_replacements,notes,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(client_id) DO UPDATE SET likes=excluded.likes,dislikes=excluded.dislikes,excluded=excluded.excluded,allowed_replacements=excluded.allowed_replacements,notes=excluded.notes,updated_at=excluded.updated_at')->execute([$cid,json_encode($in['likes']??[]),json_encode($in['dislikes']??[]),json_encode($in['excluded']??[]),(int)($in['allowed_replacements']??1),$in['notes']??null,now()]);json_response(['ok'=>true]);}
 if($method==='GET'&&preg_match('#^/specialist/menu-items/(\d+)/replacements$#',$path,$m)){ $iid=(int)$m[1];$q=$pdo->prepare('SELECT mir.dish_id,d.name,d.kcal_100,d.protein_100,d.fat_100,d.carbs_100,d.base_portion_g FROM menu_item_replacements mir JOIN dishes d ON d.id=mir.dish_id JOIN menu_items mi ON mi.id=mir.menu_item_id JOIN menus mn ON mn.id=mi.menu_id WHERE mir.menu_item_id=? AND mn.specialist_id=? ORDER BY mir.sort_order');$q->execute([$iid,$sid]);json_response(['dishes'=>$q->fetchAll()]);}
 if($method==='PUT'&&preg_match('#^/specialist/menu-items/(\d+)/replacements$#',$path,$m)){ $iid=(int)$m[1];$q=$pdo->prepare('SELECT mi.id FROM menu_items mi JOIN menus mn ON mn.id=mi.menu_id WHERE mi.id=? AND mn.specialist_id=?');$q->execute([$iid,$sid]);if(!$q->fetch())json_response(['error'=>'Не найдено'],404);$in=input();$pdo->prepare('DELETE FROM menu_item_replacements WHERE menu_item_id=?')->execute([$iid]);$st=$pdo->prepare('INSERT INTO menu_item_replacements(menu_item_id,dish_id,sort_order) VALUES(?,?,?)');foreach(array_values($in['dish_ids']??[]) as $i=>$did){$st->execute([$iid,(int)$did,$i]);}json_response(['ok'=>true]);}
 if($method==='GET'&&$path==='/specialist/signals'){ $j=(function()use($sid){$q=db()->prepare('SELECT c.id,c.name,(SELECT COUNT(*) FROM messages m WHERE m.client_id=c.id AND m.author_type="client" AND m.read_at IS NULL) unread,(SELECT MAX(logged_at) FROM meal_logs ml WHERE ml.client_id=c.id) last_meal,(SELECT COUNT(*) FROM meal_logs ml WHERE ml.client_id=c.id AND ml.status="skipped" AND ml.logged_at>=datetime("now","-7 day")) skips,(SELECT MAX(measured_on) FROM weight_logs wl WHERE wl.client_id=c.id) last_weight FROM clients c WHERE c.specialist_id=? AND c.status="active" ORDER BY c.name');$q->execute([$sid]);$out=[];foreach($q->fetchAll() as $r){if($r['unread']||!$r['last_meal']||strtotime($r['last_meal'])<time()-172800||$r['skips']>=3||!$r['last_weight']||strtotime($r['last_weight'])<time()-604800)$out[]=$r;}return $out;})();json_response(['signals'=>$j]);}
 if($method==='GET'&&$path==='/specialist/shopping'){ $cid=(int)($_GET['client_id']??0);ownedClient($cid,$sid);$mid=(int)($_GET['menu_id']??0);$m=ownedMenu($mid,$sid);if((int)$m['client_id']!==$cid)json_response(['error'=>'Неверный клиент'],422);$items=menuItems($mid);$agg=[];foreach($items as $it){$dq=$pdo->prepare('SELECT base_portion_g FROM dishes WHERE id=?');$dq->execute([$it['dish_id']]);$base=max(1,(float)$dq->fetchColumn());$scale=(float)$it['portion_g']/$base;$q=$pdo->prepare('SELECT di.grams,i.name,i.category,i.cooked_ratio FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=?');$q->execute([$it['dish_id']]);foreach($q->fetchAll() as $r){$key=mb_strtolower($r['name']);$agg[$key]['name']=$r['name'];$agg[$key]['category']=$r['category'];$agg[$key]['grams']=($agg[$key]['grams']??0)+(float)$r['grams']*$scale;}}$list=[];foreach($agg as $r)$list[]=$r;usort($list,fn($a,$b)=>strcmp($a['category'].$a['name'],$b['category'].$b['name']));json_response(['items'=>$list]);}
 if($method==='POST'&&preg_match('#^/specialist/clients/(\d+)/measurements$#',$path,$m)){ $cid=(int)$m[1];ownedClient($cid,$sid);$in=input();$pdo->prepare('INSERT INTO progress_measurements(client_id,measured_on,waist_cm,hips_cm,chest_cm,note) VALUES(?,?,?,?,?,?) ON CONFLICT(client_id,measured_on) DO UPDATE SET waist_cm=excluded.waist_cm,hips_cm=excluded.hips_cm,chest_cm=excluded.chest_cm,note=excluded.note')->execute([$cid,$in['measured_on']??date('Y-m-d'),$in['waist_cm']??null,$in['hips_cm']??null,$in['chest_cm']??null,$in['note']??null]);json_response(['ok'=>true]);}
 /* Уведомления специалиста — из двух источников: события у клиентов и
    то, что касается его самого. Клиентские записи принадлежат клиентам,
    гасить их специалист не вправе, поэтому «прочитано» у него своё —
    одна отметка времени на всё. Без неё колокольчик не гас никогда. */
 if($method==='GET'&&$path==='/specialist/notifications'){
   $q=$pdo->prepare('SELECT notices_seen_at,notices_cleared_at FROM specialists WHERE id=?');
   $q->execute([$sid]); $row=$q->fetch()?:[];
   $seen=(string)($row['notices_seen_at']??'');
   /* Уведомления о клиентах принадлежат клиентам — удалять их специалист
      не вправе. Поэтому «очистить» для него это отметка времени: всё,
      что было раньше, из его ленты не показываем. Свои уведомления
      (specialist_notices) при очистке удаляются по-настоящему. */
   $cleared=(string)($row['notices_cleared_at']??'');

   $c=$pdo->prepare('SELECT n.id,n.type,n.title,n.body,n.read_at,n.created_at,c.name client_name
                     FROM notifications n JOIN clients c ON c.id=n.client_id
                     WHERE c.specialist_id=? AND (? = \'\' OR n.created_at > ?)
                     ORDER BY n.created_at DESC LIMIT 100');
   $c->execute([$sid,$cleared,$cleared]);
   $out=[];
   foreach($c->fetchAll() as $r){
     $r['source']='client';
     /* Клиентское read_at — про клиента, а не про специалиста.
        Сравнение строгое: время хранится с точностью до секунды, и при
        «<=» уведомление, пришедшее в ту же секунду, что и нажатие
        «прочитано», молча пропадало бы из непрочитанных. */
     $r['read_at']=($seen!==''&&$r['created_at']<$seen)?$seen:null;
     $out[]=$r;
   }
   $o=$pdo->prepare('SELECT id,type,title,body,read_at,created_at FROM specialist_notices
                     WHERE specialist_id=? ORDER BY created_at DESC LIMIT 100');
   $o->execute([$sid]);
   foreach($o->fetchAll() as $r){
     $r['source']='own'; $r['client_name']=null;
     if(!$r['read_at']&&$seen!==''&&$r['created_at']<$seen)$r['read_at']=$seen;
     $out[]=$r;
   }
   usort($out,fn($a,$b)=>strcmp((string)$b['created_at'],(string)$a['created_at']));
   json_response(['notifications'=>array_slice($out,0,100)]);
 }
 if($method==='DELETE'&&$path==='/specialist/notifications'){
   $pdo->prepare('UPDATE specialists SET notices_cleared_at=?, notices_seen_at=? WHERE id=?')
       ->execute([now(),now(),$sid]);
   $pdo->prepare('DELETE FROM specialist_notices WHERE specialist_id=?')->execute([$sid]);
   json_response(['ok'=>true]);
 }
 if($method==='POST'&&$path==='/specialist/notifications/read'){
   $pdo->prepare('UPDATE specialists SET notices_seen_at=? WHERE id=?')->execute([now(),$sid]);
   $pdo->prepare('UPDATE specialist_notices SET read_at=? WHERE specialist_id=? AND read_at IS NULL')
       ->execute([now(),$sid]);
   json_response(['ok'=>true]);
 }
 if($method==='GET'&&$path==='/specialist/push/preferences'){ensurePrefs('specialist',$sid);$q=$pdo->prepare('SELECT * FROM notification_preferences WHERE user_type="specialist" AND user_id=?');$q->execute([$sid]);json_response(['preferences'=>$q->fetch()]);}
 if($method==='PATCH'&&$path==='/specialist/push/preferences'){ensurePrefs('specialist',$sid);$in=input();$allowed=['messages','meal_logs','client_inactive','quiet_start','quiet_end'];$sets=[];$vals=[];foreach($allowed as $k)if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=$in[$k];}$vals[]='specialist';$vals[]=$sid;if($sets)$pdo->prepare('UPDATE notification_preferences SET '.implode(',',$sets).' WHERE user_type=? AND user_id=?')->execute($vals);json_response(['ok'=>true]);}
 /* ---- Здоровье клиента ----
    Каждый маршрут начинается с ownedClient: чужую карточку специалист
    не откроет, даже зная её номер. */
 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/health$#',$path,$m)){
   $cid=(int)$m[1];ownedClient($cid,$sid);json_response(healthOf($cid));}

 if($method==='POST'&&preg_match('#^/specialist/clients/(\d+)/allergies$#',$path,$m)){
   $cid=(int)$m[1];ownedClient($cid,$sid);$in=input();
   $t=trim((string)($in['title']??''));if($t==='')json_response(['error'=>'Что именно нельзя?'],422);
   $kind=in_array($in['kind']??'',['allergy','intolerance','avoid'],true)?$in['kind']:'allergy';
   $pdo->prepare('INSERT INTO client_allergies(client_id,title,kind,note,created_at) VALUES(?,?,?,?,?)')
       ->execute([$cid,$t,$kind,$in['note']??null,now()]);
   json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()],201);}

 if($method==='POST'&&preg_match('#^/specialist/clients/(\d+)/meds$#',$path,$m)){
   $cid=(int)$m[1];ownedClient($cid,$sid);$in=input();
   $t=trim((string)($in['title']??''));if($t==='')json_response(['error'=>'Укажите название'],422);
   $kind=in_array($in['kind']??'',['medicine','supplement','vitamin'],true)?$in['kind']:'supplement';
   $pdo->prepare('INSERT INTO client_meds(client_id,kind,title,dosage,schedule,started_on,ended_on,note,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
       ->execute([$cid,$kind,$t,$in['dosage']??null,$in['schedule']??null,
                  $in['started_on']??null,$in['ended_on']??null,$in['note']??null,now()]);
   json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()],201);}

 /* Курс закончился — не удаляем, а проставляем дату: история приёма
    нужна, чтобы понимать, что уже пробовали. */
 if($method==='PATCH'&&preg_match('#^/specialist/meds/(\d+)$#',$path,$m)){
   $id=(int)$m[1];$q=$pdo->prepare('SELECT client_id FROM client_meds WHERE id=?');$q->execute([$id]);
   $r=$q->fetch();if(!$r)json_response(['error'=>'Не найдено'],404);ownedClient((int)$r['client_id'],$sid);
   $in=input();$sets=[];$vals=[];
   foreach(['title','dosage','schedule','started_on','ended_on','note','kind'] as $k)
     if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=$in[$k];}
   if($sets){$vals[]=$id;$pdo->prepare('UPDATE client_meds SET '.implode(',',$sets).' WHERE id=?')->execute($vals);}
   json_response(['ok'=>true]);}

 /* Анализ приходит формой: файл и подписи одним запросом. */
 if($method==='POST'&&preg_match('#^/specialist/clients/(\d+)/labs$#',$path,$m)){
   $cid=(int)$m[1];ownedClient($cid,$sid);
   $t=trim((string)($_POST['title']??(input()['title']??'')));
   if($t==='')json_response(['error'=>'Как называется анализ?'],422);
   $url=saveLabFile();
   $pdo->prepare('INSERT INTO client_labs(client_id,title,taken_on,file_url,note,created_at) VALUES(?,?,?,?,?,?)')
       ->execute([$cid,$t,($_POST['taken_on']??null)?:null,$url,($_POST['note']??null)?:null,now()]);
   json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId(),'file_url'=>$url],201);}

 if($method==='POST'&&preg_match('#^/specialist/clients/(\d+)/recommendations$#',$path,$m)){
   $cid=(int)$m[1];ownedClient($cid,$sid);$in=input();
   $b=trim((string)($in['body']??''));if($b==='')json_response(['error'=>'Пустая рекомендация'],422);
   $pdo->prepare('INSERT INTO client_recommendations(client_id,specialist_id,body,created_at) VALUES(?,?,?,?)')
       ->execute([$cid,$sid,$b,now()]);
   json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()],201);}

 /* Удаление: сначала выясняем, чья это запись, и только потом трогаем. */
 if($method==='DELETE'&&preg_match('#^/specialist/(allergies|meds|labs|recommendations)/(\d+)$#',$path,$m)){
   $table=['allergies'=>'client_allergies','meds'=>'client_meds',
           'labs'=>'client_labs','recommendations'=>'client_recommendations'][$m[1]];
   $id=(int)$m[2];
   $q=$pdo->prepare("SELECT * FROM $table WHERE id=?");$q->execute([$id]);$row=$q->fetch();
   if(!$row)json_response(['error'=>'Не найдено'],404);
   ownedClient((int)$row['client_id'],$sid);
   $pdo->prepare("DELETE FROM $table WHERE id=?")->execute([$id]);
   if($m[1]==='labs'&&!empty($row['file_url']))dropUploads([$row['file_url']]);
   json_response(['ok'=>true]);}

 if($method==='GET'&&preg_match('#^/specialist/clients/(\d+)/shopping$#',$path,$m)){ $cid=(int)$m[1];ownedClient($cid,$sid);$mid=(int)($_GET['menu_id']??0);$mnu=ownedMenu($mid,$sid);if((int)$mnu['client_id']!==$cid)json_response(['error'=>'Меню не найдено'],404);$list=shoppingWithChecks($cid,$mid,shoppingAggregate($mid));$done=0;foreach($list as $x)$done+=(int)$x['checked'];json_response(['menu'=>$mnu,'items'=>$list,'checked_count'=>$done,'total_count'=>count($list)]);}

}
if(str_starts_with($path,'/client/progress/photos/')){$a=client();$cid=(int)$a['user_id'];$name=basename($path);$q=db()->prepare('SELECT photo_url FROM progress_photos WHERE client_id=? AND photo_url LIKE ?');$q->execute([$cid,'%/'.$name]);$row=$q->fetch();if(!$row)json_response(['error'=>'Не найдено'],404);$file=__DIR__.'/../storage/uploads/'.$name;if(!is_file($file))json_response(['error'=>'Не найдено'],404);$ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));$mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp'][$ext]??'application/octet-stream';header('Content-Type:'.$mime);header('Cache-Control:private,max-age=3600');readfile($file);exit;}
if(str_starts_with($path,'/client/')){$a=client();$cid=(int)$a['user_id'];
 /* --- Отзыв о своём специалисте ---
    Отзыв виден всем, поэтому клиенту об этом говорим прямо в приложении.
    Один клиент — один отзыв: иначе это не отзыв, а голосование. */
 if($method==='GET'&&$path==='/client/review'){
   $q=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');
   $q->execute([$cid]); $spid=(int)($q->fetchColumn()?:0);
   if(!$spid)json_response(['specialist'=>null,'review'=>null]);
   $r=$pdo->prepare('SELECT id,rating,body,status,created_at,updated_at FROM specialist_reviews WHERE specialist_id=? AND client_id=?');
   $r->execute([$spid,$cid]);
   $n=$pdo->prepare('SELECT name FROM specialists WHERE id=?');$n->execute([$spid]);
   json_response(['specialist'=>['id'=>$spid,'name'=>$n->fetchColumn()],'review'=>$r->fetch()?:null]);
 }
 if($method==='POST'&&$path==='/client/review'){
   $q=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');
   $q->execute([$cid]); $spid=(int)($q->fetchColumn()?:0);
   if(!$spid)json_response(['error'=>'Сначала подключитесь к специалисту'],422);
   $in=input();
   $rate=(int)($in['rating']??0);
   if($rate<1||$rate>5)json_response(['error'=>'Поставьте оценку от 1 до 5'],422);
   $body=mb_substr(trim((string)($in['body']??'')),0,2000);
   $pdo->prepare('INSERT INTO specialist_reviews(specialist_id,client_id,rating,body,created_at)
                  VALUES(?,?,?,?,?)
                  ON CONFLICT(specialist_id,client_id) DO UPDATE SET
                    rating=excluded.rating, body=excluded.body, updated_at=excluded.created_at')
       ->execute([$spid,$cid,$rate,$body?:null,now()]);
   refreshRating($spid);
   notifySpecialist($spid,'review','Новый отзыв',
     'Клиент оставил отзыв: '.$rate.' из 5. Он виден в каталоге.');
   json_response(['ok'=>true],201);
 }
 if($method==='DELETE'&&$path==='/client/review'){
   $q=$pdo->prepare('SELECT specialist_id FROM specialist_reviews WHERE client_id=?');
   $q->execute([$cid]); $spid=(int)($q->fetchColumn()?:0);
   $pdo->prepare('DELETE FROM specialist_reviews WHERE client_id=?')->execute([$cid]);
   if($spid)refreshRating($spid);
   json_response(['ok'=>true]);
 }

 if($method==='GET'&&$path==='/client/my-specialist'){ $q=$pdo->prepare('SELECT s.id,s.name,s.avatar_url,COALESCE(s.profession,"nutritionist") profession,CASE WHEN s.verify_status=\'verified\' THEN 1 ELSE 0 END verified FROM clients c LEFT JOIN specialists s ON s.id=c.specialist_id WHERE c.id=?');$q->execute([$cid]);$r=$q->fetch();json_response(['specialist'=>($r&&$r['id'])?$r:null]);}
 if($method==='POST'&&($path==='/client/connect'||$path==='/client/connect-code')){ $in=input();
  $q=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');$q->execute([$cid]);if((int)$q->fetchColumn())json_response(['error'=>'Вы уже подключены к специалисту'],422);
  if($path==='/client/connect-code'){ $code=strtoupper(trim((string)($in['code']??'')));if($code==='')json_response(['error'=>'Введите код специалиста'],422);$q=$pdo->prepare('SELECT id,name FROM specialists WHERE UPPER(join_code)=?');$q->execute([$code]); }
  else { $spid=(int)($in['specialist_id']??0);$q=$pdo->prepare('SELECT id,name FROM specialists WHERE id=?');$q->execute([$spid]); }
  $s=$q->fetch();if(!$s)json_response(['error'=>$path==='/client/connect-code'?'Код не найден — проверьте и попробуйте снова':'Специалист не найден'],404);
  $pdo->prepare('UPDATE clients SET specialist_id=? WHERE id=?')->execute([(int)$s['id'],$cid]);
  /* Код от специалиста — приглашение; выбор из каталога — наш лид */
  attributeClient($cid,(int)$s['id'],$path==='/client/connect-code'?'invite':'catalog');
  json_response(['ok'=>true,'specialist'=>$s]);}
 if($method==='GET'&&$path==='/client/onboarding'){ $q=$pdo->prepare('SELECT answers_json,completed_at FROM client_onboarding WHERE client_id=?');$q->execute([$cid]);$r=$q->fetch();json_response(['completed'=>(bool)$r,'answers'=>$r?(json_decode($r['answers_json'],true)??[]):[],'completed_at'=>$r['completed_at']??null]);}
 if($method==='POST'&&$path==='/client/onboarding'){ $in=input();$answers=$in['answers']??[];$pdo->prepare('INSERT INTO client_onboarding(client_id,answers_json,completed_at,updated_at) VALUES(?,?,?,?) ON CONFLICT(client_id) DO UPDATE SET answers_json=excluded.answers_json,updated_at=excluded.updated_at,completed_at=excluded.completed_at')->execute([$cid,json_encode($answers,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),now(),now()]);$sets=[];$vals=[];foreach(['sex','height_cm','weight_kg','activity_level','goal','target_kcal','target_protein','target_fat','target_carbs','notes'] as $k)if(array_key_exists($k,$answers)){$sets[]="$k=?";$vals[]=$answers[$k];}if(!empty($answers['age'])){$sets[]='birth_year=?';$vals[]=(int)date('Y')-(int)$answers['age'];}if(array_key_exists('dislikes',$answers)){$sets[]='excluded_ingredients=?';$vals[]=json_encode($answers['dislikes'],JSON_UNESCAPED_UNICODE);}if($sets){$vals[]=$cid;$pdo->prepare('UPDATE clients SET '.implode(',',$sets).' WHERE id=?')->execute($vals);}json_response(['ok'=>true]);}

 if($method==='GET'&&$path==='/client/today'){
   /* Дневник продуктов есть и без меню: человек без специалиста
      раньше упирался в «Меню готовится» и уходил. Поэтому съеденное,
      вода и вес считаются до проверки меню, а не после неё. */
   $today=date('Y-m-d');
   $food=foodEntries($cid,$today);
   $foodT=foodTotals($food);
   $q=$pdo->prepare('SELECT * FROM menus WHERE client_id=? AND status="published" ORDER BY id DESC LIMIT 1');$q->execute([$cid]);$m=$q->fetch();
   if(!$m){
     $qw=$pdo->prepare('SELECT weight_kg,measured_on FROM weight_logs WHERE client_id=? ORDER BY measured_on');$qw->execute([$cid]);$wl=$qw->fetchAll();
     $weight=null;
     if($wl){$lastW=(float)end($wl)['weight_kg'];$firstW=(float)$wl[0]['weight_kg'];
       $weight=['last'=>$lastW,'delta'=>round($lastW-$firstW,1),'measured_on'=>end($wl)['measured_on']];}
     $qwa=$pdo->prepare('SELECT ml FROM water_logs WHERE client_id=? AND logged_on=?');$qwa->execute([$cid,$today]);
     json_response(['menu'=>null,'items'=>[],'food'=>$food,'food_totals'=>$foodT,
       'totals'=>sumTotals(['kcal'=>0,'protein'=>0,'fat'=>0,'carbs'=>0],$foodT),
       'weight'=>$weight,'water'=>['ml'=>(int)($qwa->fetchColumn()?:0),'goal_ml'=>waterGoal($cid)]]);
   }
$items=menuItems((int)$m['id']);$qlog=$pdo->prepare('SELECT menu_item_id,status FROM meal_logs WHERE client_id=?');$qlog->execute([$cid]);$logs=[];foreach($qlog->fetchAll() as $lr)$logs[(int)$lr['menu_item_id']]=$lr['status'];foreach($items as &$ix)$ix['log_status']=$logs[(int)$ix['id']]??null;$day=max(1,min((int)$m['days_count'],(int)ceil((strtotime(date('Y-m-d'))-strtotime($m['start_date']))/86400)+1));$qw=$pdo->prepare('SELECT weight_kg,measured_on FROM weight_logs WHERE client_id=? ORDER BY measured_on');$qw->execute([$cid]);$wl=$qw->fetchAll();$weight=null;if($wl){$lastW=(float)end($wl)['weight_kg'];$firstW=(float)$wl[0]['weight_kg'];$weight=['last'=>$lastW,'delta'=>round($lastW-$firstW,1),'measured_on'=>end($wl)['measured_on']];}$qwa=$pdo->prepare('SELECT ml FROM water_logs WHERE client_id=? AND logged_on=?');$qwa->execute([$cid,date('Y-m-d')]);/* Итог дня — съеденное по меню плюс съеденное мимо него. Иначе
   обед из свёклы и йогурта в кольцах КБЖУ не виден вовсе. */
json_response(['menu'=>$m,'day'=>$day,'items'=>array_values(array_filter($items,fn($x)=>(int)$x['day_number']===$day)),'totals'=>sumTotals(totals($items,$day,true),$foodT),'menu_totals'=>totals($items,$day,true),'food'=>$food,'food_totals'=>$foodT,'plan_totals'=>totals($items,$day),'weight'=>$weight,'water'=>['ml'=>(int)($qwa->fetchColumn()?:0),'goal_ml'=>waterGoal($cid)]]);}
 if($method==='GET'&&$path==='/client/week'){ $q=$pdo->prepare('SELECT * FROM menus WHERE client_id=? AND status="published" ORDER BY id DESC LIMIT 1');$q->execute([$cid]);$m=$q->fetch();if(!$m)json_response(['menu'=>null,'items'=>[]]);$items=menuItems((int)$m['id']);json_response(menuPayload($m,$items));}
 /* Список покупок. Кладовка идёт отдельным массивом, а не подмешивается
    к покупкам: соль и масло попадают в список каждую неделю и каждую
    неделю в нём не нужны, но убирать их совсем нельзя — иногда они
    как раз заканчиваются. */
 if($method==='GET'&&$path==='/client/shopping'){
   $m=shoppingMenu($cid);
   if(!$m)json_response(['menu'=>null,'items'=>[],'pantry'=>[]]);
   $days=isset($_GET['days'])?max(1,(int)$_GET['days']):(int)$m['days_count'];
   $all=shoppingWithChecks($cid,(int)$m['id'],shoppingAggregate((int)$m['id'],$days));

   $q=$pdo->prepare('SELECT name_key FROM client_pantry WHERE client_id=?');
   $q->execute([$cid]);
   $home=array_flip(array_column($q->fetchAll(),'name_key'));

   $items=[];$pantry=[];
   foreach($all as $x){
     $x['at_home']=isset($home[$x['key']])?1:0;
     if($x['at_home'])$pantry[]=$x; else $items[]=$x;
   }
   json_response(['menu'=>$m,'days'=>$days,'items'=>$items,'pantry'=>$pantry]);
 }
 if($method==='POST'&&$path==='/client/shopping/pantry'){
   $in=input();$key=mb_strtolower(trim((string)($in['name']??'')));
   if($key==='')json_response(['error'=>'Не указан продукт'],422);
   if(!empty($in['remove'])){
     $pdo->prepare('DELETE FROM client_pantry WHERE client_id=? AND name_key=?')->execute([$cid,$key]);
     json_response(['ok'=>true,'at_home'=>false]);
   }
   $pdo->prepare('INSERT INTO client_pantry(client_id,name_key,created_at) VALUES(?,?,?)
                  ON CONFLICT(client_id,name_key) DO NOTHING')->execute([$cid,$key,now()]);
   json_response(['ok'=>true,'at_home'=>true]);
 }
 if($method==='POST'&&$path==='/client/shopping/check'){ $in=input();$key=mb_strtolower(trim((string)($in['name']??'')));$m=shoppingMenu($cid);if(!$m)json_response(['error'=>'Меню не найдено'],404);$mid=(int)$m['id'];$row=null;foreach(shoppingAggregate($mid) as $x)if($x['key']===$key){$row=$x;break;}if(!$row)json_response(['error'=>'Такого продукта нет в списке'],422);$checked=!empty($in['checked'])?1:0;$pdo->prepare('INSERT INTO shopping_items(client_id,menu_id,ingredient_name,grams,category,checked) VALUES(?,?,?,?,?,?) ON CONFLICT(client_id,menu_id,ingredient_name) DO UPDATE SET checked=excluded.checked,grams=excluded.grams,category=excluded.category')->execute([$cid,$mid,$key,$row['grams'],$row['category'],$checked]);json_response(['ok'=>true,'checked'=>$checked]);}
 if($method==='POST'&&$path==='/client/shopping/clear'){ $m=shoppingMenu($cid);if($m)$pdo->prepare('DELETE FROM shopping_items WHERE client_id=? AND menu_id=?')->execute([$cid,(int)$m['id']]);json_response(['ok'=>true]);}
 if($method==='GET'&&preg_match('#^/client/menu-items/(\d+)$#',$path,$m)){ $q=$pdo->prepare('SELECT mi.*,d.name dish_name,d.instructions,d.photo_url,d.base_portion_g,(SELECT status FROM meal_logs ml WHERE ml.menu_item_id=mi.id AND ml.client_id=?) log_status FROM menu_items mi JOIN menus mn ON mn.id=mi.menu_id JOIN dishes d ON d.id=mi.dish_id WHERE mi.id=? AND mn.client_id=?');$q->execute([$cid,(int)$m[1],$cid]);$x=$q->fetch();if(!$x)json_response(['error'=>'Не найдено'],404);$x['nutrition']=nutrition((int)$x['dish_id'],(float)$x['portion_g'],$x['overrides']);$q=$pdo->prepare('SELECT i.name ingredient_name,di.grams,i.kcal,i.protein,i.fat,i.carbs FROM dish_ingredients di JOIN ingredients i ON i.id=di.ingredient_id WHERE di.dish_id=? ORDER BY di.sort_order');$q->execute([$x['dish_id']]);$x['ingredients']=$q->fetchAll();json_response(['item'=>$x]);}
 // meal-log обрабатывается ниже единым обработчиком (с причиной пропуска и уведомлением специалисту)
 /* ---------- Питьевой режим ----------
    Норма по умолчанию считается от веса: 30 мл на килограмм — общая
    рекомендация, от которой отталкиваются и врачи, и калькуляторы.
    Как только клиент задаст свою, считаться перестаёт: назначенное
    важнее вычисленного. Округляем до сотен, чтобы не показывать
    «2022 мл», и держим в разумных границах на случай крайнего веса. */
 if($method==='GET'&&$path==='/client/water'){
   $q=$pdo->prepare('SELECT ml FROM water_logs WHERE client_id=? AND logged_on=?');
   $q->execute([$cid,date('Y-m-d')]);
   $today=(int)($q->fetchColumn()?:0);
   $q=$pdo->prepare('SELECT logged_on,ml FROM water_logs WHERE client_id=? ORDER BY logged_on DESC LIMIT 14');
   $q->execute([$cid]);
   json_response(['goal_ml'=>waterGoal($cid),'today_ml'=>$today,'history'=>array_reverse($q->fetchAll())]);
 }
 if($method==='POST'&&$path==='/client/water'){
   $in=input();$delta=(int)($in['ml']??0);
   if($delta===0)json_response(['error'=>'Укажите объём'],422);
   $day=date('Y-m-d');
   $q=$pdo->prepare('SELECT ml FROM water_logs WHERE client_id=? AND logged_on=?');
   $q->execute([$cid,$day]);
   $was=(int)($q->fetchColumn()?:0);
   /* Отрицательное значение отменяет последний глоток, ниже нуля не уходим */
   $now=max(0,$was+$delta);
   $pdo->prepare('INSERT INTO water_logs(client_id,logged_on,ml,updated_at) VALUES(?,?,?,?) ON CONFLICT(client_id,logged_on) DO UPDATE SET ml=excluded.ml,updated_at=excluded.updated_at')
       ->execute([$cid,$day,$now,now()]);
   json_response(['ok'=>true,'today_ml'=>$now,'goal_ml'=>waterGoal($cid)]);
 }
 if($method==='PATCH'&&$path==='/client/water/goal'){
   $in=input();$g=(int)($in['goal_ml']??0);
   if($g<500||$g>6000)json_response(['error'=>'Норма должна быть от 500 до 6000 мл'],422);
   $pdo->prepare('UPDATE clients SET water_goal_ml=? WHERE id=?')->execute([$g,$cid]);
   json_response(['ok'=>true,'goal_ml'=>$g]);
 }
 /* ==========================================================================
    ДНЕВНИК ПРОДУКТОВ У КЛИЕНТА

    Бывает, что человек ел не блюдо, а набор продуктов — свёклу и
    греческий йогурт. Раньше отметить это было негде: журнал питания
    привязан к блюду меню, и съеденное мимо меню просто не попадало
    в итог дня. Специалист видел «съедено 30%» и не понимал, почему
    вес стоит.
    ========================================================================== */

 /* Поиск по справочнику. Сначала то, что начинается с запроса, потом
    то, где он внутри: человек набирает «йог» и ждёт «йогурт», а не
    «питьевой йогурт» первым. */
 if($method==='GET'&&$path==='/client/foods'){
   $q=trim((string)($_GET['q']??''));
   $limit=max(1,min(60,(int)($_GET['limit']??40)));
   if($q===''){
     /* Пустой запрос — не пустой экран: сверху то, что этот человек уже
        ел, а ниже остальной справочник. Раньше список состоял только из
        съеденного, и после первого же добавления он схлопывался до
        одной строки: человек добавлял индейку и больше ничего не видел. */
     $st=$pdo->prepare('SELECT i.* FROM ingredients i
                         JOIN (SELECT ingredient_id, MAX(fi.id) last_id, COUNT(*) n
                                 FROM food_entry_items fi
                                 JOIN food_entries fe ON fe.id=fi.entry_id
                                WHERE fe.client_id=? AND fi.ingredient_id IS NOT NULL
                                GROUP BY ingredient_id) u ON u.ingredient_id=i.id
                        ORDER BY u.n DESC, u.last_id DESC LIMIT ?');
     $st->execute([$cid,min(12,$limit)]);
     $rows=$st->fetchAll();
     $seen=array_column($rows,'id');
     $need=$limit-count($rows);
     if($need>0){
       $skip=$seen?(' AND id NOT IN ('.implode(',',array_map('intval',$seen)).')'):'';
       $st=$pdo->prepare('SELECT * FROM ingredients WHERE is_public=1'.$skip.' ORDER BY category,name LIMIT ?');
       $st->execute([$need]);
       $rows=array_merge($rows,$st->fetchAll());
     }
     json_response(['foods'=>array_map('foodPublic',$rows)]);
   }
   /* Ищем по свёрнутому имени: SQLite сравнивает LIKE без учёта
      регистра только для латиницы, и «свёкл» не находил «Свёкла».
      Своё, заведённое этим человеком, показываем вместе с общим. */
   $f=foodFold($q); $like=$f.'%'; $any='%'.$f.'%';
   $st=$pdo->prepare('SELECT *, CASE WHEN name_fold LIKE ? THEN 0 ELSE 1 END rank
                        FROM ingredients
                       WHERE (is_public=1 OR client_id=?) AND name_fold LIKE ?
                       ORDER BY rank, length(name), name LIMIT ?');
   $st->execute([$like,$cid,$any,$limit]);
   json_response(['foods'=>array_map('foodPublic',$st->fetchAll())]);
 }

 /* Штрихкод: сперва свой справочник, потом Open Food Facts. Найденное
    у них сохраняем себе — второй человек с той же пачкой уже не ждёт
    ответа чужого сервиса. */
 if($method==='GET'&&preg_match('#^/client/foods/barcode/([0-9]{6,20})$#',$path,$m)){
   $code=$m[1];
   $st=$pdo->prepare('SELECT * FROM ingredients WHERE barcode=?');
   $st->execute([$code]); $row=$st->fetch();
   if($row)json_response(['food'=>foodPublic($row),'source'=>'own']);
   $r=offByBarcode($code);
   if(!$r)json_response(['error'=>'Такого штрихкода не нашлось. Добавьте продукт вручную.'],404);
   $id=offStore($r);
   $st->execute([$code]); $row=$st->fetch();
   json_response(['food'=>foodPublic($row?:['id'=>$id]+$r),'source'=>'off']);
 }

 /* Своего продукта нет в справочнике — заводим. Он остаётся личным:
    в общий справочник попадает только то, что завёл владелец. */
 if($method==='POST'&&$path==='/client/foods'){
   $in=input();
   $name=mb_substr(trim((string)($in['name']??'')),0,120);
   if($name==='')json_response(['error'=>'Как называется продукт?'],422);
   $num=fn($k)=>max(0.0,min(1000.0,(float)($in[$k]??0)));
   $kcal=$num('kcal');$p1=$num('protein');$f1=$num('fat');$c1=$num('carbs');
   if($p1+$f1+$c1>101)json_response(['error'=>'Белки, жиры и углеводы вместе больше 100 г на 100 г продукта'],422);
   if(!foodKcalPlausible($kcal,$p1,$f1,$c1))
     json_response(['error'=>'Калории не сходятся с БЖУ. Проверьте значения на упаковке — они указаны на 100 г.'],422);
   $pdo->prepare('INSERT INTO ingredients(name,name_fold,category,kcal,protein,fat,carbs,fiber,unit,is_public,client_id,source,created_at)
                  VALUES(?,?,?,?,?,?,?,0,"g",0,?,"client",?)')
       ->execute([$name,foodFold($name),'Свои продукты',$kcal,$p1,$f1,$c1,$cid,now()]);
   $id=(int)$pdo->lastInsertId();
   $st=$pdo->prepare('SELECT * FROM ingredients WHERE id=?');$st->execute([$id]);
   json_response(['food'=>foodPublic($st->fetch())],201);
 }

 if($method==='GET'&&$path==='/client/food-log'){
   $date=preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($_GET['date']??''))?$_GET['date']:date('Y-m-d');
   $e=foodEntries($cid,$date);
   json_response(['date'=>$date,'entries'=>$e,'totals'=>foodTotals($e)]);
 }

 if($method==='POST'&&$path==='/client/food-log'){
   $in=input();
   $date=preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($in['eaten_on']??''))?$in['eaten_on']:date('Y-m-d');
   /* Задним числом — можно, вперёд — нет: дневник про съеденное. */
   if($date>date('Y-m-d'))json_response(['error'=>'Нельзя отметить съеденное в будущем'],422);
   /* «snack» приходил от старых версий приложения — кладём во второй
      перекус, а не роняем запись из-за незнакомого слова. */
   $meal=($in['meal']??'')==='snack'?'snack2':$in['meal']??'';
   if(!in_array($meal,FOOD_MEALS,true))$meal='snack2';
   $items=is_array($in['items']??null)?$in['items']:[];
   if(!$items)json_response(['error'=>'Добавьте хотя бы один продукт'],422);
   if(count($items)>50)json_response(['error'=>'Слишком много продуктов в одной записи'],422);
   $sel=$pdo->prepare('SELECT * FROM ingredients WHERE id=? AND (is_public=1 OR client_id=?)');
   $rows=[];
   foreach($items as $it){
     $g=(float)($it['grams']??0);
     if($g<=0||$g>5000)json_response(['error'=>'Вес продукта — от 1 до 5000 г'],422);
     $sel->execute([(int)($it['ingredient_id']??0),$cid]);
     $ing=$sel->fetch();
     if(!$ing)json_response(['error'=>'Продукт не найден в справочнике'],422);
     $rows[]=foodItemFrom($ing,$g);
   }
   $pdo->beginTransaction();
   $pdo->prepare('INSERT INTO food_entries(client_id,eaten_on,meal,note,created_at,updated_at) VALUES(?,?,?,?,?,?)')
       ->execute([$cid,$date,$meal,mb_substr(trim((string)($in['note']??'')),0,300)?:null,now(),now()]);
   $eid=(int)$pdo->lastInsertId();
   $ins=$pdo->prepare('INSERT INTO food_entry_items(entry_id,ingredient_id,name,grams,kcal,protein,fat,carbs,fiber,sort_order)
                       VALUES(?,?,?,?,?,?,?,?,?,?)');
   foreach($rows as $i=>$r)$ins->execute([$eid,$r['ingredient_id'],$r['name'],$r['grams'],
     $r['kcal'],$r['protein'],$r['fat'],$r['carbs'],$r['fiber'],$i]);
   $pdo->commit();
   $e=foodEntries($cid,$date);
   $one=null;foreach($e as $x)if($x['id']===$eid)$one=$x;
   json_response(['entry'=>$one,'totals'=>foodTotals($e)],201);
 }

 if($method==='DELETE'&&preg_match('#^/client/food-log/(\d+)$#',$path,$m)){
   $st=$pdo->prepare('SELECT eaten_on FROM food_entries WHERE id=? AND client_id=?');
   $st->execute([(int)$m[1],$cid]); $date=$st->fetchColumn();
   if(!$date)json_response(['error'=>'Запись не найдена'],404);
   $pdo->prepare('DELETE FROM food_entry_items WHERE entry_id=?')->execute([(int)$m[1]]);
   $pdo->prepare('DELETE FROM food_entries WHERE id=? AND client_id=?')->execute([(int)$m[1],$cid]);
   $e=foodEntries($cid,(string)$date);
   json_response(['ok'=>true,'totals'=>foodTotals($e)]);
 }

 if($method==='GET'&&$path==='/client/progress'){ $q=$pdo->prepare('SELECT * FROM weight_logs WHERE client_id=? ORDER BY measured_on');$q->execute([$cid]);$w=$q->fetchAll();$q=$pdo->prepare('SELECT COUNT(*) FROM meal_logs WHERE client_id=? AND status="eaten"');$q->execute([$cid]);$eaten=(int)$q->fetchColumn();$q=$pdo->prepare('SELECT * FROM progress_measurements WHERE client_id=? ORDER BY measured_on');$q->execute([$cid]);$measurements=$q->fetchAll();$q=$pdo->prepare('SELECT * FROM progress_photos WHERE client_id=? ORDER BY measured_on DESC,id DESC');$q->execute([$cid]);$photos=$q->fetchAll();foreach($photos as &$pp)$pp['photo_url']=photoData($pp['photo_url']);json_response(['weights'=>$w,'eaten_count'=>$eaten,'measurements'=>$measurements,'photos'=>$photos]);}
 if($method==='POST'&&$path==='/client/weight'){ $in=input();$pdo->prepare('INSERT INTO weight_logs(client_id,weight_kg,measured_on) VALUES(?,?,?) ON CONFLICT(client_id,measured_on) DO UPDATE SET weight_kg=excluded.weight_kg')->execute([$cid,(float)$in['weight_kg'],$in['measured_on']??date('Y-m-d')]);json_response(['ok'=>true]);}
 if($method==='POST'&&$path==='/client/avatar'){ $url=saveAvatar();$pdo->prepare('UPDATE clients SET avatar_url=? WHERE id=?')->execute([$url,$cid]);json_response(['avatar_url'=>$url]);}
 /* Удаление аккаунта — из самого приложения и по-настоящему: записи
    уходят каскадом, файлы с диска, сессии закрываются. Восстановлению
    не подлежит, поэтому подтверждение спрашивает интерфейс. */
 if($method==='DELETE'&&$path==='/client/account'){ deleteClientAccount($cid);json_response(['ok'=>true]); }
 if($method==='DELETE'&&$path==='/client/avatar'){ $pdo->prepare('UPDATE clients SET avatar_url=NULL WHERE id=?')->execute([$cid]);json_response(['ok'=>true]);}
 /* Задание с фотоотчётом без снимка не закрывается: в этом и был
    смысл — специалист хочет увидеть результат, а не галочку. */
 if($method==='POST'&&preg_match('#^/client/tasks/(\d+)/done$#',$path,$m)){
   $tid=(int)$m[1];
   $q=$pdo->prepare("SELECT * FROM client_tasks WHERE id=? AND client_id=? AND status='open'");
   $q->execute([$tid,$cid]); $t=$q->fetch();
   if(!$t)json_response(['error'=>'Задание не найдено'],404);

   $photo=null;
   if(!empty($_FILES['photo'])&&$_FILES['photo']['error']===UPLOAD_ERR_OK) $photo=saveAvatar();
   if($t['kind']==='photo'&&!$photo)json_response(['error'=>'Приложите фото — задание с отчётом'],422);

   $comment=mb_substr(trim((string)($_POST['comment']??(input()['comment']??''))),0,1000);
   $pdo->prepare("UPDATE client_tasks SET status='done',photo_url=?,comment=?,done_at=? WHERE id=?")
       ->execute([$photo,$comment?:null,now(),$tid]);
   if($t['specialist_id'])
     notifySpecialist((int)$t['specialist_id'],'task','Задание выполнено',(string)$t['title']);
   json_response(['ok'=>true,'points'=>(int)$t['points']]);
 }

 if($method==='GET'&&$path==='/client/gamification'){ json_response(gamification($cid));}
 /* Обмен баллов на привилегию своего специалиста. Код нужен, чтобы
    специалист мог сверить: клиент называет его при встрече. */
 if($method==='POST'&&$path==='/client/redeem'){
   $in=input();
   $rid=(int)($in['reward_id']??0);
   $q=$pdo->prepare('SELECT r.* FROM specialist_rewards r JOIN clients c ON c.specialist_id=r.specialist_id
                     WHERE r.id=? AND c.id=? AND r.is_active=1');
   $q->execute([$rid,$cid]); $r=$q->fetch();
   if(!$r)json_response(['error'=>'Привилегия не найдена'],404);
   $g=gamification($cid);
   if($g['balance']<(int)$r['cost'])json_response(['error'=>'Недостаточно баллов'],422);
   $code='EQ-'.strtoupper(bin2hex(random_bytes(3)));
   $pdo->prepare('INSERT INTO point_redemptions(client_id,reward_key,reward_id,title,points_cost,discount_pct,code,status,created_at)
                  VALUES(?,?,?,?,?,?,?,?,?)')
       ->execute([$cid,'r'.$r['id'],(int)$r['id'],$r['title'],(int)$r['cost'],0,$code,'active',now()]);
   $sq=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');$sq->execute([$cid]);
   if($spid=(int)($sq->fetchColumn()?:0))
     notifySpecialist($spid,'reward','Обмен баллов',$r['title'].' · код '.$code);
   json_response(['ok'=>true,'code'=>$code,'title'=>$r['title']],201);
 }
 if($method==='GET'&&$path==='/client/messages'){
   $after=(int)($_GET['after_id']??0);
   $q=$pdo->prepare('SELECT * FROM messages WHERE client_id=?'.($after?' AND id>?':'').' ORDER BY id');
   $q->execute($after?[$cid,$after]:[$cid]);
   $rows=$q->fetchAll();
   $pdo->prepare('UPDATE messages SET read_at=? WHERE client_id=? AND author_type="specialist" AND read_at IS NULL')->execute([now(),$cid]);
   /* Шапка переписки показывает, с кем говоришь и был ли он на связи —
      как в любом мессенджере. Без этого там стояло слово «Специалист». */
   $peer=null;
   $sq2=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');$sq2->execute([$cid]);
   $sid=(int)($sq2->fetchColumn()?:0);
   if($sid){
     $ps=$pdo->prepare('SELECT name,avatar_url,last_seen_at FROM specialists WHERE id=?');
     $ps->execute([$sid]);$peer=$ps->fetch()?:null;
   }
   json_response(['messages'=>$rows,'peer'=>$peer]);}
 if($method==='POST'&&$path==='/client/messages'){ $in=input();$body=trim((string)($in['body']??''));$att=trim((string)($in['attachment_url']??''));if(!$body&&!$att)json_response(['error'=>'Сообщение пустое'],422);$pdo->prepare('INSERT INTO messages(client_id,author_type,body,attachment_url,created_at) VALUES(?,?,?,?,?)')->execute([$cid,'client',$body,$att?:null,now()]);
   $mid=(int)$pdo->lastInsertId();
   $q=$pdo->prepare('SELECT specialist_id,name FROM clients WHERE id=?');$q->execute([$cid]);$c=$q->fetch()?:[];
   if(!empty($c['specialist_id']))
     pushSend('specialist',(int)$c['specialist_id'],(string)($c['name']??'Клиент'),
              mb_substr($body!==''?$body:'Вложение',0,120),'/app/','message');
   $q=$pdo->prepare('SELECT * FROM messages WHERE id=?');$q->execute([$mid]);
   json_response(['ok'=>true,'message'=>$q->fetch()],201);}
 if($method==='POST'&&$path==='/client/upload'){ json_response(['url'=>saveAvatar()]);}
 if($method==='POST'&&$path==='/client/attachment'){ json_response(['url'=>saveAttachment()]);}
 if($method==='GET'&&$path==='/client/notifications'){ $q=$pdo->prepare('SELECT * FROM notifications WHERE client_id=? ORDER BY created_at DESC');$q->execute([$cid]);json_response(['notifications'=>$q->fetchAll()]);}
 if($method==='GET'&&$path==='/client/preferences'){ensurePrefs('client',$cid);$q=$pdo->prepare('SELECT cp.*,np.breakfast,np.lunch,np.dinner,np.weight,np.messages,np.menu_updates,np.quiet_start,np.quiet_end FROM client_preferences cp LEFT JOIN notification_preferences np ON np.user_type="client" AND np.user_id=cp.client_id WHERE cp.client_id=?');$q->execute([$cid]);$r=$q->fetch();if(!$r){$r=['client_id'=>$cid,'likes'=>'[]','dislikes'=>'[]','excluded'=>'[]','allowed_replacements'=>1];}json_response(['preferences'=>$r]);}
 if($method==='PATCH'&&$path==='/client/preferences'){ $in=input();$pdo->prepare('INSERT INTO client_preferences(client_id,likes,dislikes,excluded,allowed_replacements,notes,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(client_id) DO UPDATE SET likes=excluded.likes,dislikes=excluded.dislikes,excluded=excluded.excluded,allowed_replacements=excluded.allowed_replacements,notes=excluded.notes,updated_at=excluded.updated_at')->execute([$cid,json_encode($in['likes']??[]),json_encode($in['dislikes']??[]),json_encode($in['excluded']??[]),(int)($in['allowed_replacements']??1),$in['notes']??null,now()]);json_response(['ok'=>true]);}
  /* Замены клиенту. Список специалиста — главный, но он его почти
     никогда не заполняет, и кнопка «Заменить» упиралась в пустоту.
     Если списка нет — подбираем сами: тот же приём пищи, близкие КБЖУ,
     без запретов клиента. Порции и расхождения считаем в обоих случаях,
     чтобы клиент видел, на что меняет. */
  if($method==='GET'&&preg_match('#^/client/menu-items/(\d+)/replacements$#',$path,$m)){
    $iid=(int)$m[1];
    $q=$pdo->prepare('SELECT mir.dish_id FROM menu_item_replacements mir JOIN menu_items mi ON mi.id=mir.menu_item_id JOIN menus mn ON mn.id=mi.menu_id WHERE mir.menu_item_id=? AND mn.client_id=? ORDER BY mir.sort_order');
    $q->execute([$iid,$cid]);
    $ids=array_map('intval',array_column($q->fetchAll(),'dish_id'));
    $dishes=$ids?autoReplacements($iid,$cid,count($ids),$ids):autoReplacements($iid,$cid,6);
    json_response(['dishes'=>$dishes,'source'=>$ids?'specialist':'auto']);
  }
  /* Сама замена. Разрешена, только если специалист не снял галочку, и
     только на блюдо из того же списка, который клиенту показали, —
     иначе через этот маршрут можно поставить в меню что угодно.
     Порцию берём ту, что посчитал подбор: она выравнивает калории. */
  if($method==='POST'&&preg_match('#^/client/menu-items/(\d+)/replace$#',$path,$m)){
    $iid=(int)$m[1];$in=input();$did=(int)($in['dish_id']??0);
    $q=$pdo->prepare('SELECT mi.id,mi.portion_g FROM menu_items mi JOIN menus mn ON mn.id=mi.menu_id WHERE mi.id=? AND mn.client_id=?');
    $q->execute([$iid,$cid]);
    $item=$q->fetch(); if(!$item)json_response(['error'=>'Не найдено'],404);
    $q=$pdo->prepare('SELECT allowed_replacements FROM client_preferences WHERE client_id=?');
    $q->execute([$cid]);$pref=$q->fetch();
    if($pref&&!(int)$pref['allowed_replacements'])json_response(['error'=>'Специалист не разрешил самостоятельные замены'],403);
    $q=$pdo->prepare('SELECT mir.dish_id FROM menu_item_replacements mir WHERE mir.menu_item_id=? ORDER BY mir.sort_order');
    $q->execute([$iid]);
    $ids=array_map('intval',array_column($q->fetchAll(),'dish_id'));
    $list=$ids?autoReplacements($iid,$cid,count($ids),$ids):autoReplacements($iid,$cid,6);
    $pick=null; foreach($list as $r) if((int)$r['id']===$did){$pick=$r;break;}
    if(!$pick)json_response(['error'=>'Эта замена недоступна'],403);
    $pdo->prepare('UPDATE menu_items SET dish_id=?,portion_g=? WHERE id=?')->execute([$did,$pick['portion_g'],$iid]);
    createNotification($cid,'replacement','Блюдо заменено','В плане теперь «'.$pick['name'].'», '.$pick['portion_g'].' г.');
    json_response(['ok'=>true,'dish'=>$pick]);
  }
 if($method==='PATCH'&&$path==='/client/push/preferences'){ensurePrefs('client',$cid);$in=input();$allowed=['breakfast','lunch','dinner','weight','messages','menu_updates','quiet_start','quiet_end'];$sets=[];$vals=[];foreach($allowed as $k)if(array_key_exists($k,$in)){$sets[]="$k=?";$vals[]=$in[$k];}$vals[]='client';$vals[]=$cid;if($sets)$pdo->prepare('UPDATE notification_preferences SET '.implode(',',$sets).' WHERE user_type=? AND user_id=?')->execute($vals);json_response(['ok'=>true]);}
 /* Своё здоровье клиент видит целиком, но не правит: записи ведёт
    специалист, иначе история рекомендаций перестанет быть историей. */
 if($method==='GET'&&$path==='/client/health'){ json_response(healthOf($cid)); }

 if($method==='GET'&&$path==='/client/push/preferences'){ensurePrefs('client',$cid);$q=$pdo->prepare('SELECT * FROM notification_preferences WHERE user_type="client" AND user_id=?');$q->execute([$cid]);json_response(['preferences'=>$q->fetch()]);}
 if($method==='POST'&&$path==='/client/measurements'){ $in=input();$pdo->prepare('INSERT INTO progress_measurements(client_id,measured_on,waist_cm,hips_cm,chest_cm,note) VALUES(?,?,?,?,?,?) ON CONFLICT(client_id,measured_on) DO UPDATE SET waist_cm=excluded.waist_cm,hips_cm=excluded.hips_cm,chest_cm=excluded.chest_cm,note=excluded.note')->execute([$cid,$in['measured_on']??date('Y-m-d'),$in['waist_cm']??null,$in['hips_cm']??null,$in['chest_cm']??null,$in['note']??null]);json_response(['ok'=>true]);}
 if($method==='POST'&&$path==='/client/progress/photo'){if(empty($_FILES['photo'])||$_FILES['photo']['error']!==UPLOAD_ERR_OK)json_response(['error'=>'Фото не загружено'],422);$f=$_FILES['photo'];if($f['size']>8*1024*1024)json_response(['error'=>'Фото больше 8 МБ'],422);$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);$allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];if(!isset($allowed[$mime]))json_response(['error'=>'Разрешены JPG, PNG, WEBP'],422);$dir=__DIR__.'/../storage/uploads';if(!is_dir($dir))mkdir($dir,0775,true);$name=bin2hex(random_bytes(12)).'.'.$allowed[$mime];move_uploaded_file($f['tmp_name'],$dir.'/'.$name);$url='/api/v1/client/progress/photos/'.$name;$pdo->prepare('INSERT INTO progress_photos(client_id,photo_url,measured_on,created_at) VALUES(?,?,?,?)')->execute([$cid,$url,$_POST['measured_on']??date('Y-m-d'),now()]);json_response(['photo_url'=>$url],201);}
 if($method==='POST'&&preg_match('#^/client/meals/(\d+)/log$#',$path,$m)){ $iid=(int)$m[1];$in=input();$status=$in['status']??'eaten';$q=$pdo->prepare('SELECT mi.id,mn.specialist_id,mn.client_id FROM menu_items mi JOIN menus mn ON mn.id=mi.menu_id WHERE mi.id=? AND mn.client_id=?');$q->execute([$iid,$cid]);$row=$q->fetch();if(!$row)json_response(['error'=>'Не найдено'],404);$pdo->prepare('INSERT INTO meal_logs(menu_item_id,client_id,status,comment,logged_at) VALUES(?,?,?,?,?) ON CONFLICT(menu_item_id) DO UPDATE SET status=excluded.status,comment=excluded.comment,logged_at=excluded.logged_at')->execute([$iid,$cid,$status,$in['comment']??null,now()]);if($status==='skipped')$pdo->prepare('INSERT INTO meal_log_feedback(menu_item_id,client_id,reason,created_at) VALUES(?,?,?,?) ON CONFLICT(menu_item_id) DO UPDATE SET reason=excluded.reason,created_at=excluded.created_at')->execute([$iid,$cid,$in['reason']??null,now()]);$prefs=$pdo->prepare('SELECT meal_logs FROM notification_preferences WHERE user_type="specialist" AND user_id=?');$prefs->execute([$row['specialist_id']]);if((int)$prefs->fetchColumn())createNotification($cid,'meal_log',$status==='eaten'?'Клиент отметил блюдо':'Клиент пропустил блюдо',$status==='eaten'?'Клиент отметил блюдо как съеденное.':'Клиент пропустил блюдо.');json_response(['ok'=>true]);}

}

if(str_starts_with($path,'/specialist/clients/') && preg_match('#^/specialist/clients/(\d+)/notes$#',$path,$m)){
  $a=specialist();$sid=(int)$a['user_id'];$cid=(int)$m[1];ownedClient($cid,$sid);
  if($method==='GET'){ $q=$pdo->prepare('SELECT * FROM specialist_notes WHERE client_id=? AND specialist_id=? ORDER BY created_at DESC');$q->execute([$cid,$sid]);json_response(['notes'=>$q->fetchAll()]); }
  if($method==='POST'){ $in=input();$body=trim((string)($in['body']??''));if(!$body)json_response(['error'=>'Заметка пустая'],422);$pdo->prepare('INSERT INTO specialist_notes(specialist_id,client_id,body,created_at) VALUES(?,?,?,?)')->execute([$sid,$cid,$body,now()]);json_response(['ok'=>true],201); }
}

if($method==='GET'&&$path==='/specialist/programs'){
  $a=specialist();$sid=(int)$a['user_id'];$cid=(int)($_GET['client_id']??0);if($cid)ownedClient($cid,$sid);$q=$pdo->prepare('SELECT * FROM nutrition_programs WHERE specialist_id=? '.($cid?'AND client_id=? ':'').'ORDER BY start_date DESC,id DESC');$q->execute($cid?[$sid,$cid]:[$sid]);json_response(['programs'=>$q->fetchAll()]);
}
if($method==='POST'&&$path==='/specialist/programs'){
  $a=specialist();$sid=(int)$a['user_id'];$in=input();$cid=(int)($in['client_id']??0);ownedClient($cid,$sid);$title=trim((string)($in['title']??'Программа питания'));if(!$title)json_response(['error'=>'Название обязательно'],422);$pdo->prepare('INSERT INTO nutrition_programs(specialist_id,client_id,title,goal,start_date,weeks_count,status,created_at) VALUES(?,?,?,?,?,?,?,?)')->execute([$sid,$cid,$title,$in['goal']??null,$in['start_date']??date('Y-m-d'),(int)($in['weeks_count']??12),'active',now()]);json_response(['program_id'=>(int)$pdo->lastInsertId()],201);
}
if($method==='GET'&&$path==='/client/program'){
  $a=client();$q=$pdo->prepare('SELECT * FROM nutrition_programs WHERE client_id=? ORDER BY start_date DESC,id DESC LIMIT 1');$q->execute([(int)$a['user_id']]);json_response(['program'=>$q->fetch()?:null]);
}
if($method==='GET'&&$path==='/specialist/weekly-report'){
  $a=specialist();$sid=(int)$a['user_id'];$cid=(int)($_GET['client_id']??0);$c=ownedClient($cid,$sid);
  $from=date('Y-m-d',time()-6*86400);
  $q=$pdo->prepare('SELECT COUNT(*) FROM meal_logs WHERE client_id=? AND status="eaten" AND date(logged_at)>=?');$q->execute([$cid,$from]);$eaten=(int)$q->fetchColumn();
  $q=$pdo->prepare('SELECT COUNT(*) FROM meal_logs WHERE client_id=? AND date(logged_at)>=?');$q->execute([$cid,$from]);$logged=(int)$q->fetchColumn();
  $q=$pdo->prepare('SELECT weight_kg,measured_on FROM weight_logs WHERE client_id=? ORDER BY measured_on DESC LIMIT 2');$q->execute([$cid]);$w=$q->fetchAll();
  $q=$pdo->prepare('SELECT * FROM client_checkins WHERE client_id=? ORDER BY week_start DESC LIMIT 1');$q->execute([$cid]);$check=$q->fetch();
  $q=$pdo->prepare('SELECT ml.status,ml.comment,mi.meal_type,d.name dish_name FROM meal_logs ml JOIN menu_items mi ON mi.id=ml.menu_item_id JOIN dishes d ON d.id=mi.dish_id WHERE ml.client_id=? AND ml.status="skipped" AND date(ml.logged_at)>=? ORDER BY ml.logged_at DESC LIMIT 10');$q->execute([$cid,$from]);$skips=$q->fetchAll();
  $q=$pdo->prepare('SELECT AVG(mi2.nutrition_kcal) FROM (SELECT mi.id,mi.menu_id,mi.portion_g,d.kcal_100*mi.portion_g/100 nutrition_kcal FROM menu_items mi JOIN dishes d ON d.id=mi.dish_id) mi2 JOIN menus mn ON mn.id=mi2.menu_id WHERE mn.client_id=? AND mi2.menu_id=(SELECT id FROM menus WHERE client_id=? ORDER BY id DESC LIMIT 1)');$q->execute([$cid,$cid]);$avg=$q->fetchColumn();
  $delta=(count($w)>=2)?round((float)$w[0]['weight_kg']-(float)$w[1]['weight_kg'],1):null;
  json_response(['client'=>safeClient($c),'period'=>['from'=>$from,'to'=>date('Y-m-d')],'eaten'=>$eaten,'logged'=>$logged,'adherence'=>$logged?round($eaten/$logged*100):0,'weight_delta'=>$delta,'latest_weight'=>$w[0]['weight_kg']??null,'checkin'=>$check,'skips'=>$skips,'avg_kcal'=>$avg?round((float)$avg):null]);
}
if(str_starts_with($path,'/specialist/dishes/') && preg_match('#^/specialist/dishes/(\d+)/meta$#',$path,$m)){
  $a=specialist();$sid=(int)$a['user_id'];$did=(int)$m[1];
  $q=$pdo->prepare('SELECT * FROM dishes WHERE id=? AND (is_public=1 OR created_by=?)');$q->execute([$did,$sid]);if(!$q->fetch())json_response(['error'=>'Блюдо не найдено'],404);
  if($method==='GET'){ $q=$pdo->prepare('SELECT * FROM dish_meta WHERE dish_id=?');$q->execute([$did]);json_response(['meta'=>$q->fetch()?:[]]); }
  if($method==='PATCH'){ $in=input();$pdo->prepare('INSERT INTO dish_meta(dish_id,cost_rub,difficulty,office_friendly,freezer_friendly,restaurant_friendly,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(dish_id) DO UPDATE SET cost_rub=excluded.cost_rub,difficulty=excluded.difficulty,office_friendly=excluded.office_friendly,freezer_friendly=excluded.freezer_friendly,restaurant_friendly=excluded.restaurant_friendly,updated_at=excluded.updated_at')->execute([$did,$in['cost_rub']??null,$in['difficulty']??null,(int)($in['office_friendly']??0),(int)($in['freezer_friendly']??0),(int)($in['restaurant_friendly']??0),now()]);json_response(['ok'=>true]); }
}
if(str_starts_with($path,'/client/') && $method==='GET' && $path==='/client/checkin'){
  $a=client();$cid=(int)$a['user_id'];$q=$pdo->prepare('SELECT * FROM client_checkins WHERE client_id=? ORDER BY week_start DESC LIMIT 4');$q->execute([$cid]);json_response(['checkins'=>$q->fetchAll()]);
}
if(str_starts_with($path,'/client/') && $method==='POST' && $path==='/client/checkin'){
  $a=client();$cid=(int)$a['user_id'];$in=input();$week=$in['week_start']??date('Y-m-d',strtotime('monday this week'));$ease=max(1,min(5,(int)($in['ease_score']??3)));$well=$in['wellbeing_score']??null;$pdo->prepare('INSERT INTO client_checkins(client_id,week_start,ease_score,wellbeing_score,difficulties,comment,created_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(client_id,week_start) DO UPDATE SET ease_score=excluded.ease_score,wellbeing_score=excluded.wellbeing_score,difficulties=excluded.difficulties,comment=excluded.comment,created_at=excluded.created_at')->execute([$cid,$week,$ease,$well,json_encode($in['difficulties']??[],JSON_UNESCAPED_UNICODE),$in['comment']??null,now()]);createNotification($cid,'checkin','Еженедельный check-in','Ваш отчёт за неделю отправлен специалисту.');json_response(['ok'=>true]);
}
if($method==='GET'&&$path==='/client/home-products'){
  $a=client();$q=$pdo->prepare('SELECT * FROM home_products WHERE client_id=? ORDER BY name');$q->execute([(int)$a['user_id']]);json_response(['items'=>$q->fetchAll()]);
}
if($method==='POST'&&$path==='/client/home-products'){
  $a=client();$in=input();$name=trim((string)($in['name']??''));if(!$name)json_response(['error'=>'Название обязательно'],422);$pdo->prepare('INSERT INTO home_products(client_id,name,quantity,created_at) VALUES(?,?,?,?) ON CONFLICT(client_id,name) DO UPDATE SET quantity=excluded.quantity')->execute([(int)$a['user_id'],$name,$in['quantity']??null,now()]);json_response(['ok'=>true]);
}
/* Подписка приложения: вместо адреса и ключей VAPID приходит токен
   службы Expo. Кладём его в ту же таблицу с пометкой platform. */
if($method==='POST'&&$path==='/push/expo'){ $a=auth();$in=input();$t=trim((string)($in['token']??''));
  if(!preg_match('/^Expo(nent)?PushToken\[[^\]]+\]$/',$t))json_response(['error'=>'Это не токен Expo'],422);
  $pdo->prepare("INSERT INTO push_subscriptions(user_type,user_id,endpoint,p256dh,auth,device,platform,created_at,last_used_at) VALUES(?,?,?,'','',?,'expo',?,?) ON CONFLICT(endpoint) DO UPDATE SET user_type=excluded.user_type,user_id=excluded.user_id,device=excluded.device,platform='expo',last_used_at=excluded.last_used_at")
      ->execute([$a['user_type'],$a['user_id'],$t,$in['device']??null,now(),now()]);
  json_response(['ok'=>true]);}
if($method==='DELETE'&&$path==='/push/expo'){ $a=auth();$in=input();
  $pdo->prepare("DELETE FROM push_subscriptions WHERE endpoint=? AND user_type=? AND user_id=? AND platform='expo'")
      ->execute([(string)($in['token']??''),$a['user_type'],$a['user_id']]);
  json_response(['ok'=>true]);}
if($method==='POST'&&$path==='/push/subscribe'){ $a=auth();$in=input();if(empty($in['endpoint'])||empty($in['keys']['p256dh'])||empty($in['keys']['auth']))json_response(['error'=>'Неполная push-подписка'],422);$pdo->prepare('INSERT INTO push_subscriptions(user_type,user_id,endpoint,p256dh,auth,device,created_at,last_used_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET p256dh=excluded.p256dh,auth=excluded.auth,device=excluded.device,last_used_at=excluded.last_used_at')->execute([$a['user_type'],$a['user_id'],$in['endpoint'],$in['keys']['p256dh'],$in['keys']['auth'],$in['device']??null,now(),now()]);json_response(['ok'=>true]);}
/* «Всё включено, а ничего не приходит»: показывает, чего не хватает —
   каталога vendor, ключей или самой подписки, — и по запросу шлёт
   пробное уведомление, возвращая ответ службы доставки. */
if($method==='GET'&&$path==='/push/diag'){ $a=auth();
  json_response(pushDiag($a['user_type'],(int)$a['user_id'],false)); }
if($method==='POST'&&$path==='/push/test'){ $a=auth();
  json_response(pushDiag($a['user_type'],(int)$a['user_id'],true)); }
if($method==='DELETE'&&$path==='/push/subscribe'){ $a=auth();$in=input();$pdo->prepare('DELETE FROM push_subscriptions WHERE endpoint=? AND user_type=? AND user_id=?')->execute([$in['endpoint']??'',$a['user_type'],$a['user_id']]);json_response(['ok'=>true]);}
if($method==='DELETE'&&$path==='/client/notifications'){ $a=client();$pdo->prepare('DELETE FROM notifications WHERE client_id=?')->execute([$a['user_id']]);json_response(['ok'=>true]);}
if($method==='POST'&&$path==='/client/notifications/read'){ $a=client();$pdo->prepare('UPDATE notifications SET read_at=? WHERE client_id=?')->execute([now(),$a['user_id']]);json_response(['ok'=>true]);}
if($method==='GET'&&$path==='/export/menu.html'){ $a=specialist();$sid=(int)$a['user_id'];$mid=(int)($_GET['id']??0);$m=ownedMenu($mid,$sid);$items=menuItems($mid);header('Content-Type:text/html; charset=utf-8');echo '<!doctype html><html lang="ru"><meta charset="utf-8"><title>'.htmlspecialchars($m['title']).'</title><style>body{font:14px -apple-system,BlinkMacSystemFont,Arial;color:#171717;max-width:900px;margin:40px auto}h1{font-size:30px}table{width:100%;border-collapse:collapse;margin:12px 0 30px}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left}@media print{body{margin:10mm}}</style><h1>'.htmlspecialchars($m['title']).'</h1><p>Клиент: '.htmlspecialchars($m['client_name']).' · '.htmlspecialchars($m['start_date']).'</p>';for($d=1;$d<=$m['days_count'];$d++){echo '<h2>День '.$d.'</h2><table><tr><th>Приём</th><th>Блюдо</th><th>Порция</th><th>КБЖУ</th></tr>';foreach($items as $x)if((int)$x['day_number']===$d)echo '<tr><td>'.htmlspecialchars($x['meal_type']).'</td><td>'.htmlspecialchars($x['dish_name']).'</td><td>'.round($x['portion_g']).' г</td><td>'.round($x['nutrition']['kcal']).' ккал · Б '.round($x['nutrition']['protein']).' · Ж '.round($x['nutrition']['fat']).' · У '.round($x['nutrition']['carbs']).'</td></tr>';echo '</table>';}exit;}

/* ==========================================================================
   ВИДЕОЗВОНКИ (WebRTC) — сигналинг поверх обычного HTTP.
   Сервер не участвует в передаче медиа: он только перекладывает SDP и ICE
   между двумя браузерами, пока они устанавливают прямое соединение.
   ========================================================================== */
function iceServers():array{
  $out=[['urls'=>array_values(STUN_SERVERS)]];
  if(TURN_URL!=='')$out[]=['urls'=>TURN_URL,'username'=>TURN_USER,'credential'=>TURN_PASS];
  return $out;
}
/* Моя сторона в звонке: client или specialist. admin к звонкам не допускается. */
function callSide(array $a):string{
  if($a['user_type']!=='client'&&$a['user_type']!=='specialist')json_response(['error'=>'Forbidden'],403);
  return $a['user_type'];
}
/* Звонок, в котором участвую я. Иначе 404 — чужие звонки не видны в принципе. */
function callFor(array $a,int $id):array{
  $col=$a['user_type']==='client'?'client_id':'specialist_id';
  $q=db()->prepare("SELECT * FROM calls WHERE id=? AND $col=?");$q->execute([$id,(int)$a['user_id']]);
  $c=$q->fetch();if(!$c)json_response(['error'=>'Звонок не найден'],404);return $c;
}
/* Просроченные вызовы становятся пропущенными, старый сигналинг чистится. */
function callSweep(array $a):void{
  $pdo=db();$col=$a['user_type']==='client'?'client_id':'specialist_id';$uid=(int)$a['user_id'];
  $st=$pdo->prepare("SELECT * FROM calls WHERE $col=? AND status='ringing' AND created_at<datetime('now','-".CALL_RING_SECONDS." second')");
  $st->execute([$uid]);
  foreach($st->fetchAll() as $c)callFinish($c,'missed','timeout');
  /* Собеседник закрыл вкладку и не сообщил об этом — не держим звонок вечно */
  $st=$pdo->prepare("SELECT * FROM calls WHERE $col=? AND status='active' AND started_at<datetime('now','-4 hour')");
  $st->execute([$uid]);
  foreach($st->fetchAll() as $c)callFinish($c,'ended','hangup');
  $pdo->exec("DELETE FROM call_signals WHERE created_at<datetime('now','-2 hour')");
}
/* Завершение звонка. Срабатывает один раз: карточка в чате пишется только при
   реальном переходе из ringing/active, повторные вызовы ничего не меняют. */
function callFinish(array $c,string $status,string $reason):array{
  $pdo=db();$id=(int)$c['id'];
  $dur=0;
  if(!empty($c['started_at']))$dur=max(0,strtotime(now())-strtotime((string)$c['started_at']));
  $u=$pdo->prepare("UPDATE calls SET status=?,end_reason=?,ended_at=?,duration_sec=? WHERE id=? AND status IN ('ringing','active')");
  $u->execute([$status,$reason,now(),$dur,$id]);
  if($u->rowCount()){
    $mins=intdiv($dur,60);$secs=$dur%60;
    $len=$mins.':'.str_pad((string)$secs,2,'0',STR_PAD_LEFT);
    $body=$status==='ended'?'Видеозвонок · '.$len
      :($status==='declined'?'Звонок отклонён':'Пропущенный звонок');
    $pdo->prepare('INSERT INTO messages(client_id,author_type,body,kind,call_id,created_at) VALUES(?,?,?,?,?,?)')
        ->execute([(int)$c['client_id'],(string)$c['caller_type'],$body,'call',$id,now()]);
    if((string)$c['caller_type']==='specialist'&&$status!=='ended')
      createNotification((int)$c['client_id'],'call','Пропущенный звонок','Специалист звонил вам по видео.');
    /* Пропущенный вызов — единственное в звонках, что имеет смысл слать в push:
       дозвон он не заменит (задержка в секунды), но не даст потерять попытку связи. */
    if($status==='missed'){
      $who=callPeer($c,(string)$c['caller_type']);
      if((string)$c['caller_type']==='specialist')
        pushSend('client',(int)$c['client_id'],'Пропущенный звонок',
          $who['name'].' звонил вам по видео','/app/','call','/client/chat');
      elseif($c['specialist_id'])
        pushSend('specialist',(int)$c['specialist_id'],'Пропущенный звонок',
          $who['name'].' звонил вам по видео','/app/','call','/sp-chat/'.(int)$c['client_id']);
    }
  }
  $q=$pdo->prepare('SELECT * FROM calls WHERE id=?');$q->execute([$id]);return $q->fetch();
}
function callPeer(array $c,string $side):array{
  if($side==='client'){
    if(!$c['specialist_id'])return ['name'=>'Специалист','avatar_url'=>null];
    $q=db()->prepare('SELECT name,avatar_url FROM specialists WHERE id=?');$q->execute([(int)$c['specialist_id']]);
  }else{
    $q=db()->prepare('SELECT name,avatar_url FROM clients WHERE id=?');$q->execute([(int)$c['client_id']]);
  }
  $r=$q->fetch();return ['name'=>$r['name']??'Собеседник','avatar_url'=>$r['avatar_url']??null];
}
function callPublic(array $c):array{
  return ['id'=>(int)$c['id'],'status'=>$c['status'],'caller_type'=>$c['caller_type'],
    'end_reason'=>$c['end_reason'],'started_at'=>$c['started_at'],'duration_sec'=>(int)$c['duration_sec']];
}

if($method==='POST'&&$path==='/calls/start'){
  $a=auth();$side=callSide($a);$in=input();
  if($side==='client'){
    $cid=(int)$a['user_id'];
    $q=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');$q->execute([$cid]);
    $sid=(int)($q->fetchColumn()?:0);
    if(!$sid)json_response(['error'=>'У вас пока нет специалиста — звонить некому'],422);
  }else{
    $sid=(int)$a['user_id'];$cid=(int)($in['client_id']??0);ownedClient($cid,$sid);
  }
  callSweep($a);
  /* Уже идёт звонок с этим собеседником — отдаём его, а не плодим второй */
  $q=$pdo->prepare("SELECT * FROM calls WHERE client_id=? AND specialist_id=? AND status IN ('ringing','active') ORDER BY id DESC LIMIT 1");
  $q->execute([$cid,$sid]);$exist=$q->fetch();
  if($exist)json_response(['call'=>callPublic($exist),'peer'=>callPeer($exist,$side),'ice_servers'=>iceServers(),'existing'=>true]);
  $pdo->prepare('INSERT INTO calls(client_id,specialist_id,caller_type,status,created_at) VALUES(?,?,?,?,?)')
      ->execute([$cid,$sid,$side,'ringing',now()]);
  $id=(int)$pdo->lastInsertId();
  /* Звонок — единственное уведомление, которое бессмысленно доставлять
     позже: через пять минут отвечать уже некому. Поэтому push уходит
     прямо отсюда, а не из планировщика. */
  if($side==='specialist'){
    createNotification($cid,'call','Входящий звонок','Специалист звонит вам по видео.');
    $sq=$pdo->prepare('SELECT name FROM specialists WHERE id=?');$sq->execute([$sid]);
    $who=(string)($sq->fetchColumn()?:'Специалист');
    pushSend('client',$cid,'Входящий звонок 📹',$who.' звонит вам по видео.','/app/','call','/client/chat');
  }else{
    $cq=$pdo->prepare('SELECT name FROM clients WHERE id=?');$cq->execute([$cid]);
    $who=(string)($cq->fetchColumn()?:'Клиент');
    pushSend('specialist',$sid,'Входящий звонок 📹',$who.' звонит вам по видео.','/app/','call','/sp/chats');
  }
  $q=$pdo->prepare('SELECT * FROM calls WHERE id=?');$q->execute([$id]);$c=$q->fetch();
  json_response(['call'=>callPublic($c),'peer'=>callPeer($c,$side),'ice_servers'=>iceServers(),'ring_seconds'=>CALL_RING_SECONDS],201);
}

/* Единая точка опроса: и «мне звонят?», и состояние текущего звонка, и новые сигналы. */
if($method==='GET'&&$path==='/calls/poll'){
  $a=auth();$side=callSide($a);callSweep($a);
  $col=$side==='client'?'client_id':'specialist_id';$uid=(int)$a['user_id'];
  $out=['incoming'=>null,'call'=>null,'signals'=>[]];
  $q=$pdo->prepare("SELECT * FROM calls WHERE $col=? AND status='ringing' AND caller_type<>? ORDER BY id DESC LIMIT 1");
  $q->execute([$uid,$side]);
  if($inc=$q->fetch())$out['incoming']=['call'=>callPublic($inc),'peer'=>callPeer($inc,$side),'ice_servers'=>iceServers()];
  $cid=(int)($_GET['call_id']??0);
  if($cid){
    $c=callFor($a,$cid);$out['call']=callPublic($c);
    $since=(int)($_GET['since']??0);
    $q=$pdo->prepare('SELECT id,from_type,kind,payload FROM call_signals WHERE call_id=? AND id>? AND from_type<>? ORDER BY id LIMIT 60');
    $q->execute([$cid,$since,$side]);
    foreach($q->fetchAll() as $r)$out['signals'][]=['id'=>(int)$r['id'],'kind'=>$r['kind'],'payload'=>$r['payload']];
  }
  json_response($out);
}

if($method==='POST'&&$path==='/calls/signal'){
  $a=auth();$side=callSide($a);$in=input();
  $c=callFor($a,(int)($in['call_id']??0));
  if(!in_array($c['status'],['ringing','active'],true))json_response(['error'=>'Звонок завершён'],409);
  $kind=(string)($in['kind']??'');
  if(!in_array($kind,['offer','answer','ice'],true))json_response(['error'=>'Неизвестный тип сигнала'],422);
  $payload=json_encode($in['payload']??null,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  if($payload===false||strlen($payload)>65536)json_response(['error'=>'Сигнал слишком большой'],422);
  $pdo->prepare('INSERT INTO call_signals(call_id,from_type,kind,payload,created_at) VALUES(?,?,?,?,?)')
      ->execute([(int)$c['id'],$side,$kind,$payload,now()]);
  json_response(['ok'=>true],201);
}

if($method==='POST'&&$path==='/calls/accept'){
  $a=auth();$side=callSide($a);$in=input();
  $c=callFor($a,(int)($in['call_id']??0));
  if($c['caller_type']===$side)json_response(['error'=>'Это ваш исходящий звонок'],422);
  if($c['status']!=='ringing')json_response(['error'=>'Звонок уже недоступен','call'=>callPublic($c)],409);
  $pdo->prepare("UPDATE calls SET status='active',started_at=? WHERE id=? AND status='ringing'")->execute([now(),(int)$c['id']]);
  $q=$pdo->prepare('SELECT * FROM calls WHERE id=?');$q->execute([(int)$c['id']]);$c=$q->fetch();
  json_response(['call'=>callPublic($c),'peer'=>callPeer($c,$side),'ice_servers'=>iceServers()]);
}

if($method==='POST'&&$path==='/calls/decline'){
  $a=auth();callSide($a);$in=input();
  $c=callFor($a,(int)($in['call_id']??0));
  json_response(['call'=>callPublic(callFinish($c,'declined','declined'))]);
}

if($method==='POST'&&$path==='/calls/end'){
  $a=auth();callSide($a);$in=input();
  $c=callFor($a,(int)($in['call_id']??0));
  $reason=in_array($in['reason']??'',['hangup','failed'],true)?(string)$in['reason']:'hangup';
  /* Никто не успел взять трубку — это пропущенный, а не завершённый разговор */
  $status=($c['status']==='ringing')?'missed':'ended';
  json_response(['call'=>callPublic(callFinish($c,$status,$reason))]);
}


 if($method==='GET'&&$path==='/specialist/services'){
   $q=$pdo->prepare('SELECT * FROM specialist_services WHERE specialist_id=? ORDER BY is_active DESC,sort_order,id');
   $q->execute([$sid]);
   json_response(['services'=>array_map('servicePublic',$q->fetchAll())]);
 }
 if($method==='POST'&&$path==='/specialist/services'){
   $in=input();$d=serviceInput($in,true);$kop=servicePrice($in['price']??'');
   $next=(int)$pdo->query("SELECT COALESCE(MAX(sort_order),0)+1 FROM specialist_services WHERE specialist_id=$sid")->fetchColumn();
   $pdo->prepare('INSERT INTO specialist_services(specialist_id,title,description,kind,price_kop,period_days,duration_min,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
       ->execute([$sid,$d['title'],$d['description'],$d['kind'],$kop,$d['period_days'],$d['duration_min'],$next,now()]);
   $q=$pdo->prepare('SELECT * FROM specialist_services WHERE id=?');$q->execute([(int)$pdo->lastInsertId()]);
   json_response(['service'=>servicePublic($q->fetch())],201);
 }
 if($method==='PATCH'&&preg_match('#^/specialist/services/(\d+)$#',$path,$m)){
   $id=(int)$m[1];
   $q=$pdo->prepare('SELECT * FROM specialist_services WHERE id=? AND specialist_id=?');$q->execute([$id,$sid]);
   $cur=$q->fetch();if(!$cur)json_response(['error'=>'Услуга не найдена'],404);
   $in=input();$d=serviceInput($in+['kind'=>$cur['kind'],'period_days'=>$cur['period_days'],'duration_min'=>$cur['duration_min']??''],false);
   $kop=array_key_exists('price',$in)?servicePrice($in['price']):(int)$cur['price_kop'];
   $active=array_key_exists('is_active',$in)?(!empty($in['is_active'])?1:0):(int)$cur['is_active'];
   $pdo->prepare('UPDATE specialist_services SET title=?,description=?,kind=?,price_kop=?,period_days=?,duration_min=?,is_active=? WHERE id=? AND specialist_id=?')
       ->execute([$d['title']!==''?$d['title']:$cur['title'],$d['description'],$d['kind'],$kop,$d['period_days'],$d['duration_min'],$active,$id,$sid]);
   $q->execute([$id,$sid]);json_response(['service'=>servicePublic($q->fetch())]);
 }
 /* Не удаляем, а гасим: на услугу будут ссылаться прошлые заказы */
 if($method==='DELETE'&&preg_match('#^/specialist/services/(\d+)$#',$path,$m)){
   $st=$pdo->prepare('UPDATE specialist_services SET is_active=0 WHERE id=? AND specialist_id=?');
   $st->execute([(int)$m[1],$sid]);
   if(!$st->rowCount())json_response(['error'=>'Услуга не найдена'],404);
   json_response(['ok'=>true]);
 }
 if($method==='GET'&&$path==='/client/services'){
   $q=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');$q->execute([$cid]);
   $spid=(int)($q->fetchColumn()?:0);
   if(!$spid)json_response(['specialist'=>null,'services'=>[]]);
   $q=$pdo->prepare('SELECT id,name,avatar_url FROM specialists WHERE id=?');$q->execute([$spid]);$sp=$q->fetch();
   $q=$pdo->prepare('SELECT * FROM specialist_services WHERE specialist_id=? AND is_active=1 ORDER BY sort_order,id');
   $q->execute([$spid]);
   json_response(['specialist'=>$sp,'services'=>array_map('servicePublic',$q->fetchAll()),
     'payments_mode'=>balanceSettings()['payments_mode'],
     /* Что клиент уже включил: экран услуг должен отличать выбранную от
        остальных и показывать, сколько ей осталось. */
     'subscription'=>subActive($cid),
     'note'=>balanceSettings()['payments_mode']==='off'
       ? 'Оплата внутри приложения пока не подключена — услуга включается сразу.'
       : 'Деньги за услугу замораживаются и переходят специалисту после выполнения.']);
 }
 /* Включить услугу. Оплаты нет: подписка становится активной сразу, а
    поле paid остаётся нулём — по нему потом отличим оплаченные. */
 /* Проверить промокод до оплаты: человек вводит код и сразу видит,
    сколько будет стоить. Молчаливое «код не подошёл» на этапе списания
    денег — худший момент для такой новости. */
 if($method==='POST'&&$path==='/client/promo/check'){
   $in=input();
   $svcId=(int)($in['service_id']??0);
   $q=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');$q->execute([$cid]);
   $spid=(int)($q->fetchColumn()?:0);
   $q=$pdo->prepare('SELECT price_kop,title FROM specialist_services WHERE id=? AND specialist_id=?');
   $q->execute([$svcId,$spid]); $svc=$q->fetch();
   if(!$svc)json_response(['error'=>'Услуга не найдена'],404);
   $r=promoCheck((string)($in['code']??''),$spid,(int)$svc['price_kop']);
   if(!empty($r['error']))json_response(['error'=>$r['error']],422);
   json_response(['ok'=>true,'discount_kop'=>$r['discount_kop'],
     'price_kop'=>(int)$svc['price_kop'],
     'total_kop'=>(int)$svc['price_kop']-(int)$r['discount_kop'],
     'percent'=>(int)$r['promo']['percent']]);
 }
 if($method==='POST'&&preg_match('#^/client/services/(\d+)/activate$#',$path,$m)){
   $svcId=(int)$m[1];
   $q=$pdo->prepare('SELECT specialist_id FROM clients WHERE id=?');$q->execute([$cid]);
   $spid=(int)($q->fetchColumn()?:0);
   if(!$spid)json_response(['error'=>'Сначала выберите специалиста'],409);
   /* Услуга обязана принадлежать своему специалисту: иначе по чужому
      идентификатору можно включить себе чей угодно тариф. */
   $q=$pdo->prepare('SELECT * FROM specialist_services WHERE id=? AND specialist_id=? AND is_active=1');
   $q->execute([$svcId,$spid]);
   $svc=$q->fetch();
   if(!$svc)json_response(['error'=>'Услуга не найдена'],404);
   $sub=subActivate($cid,$spid,$svc);
   /* Режим off — как и было: витрина без денег. В demo и live покупка
      проводится по балансу, и доля специалиста замораживается. Разница
      между ними только в том, настоящие это деньги или учебные. */
   $mode=balanceSettings()['payments_mode'];
   $pay=null;
   if($mode!=='off'&&!empty($sub['id'])){
     if($mode==='live'){
       /* Настоящие деньги: открываем сделку у эквайера и ждём его
          уведомления. Замораживать до подтверждения оплаты нельзя —
          иначе на балансе появятся деньги, которых никто не платил. */
       $pay=paymentOpen((int)$sub['id']);
       if(!empty($pay['error']))json_response(['error'=>$pay['error']],502);
     }else{
       /* Проверочный режим: оплату считаем прошедшей сразу — смотреть
          нужно на механику, а не на платёжную форму. */
       subPay((int)$sub['id'],trim((string)(input()['promo']??''))?:null);
     }
     $sub=subActive($cid);
   }
   /* Специалисту это знать нужнее всего: клиент выбрал тариф. */
   $q=$pdo->prepare('SELECT name FROM clients WHERE id=?');$q->execute([$cid]);
   $cname=(string)($q->fetchColumn()?:'Клиент');
   pushSend('specialist',$spid,'Клиент выбрал услугу',
     $cname.' подключил «'.$svc['title'].'»','/app/','client-service');
   json_response(['ok'=>true,'subscription'=>$sub,
     'confirmation_url'=>$pay['confirmation_url']??null]);
 }
 if($method==='GET'&&$path==='/client/subscription'){
   json_response(['subscription'=>subActive($cid)]);
 }

/* ==========================================================================
   БАЛАНС СПЕЦИАЛИСТА

   Экран показывает два числа — заморожено и доступно — и выписку, из
   которой они складываются. Считаем при каждом обращении: там же
   дописываются начисления, срок которых наступил.
   ========================================================================== */
 if($method==='GET'&&$path==='/specialist/balance'){
   json_response([
     'balance'=>balanceOf($sid),
     'entries'=>balanceEntries($sid),
     'details'=>payoutDetailsOf($sid),
     'payouts'=>payoutList($sid),
   ]);
 }

 /* Реквизиты сохраняются целиком: полупустая карточка на выводе хуже,
    чем её отсутствие — перевод уйдёт не туда. */
 if($method==='POST'&&$path==='/specialist/payout-details'){
   $in=input();
   $legal=in_array($in['legal_type']??'',['self_employed','ip','individual'],true)?$in['legal_type']:'self_employed';
   $name=trim((string)($in['full_name']??''));
   $acc=preg_replace('/\s+/','',(string)($in['account']??''));
   $inn=preg_replace('/\D+/','',(string)($in['inn']??''));
   if(mb_strlen($name)<5)json_response(['error'=>'Укажите фамилию, имя и отчество получателя'],422);
   if(!preg_match('/^\d{16,20}$/',$acc))json_response(['error'=>'Номер карты или счёта — от 16 до 20 цифр'],422);
   if($legal!=='individual'&&!preg_match('/^\d{10,12}$/',$inn))
     json_response(['error'=>'Для самозанятого и ИП нужен ИНН'],422);
   if(empty($in['agreement']))json_response(['error'=>'Без согласия с агентским договором перевод невозможен'],422);
   $q=$pdo->prepare('SELECT agreement_accepted_at FROM payout_details WHERE specialist_id=?');
   $q->execute([$sid]); $was=(string)($q->fetchColumn()?:'');
   $pdo->prepare('INSERT INTO payout_details(specialist_id,legal_type,full_name,inn,account,bank,agreement_accepted_at,updated_at)
        VALUES(?,?,?,?,?,?,?,?)
        ON CONFLICT(specialist_id) DO UPDATE SET legal_type=excluded.legal_type,full_name=excluded.full_name,
          inn=excluded.inn,account=excluded.account,bank=excluded.bank,updated_at=excluded.updated_at')
      ->execute([$sid,$legal,mb_substr($name,0,120),$inn?:null,$acc,
                 mb_substr(trim((string)($in['bank']??'')),0,120)?:null,$was?:now(),now()]);
   json_response(['details'=>payoutDetailsOf($sid)]);
 }

 /* Заявка на вывод. Сумма сразу уходит из доступного отдельным
    движением: иначе те же деньги можно запросить дважды, пока первая
    заявка ждёт своей очереди. */
 if($method==='POST'&&$path==='/specialist/payout'){
   $b=balanceOf($sid);
   if(!$b['can_payout'])json_response(['error'=>$b['payments_mode']==='demo'
     ? 'Проверочный режим: суммы учебные, вывести их нельзя'
     : 'Приём платежей ещё не подключён — выводить нечего'],409);
   $det=payoutDetailsOf($sid);
   if(!$det)json_response(['error'=>'Сначала заполните реквизиты'],409);
   $in=input();
   $amount=array_key_exists('amount',$in)?servicePrice($in['amount']):$b['available_kop'];
   if($amount<$b['payout_min_kop'])
     json_response(['error'=>'Минимальная сумма вывода — '.round($b['payout_min_kop']/100).' ₽'],422);
   if($amount>$b['available_kop'])json_response(['error'=>'Столько нет на балансе'],422);
   /* Раскладываем сумму на покупки заранее: эквайер закрывает сделки, а
      не суммы, и если разложить не удалось — значит учёт разошёлся, и
      заводить заявку нельзя. */
   $items=payoutPick($sid,$amount);
   if(!$items)json_response(['error'=>'Не удалось собрать сумму из оплаченных услуг'],409);
   $pdo->prepare('INSERT INTO payout_requests(specialist_id,amount_kop,status,details_json,created_at)
        VALUES(?,?,\'pending\',?,?)')
      ->execute([$sid,$amount,json_encode($det,JSON_UNESCAPED_UNICODE),now()]);
   $pid=(int)$pdo->lastInsertId();
   $st=$pdo->prepare('INSERT INTO payout_orders(payout_id,sub_id,amount_kop) VALUES(?,?,?)');
   foreach($items as $it)$st->execute([$pid,$it['sub_id'],$it['amount_kop']]);
   balanceAdd($sid,null,'payout',0,-$amount,'Заявка на вывод №'.$pid,null,$pid);
   /* Заявка на вывод — живые деньги, которые ждут решения человека.
      Письмо владельцу, чтобы не узнавать о ней из письма специалиста
      «когда переведёте?». Не чаще раза в час: десять заявок подряд — не
      десять писем, а одно с общим числом. */
   $waiting=(int)fetchOne($pdo,"SELECT COUNT(*) FROM payout_requests WHERE status='pending'");
   [$ph,$pt]=plainLetter('Заявка на вывод в '.APP_NAME,
     fetchOne($pdo,'SELECT name FROM specialists WHERE id=?',[$sid])
       .' просит вывести '.number_format($amount/100,0,',',' ').' ₽.'
       ."\nВсего заявок ждут решения: ".$waiting.'.',
     'Раздел «Деньги» в панели: '.siteUrl().'/app/');
   mailOwnerThrottled('payout',1,'Заявка на вывод — '.APP_NAME,$ph,$pt);
   json_response(['ok'=>true,'balance'=>balanceOf($sid),'payouts'=>payoutList($sid)],201);
 }

 /* Продажи: что куплено, что ждёт приёмки, что уже разморожено.
    Это тот же список, что у клиента, но с другой стороны. */
 if($method==='GET'&&$path==='/specialist/sales'){
   balanceAccrue($sid);
   $q=$pdo->prepare("SELECT s.*,c.name client_name FROM client_subscriptions s
                       JOIN clients c ON c.id=s.client_id
                      WHERE s.specialist_id=? AND s.paid=1 ORDER BY s.id DESC LIMIT 100");
   $q->execute([$sid]);
   json_response(['sales'=>array_map('subDecorate',$q->fetchAll())]);
 }

 /* Отметка выполнения разовой услуги. С этого момента у клиента есть
    окно на возражение, и только после него деньги размораживаются. */
 if($method==='POST'&&preg_match('#^/specialist/sales/(\d+)/done$#',$path,$m)){
   $q=$pdo->prepare('SELECT * FROM client_subscriptions WHERE id=? AND specialist_id=?');
   $q->execute([(int)$m[1],$sid]); $sub=$q->fetch();
   if(!$sub)json_response(['error'=>'Покупка не найдена'],404);
   if($sub['kind']!=='one_time')json_response(['error'=>'Подписка размораживается сама, по дням'],422);
   if((int)$sub['paid']!==1)json_response(['error'=>'Услуга не оплачена'],409);
   if(!empty($sub['done_at']))json_response(['error'=>'Выполнение уже отмечено'],409);
   $days=balanceSettings()['accept_days'];
   $due=date('Y-m-d H:i:s',time()+$days*86400);
   $pdo->prepare('UPDATE client_subscriptions SET done_at=?,accept_due_at=? WHERE id=? AND done_at IS NULL')
       ->execute([now(),$due,(int)$sub['id']]);
   createNotification((int)$sub['client_id'],'service',
     'Подтвердите выполнение',
     'Специалист отметил «'.$sub['title'].'» выполненной. Подтвердите или напишите, что не так — через '
      .$days.' '.plural_ru($days,'день','дня','дней').' подтвердится само.');
   pushSend('client',(int)$sub['client_id'],'Подтвердите выполнение',
     'Услуга «'.$sub['title'].'» отмечена выполненной','/app/','service-done');
   json_response(['ok'=>true]);
 }

/* --- Клиент: приёмка разовой услуги ------------------------------------ */
 if($method==='POST'&&preg_match('#^/client/subscriptions/(\d+)/accept$#',$path,$m)){
   $sub=clientSub($cid,(int)$m[1]);
   if(empty($sub['done_at']))json_response(['error'=>'Специалист ещё не отметил выполнение'],409);
   if(!empty($sub['accepted_at']))json_response(['error'=>'Уже подтверждено'],409);
   $left=subHeld((int)$sub['id']);
   if($left>0)balanceAdd((int)$sub['specialist_id'],(int)$sub['id'],'release',-$left,$left,
      'Клиент подтвердил выполнение');
   $pdo->prepare("UPDATE client_subscriptions SET accepted_at=?,accepted_by='client',disputed_at=NULL WHERE id=?")
       ->execute([now(),(int)$sub['id']]);
   pushSend('specialist',(int)$sub['specialist_id'],'Услуга принята',
     'Клиент подтвердил «'.$sub['title'].'»','/app/','service-accepted');
   json_response(['ok'=>true]);
 }

 /* Возражение. Деньги остаются замороженными, пока спор не разберёт
    владелец: без этого кнопка «подтвердить» была бы единственной, а
    значит ничего не значила бы. */
 if($method==='POST'&&preg_match('#^/client/subscriptions/(\d+)/dispute$#',$path,$m)){
   $sub=clientSub($cid,(int)$m[1]);
   if(!empty($sub['accepted_at']))json_response(['error'=>'Услуга уже принята'],409);
   $note=mb_substr(trim((string)(input()['note']??'')),0,600);
   if(mb_strlen($note)<10)json_response(['error'=>'Опишите, что не так — хотя бы пару фраз'],422);
   $pdo->prepare('UPDATE client_subscriptions SET disputed_at=?,dispute_note=? WHERE id=?')
       ->execute([now(),$note,(int)$sub['id']]);
   pushSend('specialist',(int)$sub['specialist_id'],'Клиент не принял услугу',
     mb_substr($note,0,120),'/app/','service-dispute');
   json_response(['ok'=>true]);
 }
json_response(['error'=>'Not found'],404);
}catch(Throwable $e){error_log((string)$e);json_response(['error'=>'Server error','detail'=>$e->getMessage()],500);}
