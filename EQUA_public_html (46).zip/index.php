<?php
/* Тексты главной ведёт владелец из панели. В разметке остаются
   запасные варианты: пустое поле в панели не должно опустошать сайт. */
require_once __DIR__.'/config/config.php';
$H=fn(string $k,string $d)=>htmlspecialchars(siteText($k,$d),ENT_QUOTES,'UTF-8');
?><!doctype html>
<html lang="ru">
<head><link rel="icon" type="image/png" sizes="32x32" href="/icon-32.png"><link rel="icon" type="image/svg+xml" href="/icon.svg">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#F5F6F7">
<link rel="manifest" href="/manifest.json"><link rel="apple-touch-icon" href="/icon-180.png">
<title>EQUA — персональное питание с нутрициологом</title>
<meta name="description" content="EQUA соединяет вас с нутрициологом: персональное меню под ваши цели, подсчёт КБЖУ, чат со специалистом и наглядный прогресс.">
<meta property="og:title" content="EQUA — персональное питание с нутрициологом">
<meta property="og:description" content="Меню под ваши цели от живого специалиста. КБЖУ считается само, прогресс виден, специалист рядом в чате.">
<meta property="og:type" content="website">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap">
<link rel="stylesheet" href="/landing.css">
</head>
<body>

<div class="grain" aria-hidden="true"></div>

<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
<symbol id="leaf" viewBox="0 0 24 24"><path d="M5 19c0-8 6-14 14-14 0 8-6 14-14 14ZM5 19c4-2 7-5 9-9"/></symbol>
<symbol id="arr" viewBox="0 0 24 24"><path d="M6 18 18 6M9 6h9v9"/></symbol>
<symbol id="check" viewBox="0 0 24 24"><path d="m5 12 5 5L20 6"/></symbol>
</defs></svg>

<a class="skip" href="#main" style="position:absolute;left:-9999px">К содержимому</a>

<header class="island" id="island">
  <a class="logo" href="/"><?php include __DIR__.'/partials/logo.php' ?></a>
  <nav class="isl-menu">
    <a href="#how">Как это работает</a>
    <a href="#features">Возможности</a>
    <a href="#aud">Для кого</a>
    <a href="/catalog.php">Специалисты</a>
    <a href="#reviews">Отзывы</a>
  </nav>
  <div class="isl-cta">
    <a class="btn o plain" href="/app/">Вход</a>
    <a class="btn p" href="/app/"><span class="cap">Попробовать</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
    <button class="burger" id="burger" aria-label="Меню" aria-expanded="false"><i></i><i></i></button>
  </div>
</header>

<nav class="sheetnav" id="sheetnav">
  <a href="#how">Как это работает</a>
  <a href="#features">Возможности</a>
  <a href="#aud">Для кого</a>
  <a href="/catalog.php">Специалисты</a>
  <a href="#reviews">Отзывы</a>
  <a href="/app/">Вход</a>
  <a class="btn p" href="/app/"><span class="cap">Попробовать бесплатно</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
</nav>

<main id="main">

<section class="hero">
  <div class="aura a"></div><div class="aura b"></div>
  <div class="wrap hero-grid">
    <div>
      <span class="eyebrow rev"><svg class="i"><use href="#leaf"/></svg> Питание со специалистом</span>
      <h1 class="display rev d1"><?= siteText('home_title','')!=='' ? $H('home_title','')
        : 'Питайтесь правильно<br><em>с личным нутрициологом</em>' ?></h1>
      <p class="lead rev d2"><?= $H('home_sub','EQUA соединяет вас с нутрициологом: он собирает персональное меню под ваши цели, а приложение считает КБЖУ, напоминает о приёмах пищи и показывает прогресс.') ?></p>
      <div class="hero-cta rev d3">
        <a class="btn p" href="/catalog.php"><span class="cap"><?= $H('home_cta','Найти специалиста') ?></span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
        <a class="btn o" href="/for-specialists.php"><span class="cap">Я специалист</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
      </div>
      <div class="trust rev d4">
        <div><span class="ti"><svg class="i" viewBox="0 0 24 24"><path d="M3.5 11h17a8.5 8.5 0 0 1-17 0Z"/><path d="M8 8c0-1.5 1-2 1-3"/></svg></span> Меню под вас</div>
        <div><span class="ti"><svg class="i" viewBox="0 0 24 24"><path d="M20 12a7.5 7.5 0 0 1-10.6 6.8L4 20l1.2-4.3A7.5 7.5 0 0 1 20 12Z"/></svg></span> Чат со специалистом</div>
        <div><span class="ti"><svg class="i" viewBox="0 0 24 24"><path d="m3 16 5-5 4 3 6-7"/></svg></span> Прогресс и вес</div>
      </div>
    </div>

    <div class="stage rev d2">
      <div class="bezel"><div class="core pad-b">
        <div class="panel-head"><b>Меню на день</b><span class="chip">12 мая, понедельник</span></div>
        <div class="kpis">
          <div class="kpi"><b class="num">1640</b><span>ккал</span></div>
          <div class="kpi"><b class="num">112</b><span>белки</span></div>
          <div class="kpi"><b class="num">47</b><span>жиры</span></div>
          <div class="kpi"><b class="num">178</b><span>углеводы</span></div>
          <div class="ring num">91%</div>
        </div>
        <div class="mlabel">Завтрак</div>
        <div class="pdish"><span class="th" style="background-image:url(/food_oatmeal.jpg)"></span><div class="g"><b>Овсяная каша с ягодами</b><span class="num">320 г · 420 ккал · Б 14 · Ж 12 · У 58</span></div><span class="ok"><svg class="i"><use href="#check"/></svg></span></div>
        <div class="pdish"><span class="th" style="background-image:url(/food_cottage.jpg)"></span><div class="g"><b>Яйцо варёное</b><span class="num">1 шт (50 г) · 70 ккал</span></div><span class="ok"><svg class="i"><use href="#check"/></svg></span></div>
        <div class="mlabel">Перекус</div>
        <div class="pdish"><span class="th" style="background-image:url(/food_alt1.jpg)"></span><div class="g"><b>Смузи банан-миндаль</b><span class="num">250 г · 210 ккал</span></div><span class="ok"><svg class="i"><use href="#check"/></svg></span></div>
      </div></div>
      <div class="phone"><div class="scr">
        <div class="ptop"><div class="ring num">91%</div><div class="pk"><b class="num">1640</b> <span class="of num">/ 1800 ккал</span><span class="dt">Сегодня</span></div></div>
        <div class="pdish"><span class="th" style="background-image:url(/food_oatmeal.jpg)"></span><div class="g"><b>Овсяная каша</b><span class="num">420 ккал</span></div><span class="ok"><svg class="i"><use href="#check"/></svg></span></div>
        <div class="pdish"><span class="th" style="background-image:url(/food_pasta.jpg)"></span><div class="g"><b>Паста с курицей</b><span class="num">610 ккал</span></div><span class="ok"><svg class="i"><use href="#check"/></svg></span></div>
      </div></div>
    </div>
  </div>
</section>

<section class="block" id="aud"><div class="wrap">
  <div class="sec-head rev">
    <span class="eyebrow">Для кого</span>
    <h2 class="h2">Одна платформа<br>для двух сторон стола</h2>
    <p class="lead">Тех, кто хочет питаться правильно, и специалистов — нутрициологов, тренеров и коучей, — которые в этом помогают.</p>
  </div>
  <div class="bento">
    <article class="tile b-7 rev">
      <span class="tag">Вам, если хотите питаться правильно</span>
      <h3 class="h3">Меню под вас — без диет из интернета</h3>
      <ul class="ticks">
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Персональное меню от вашего специалиста под цели и вкусы</li>
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Отмечайте съеденное в телефоне — КБЖУ считается само</li>
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Замены блюд, если что-то не подошло</li>
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Прогресс, вес и замеры — всё наглядно</li>
      </ul>
      <a class="btn p" href="/app/"><span class="cap">Подобрать меню</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
    </article>

    <article class="tile ink b-5 rev d1">
      <span class="tag">Вам, если вы нутрициолог или тренер</span>
      <h3 class="h3">Ведите подопечных и назначайте свою цену</h3>
      <ul class="ticks">
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Конструктор меню за минуты из базы блюд</li>
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Клиенты, анкеты, чат и прогресс в одном месте</li>
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Шаблоны и копирование дней — меньше рутины</li>
        <li><span class="tick"><svg class="i"><use href="#check"/></svg></span> Стоимость услуги вы определяете сами</li>
      </ul>
      <a class="btn o" href="/app/"><span class="cap">Стать специалистом</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
    </article>

    <div class="tile quiet stat b-4 rev"><b>5–7</b><span>минут на анкету — и специалист видит ваши цели, вкусы и ограничения</span></div>
    <div class="tile quiet stat b-4 rev d1"><b class="num">1640</b><span>ккал в дневном плане пересчитываются сами при каждой замене блюда</span></div>
    <div class="tile quiet stat b-4 rev d2"><b class="num">0 ₽</b><span>за сам сервис для специалиста — цену своей работы он назначает сам</span></div>
  </div>
</div></section>

<section class="block" id="how"><div class="wrap">
  <div class="sec-head rev">
    <span class="eyebrow">Как это работает</span>
    <h2 class="h2">Путь от анкеты<br>до первого меню — за вечер</h2>
  </div>
  <div class="steps">
    <div class="step rev"><span class="no">01</span><h3>Пройдите анкету</h3><p>Расскажите о себе, целях, вкусах и ограничениях — 5–7 минут.</p></div>
    <div class="step rev d1"><span class="no">02</span><h3>Выберите специалиста</h3><p>Подберите нутрициолога или тренера и начните работу — оплата напрямую по его цене.</p></div>
    <div class="step rev d2"><span class="no">03</span><h3>Получите меню</h3><p>Специалист собирает персональный рацион, а сервис считает КБЖУ.</p></div>
    <div class="step rev d3"><span class="no">04</span><h3>Следуйте и следите</h3><p>Отмечайте приёмы пищи, общайтесь в чате и наблюдайте прогресс.</p></div>
  </div>
</div></section>

<section class="block" id="features"><div class="wrap">
  <div class="sec-head rev">
    <span class="eyebrow">Возможности</span>
    <h2 class="h2">Всё, что нужно,<br>чтобы дойти до цели</h2>
    <p class="lead">Инструменты для клиента и для специалиста — в одном сервисе.</p>
  </div>
  <div class="bento">
    <article class="tile feature b-6 rev"><div class="fi"><svg class="i" viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="16" rx="3"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/></svg></div><h3>Персональное меню</h3><p>Рацион под ваши цели, вкусы и ограничения — от вашего нутрициолога или тренера.</p></article>
    <article class="tile feature b-6 rev d1"><div class="fi"><svg class="i" viewBox="0 0 24 24"><path d="M20 12a7.5 7.5 0 0 1-10.6 6.8L4 20l1.2-4.3A7.5 7.5 0 1 1 20 12Z"/></svg></div><h3>Личный чат со специалистом</h3><p>Задавайте вопросы, получайте поддержку и обратную связь в переписке.</p></article>
    <article class="tile feature b-4 rev"><div class="fi"><svg class="i" viewBox="0 0 24 24"><rect x="7" y="3" width="10" height="18" rx="3"/><path d="M11 18h2"/></svg></div><h3>Приложение в телефоне</h3><p>Меню на день, отметки «съел» и список покупок — всегда с собой.</p></article>
    <article class="tile feature b-4 rev d1"><div class="fi"><svg class="i" viewBox="0 0 24 24"><path d="M4 20V4M4 20h16M8 15l4-4 3 3 5-6"/></svg></div><h3>Прогресс и вес наглядно</h3><p>Графики веса, замеры и история — видно, как вы двигаетесь к цели.</p></article>
    <article class="tile feature b-4 rev d2"><div class="fi"><svg class="i" viewBox="0 0 24 24"><path d="M3.5 11h17a8.5 8.5 0 0 1-17 0ZM8 8c0-1.6 1-2.5 1-3.5M12 8c0-1.6 1-2.5 1-3.5"/></svg></div><h3>Замены блюд</h3><p>Не подошло блюдо — выберите равноценную замену, одобренную специалистом.</p></article>
    <article class="tile feature b-6 rev"><div class="fi"><svg class="i" viewBox="0 0 24 24"><path d="M6 17h12l-1.4-2v-4a4.6 4.6 0 0 0-9.2 0v4zM10 19h4"/></svg></div><h3>Напоминания</h3><p>Уведомления о приёмах пищи, взвешивании и сообщениях — ничего не забудете.</p></article>
    <article class="tile quiet b-6 rev d1"><span class="tag">Скоро</span><h3 class="h3">Лента и сообщество</h3><p>Фото приёмов пищи, результаты и поддержка тех, кто идёт к той же цели.</p></article>
  </div>
</div></section>

<section class="block" id="reviews"><div class="wrap">
  <div class="sec-head rev">
    <span class="eyebrow">Отзывы</span>
    <h2 class="h2">О нас говорят</h2>
  </div>
  <div class="wall">
    <figure class="review lg rev" style="margin:0 0 16px"><div class="stars">★★★★★</div><p>«Впервые питаюсь по плану и не срываюсь — меню правда учитывает мои вкусы. Минус 4 кг за два месяца без мучений.»</p><figcaption class="rev-by"><span class="av" style="background:linear-gradient(135deg,#EC4899,#F43F5E)">А</span><div><b>Анна П.</b><span>клиент</span></div></figcaption></figure>
    <figure class="review rev d1" style="margin:0 0 16px"><div class="stars">★★★★★</div><p>«Собираю меню в разы быстрее, все клиенты и их прогресс — в одном месте. Цену за услугу задаю сама.»</p><figcaption class="rev-by"><span class="av" style="background:linear-gradient(135deg,#14B8A6,#0D9488)">М</span><div><b>Мария И.</b><span>нутрициолог</span></div></figcaption></figure>
    <figure class="review rev d1" style="margin:0 0 16px"><div class="stars">★★★★★</div><p>«Удобно, что всё в телефоне: отметил, что съел, — и видишь КБЖУ. А если что-то не хочу, есть замены.»</p><figcaption class="rev-by"><span class="av" style="background:linear-gradient(135deg,#06B6D4,#0EA5E9)">И</span><div><b>Игорь Л.</b><span>клиент</span></div></figcaption></figure>
    <figure class="review lg rev d2" style="margin:0 0 16px"><div class="stars">★★★★★</div><p>«Веду онлайн-подопечных: питание, вес и замеры под контролем без бесконечных переписок в мессенджерах. Дисциплина выросла.»</p><figcaption class="rev-by"><span class="av" style="background:linear-gradient(135deg,#F97316,#EA580C)">Д</span><div><b>Дмитрий К.</b><span>фитнес-тренер</span></div></figcaption></figure>
  </div>
  <p class="demo-note">Отзывы демонстрационные — для наполнения перед пилотом.</p>
</div></section>

<section class="block" style="padding-top:0"><div class="wrap">
  <div class="final rev">
    <div class="aura c"></div>
    <h2 class="h2">Начните питаться правильно<br>уже сегодня</h2>
    <p class="lead">Пройдите анкету за 5 минут — и получите меню под себя. Регистрация для специалистов бесплатна.</p>
    <a class="btn p" href="/app/"><span class="cap">Начать бесплатно</span><span class="knob"><svg class="i"><use href="#arr"/></svg></span></a>
  </div>
</div></section>

</main>

<footer><div class="wrap">
  <p class="slogan rev">EQUA помогает нутрициологам и тренерам быть эффективнее,<br><em>а клиентам — достигать своих целей.</em></p>
  <div class="foot">
    <a class="logo" href="/"><?php include __DIR__.'/partials/logo.php' ?></a>
    <nav><a href="#how">Как это работает</a><a href="#features">Возможности</a><a href="#aud">Для кого</a><a href="/catalog.php">Специалисты</a><a href="/for-specialists.php">Нутрициологам</a><a href="#reviews">Отзывы</a><a href="/privacy">Конфиденциальность</a><a href="/terms">Условия</a></nav>
    <span class="cp">© 2026 EQUA</span>
  </div>
</div></footer>

<script>
/* Раскрытие меню: морф гамбургера + ступенчатый вход ссылок */
(function(){
  var b=document.getElementById('burger'),sheet=document.getElementById('sheetnav');
  if(!b)return;
  function set(open){
    document.body.classList.toggle('nav-open',open);
    b.setAttribute('aria-expanded',open?'true':'false');
    document.body.style.overflow=open?'hidden':'';
  }
  b.addEventListener('click',function(){set(!document.body.classList.contains('nav-open'))});
  sheet.addEventListener('click',function(e){if(e.target.closest('a'))set(false)});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')set(false)});
})();

/* Вход при скролле — IntersectionObserver, без слушателя scroll */
(function(){
  var els=[].slice.call(document.querySelectorAll('.rev'));
  if(!('IntersectionObserver' in window)){els.forEach(function(el){el.classList.add('in')});return}
  var io=new IntersectionObserver(function(en){
    en.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})
  },{rootMargin:'0px 0px -12% 0px',threshold:.08});
  els.forEach(function(el){io.observe(el)});
})();

/* Остров слегка поджимается при отрыве от верха */
(function(){
  var isl=document.getElementById('island'),top=document.createElement('div');
  top.style.cssText='position:absolute;top:0;height:1px;width:1px';
  document.body.appendChild(top);
  new IntersectionObserver(function(en){
    isl.classList.toggle('tucked',!en[0].isIntersecting);
  },{threshold:0}).observe(top);
})();
</script>

</body>
</html>
